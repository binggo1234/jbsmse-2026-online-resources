"""Compare rerun public routes with the versioned reference, excluding timing."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output_dir', type=Path)
    args = parser.parse_args()
    reference = Path(__file__).resolve().parents[1] / 'reference_results/routes'
    jobs = sorted((args.output_dir / 'routes').glob('*.json'))
    assert jobs, 'No completed jobs found'
    for path in jobs:
        actual = json.loads(path.read_text())
        expected = json.loads((reference / path.name).read_text())
        for field in ('layout', 'tool', 'search', 'order', 'actions', 'metrics'):
            assert actual[field] == expected[field], (path.name, field)
        for field in actual['row']:
            if field not in ('generation_ms', 'replay_ms'):
                assert actual['row'][field] == expected['row'][field], (path.name, field)
    print(json.dumps({'status': 'PASS', 'public_jobs_identical_except_time': len(jobs)}))


if __name__ == '__main__':
    main()
