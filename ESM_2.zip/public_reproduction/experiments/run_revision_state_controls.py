from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, replace
from pathlib import Path
from statistics import mean
from time import perf_counter

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.geometry import rectangle_edges
from cnc_cutting.io import (
    PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    load_layout,
    tool_config_from_chapter2_config,
)
from cnc_cutting.local_search import BeamSearchConfig, process_aware_beam_search_order
from cnc_cutting.metrics import evaluate_actions, materialize_action_clearance
from cnc_cutting.models import EdgeRole, Panel, Point, ToolConfig, CuttingActionType
from cnc_cutting.optimizer import select_coverage_units
from cnc_cutting.process_model import build_process_model
from cnc_cutting.span_coverage_audit import ExecutedCenterlineCut, audit_centerline_span_coverage
from cnc_cutting.spans import layout_edges_relations_and_spans
from cnc_cutting.topology_operators import directed_units_to_actions
from cnc_cutting.travel import clear_detour_cache


ROOT = Path(__file__).resolve().parents[1]
STAGE7 = ROOT / 'results/corrected_model_stage7_kerf'
VARIANTS = ('static', 'release_only', 'full_unfiltered', 'full_state')
ALPHAS = (0.0, 1.0)
SEARCH = BeamSearchConfig(
    beam_width=6, candidate_pool_size=18, max_expansions_per_node=36,
    max_layer_expansions=42, diversity_bucket_limit=None,
    unstable_min_expansions_per_parent=0, repeat_cut_policy='hard',
)


def read_csv(path):
    with path.open(newline='', encoding='utf-8-sig') as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    if not rows:
        return
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_cases(cohort='all', limit=0):
    cases = []
    if cohort in ('all', 'development'):
        archive = STAGE7 / 'kerf_layouts/stage7_kerf_layouts.zip'
        for record in read_csv(STAGE7 / 'kerf_layouts/stage7_kerf_layout_manifest.csv'):
            config = load_chapter2_config_from_zip(
                archive, placements_member=record['placements_member'],
                config_member=record['config_member'],
            )
            tool = tool_config_from_chapter2_config(config)
            layout = load_chapter2_layouts_from_zip(
                archive, placements_member=record['placements_member'],
                config_member=record['config_member'],
                board_ids=(record['selected_board_id'],),
                placement_geometry_mode=PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
                tool_diameter=tool.tool_diameter,
            )[0]
            cases.append(('development', record['record_id'], record['inventory_sha256'], layout, tool))
    if cohort in ('all', 'public'):
        for path in sorted((ROOT / 'data/public_benchmarks/layouts_2dpacklib30_stage7_kerf').glob('*.json')):
            tool = ToolConfig(
                centerline_boundary_margin=3.0, geometric_kerf_compensation=True,
                allow_safe_lift_over_released_parts=True, allow_low_clearance_detour=True,
                start_point=Point(5.0, 5.0),
            )
            cases.append(('public', path.stem, path.stem, load_layout(path), tool))
    return cases[:limit] if limit else cases


def full_model(layout, tool, alpha):
    return build_process_model(
        layout, tool=tool,
        support_edge_roles=(EdgeRole.BOTTOM, EdgeRole.RIGHT, EdgeRole.TOP, EdgeRole.LEFT),
        min_remaining_support_count=1, min_remaining_support_length_ratio=0.75,
        min_area_normalized_support_length=0.0, adjacency_support_weight=alpha,
        max_collinear_gap=tool.min_channel_width,
    )


def generation_model(model, variant):
    if variant == 'static':
        return None
    if variant == 'release_only':
        return replace(model, support_segment_ids={}, support_span_ids={},
                       min_remaining_support_count=0, min_remaining_support_length_ratio=0.0,
                       min_area_normalized_support_length=0.0, adjacency_support_weight=0.0)
    if variant in ('full_state', 'full_unfiltered'):
        return model
    raise ValueError(variant)


def replay_order(order, layout, tool, model):
    clear_detour_cache()
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    raw_actions = directed_units_to_actions(order, start_point=tool.start_point)
    actions = materialize_action_clearance(raw_actions, panel, tool, process_model=model)
    metrics = evaluate_actions(actions, panel, tool, process_model=model)
    primitives = {edge.segment_id: edge for part in layout.rectangles for edge in rectangle_edges(part)}
    _, _, by_segment = layout_edges_relations_and_spans(layout, tool, max_collinear_gap=tool.min_channel_width)
    cuts = tuple(ExecutedCenterlineCut(i, action.start, action.end, action.cutting_unit_id or '')
                 for i, action in enumerate(actions) if action.action_type == CuttingActionType.CUT)
    audit = audit_centerline_span_coverage(
        cuts, primitives, (span for spans in by_segment.values() for span in spans),
        expected_centerline_offset=tool.tool_radius,
    )
    return actions, metrics, audit


def run_condition(case, selected, alpha, variant):
    cohort, case_id, inventory, layout, tool = case
    model = full_model(layout, tool, alpha)
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    search = replace(SEARCH, completion_candidate_filter=variant != 'full_unfiltered')
    clear_detour_cache()
    started = perf_counter()
    result = process_aware_beam_search_order(
        selected, panel, tool, process_model=generation_model(model, variant), config=search,
    )
    generation_ms = 1000 * (perf_counter() - started)
    assert Counter(candidate.unit.unit_id for candidate in result.directed_units) == Counter(unit.unit_id for unit in selected)
    assert result.expanded_nodes <= len(selected) * SEARCH.max_layer_expansions
    started = perf_counter()
    actions, metrics, audit = replay_order(result.directed_units, layout, tool, model)
    replay_ms = 1000 * (perf_counter() - started)
    counts = Counter(span.span_id for action in actions if action.action_type == CuttingActionType.CUT
                     for span in action.covered_spans)
    order = [{'unit_id': candidate.unit.unit_id, 'is_reversed': candidate.is_reversed}
             for candidate in result.directed_units]
    row = {
        'cohort': cohort, 'case_id': case_id, 'inventory': inventory,
        'alpha': alpha, 'variant': variant, 'rectangle_count': len(layout.rectangles),
        'selected_unit_count': len(selected), 'selected_unit_hash': digest([asdict(unit) for unit in selected]),
        'search_config_hash': digest(asdict(search)),
        'search_caps_hash': digest({k: v for k, v in asdict(search).items() if k != 'completion_candidate_filter'}),
        'expanded_nodes': result.expanded_nodes,
        'generation_ms': generation_ms, 'replay_ms': replay_ms,
        'order_hash': digest(order), 'c_plan': metrics.cutting_length + metrics.travel_mode_cost,
        'cutting_length': metrics.cutting_length, 'travel_cost': metrics.travel_mode_cost,
        'air_distance': metrics.air_move_distance, 'detour_count': metrics.detour_count,
        'detour_distance': metrics.detour_distance, 'safe_lift_count': metrics.safe_lift_count,
        'safe_lift_distance': metrics.safe_lift_distance,
        'tool_events': metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
        'support_penalty': metrics.stability_penalty, 'hard_penalty': metrics.hard_penalty,
        'missing_spans': len(audit.incomplete_span_ids), 'uncovered_length': audit.uncovered_length,
        'repeated_spans': sum(value - 1 for value in counts.values()),
    }
    payload = {'row': row, 'layout': asdict(layout), 'tool': asdict(tool), 'search': asdict(search),
               'order': order, 'actions': [asdict(action) for action in actions],
               'metrics': asdict(metrics)}
    return row, payload


def summaries(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[(row['cohort'], row['alpha'], row['variant'])].append(row)
    output = []
    for (cohort, alpha, variant), group in sorted(groups.items()):
        output.append({
            'cohort': cohort, 'alpha': alpha, 'variant': variant, 'n': len(group),
            'c_plan_mean': mean(row['c_plan'] for row in group),
            'travel_cost_mean': mean(row['travel_cost'] for row in group),
            'support_positive_layouts': sum(row['support_penalty'] > 1e-9 for row in group),
            'support_penalty_mean': mean(row['support_penalty'] for row in group),
            'hard_failure_layouts': sum(row['hard_penalty'] > 1e-9 for row in group),
            'missing_span_layouts': sum(row['missing_spans'] > 0 for row in group),
            'expanded_nodes_mean': mean(row['expanded_nodes'] for row in group),
            'generation_ms_mean': mean(row['generation_ms'] for row in group),
        })
    lookup = {(row['cohort'], row['case_id'], row['alpha'], row['variant']): row for row in rows}
    paired = []
    for (cohort, alpha, variant), group in sorted(groups.items()):
        if variant == 'full_state':
            continue
        differences = []
        inventories = defaultdict(list)
        travel = []
        wins = losses = ties = 0
        for baseline in group:
            full = lookup[(cohort, baseline['case_id'], alpha, 'full_state')]
            reduction = 100 * (baseline['c_plan'] - full['c_plan']) / baseline['c_plan']
            differences.append(reduction)
            inventories[baseline['inventory']].append(reduction)
            travel.append(100 * (baseline['travel_cost'] - full['travel_cost']) / baseline['travel_cost']
                          if baseline['travel_cost'] else 0.0)
            wins += reduction > 1e-9
            losses += reduction < -1e-9
            ties += abs(reduction) <= 1e-9
        paired.append({
            'cohort': cohort, 'alpha': alpha, 'baseline': variant, 'n': len(group),
            'mean_paired_cplan_reduction_pct': mean(differences),
            'inventory_equal_cplan_reduction_pct': mean(mean(values) for values in inventories.values()),
            'mean_paired_travel_reduction_pct': mean(travel),
            'wins': wins, 'ties': ties, 'losses': losses,
        })
    return output, paired


def main():
    parser = argparse.ArgumentParser(description='Fixed-cap static/release/full-state generation with common replay.')
    parser.add_argument('--cohort', choices=['all', 'development', 'public'], default='all')
    parser.add_argument('--limit', type=int, default=0)
    parser.add_argument('--output-dir', type=Path, default=ROOT.parent / 'outputs/state_controls')
    args = parser.parse_args()
    if os.environ.get('PYTHONHASHSEED') != '0':
        raise SystemExit('Set PYTHONHASHSEED=0 for deterministic tie handling.')
    cases = load_cases(args.cohort, args.limit)
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    (output / 'routes').mkdir(exist_ok=True)
    design = {
        'runner_sha256': file_hash(Path(__file__)), 'python': sys.version,
        'library_sha256': {str(p.relative_to(ROOT)): file_hash(p) for p in sorted((ROOT / 'src/cnc_cutting').glob('*.py'))},
        'platform': platform.platform(), 'python_hash_seed': '0', 'cohort': args.cohort,
        'limit': args.limit, 'alphas': ALPHAS, 'variants': VARIANTS, 'search': asdict(SEARCH),
        'cases': [{'cohort': c[0], 'case_id': c[1], 'inventory': c[2],
                   'geometry_hash': digest(asdict(c[3])), 'tool_hash': digest(asdict(c[4]))} for c in cases],
        'interpretation': 'Post-hoc mechanism analysis. Equal configured caps, not equal realized calls or elapsed time.',
    }
    design = json.loads(json.dumps(design))
    design_file = output / 'design.json'
    if design_file.exists() and json.loads(design_file.read_text()) != design:
        raise SystemExit('Output directory belongs to a different frozen design; choose a new directory.')
    design_file.write_text(json.dumps(design, indent=2) + '\n')
    rows = []
    for index, case in enumerate(cases, 1):
        units = build_candidate_cutting_units(case[3], case[4], max_collinear_gap=case[4].min_channel_width)
        selected = select_coverage_units(units, allow_bridge_cut=False, repeat_cut_policy='hard')
        for alpha in ALPHAS:
            for variant in VARIANTS:
                path = output / 'routes' / f'{case[0]}_{case[1]}_a{int(alpha)}_{variant}.json'
                if path.exists():
                    payload = json.loads(path.read_text())
                    row = payload['row']
                else:
                    row, payload = run_condition(case, selected, alpha, variant)
                    temporary = path.with_suffix('.tmp')
                    temporary.write_text(json.dumps(payload, indent=2) + '\n')
                    temporary.replace(path)
                rows.append(row)
        print(f'{index}/{len(cases)} {case[0]} {case[1]} completed', flush=True)
    write_csv(output / 'results.csv', rows)
    summary, paired = summaries(rows)
    write_csv(output / 'summary.csv', summary)
    write_csv(output / 'paired.csv', paired)
    failures = [row for row in rows if row['hard_penalty'] > 1e-9 or row['missing_spans'] or row['repeated_spans']]
    audit = {'planned_jobs': len(cases) * len(ALPHAS) * len(VARIANTS), 'completed_jobs': len(rows),
             'coverage_or_hard_failures': len(failures),
             'all_layouts_share_selected_unit_hash': all(len({r['selected_unit_hash'] for r in rows if r['cohort'] == c[0] and r['case_id'] == c[1]}) == 1 for c in cases),
             'all_conditions_share_search_caps': len({r['search_caps_hash'] for r in rows}) == 1,
             'failure_jobs': [f"{r['cohort']}/{r['case_id']}/{r['alpha']}/{r['variant']}" for r in failures]}
    (output / 'completion_audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(audit), flush=True)


if __name__ == '__main__':
    main()
