# v36 public reproduction: four state/filter conditions

This bundle contains 30 kerf-corrected 2DPackLib-derived layouts, the versioned routing source, focused tests, and all 240 public reference jobs. It contains no factory geometry, task lineage, private task identifiers, commercial simulator project or licensed machine geometry.

The runner uses the Python standard library. Reference execution used Python 3.9.6 on macOS with PYTHONHASHSEED=0. pytest is optional for tests. Runtime is host dependent; other Python versions can change deterministic tie behavior.

Run from this directory:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONPATH=src:experiments python3 experiments/run_revision_state_controls.py --cohort public --output-dir outputs/public_state_controls
python3 experiments/verify_public_results.py outputs/public_state_controls
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONPATH=src:experiments python3 -m pytest -q -p no:cacheprovider tests/test_revision_state_controls.py
```

For a small plumbing check add --limit 1 and choose a new output directory. This produces eight jobs. Completed jobs are resumable only within an identical design. Always pass --cohort public: restricted development inputs are deliberately absent. Reference timings are descriptive, not matched-time performance claims.

The selected units and configured expansion caps are shared. Conditions are static (no process model), release_only (policy tracking disabled), full_unfiltered (full state and the same nearest-unit admission rule), and full_state (full state plus completion-candidate filtering). Each order is replayed using the full evaluator at alpha=0 or 1; actual search allocations may differ. No portfolio is used.

Expected outcomes:

- 240/240 jobs: complete coverage, no repeated spans or modeled hard penalty.
- Release-only/static paired mean cost reduction: 27.8707%.
- At alpha=0 full_unfiltered violates the set policy on 12/30 layouts; filtered full_state has zero violations.
- At alpha=1 both full-state variants comply, but filtering increases paired mean cost by 2.0520%.
- Filtered full-state/static paired mean reductions remain 12.2673% at alpha=1 and 8.7049% at alpha=0; these combine multiple mechanisms.

verify_public_results.py compares layout, tool, search, order, actions, metrics and every result-row field except generation/replay time with the versioned reference. It checks reproducibility, not independent evaluator correctness. The route runner also checks geometric span coverage without optimizer completion flags. Zero policy penalty is compliance with a geometric set-continuation rule, not calibrated physical holding stability. This package does not measure machine cycle time or part quality.

Geometry derives from 2DPackLib (Iori et al., 2022), DOI: https://doi.org/10.1007/s11590-021-01808-y . Filenames retain the benchmark family. These are derived kerf-spaced layouts. SHA256SUMS.json identifies every supplied file except the manifest itself. The main manuscript and separate frozen evidence archives delimit the industrial/NC claims.
