from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

from .models import CuttingUnit, EdgeOrientation, EdgeSegment, Point, SegmentSpan


@dataclass(frozen=True)
class ExecutedCenterlineCut:
    """One executed axis-aligned cutter-center motion."""

    action_index: int
    start: Point
    end: Point
    cutting_unit_id: str = ""


@dataclass(frozen=True)
class LegacyCompletionSnapshot:
    """First prefix accepted by parent-edge completion semantics."""

    stop_cut_count: int
    processed_segment_ids: frozenset[str]
    processed_span_ids: frozenset[str]


@dataclass(frozen=True)
class SpanCoverageFinding:
    span_id: str
    segment_id: str
    part_id: str
    start_axis: float
    end_axis: float
    span_length: float
    covered_length: float
    uncovered_length: float
    status: str
    merged_intervals: tuple[tuple[float, float], ...]


@dataclass(frozen=True)
class IndependentSpanCoverageAudit:
    findings: tuple[SpanCoverageFinding, ...]

    @property
    def incomplete_findings(self) -> tuple[SpanCoverageFinding, ...]:
        return tuple(finding for finding in self.findings if finding.status != "full")

    @property
    def incomplete_span_ids(self) -> frozenset[str]:
        return frozenset(finding.span_id for finding in self.incomplete_findings)

    @property
    def incomplete_segment_ids(self) -> frozenset[str]:
        return frozenset(finding.segment_id for finding in self.incomplete_findings)

    @property
    def incomplete_part_ids(self) -> frozenset[str]:
        return frozenset(finding.part_id for finding in self.incomplete_findings)

    @property
    def uncovered_length(self) -> float:
        return sum(finding.uncovered_length for finding in self.findings)


def legacy_whole_edge_completion_snapshot(
    executed_units: Sequence[CuttingUnit],
    required_segment_ids: Iterable[str],
) -> LegacyCompletionSnapshot | None:
    """Return the first prefix that completes all parent segment identifiers."""

    required = frozenset(required_segment_ids)
    processed_segments: set[str] = set()
    processed_spans: set[str] = set()
    for cut_count, unit in enumerate(executed_units, start=1):
        processed_segments.update(unit.covered_segment_ids)
        processed_spans.update(span.span_id for span in unit.covered_spans)
        if required <= processed_segments:
            return LegacyCompletionSnapshot(
                stop_cut_count=cut_count,
                processed_segment_ids=frozenset(processed_segments),
                processed_span_ids=frozenset(processed_spans),
            )
    return None


def audit_centerline_span_coverage(
    cuts: Sequence[ExecutedCenterlineCut],
    primitive_segments: Mapping[str, EdgeSegment],
    spans: Iterable[SegmentSpan],
    expected_centerline_offset: float,
    tolerance: float = 1e-6,
) -> IndependentSpanCoverageAudit:
    """Audit span coverage from cutter-center geometry, without unit credit fields."""

    intervals_by_span: dict[str, list[tuple[float, float]]] = defaultdict(list)
    span_list = tuple(spans)
    spans_by_orientation: dict[EdgeOrientation, list[SegmentSpan]] = defaultdict(list)
    for span in span_list:
        spans_by_orientation[span.orientation].append(span)

    for cut in cuts:
        orientation = _cut_orientation(cut, tolerance)
        if orientation is None:
            continue
        cut_lo, cut_hi = _cut_axis_interval(cut, orientation)
        cut_fixed = _cut_fixed_coordinate(cut, orientation)
        for span in spans_by_orientation[orientation]:
            segment = primitive_segments[span.segment_id]
            offset = abs(_segment_fixed_coordinate(segment) - cut_fixed)
            if abs(offset - expected_centerline_offset) > tolerance:
                continue
            left = max(cut_lo, span.start_axis)
            right = min(cut_hi, span.end_axis)
            if right > left + tolerance:
                intervals_by_span[span.span_id].append((left, right))

    findings: list[SpanCoverageFinding] = []
    for span in sorted(span_list, key=lambda item: item.span_id):
        merged = _merge_intervals(intervals_by_span[span.span_id], tolerance)
        covered = min(span.length, sum(right - left for left, right in merged))
        uncovered = max(0.0, span.length - covered)
        if uncovered <= tolerance:
            status = "full"
        elif covered <= tolerance:
            status = "missing"
        else:
            status = "partial"
        findings.append(
            SpanCoverageFinding(
                span_id=span.span_id,
                segment_id=span.segment_id,
                part_id=span.part_id,
                start_axis=span.start_axis,
                end_axis=span.end_axis,
                span_length=span.length,
                covered_length=covered,
                uncovered_length=uncovered,
                status=status,
                merged_intervals=merged,
            )
        )
    return IndependentSpanCoverageAudit(findings=tuple(findings))


def cuts_from_units(units: Sequence[CuttingUnit]) -> tuple[ExecutedCenterlineCut, ...]:
    return tuple(
        ExecutedCenterlineCut(
            action_index=index,
            start=unit.start,
            end=unit.end,
            cutting_unit_id=unit.unit_id,
        )
        for index, unit in enumerate(units)
    )


def _cut_orientation(
    cut: ExecutedCenterlineCut,
    tolerance: float,
) -> EdgeOrientation | None:
    if abs(cut.start.y - cut.end.y) <= tolerance:
        if abs(cut.start.x - cut.end.x) > tolerance:
            return EdgeOrientation.HORIZONTAL
        return None
    if abs(cut.start.x - cut.end.x) <= tolerance:
        return EdgeOrientation.VERTICAL
    return None


def _cut_axis_interval(
    cut: ExecutedCenterlineCut,
    orientation: EdgeOrientation,
) -> tuple[float, float]:
    if orientation == EdgeOrientation.HORIZONTAL:
        return (min(cut.start.x, cut.end.x), max(cut.start.x, cut.end.x))
    return (min(cut.start.y, cut.end.y), max(cut.start.y, cut.end.y))


def _cut_fixed_coordinate(
    cut: ExecutedCenterlineCut,
    orientation: EdgeOrientation,
) -> float:
    if orientation == EdgeOrientation.HORIZONTAL:
        return cut.start.y
    return cut.start.x


def _segment_fixed_coordinate(segment: EdgeSegment) -> float:
    if segment.orientation == EdgeOrientation.HORIZONTAL:
        return segment.start.y
    return segment.start.x


def _merge_intervals(
    intervals: Sequence[tuple[float, float]],
    tolerance: float,
) -> tuple[tuple[float, float], ...]:
    merged: list[list[float]] = []
    for left, right in sorted(intervals):
        if right <= left + tolerance:
            continue
        if not merged or left > merged[-1][1] + tolerance:
            merged.append([left, right])
        else:
            merged[-1][1] = max(merged[-1][1], right)
    return tuple((left, right) for left, right in merged)
