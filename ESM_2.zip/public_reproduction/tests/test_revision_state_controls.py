from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.models import Layout, PlacedRectangle, Point, ToolConfig
from cnc_cutting.optimizer import select_coverage_units
from run_revision_state_controls import full_model, generation_model, replay_order, run_condition


def sample_case():
    layout = Layout('test', 100, 100, (
        PlacedRectangle('A', 10, 10, 20, 40),
        PlacedRectangle('B', 36, 20, 20, 10),
    ))
    tool = ToolConfig(geometric_kerf_compensation=True, centerline_boundary_margin=3.0,
                      allow_safe_lift_over_released_parts=True,
                      allow_low_clearance_detour=True, start_point=Point(5, 5))
    units = build_candidate_cutting_units(layout, tool, max_collinear_gap=6)
    selected = select_coverage_units(units, repeat_cut_policy='hard')
    return ('public', 'test', 'test', layout, tool), selected


def test_release_only_preserves_release_mapping_but_disables_policy():
    case, _ = sample_case()
    full = full_model(case[3], case[4], 1)
    release = generation_model(full, 'release_only')
    assert release.part_span_ids == full.part_span_ids
    assert release.part_collision_polygons == full.part_collision_polygons
    assert not release.support_span_ids
    assert release.min_remaining_support_count == 0
    assert generation_model(full, 'static') is None


def test_all_conditions_share_units_and_replay_complete_geometry():
    case, selected = sample_case()
    rows = [run_condition(case, selected, alpha, variant)[0]
            for alpha in (0, 1) for variant in ('static', 'release_only', 'full_state')]
    assert len({row['selected_unit_hash'] for row in rows}) == 1
    assert len({row['search_config_hash'] for row in rows}) == 1
    assert all(row['missing_spans'] == row['hard_penalty'] == row['repeated_spans'] == 0 for row in rows)


def test_independent_audit_detects_missing_cut_after_metadata_is_removed():
    from cnc_cutting.local_search import process_aware_beam_search_order
    from cnc_cutting.models import Panel
    case, selected = sample_case()
    layout, tool = case[3:]
    result = process_aware_beam_search_order(selected, Panel('test', 100, 100), tool)
    _, _, audit = replay_order(result.directed_units[:-1], layout, tool, full_model(layout, tool, 1))
    assert audit.incomplete_span_ids


def test_unfiltered_state_control_changes_filter_only_and_replays_full_policy():
    from dataclasses import asdict
    case, selected = sample_case()
    full_row, full_payload = run_condition(case, selected, 1, 'full_state')
    row, payload = run_condition(case, selected, 1, 'full_unfiltered')
    assert full_payload['search']['completion_candidate_filter'] is True
    assert payload['search']['completion_candidate_filter'] is False
    assert {k: v for k, v in payload['search'].items() if k != 'completion_candidate_filter'} == {
        k: v for k, v in full_payload['search'].items() if k != 'completion_candidate_filter'}
    assert row['search_caps_hash'] == full_row['search_caps_hash']
    assert row['selected_unit_hash'] == full_row['selected_unit_hash']
    assert row['missing_spans'] == row['repeated_spans'] == row['hard_penalty'] == 0
    assert asdict(generation_model(full_model(case[3], case[4], 1), 'full_unfiltered')) == asdict(full_model(case[3], case[4], 1))


def test_filter_switch_changes_admission_of_far_pending_part():
    from dataclasses import replace
    from cnc_cutting.local_search import (
        BeamSearchConfig, BeamSearchNode, _limited_beam_expansions,
        directed_unit_candidates, unit_process_part_ids,
    )
    from cnc_cutting.models import IncrementalMetricsState
    case, selected = sample_case()
    model = full_model(case[3], case[4], 1)
    b_only = next(u for u in selected if unit_process_part_ids(u, model) == frozenset({'B'}))
    node = BeamSearchNode(directed_units=(), remaining_units=selected,
                         state=IncrementalMetricsState(current_point=b_only.start, unstable_part_ids={'A'}))
    cache = {u.unit_id: directed_unit_candidates(u) for u in selected}
    config = BeamSearchConfig(candidate_pool_size=1, max_expansions_per_node=2)
    filtered = _limited_beam_expansions((node,), cache, model, config)[0]
    unfiltered = _limited_beam_expansions((node,), cache, model, replace(config, completion_candidate_filter=False))[0]
    assert filtered and all('A' in unit_process_part_ids(e.candidate.unit, model) for e in filtered)
    assert unfiltered and all('A' not in unit_process_part_ids(e.candidate.unit, model) for e in unfiltered)

