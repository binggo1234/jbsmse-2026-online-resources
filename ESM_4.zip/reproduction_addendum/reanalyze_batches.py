"""Post-review source-batch reanalysis of unchanged frozen aggregate tables.

The batch assignment is from raw-source identity and folder provenance, not
route quality. Exclude any source batch containing a prior upstream task.
Within each included batch average task paired reductions, then weight batches
equally. Bootstrap resamples batch pairs. Original 20-task estimates remain
descriptive companions, not independent-task confirmatory inference.
"""
import argparse
import csv
import json
import math
import random
import statistics as st
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
FROZEN = HERE.parent / 'frozen_industrial_evidence/frozen_aggregate_results'
PROPOSED = 'process_aware_beam_adaptive_polished'


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as h:
        return list(csv.DictReader(h))


def percentile(a, p):
    a = sorted(a)
    index = (len(a)-1)*p
    lo, hi = math.floor(index), math.ceil(index)
    return a[lo] + (a[hi]-a[lo])*(index-lo)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    assignment = {r['task_id']:r for r in read(HERE / 'task_batch_assignments.csv')}
    assert len(assignment) == 20
    clean = sorted(t for t,r in assignment.items() if r['batch_isolated_analysis_include']=='true')
    batches = sorted({assignment[t]['source_batch'] for t in clean})
    assert len(clean)==19 and len(batches)==7
    grouped = {b:sorted(t for t in clean if assignment[t]['source_batch']==b) for b in batches}
    rng = random.Random(20261109)
    indices = [[rng.randrange(len(batches)) for _ in batches] for _ in range(100000)]

    def stats(task_values):
        values = [st.mean(task_values[t] for t in grouped[b]) for b in batches]
        boot = [sum(values[i] for i in index)/len(batches) for index in indices]
        wins = sum(v>1e-9 for v in values);losses = sum(v < -1e-9 for v in values)
        n=wins+losses
        p = min(1., 2*sum(math.comb(n,k) for k in range(min(wins,losses)+1))/(2**n)) if n else 1.
        return {'batch_equal_mean_pct':st.mean(values),'batch_median_pct':st.median(values),
                'batch_bootstrap_ci95':[percentile(boot,.025),percentile(boot,.975)],
                'batch_wtl':[wins,len(batches)-n,losses],'batch_sign_p_raw':p,
                'batch_means_pct':dict(zip(batches,values)),
                'all20_task_equal_mean_pct':st.mean(task_values.values()),
                'clean19_task_equal_mean_pct':st.mean(task_values[t] for t in clean)}

    task = read(FROZEN/'holdout_confirmatory_analysis_v1/task_metrics.csv')
    lookup={(r['task_id'],r['method']):r for r in task}
    assert set(assignment)=={r['task_id'] for r in task}
    methods=sorted({r['method'] for r in task})
    summaries={m:{key:st.mean(st.mean(float(lookup[t,m][key]) for t in grouped[b]) for b in batches)
                  for key in ('c_plan','travel_mode_cost','cutting_length','runtime_ms','tool_event_count')}
               for m in methods}
    plan={}
    for base in (m for m in methods if m!=PROPOSED):
        plan[base]=stats({t:100*(1-float(lookup[t,PROPOSED]['c_plan'])/float(lookup[t,base]['c_plan'])) for t in assignment})
    primary=['topology_process_aware','endpoint_aware_gtsp']
    order=sorted(primary,key=lambda k:plan[k]['batch_sign_p_raw'])
    adjusted=0.
    for i,k in enumerate(order):
        adjusted=max(adjusted,(len(order)-i)*plan[k]['batch_sign_p_raw'])
        plan[k]['batch_sign_p_holm_primary_two']=min(1.,adjusted)
    nc=read(FROZEN/'nc_kinematic/task_scenario_metrics.csv')
    nc_lookup={(r['task_id'],r['method'],r['scenario']):r for r in nc}
    scenarios=sorted({r['scenario'] for r in nc})
    nominal='r200_axy1000_z40_az500'
    nc_stats={}
    for base in ('topology_process_aware','process_aware_beam','endpoint_aware_gtsp'):
        nc_stats[base]={metric:stats({t:100*(1-float(nc_lookup[t,PROPOSED,nominal][f'continuous_{metric}_time_s'])/float(nc_lookup[t,base,nominal][f'continuous_{metric}_time_s'])) for t in assignment}) for metric in ('noncut','total')}
    hours={m:{metric:st.mean(st.mean(float(nc_lookup[t,m,nominal][f'continuous_{metric}_time_s']) for t in grouped[b]) for b in batches)/3600 for metric in ('noncut','total')} for m in methods}
    stop_hours={m:{metric:st.mean(st.mean(float(nc_lookup[t,m,nominal][f'stop_{metric}_time_s']) for t in grouped[b]) for b in batches)/3600 for metric in ('noncut','total')} for m in methods}
    robustness=[]
    for base in (m for m in methods if m!=PROPOSED):
        for mode in ('continuous','stop'):
            for metric in ('noncut','total'):
                means=[];all_tasks=0
                for scenario in scenarios:
                    field=f'{mode}_{metric}_time_s'
                    values={t:100*(1-float(nc_lookup[t,PROPOSED,scenario][field])/float(nc_lookup[t,base,scenario][field])) for t in clean}
                    means.append(st.mean(st.mean(values[t] for t in grouped[b]) for b in batches))
                    all_tasks+=min(values.values())>0
                robustness.append({'baseline':base,'mode':mode,'metric':metric,'min':min(means),'median':st.median(means),'max':max(means),'positive_mean_scenarios':sum(v>0 for v in means),'all19_positive_scenarios':all_tasks})
    envelope={}
    for base in ('topology_process_aware','endpoint_aware_gtsp'):
        envelope[base]={}
        for metric in ('noncut','total'):
            reductions=[]
            for scenario in scenarios:
                for mode in ('continuous','stop'):
                    field=f'{mode}_{metric}_time_s'
                    vals={t:100*(1-float(nc_lookup[t,PROPOSED,scenario][field])/float(nc_lookup[t,base,scenario][field])) for t in clean}
                    if base == 'topology_process_aware' or metric == 'total':
                        assert min(vals.values())>0
                    reductions.append(st.mean(st.mean(vals[t] for t in grouped[b]) for b in batches))
            envelope[base][metric]=[min(reductions),max(reductions)]
    seed=read(FROZEN/'holdout_confirmatory_analysis_v1/task_seed_metrics.csv')
    clean_boards=sum(int(r['board_count']) for r in seed if r['method']==PROPOSED and r['task_id'] in clean)
    xml=read(FROZEN/'factory_xml_analysis_v1/task_metrics.csv')
    xml_ids=sorted(t for t in clean if any(r['task_id']==t for r in xml))
    xml_batches=sorted({assignment[t]['source_batch'] for t in xml_ids})
    xml_lookup={(r['task_id'],r['method']):r for r in xml}
    xml_stats={base:st.mean(st.mean(100*(1-float(xml_lookup[t,PROPOSED]['c_plan'])/float(xml_lookup[t,base]['c_plan'])) for t in xml_ids if assignment[t]['source_batch']==b) for b in xml_batches) for base in primary}
    result={'status':'PASS','analysis_role':'post-review source-batch correction; not retroactively prespecified',
            'original_task_count':20,'original_source_batch_count':8,
            'excluded_prior_overlap_task_count':1,'included_tasks':19,'included_batches':7,
            'clean_board_count':clean_boards,'clean_method_board_jobs':5*clean_boards,
            'batch_task_counts':{b:len(grouped[b]) for b in batches},
            'bootstrap':{'replicates':100000,'seed':20261109,'unit':'source batch','interval':'percentile, linear interpolation'},
            'planning':plan,'batch_equal_task_cost_means':summaries,
            'nominal_nc':nc_stats,'batch_equal_hours_per_task':hours,'batch_equal_stop_hours_per_task':stop_hours,'nc_ranges':envelope,'nc_robustness_rows':robustness,
            'xml_batch_isolated_descriptive':{'tasks':len(xml_ids),'batches':len(xml_batches),'batch_ids':xml_batches,'mean_reduction_pct':xml_stats,'confidence_intervals_and_p_values':'not reported with only two source batches'},
            'scope':'Existing route metrics unchanged. Batch pairs are resampling units; a single manufacturing source and unknown higher-order relationships limit external inference.'}
    (args.output/'BATCH_REANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','planning_topology':plan['topology_process_aware'],'nc_topology':nc_stats['topology_process_aware'],'xml':result['xml_batch_isolated_descriptive'],'clean_boards':clean_boards},indent=2))


if __name__=='__main__':main()
