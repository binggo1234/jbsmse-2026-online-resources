"""Verify the shipped configuration JSON against the unchanged frozen modules."""
import json
import sys
from dataclasses import asdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
CODE = HERE.parent / 'frozen_industrial_evidence/routing_code_and_public_data'
sys.path[:0] = [str(CODE / 'src'), str(CODE / 'experiments')]
from run_chapter2_batch import compact_beam_search_config, compact_local_search_config, topology_pool_size
from cnc_cutting.optimizer import wider_beam_search_config, ToolEventGateConfig
from cnc_cutting.gtsp_baseline import EndpointAwareGTSPConfig
from cnc_cutting.topology_operators import TopologyWeights

expected = json.loads((HERE / 'frozen_comparator_configurations.json').read_text())
for key in expected['beam']:
    n = int(key)
    base = compact_beam_search_config(n, 'hard')
    assert expected['beam'][key] == {'base': asdict(base), 'fallback': asdict(wider_beam_search_config(base))}
    assert expected['local_search'][key] == asdict(compact_local_search_config(n, True, 'hard'))
    assert expected['topology_pool'][key] == topology_pool_size(n)
assert expected['event_gate'] == asdict(ToolEventGateConfig())
assert expected['gtsp'] == asdict(EndpointAwareGTSPConfig())
assert expected['topology_weights'] == asdict(TopologyWeights())
print(json.dumps({'status':'PASS','boundary_sizes_verified':len(expected['beam']), 'module_basis':expected['frozen_stage7_commit']}))
