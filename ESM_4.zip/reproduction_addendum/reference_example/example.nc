(Canonical controller-neutral NC for transparent kinematic evaluation)
(Stock XY: 40.000 x 40.000 mm)
(Geometrically compensated cutter centerlines; controller compensation off)
G21
G90
G17
G40
G0 Z5.000
T1 M6
M3 S18000
(NCX {"action":-1,"mode":"setup","role":"setup_xy"})
G0 X0.000 Y0.000
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X0.000 Y16.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X0.000 Y0.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X0.000 Y16.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X4.000 Y16.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X0.000 Y16.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X4.000 Y16.000 F3600.0
(NCX {"action":2,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":2,"mode":"low_clearance","role":"travel_xy"})
G0 X16.000 Y16.000
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X20.000 Y16.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X16.000 Y16.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X20.000 Y16.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X20.000 Y32.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X20.000 Y16.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X20.000 Y32.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X4.000 Y32.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X20.000 Y32.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X4.000 Y32.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X4.000 Y16.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X4.000 Y32.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X4.000 Y16.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X16.000 Y16.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X4.000 Y16.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X16.000 Y16.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X16.000 Y0.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X16.000 Y16.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X16.000 Y0.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X0.000 Y0.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X16.000 Y0.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X0.000 Y0.000 F3600.0
(NCX {"action":-1,"mode":"return","role":"footer_z"})
G0 Z5.000
(NCX {"action":-1,"mode":"return","role":"return_xy"})
G0 X0.000 Y0.000
M5
M30
