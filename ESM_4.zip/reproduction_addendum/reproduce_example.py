"""Rebuild the manuscript's partial-common-cut example through selection and NC.

Extract the public bundle beside this directory and the frozen industrial ZIP
into ../frozen_industrial_evidence. Only supplied public/artificial geometry is
used. Routing and NC library files are read without modification.
"""
import argparse
import csv
import hashlib
import json
import sys
from dataclasses import asdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / 'public_reproduction/src'))
sys.path.insert(0, str(WORK / 'public_reproduction/experiments'))
sys.path.insert(0, str(WORK / 'frozen_industrial_evidence/holdout_pipeline/scripts'))

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.diagnostics import diagnose_actions
from cnc_cutting.geometry import rectangle_edges
from cnc_cutting.models import Layout, Panel, PlacedRectangle, Point, ToolConfig, CuttingActionType
from cnc_cutting.optimizer import select_coverage_units
from cnc_cutting.span_coverage_audit import ExecutedCenterlineCut, audit_centerline_span_coverage
from cnc_cutting.spans import layout_edges_relations_and_spans
from run_revision_state_controls import run_condition
from nc_kinematic_core import NcTemplate, actions_from_diagnostics, generate_canonical_gcode, parse_gcode, audit_route_nc, estimate_kinematics, default_scenarios


def write_csv(path, rows):
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    layout = Layout('partial_common_cut_example', 40.0, 40.0, (
        PlacedRectangle('A', 3.0, 3.0, 10.0, 10.0),
        PlacedRectangle('B', 7.0, 19.0, 10.0, 10.0),
    ))
    tool = ToolConfig(trim_margin=0.0, tool_diameter=6.0,
                      centerline_boundary_margin=0.0, start_point=Point(0.0, 0.0),
                      geometric_kerf_compensation=True,
                      allow_low_clearance_detour=True,
                      allow_safe_lift_over_released_parts=True)
    units = build_candidate_cutting_units(layout, tool, max_collinear_gap=tool.min_channel_width)
    selected = select_coverage_units(units, allow_bridge_cut=False, repeat_cut_policy='hard')
    # Independent, literal implementation of the documented hard-policy selector.
    priority = {'shared_edge': 0, 'near_shared_channel': 1, 'collinear_chain': 2, 'single_edge': 3}
    remaining = [u for u in units if not u.requires_bridge_cut]
    covered, oracle, steps = set(), [], []
    while True:
        choices = [u for u in remaining if {s.span_id for s in u.covered_spans} - covered]
        if not choices:
            break
        def key(u):
            ids = {s.span_id for s in u.covered_spans}
            repeated = ids & covered
            return (len(repeated), sum(s.length for s in u.covered_spans if s.span_id in repeated),
                    -len(ids - covered), priority[u.unit_type.value],
                    ((u.end.x-u.start.x)**2+(u.end.y-u.start.y)**2)**.5, u.unit_id)
        chosen = min(choices, key=key)
        steps.append({'step': len(steps)+1, 'unit_id': chosen.unit_id, 'priority_key': key(chosen)})
        oracle.append(chosen.unit_id)
        covered.update(s.span_id for s in chosen.covered_spans)
        remaining.remove(chosen)
    assert oracle == [u.unit_id for u in selected]
    _, _, by_segment = layout_edges_relations_and_spans(layout, tool, max_collinear_gap=tool.min_channel_width)
    required = {s.span_id for group in by_segment.values() for s in group}
    assert covered == required
    counts = {sid: sum(sid in {s.span_id for s in u.covered_spans} for u in selected) for sid in required}
    assert all(n == 1 for n in counts.values())
    selection_index = {u.unit_id: i+1 for i, u in enumerate(selected)}
    write_csv(out / 'candidate_and_selected_units.csv', [{
        'unit_id': u.unit_id, 'type': u.unit_type.value,
        'selection_index': selection_index.get(u.unit_id, ''),
        'start_x': u.start.x, 'start_y': u.start.y, 'end_x': u.end.x, 'end_y': u.end.y,
        'covered_span_ids': ';'.join(s.span_id for s in u.covered_spans),
    } for u in units])
    write_csv(out / 'span_coverage.csv', [dict(span_id=sid, selected_cover_count=counts[sid],
        selected_units=';'.join(u.unit_id for u in selected if sid in {s.span_id for s in u.covered_spans})) for sid in sorted(required)])
    row, route = run_condition(('example', layout.panel_id, 'artificial_two_part_geometry', layout, tool), selected, 1.0, 'full_state')
    # Reconstruct the exported actions from the serialized route by regenerating
    # the selected-unit route; run_condition's payload retains dataclass fields.
    from run_revision_state_controls import full_model, replay_order
    from cnc_cutting.topology_operators import directed_unit_candidates
    by_id = {u.unit_id: u for u in selected}
    order = [next(d for d in directed_unit_candidates(by_id[x['unit_id']]) if d.is_reversed == x['is_reversed']) for x in route['order']]
    actions, metrics, geometry_audit = replay_order(order, layout, tool, full_model(layout, tool, 1.0))
    assert not geometry_audit.incomplete_span_ids
    diagnostics = diagnose_actions(actions, Panel(layout.panel_id, 40.0, 40.0), tool, process_model=full_model(layout, tool, 1.0))
    source_actions = actions_from_diagnostics(asdict(x) for x in diagnostics)
    template = NcTemplate()
    gcode = generate_canonical_gcode(source_actions, panel_width_mm=40.0, panel_height_mm=40.0,
                                    start_x_mm=0.0, start_y_mm=0.0, template=template)
    parsed = parse_gcode(gcode)
    nc = audit_route_nc(source_actions, parsed, panel_width_mm=40.0, panel_height_mm=40.0, template=template)
    assert nc.passed
    scenario = next(s for s in default_scenarios() if s.scenario == 'r200_axy1000_z40_az500')
    timing = estimate_kinematics(parsed, scenario)
    stable_row = {k: v for k, v in row.items() if k not in ('generation_ms', 'replay_ms')}
    payload = {'scope': 'Artificial illustration of selection/replay/NC, not a new industrial effect estimate',
               'layout': asdict(layout), 'tool': asdict(tool), 'selection_steps': steps,
               'candidate_count': len(units), 'selected_count': len(selected), 'required_spans': len(required),
               'selector_matches_independent_rule': True, 'row_without_host_timings': stable_row,
               'nc_template': asdict(template), 'nc_audit': asdict(nc), 'nominal_kinematics': asdict(timing)}
    (out / 'example.nc').write_text(gcode)
    (out / 'route.json').write_text(json.dumps(route, indent=2)+'\n')
    (out / 'EXAMPLE_AUDIT.json').write_text(json.dumps(payload, indent=2)+'\n')
    stable_files = ['candidate_and_selected_units.csv', 'span_coverage.csv', 'example.nc', 'EXAMPLE_AUDIT.json']
    (out / 'SHA256SUMS.json').write_text(json.dumps({n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in stable_files},indent=2)+'\n')
    print(json.dumps({'status':'PASS','selected_units':len(selected),'spans':len(required),'nc_audit_passed':nc.passed}))


if __name__ == '__main__':
    main()
