# v38 reproducibility addendum

This adds the deterministic unit-selection rule, a complete artificial example,
frozen comparator configurations and the deidentified cohort-selection ledger.
It changes no routing-library file and no frozen industrial result.

## Exact accompanying artifacts

- `Public_Reproduction.zip` is the unchanged v36 public-control
  implementation, data and 240 serialized references.
- `Industrial_Evidence.zip` is the byte-identical historical
  `IJAMT_Reproducibility_Snapshot.zip`, renamed for its present role. Industrial
  algorithm basis is `083d869ee132a8d6c8f4d12deacb4c78bcbdb2a0`. Its `README.md`
  describes the intentionally excluded proprietary inputs.
- `Reproducibility_Addendum.zip` supplies this directory.

The sidecar `ARTIFACT_INDEX.json` supplied alongside these ZIPs records their
full SHA-256 values. This addendum's `SHA256SUMS.json` checks its distributed
members. The historical archive preserves its original provenance manifests.
Hashes recorded inside those historical manifests can identify original
controlled files before identifier/path redaction; they must not be assumed to
hash the shipped pseudonymized CSV byte streams. The external ZIP identity and
this addendum's `FROZEN_DISTRIBUTED_MEMBERS_SHA256.json` identify actual shipped
bytes separately. No source-identity mapping or raw factory geometry is added.

## Clean-directory run

Use a new empty work directory, with the three ZIPs in its parent directory.
Extract as follows. No Git clone or private factory file is required.

```sh
unzip ../Public_Reproduction.zip
unzip ../Industrial_Evidence.zip -d frozen_industrial_evidence
unzip ../Reproducibility_Addendum.zip
PYTHONDONTWRITEBYTECODE=1 python3 reproduction_addendum/verify_configurations.py
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python3 reproduction_addendum/reproduce_example.py --output outputs/example
```

The scripts use the standard library and the two extracted source trees.
Reference execution uses Python 3.9.6 with `PYTHONHASHSEED=0`. The miniature
example uses the same fixed-cap filtered generator as the state-control runner,
with its own explicitly serialized artificial geometry and tool settings.
Its independently implemented selection rule must match the library. Expected
counts are 11 candidate units, 9 selected units and 10 required spans, each
covered once. The NC audit must pass with no errors. Compare the four stable
outputs to `reference_example/SHA256SUMS.json`; wall-clock fields in the optional
`route.json` are excluded. `EXAMPLE_AUDIT.json` gives selection keys, layout,
tool, reference metrics, NC settings, audit and nominal kinematic result.

For the full public controls, run from `public_reproduction/`:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONPATH=src:experiments python3 experiments/run_revision_state_controls.py --cohort public --output-dir ../outputs/public_controls
python3 experiments/verify_public_results.py ../outputs/public_controls
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONPATH=src:experiments python3 -m pytest -q -p no:cacheprovider tests/test_revision_state_controls.py
```

Expected verification is 240 identical jobs except generation/replay time.
The focused test suite has five tests. The original public README supplies
the fixed-cap protocol, expected effects and geometric-policy boundary.

## Version and terminology mapping

`Proposed portfolio`, `Adaptive`, `Adaptive Beam+LS` and `Adaptive portfolio`
are article/historical display labels for the portfolio method key
`process_aware_beam_adaptive_polished`, with the configuration specific to each
reported experimental track. Other industrial keys are
`topology_process_aware`, `process_aware_beam`,
`process_local_search_multistart` and `endpoint_aware_gtsp`.
The new four-condition controls do not invoke the portfolio. Their `full_state`
key means `Full filtered`, not `Proposed portfolio`. Thus matching labels
do not silently merge different experiments or implementations.

Industrial constructor entry is
`frozen_industrial_evidence/routing_code_and_public_data/experiments/run_chapter2_batch.py::build_planners`.
`frozen_comparator_configurations.json` enumerates base/fallback beam,
local-search, topology and GTSP settings at the piecewise boundary sizes.
S11 explains selection, candidate membership, triggers, stopping and motion
parameters. The controls use `public_reproduction/experiments/run_revision_state_controls.py`.

The industrial analysis entry is
`frozen_industrial_evidence/documentation/holdout_reproducibility.md`.
The only authorized private Track A route file is
`route_results_cache_isolated.csv`, SHA-256
`2df56a2d5700c1356bb78745e57d3eb69d87d6507222f48730b4a3b3e375aff2`.
The quarantined v1 file is not an input. Public execution verifies an interface
and reproducible software outputs; it does not recreate private industrial
optimizers from missing factory inputs or validate physical machining.

## Cohort ledger

`cohort_lineage_deidentified.csv` is derived from the original controlled
27-task lineage file. Its original file identity, counts, exclusions and
confidence limits are recorded in `COHORT_PROVENANCE.json`. L01-L27 sort the
source-file hashes and are selection-ledger aliases only. Existing frozen
`FACTORY_TASK_*` result keys are unchanged. Original mapping stays controlled.

The archived pool has 27 source tasks and 39,267 records. Six historical tasks
were previously used upstream, one single-record task was excluded in advance,
and the original split retained 20 other tasks (27,912 source records). Four of the six
historical tasks generated the development cohort; seven holdout tasks and
four historical tasks have XML coordinates. Byte identities are distinct;
this is not a proof of different customer orders or independent batches.

The supervisor obtained the source archive from the factory. Source folders
define batches, as stated in the original README and verified by matching all
27 raw CSV hashes. The original 20-task set spans eight batches, including one
task in a batch shared with prior development. Current inference excludes
that task and uses 19 tasks in seven isolated source batches. The XML subset
then has six tasks in two batches and is descriptive. No calendar year or
higher-order independence across batches is inferred from filenames.

This addendum is a provenance and reporting artifact. No new industrial
effect estimate, real machining measurement or publisher approval is claimed.

## Post-review batch correction

The original frozen route and NC values are unchanged. Source-batch membership
requires changing their aggregation and uncertainty unit. This is explicitly
post hoc, not a retrospectively prespecified experiment. Run from the work root:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 reproduction_addendum/reanalyze_batches.py --output outputs/batch_reanalysis
```

The standard-library runner reads distributed frozen task/NC tables and
`task_batch_assignments.csv`, averages paired task percentages within source
batch and weights seven isolated batches equally. It uses 100000 batch
bootstrap resamples with seed 20261109 and an exact two-sided sign test. Holm
adjustment covers the two planning comparisons. Expected topology planning
mean is 10.2279256094%, adjusted p is 0.03125; nominal non-cutting/total-time
means are 12.2939925895%/1.3517632161%. The two-batch XML check has no p-value
or inferential interval. The 20-task and isolated 19-task descriptive means
remain in `BATCH_REANALYSIS.json`. These source-based exclusions use no quality
threshold, and no new task or route is substituted.
