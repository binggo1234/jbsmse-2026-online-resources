# Source-batch evidence and the corrected comparison

The original factory archive README states that one top-level folder represents
one data batch. Its byte identity is recorded in `COHORT_PROVENANCE.json`.
Every one of the 27 source CSV hashes matches the original controlled lineage
manifest. This supplies a grouping basis independent of routing performance.

The original split excludes six historical tasks and one single-record task,
retaining 20 nominal holdout tasks from eight source batches. One nominal
holdout task is in a batch that also contains a historical upstream task.
The current batch-isolated comparison removes that task and retains 19 tasks
from seven batches. No new task replaces it. Existing routes and all original
task/NC metrics remain unchanged.

The older, separate raw-source audit reports 20 batch-only candidate tasks.
That set includes the single-record task excluded by the original routing
protocol. The current analysis respects both source-batch isolation and the
original single-record exclusion, and therefore has 19 tasks. Its two-batch
XML subset is descriptive.

`task_batch_assignments.csv` connects the already published pseudonymous
result-table keys to source batches. The private mapping was verified by a
bijection of all 100 task-method metric rows against the unredacted original
analysis, then joined to raw file identities. Original filename patterns were
not used to guess the mapping. Raw source files, customer identifiers and the
private map remain outside the distributed materials.

The post-review correction averages paired task effects within batch, weights
the seven batches equally, resamples batches, and retains the two original
method contrasts with Holm correction. It is not described as a new
prespecified experiment. `BATCH_REANALYSIS.json` includes all-20-task and
isolated-19-task descriptive companions for comparison.

The independent audit checks the source overlap rule, all 100 row mappings and
the means. It also enumerates the exact bootstrap distribution for seven
batch effects using 1716 multinomial compositions representing 823543 equally
likely ordered resamples. The reported 100000-sample bootstrap endpoints
agree within 0.03 percentage point. This checks arithmetic and grouping; it
does not establish independence between factories or physical performance.

Raw PickupDate fields contain month/day strings only, and ProductDateEnd is
empty. A production or collection calendar year is not claimed. Distinct
source batches can still share higher-level process relationships.
