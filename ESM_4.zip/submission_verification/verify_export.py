from pathlib import Path
import csv,json
p=Path(__file__).resolve().parent
with (p/'routes_77.csv').open() as h:r=list(csv.DictReader(h))
assert len(r)==77
assert sum(x['false_completion_flag']=='True' for x in r)==13
assert sum(int(x['independent_incomplete_span_count_at_legacy_stop']) for x in r)==28
assert abs(sum(float(x['independent_uncovered_length_mm_at_legacy_stop']) for x in r)-5215.2)<1e-8
assert all(int(x['final_independent_incomplete_span_count'])==0 for x in r)
print('PASS: 77 routes; 13 coarse-stop failures; 28 spans; 5215.2 mm; 77 final geometric completions')
