"""Check the S9 illustrative state using the exact distributed public evaluator."""
from pathlib import Path
import argparse,sys,json
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);args=ap.parse_args()
sys.path.insert(0,str(args.source/'src'))
from cnc_cutting.models import CuttingProcessModel,CuttingAction,CuttingActionType,Point
from cnc_cutting.metrics import support_stability_shortfall,adjacency_support_length,update_unstable_part_state
from dataclasses import replace
ids=frozenset(['s1','s2','s3','s4'])
m=CuttingProcessModel(part_segment_ids={'i':ids},segment_part_ids={s:'i' for s in ids},part_polygons={},part_span_ids={'i':ids},segment_span_ids={s:frozenset([s]) for s in ids},span_part_ids={s:'i' for s in ids},support_span_ids={'i':ids},span_lengths={s:10. for s in ids},part_support_lengths={'i':40.},part_areas={'i':100.},part_adjacency_support_lengths={'i':{'j':10.}},min_remaining_support_count=1,min_remaining_support_length_ratio=.75,min_area_normalized_support_length=0.)
a=CuttingAction(CuttingActionType.CUT,Point(0,0),Point(0,10),covered_segment_ids=('s2',))
remaining=frozenset(['s3','s4']);processed={'s1','s2'};result={}
for alpha in [0.,1.]:
 model=replace(m,adjacency_support_weight=alpha)
 phi=support_stability_shortfall('i',remaining,model,released_part_ids=set())
 tracked=update_unstable_part_state(a,processed,processed,set(),set(),model)
 result[str(alpha)]={'credited_length_mm':20+adjacency_support_length('i',model,set()),'shortfall':phi,'tracked':sorted(tracked)}
assert result['0.0']=={'credited_length_mm':20.,'shortfall':.25,'tracked':['i']}
assert result['1.0']=={'credited_length_mm':30.,'shortfall':0.,'tracked':[]}
print(json.dumps({'status':'PASS','illustrative_state':result},indent=2))
