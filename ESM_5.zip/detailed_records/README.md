# WMSE v42 detailed records (2026-11-10)

This companion separates detailed execution records from the peer-review supplement. All essential selection rules, comparator budgets, kinematic assumptions, controls and statistical definitions remain in that PDF.

- ENGINEERING_DETAILS.md: unchanged v41 engineering excerpts (optional-screen equation, detailed NC/shard/parser protocol, VERICUT qualification details and full configuration prose). Historical references inside excerpts use v41 table numbers.
- IJAMT_VERICUT_publication_safe_review_evidence_v1_20260824.zip: existing publication-safe export, copied byte-for-byte. It contains 116 members including 15 NC programs, selection/qualification records, text logs, AUTO-DIFF outputs and timing tables. Native licensed projects/geometry are excluded by that package's RIGHTS_AND_REUSE_BOUNDARY.md. Result inspection is supported; independent commercial-simulator rerunning requires licensed controlled assets.
- fusion/fusion_api_nc_audit.json and .csv: existing corrected parser results for five exports. Included byte-for-byte; five cases pass depth, segment coverage, stock bounds and compensation checks. Timing fields are historical software outputs and are not used as manuscript timing evidence. Production geometry and Fusion NC programs are not newly redistributed.

No new industrial experiment or simulator run was performed. This companion does not modify the three older frozen archives or imply that full VERICUT run records were members of the industrial snapshot. Its ZIP/member hashes are recorded separately.

## Submission filenames

The engineering excerpts retain historical archive names. Use the following filenames for the accompanying submission files.

- `Public_Reproduction.zip` is the current filename for `Public_Reproduction_v36_20261028.zip`.
- `Industrial_Evidence.zip` is the current filename for `Frozen_Industrial_Evidence_v34_1.zip`.
- `Reproducibility_Addendum.zip` is the current filename for `WMSE_v38_Reproducibility_Addendum_20261109.zip`.
- `Detailed_Records.zip` is the current filename for `WMSE_v42_Detailed_Records_20261110.zip`.
