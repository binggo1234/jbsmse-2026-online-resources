# Detailed engineering records retained from v41

These are unchanged author-prepared source excerpts retained when the review PDF was shortened. They record the optional Event Gate criterion, NC parser/shard protocol, representative-simulator controls, Fusion scope, and full construction/configuration prose. They are supporting records, not additional experiments or a replacement for essential methods in Sections S5 and S11 of the current supplement. Formula/table references inside historical excerpts use v41 numbering. They are readable LaTeX excerpts, not standalone compilable documents.

The separate publication-safe VERICUT ZIP is the pre-existing 2026-08-24 export, copied without changing its bytes. It was not a member of Frozen_Industrial_Evidence_v34_1.zip, which contains the case-selection files only. The current reporting companion makes the distinction explicit. The Fusion folder contains the existing corrected five-export parser audit (geometry and NC remain controlled); the older ZIP whose README says pending is not distributed here.

```latex
\subsection*{\raggedright Optional event-screen implementation and inactive result}

The Event Gate is an optional engineering admission screen applied after candidate generation and before final selection; it is not part of the lexicographic objective or the branch-generation logic. The ordinary beam, polished beam, multi-start local-search, and any generated fallback beam and fallback-polished routes form the protected reference set. The topology route is the non-reference candidate subject to the screen when it introduces extra cutting engagements. For a screened candidate \(A_c\) and reference alternative \(A_r\), let \(\Delta N_{\mathrm{tool}}=N_{\mathrm{tool}}(A_c)-N_{\mathrm{tool}}(A_r)\). When \(\Delta N_{\mathrm{tool}}>0\), admission requires
\begin{equation}
\begin{aligned}
\Delta C_{\mathrm{plan}}&>\varepsilon,\\
\Delta C_{\mathrm{travel}}
&\geq
\Delta N_{\mathrm{tool}}\,
\max(\lambda_{\mathrm{abs}},
\lambda_{\mathrm{rel}}C_{\mathrm{travel}}(A_r)).
\end{aligned}
\label{eq:event-gate-criterion-supp}
\end{equation}
Here \(\Delta C_{\mathrm{plan}}=C_{\mathrm{plan}}(A_r)-C_{\mathrm{plan}}(A_c)\) and \(\Delta C_{\mathrm{travel}}=C_{\mathrm{travel}}(A_r)-C_{\mathrm{travel}}(A_c)\). The locked values are \(\lambda_{\mathrm{abs}}=25.0\)~mm-equivalent, \(\lambda_{\mathrm{rel}}=0\), and \(\varepsilon=10^{-9}\). Reference routes bypass the screen to preserve solver fallbacks, while every retained route remains subject to the same final lexicographic comparison.

The development rerun compares disabled, locked and conservative event-screen settings. All three retain the same 77 route signatures, so the screen contributes none of the observed improvement in this cohort. Candidate-level admission records and the full threshold table remain in the reproducibility archive.
```

```latex
\section*{\raggedright S5. Transparent NC-level kinematic computation and auxiliary exportability}

The corrected formal evidence for complete cutting remains the atomic-span route audit reported in the main paper. The NC-level track asks a different question: whether the route differences remain visible after every frozen holdout route has been converted into the same explicit depth-pass program and evaluated under disclosed kinematics.

The prespecified track contains all 58,920 method--board jobs from the 20-task holdout. A 100-board pilot, with all five methods for every selected board, was selected by a seeded hash before NC timing was inspected. The unchanged parser and evaluator were released to the full set only after 500/500 pilot programs passed the route-reference, syntax, semantic, coordinate, and scenario-count gates. Full execution used four deterministic board-level shards: all five methods for a board remained in one shard, and the merger required the four exact job-ID sets to be disjoint and their union to equal the frozen manifest.

The canonical NC template uses \texttt{G21}, \texttt{G90}, \texttt{G40}, a 6~mm tool, 18~mm stock, depth levels \(-6,-12,-18\)~mm, 3600~mm/min cutting feed, and 800~mm/min plunge feed. Each directed cutting action completes all three alternating-direction passes before the next top-level route action. The final pass therefore ends at the directed endpoint used by the planning evaluator. The three passes are consecutive and cannot be interleaved with another top-level cutting action. Span coverage, part release, and support-state transitions are committed only after the final pass, preserving the update point of the two-dimensional planning state. Low-clearance, detour, and safe-lift actions retain their evaluated travel-mode height.

The modal parser supports only \texttt{G0/G1}, \texttt{G17}, \texttt{G20/G21}, \texttt{G40}, \texttt{G90/G91}, modal \texttt{F/S/T/X/Y/Z}, and \texttt{M3/M5/M6/M30}; unsupported words, including arcs, are hard failures. It then audits one-to-one top-level action order, one XY block per travel action, three directed XY and Z blocks per cutting action, modal feed, pass depth, travel height and mode, stock bounds, units, coordinate mode, compensation state, spindle state, and tool-change count. The route-to-NC coordinate tolerance is 0.001~mm.

\input{supp_table_nc_audit.tex}

The 27 scenarios cross isotropic path-level rapid XY limits of 100, 200, and 300~mm/s; path-level XY accelerations of 500, 1000, and 2000~mm/s\(^2\); and paired Z-axis rapid-limit/acceleration settings of \((20,200)\), \((40,500)\), and \((60,1000)\) in mm/s and mm/s\(^2\). Thus an oblique planar block is evaluated from its Euclidean XY path length rather than from independent X- and Y-motor limits. Cutting is fixed at 60~mm/s. Every \texttt{G1} block is capped by its modal feed, so the 800~mm/min plunge command remains active in every scenario; \texttt{G0} retracts use the scenario Z-axis limit. The common 27-scenario grid is retained to align the two motion models; continuous-motion values repeat across settings that differ only in acceleration because acceleration does not enter that equation. For a coalesced block of length $\ell_b$, effective feed-capped speed $v_b$ and acceleration $a_b$, the continuous estimate is
\begin{equation}
t_b^{\mathrm{cont}}=\ell_b/v_b.
\end{equation}
The stop-at-junction estimate is
\begin{equation}
t_b^{\mathrm{stop}}=\begin{cases}2\sqrt{\ell_b/a_b},&\ell_b<v_b^2/a_b,\\ \ell_b/v_b+v_b/a_b,&\ell_b\ge v_b^2/a_b.\end{cases}
\end{equation}
Contiguous collinear blocks of the same motion class are coalesced before timing. No uncalibrated non-motion latency is added.

\input{supp_table_nc_robustness.tex}

In the batch-isolated subset, the seven-batch mean reductions relative to topology range from 9.40\% to 17.39\% for non-cutting time and from 0.89\% to 2.66\% for total time across both motion models. All 19 included tasks improve in every scenario. Table~\ref{tab:nc-robustness-supp} reports all scenario summaries and distinguishes positive batch means from positive effects in every individual task. GTSP has a different cutting length and policy outcome, so its timing contrast remains separate.

\input{supp_table_nc_reference_scenario.tex}

In the nominal continuous scenario, the proposed route uses 3.788~h non-cutting time and 38.755~h total per task under batch weighting, compared with 4.308 and 39.275~h for topology. Paired reductions are 12.29\% and 1.35\%, respectively. Table~\ref{tab:nc-nominal-full-supp} gives batch-bootstrap intervals, batch medians and W/T/L; Table~\ref{tab:nc-reference-scenario-supp} also supplies the stop-at-junction durations. These hours sum boards within a task, not per-board times.

The post-hoc batch correction averages paired task reductions within each of seven source batches and weights batches equally. Bootstrap resamples those batches, not the 27 scenarios or individual boards. The NC scenario grid and original program metrics are unchanged. Section~S12 gives the source mapping and estimand; the primary non-cutting and secondary total-time endpoints retain their separate interpretation.

\subsection*{\raggedright Auxiliary qualified representative VERICUT cross-check}

Five size-stratified boards containing 5, 7, 8, 12, and 19 rectangles were drawn from five distinct original factory tasks for a separate commercial-simulator cross-check. Selection was completed without inspecting route cost, effect direction, or simulated time. Within the prespecified size-stratum quotas, qualifying frozen geometries were ordered by geometry hash, and the first required hashes for which the proposed, process-aware topology, and ordinary process-aware beam NC programs were distinct were retained. The distinct-program condition removed uninformative identical comparisons but did not select on outcome direction or magnitude. The three routes per board were exported through the same canonical post-processor, giving 15 absolute-coordinate NC programs. Their SHA-256 values were frozen before qualification and remained unchanged. The auxiliary evidence includes the selection protocol and a 15-row manifest containing pseudonymized task IDs, case and stratum labels, packing seeds, board IDs, rectangle counts, geometry hashes, method labels, NC paths, and NC hashes; original task identifiers are withheld.

VERICUT 9.4.2 (64-bit) processed the programs using installed CGTech Cincinnati 30V library geometry configured as a fixed-head XYZ representative, with A/B locked at zero and the \texttt{fan15m} control used for representative interpretation. The frozen configuration used \(2440\times1220\times18\)~mm stock, a 6~mm cutter, \texttt{G40}, \(18{,}000\)~rpm, 3600~mm/min cutting feed, 800~mm/min plunge feed, three depth passes to \(-18\)~mm, and representative tool-holder, MDF spoilboard, and vacuum-table-envelope geometry. Axis-limit checking and explicit experiment-relevant collision pairs were enabled; Force/OptiPath, NC rewriting, and material-dependent optimization were disabled. Here, qualification means passing the prespecified negative and positive controls described next; it does not denote CGTech or machine-manufacturer certification.

The configuration passed four pre-formal controls. The collision-negative program completed with zero errors and warnings, while the positive program generated the intended T1 cutter--fixture collision. A programmed 0.500~mm gouge returned red with three reported rows, and a 0.500~mm shallow-floor excess control returned red with 22 rows. Five native VCT Design self-comparisons were green with no report rows. These case-level Designs were generated from the shared oracle/proposed removal geometry and therefore test route-equivalent final removal rather than provide independent metrology references.

All 15 formal programs reached end of file with zero VERICUT errors, zero warnings, and no reported collision under the scoped pair matrix. Solid AUTO-DIFF was green with no gouge/excess report rows in every run. The configured gouge and excess classification thresholds were 0.10~mm, but the global cut-stock tolerance was 0.25~mm; green/0 therefore does not establish mathematically zero deviation or 0.10~mm dimensional accuracy. Table~\ref{tab:vericut-selected-layouts} reports every paired case.

\input{supp_table_vericut_selected_layouts.tex}

Using the one-second report resolution as a \(\pm1\)-s tie band, proposed total time has W/T/L \(=2/3/0\) against topology and \(4/1/0\) against ordinary beam. The layout-equal mean paired total-time reductions are 0.79\% and 1.31\%, respectively. Aggregated across the five layouts, total time falls by 36/4419~s (0.82\%) versus topology and 55/4438~s (1.24\%) versus ordinary beam. The corresponding aggregate air-motion reductions are 34/555~s (6.13\%) and 57/578~s (9.86\%); aggregate non-air time changes by only \(+0.052\%\) and \(-0.052\%\). The small total-time result is thus explained almost entirely by reduced air motion, consistent with the route-level mechanism. The five boards are selected paired cases from five distinct tasks rather than random factory-task replicates; deterministic reruns are not replicates, and no population-level significance claim is made.

Formal timing uses the log field \texttt{Total cycle time since last rewind}. The post-hoc HTML tool-summary \texttt{Machine Time} excludes approximately 12~s of rewind/tool-change overhead and is not mixed with the formal table. The publication-safe review archive contains the 15 frozen NC programs, qualification and control summaries, original text logs, raw AUTO-DIFF outputs, collision-pair and tolerance records, timing and paired-comparison tables, selection files, and a file-level SHA-256 manifest. Proprietary CGTech library geometry, machine and tool libraries, simulator-native project and model files, VCT Designs, and branded native reports are retained in the authors' internal qualification archive and are not redistributed. The model is library based rather than a production digital twin; its geometry and timing are not production measured or controller calibrated, and the collision matrix does not cover adjacent internal kinematic pairs. The evidence is therefore a qualified representative commercial-simulator cross-check, not physical machining, metrology, workholding, or production collision-clearance validation.

\subsection*{\raggedright Auxiliary Autodesk Fusion exportability check}

The corrected auxiliary package regenerates generic NC/CAMotics material from span-audited routes and checks five Autodesk Fusion exports. All five use \(2440\times1220\times18\)~mm stock, absolute compensated coordinates, \texttt{G40}, a 6~mm cutter, and three 6~mm depth passes. Each export retains the intended cutter-center segments, reaches the final depth, and remains within the XY stock envelope. The check concerns geometric exportability only; it is not used for timing and does not establish controller behavior, machining quality, or commercial-CAM superiority. The individual parser rows and locked-setting checklist are archived.
```

```latex
\section*{\raggedright S11. Deterministic construction, frozen comparators and artifact entries}

\subsection*{\raggedright Coverage selection and a complete small example}

The reported selector is \path{cnc_cutting/optimizer.py::select_coverage_units}, called after \path{cutting_units.py::build_candidate_cutting_units}. Geometry and span construction use a $10^{-6}$~mm tolerance. With repeat policy \texttt{hard} and bridge cutting disabled, the selector follows Table~\ref{tab:coverage-selection-rule}. It gives priority to avoiding repeats but does not solve minimum set cover. The residual-span family supplies the complete covering alternative. The resulting selected set is fixed before any compared route generator is invoked.

\begin{table}[htbp]
\centering\small
\caption{Deterministic selected-unit construction in the reported hard-repeat setting. $P$ is the set of already credited spans, $C(u)$ the spans of candidate $u$, and $\ell(u)$ its cutter-center segment length.}
\label{tab:coverage-selection-rule}
\begin{tabular}{rp{0.84\linewidth}}
\toprule
1 & Set $P=\varnothing$ and the selected sequence empty. Remove candidates requiring a bridge cut.\\
2 & Retain candidates with $C(u)\setminus P\ne\varnothing$. If none remain, stop.\\
3 & For each retained candidate, form the ordered key consisting of $|C(u)\cap P|$; the sum of nominal lengths of those repeated spans; $-|C(u)\setminus P|$; type rank; $\ell(u)$; and unit identifier.\\
4 & Choose the smallest key, append that unit, replace $P$ by $P\cup C(u)$ and remove the chosen candidate. Return to step 2.\\
5 & The caller audits the selected union and the executed span coverage. Ordering subsequently chooses directions and sequence for this fixed unit set.\\
\bottomrule
\end{tabular}
\end{table}

Type ranks are shared, near-shared, collinear-chain and single-span, in that order. Numeric key fields use their stored values without an additional comparison tolerance; the identifier is the final deterministic tie breaker. Candidates with no new spans are never appended. The optional near-shared and collinear constructors are in \path{cutting_units.py::relation_cutting_units}; their selected counts in the factory tracks are zero (Section~S6).

For the two-part example of main Figure~3, construction gives 11 candidates and 10 required spans. The selector first chooses the shared segment from $(4,16)$ to $(16,16)$~mm, which covers one span on each part. It then selects the two residual single-span units and the other six single-edge units, giving nine selected units and exactly one credit for each required span. The two residual nominal spans have length 1~mm each; their compensated centerline segments include the endpoint extensions shown in the figure. The addendum supplies every candidate identifier, endpoint and span mapping in \path{reference_example/candidate_and_selected_units.csv}, as well as the selection keys and order in \path{reference_example/EXAMPLE_AUDIT.json}. This separates selection order from the later route order.

The runnable \path{reproduce_example.py} independently implements the stated selection key, checks equality with the library selector, replays a full-filtered fixed-cap order and exports/audits its canonical NC program. The artificial example uses a $40\times40$~mm panel, start $(0,0)$ and zero centerline margin to accommodate the illustrated outer compensation. Its explicit tool configuration is supplied; it is not a new factory experiment or a replacement for factory settings below.

\subsection*{\raggedright Industrial reference methods and budgets}

The frozen industrial algorithm basis is commit \texttt{083d869e\allowbreak e132a8d6\allowbreak c8f4d12d\allowbreak eacb4c78\allowbreak bcbdb2a0}. Comparator construction is \path{routing_code_and_public_data/experiments/run_chapter2_batch.py::build_planners} in the frozen evidence archive. Its size argument $n$ is the number of rectangles on the layout, not the selected-unit count. Table~\ref{tab:frozen-beam-budgets} supplies the ordinary and wider beam budgets.

\begin{table}[htbp]
\centering\small
\caption{Frozen industrial beam configurations by layout rectangle count. $B$ is beam width, $P$ the nearest-unit pool, $E$ the directed per-parent expansion cap and $L$ the layer cap. These differ from the size-independent four-condition controls.}
\label{tab:frozen-beam-budgets}
\begin{tabular}{lrrrrrrrr}
\toprule
 & \multicolumn{4}{c}{Ordinary beam} & \multicolumn{4}{c}{Wider fallback}\\
\cmidrule(lr){2-5}\cmidrule(lr){6-9}
Rectangle count & $B$ & $P$ & $E$ & $L$ & $B$ & $P$ & $E$ & $L$\\
\midrule
$n\le20$ & 8 & 24 & 48 & 56 & 10 & 30 & 60 & 70\\
$21\le n\le75$ & 6 & 18 & 36 & 42 & 8 & 24 & 48 & 56\\
$n>75$ & 4 & 12 & 24 & 28 & 6 & 18 & 36 & 42\\
\bottomrule
\end{tabular}
\end{table}

The industrial beam has diversity-bucket limit 1, ordinary minimum parent allocation 0 and unstable-parent minimum allocation 2. The unstable-layer multiplier is 1 with zero additive bonus. Completion-aware pre-ranking, state dominance and lower-bound ranking are disabled. Completion-related candidate admission follows the frozen tracked-set rule. The exact dataclass fields, including defaults, are enumerated in \path{frozen_comparator_configurations.json} in the addendum.

\textbf{Process-aware topology.} The greedy constructor evaluates directed candidates using the incremental process key, followed by the topology transition score, unit identifier and direction. Its candidate-pool limit is 96 for $n\le50$, 64 for $51\le n\le200$ and 48 otherwise. The transition-score weights are travel 1, turn 30, same-part bonus 25, relation-unit bonus 20, multi-segment bonus 15 and bridge penalty 1000. Outside a tracked low-support context, pre-ranking limits exact directed evaluations to $\max(16,\lfloor P/3\rfloor)$ for pool size $P$; the limit does not truncate the completion context. \path{local_search.py::process_aware_unit_order} fixes the rule and tie order.

\textbf{Local refinement and multi-start process search.} Swap, relocation and two-opt neighborhoods are enabled with first-improvement acceptance. For $n\le50$, the cap is two improving iterations, span 6 for each neighborhood and 160 generated neighbors per iteration; otherwise these are one iteration, span 5 and 120 neighbors. The associated topology pool is 96 or 64, respectively. Search terminates at the iteration cap or when no strict process-key improvement is found. Multi-start applies this same budget separately to each distinct deterministic seed order: nearest-neighbor, topology, forward/reverse x and y sweeps, and process-aware greedy. Duplicate order signatures are removed; at most seven starts remain. The best completed result is retained by the process key and order signature.

\textbf{Proposed portfolio.} Candidate membership is process-aware topology, ordinary beam, refinement of that beam and the multi-start result. The wider beam and its refinement are added if the ordinary beam's process key is no better than topology, or its travel saving relative to topology is below 1000. The ordinary/refined/multi-start and generated fallback routes are protected from the optional event screen. Other candidates face the criterion in Section~S1. Final selection minimizes the common process key; equal keys retain candidate insertion order. The extra work is part of the reported offline budget.

\textbf{Endpoint-aware GTSP.} This reference uses independent single-edge contour units, without common-cut selection. Its contour options vary start edge and direction and optimize endpoint transitions for a part order. From a nearest-endpoint initialization, it considers part-order reversal and relocation, with at most six best-improvement iterations and 400 neighbors per iteration, stopping when no distance improvement beyond $10^{-9}$ is found. \path{gtsp_baseline.py::EndpointAwareGTSPConfig} and \path{optimizer.py::plan_endpoint_aware_gtsp_route} define the options and final common-evaluator replay. It is a representation-and-policy contrast, not an isolated search comparison.

\subsection*{\raggedright Execution settings and version entry points}

Repacked factory layouts use $2440\times1220$~mm stock, 5~mm packing trim, a 6~mm tool-width channel and 3~mm tool-center boundary margin. The planning start is $(5,5)$~mm, with no planning return-to-start term. All three travel-mode length weights are 1, safe clearance is 0 and the safe-lift fixed premium is 250. Low-clearance detours and safe lifts above released parts are enabled. The original-coordinate XML interface instead permits exterior cutter-disk overhang with the tool center retained inside stock, as disclosed in Section~S7.

The canonical NC template uses $Z=+1$~mm for direct/detour travel and $Z=+5$~mm for safe travel, relative to the stock top at zero. It uses three depths $-6,-12,-18$~mm, spindle speed 18000~rpm, cutting feed 3600~mm/min and plunge feed 800~mm/min. NC export includes final retraction and return to the fixed start. The planning cost and NC time thus retain their separate definitions. The frozen NC manifest records these values and the 27 kinematic scenarios.

The following are exact accompanying files, rather than pointers to a mutable repository branch. Their complete ZIP hashes are in the accompanying \path{ARTIFACT_INDEX.json}; member hashes are in the addendum's \path{SHA256SUMS.json}.

\begin{itemize}
\item \path{Public_Reproduction_v36_20261028.zip} contains \path{public_reproduction/}, with 30 layouts, routing source, the fixed-cap runner and all 240 public control references. This version is the source for the new state controls, not the industrial portfolio configuration.
\item \path{Frozen_Industrial_Evidence_v34_1.zip} is the byte-identical historical reviewer snapshot. It contains \path{routing_code_and_public_data/}, \path{holdout_pipeline/}, \path{documentation/} and the frozen aggregate/manifests. The authorized industrial input is the cache-isolated v2 result identified in \path{documentation/holdout_reproducibility.md}; the earlier quarantined output is not an analysis input.
\item \path{WMSE_v38_Reproducibility_Addendum_20261109.zip} contains the configuration JSON, deidentified selection ledger, example script and reference outputs, and commands locating the two versions above. It adds reporting and interface checks without changing either routing library or the industrial results.
\end{itemize}

The frozen source tree, public reference results and illustrative NC can be inspected without factory records. Re-execution of the private industrial routes requires controlled access to their inputs. The addendum's extraction instructions and member index distinguish original controlled-input hashes from hashes of distributed pseudonymized files.
```
