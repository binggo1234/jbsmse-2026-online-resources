# IJAMT holdout confirmatory analysis freeze v1

Freeze date: 2026-07-26

Status: frozen before task-level method rankings are computed.

## 1. Authorized inputs

Only the following route result is authorized:

- `outputs/holdout_route_experiment_v1/route_results_cache_isolated.csv`
- SHA-256:
  `2df56a2d5700c1356bb78745e57d3eb69d87d6507222f48730b4a3b3e375aff2`

The quarantined v1 file
`outputs/holdout_route_experiment_v1/route_results.csv` must never be read by the
confirmatory analysis. Its SHA-256 is recorded only as a negative control:
`8c1bf0f5cfd76518af97869a9ed3409c8e82a94e095650c3b84cee1ff0e84aed`.

The algorithm definition is frozen at Stage7 commit
`083d869ee132a8d6c8f4d12deacb4c78bcbdb2a0`. The cache-isolation amendment and
the passed isolated audit remain mandatory provenance inputs.

## 2. Independent unit and aggregation

The independent unit is the factory task (`task_id`, n = 20). Packing seeds and
boards are nested repeated observations, not independent samples.

For every metric and method, aggregation is performed in exactly this order:

1. sum all boards within each `task_id × packing_seed`;
2. average the three frozen packing seeds (`1000`, `1001`, `1002`) with equal
   weight;
3. give each of the 20 tasks equal weight in all confirmatory summaries.

No board selection, seed selection, layout-density weighting, or pooling of
boards as independent observations is permitted.

## 3. Metrics

The primary scalar planning cost is fixed by the frozen Stage7 implementation:

`C_plan = cutting_length + travel_mode_cost`.

`travel_mode_cost` includes mode-weighted travel and the safe-lift premium.
Support-policy penalty (`stability_penalty` in the CSV), repeated processing,
tool events, and hard penalty remain separate lexicographic diagnostics and
must not be added to `C_plan`.

The tool-event count is
`pierce_count + lift_count + safe_lift_count`; this must equal the serialized
`process_tool_event_count` on every route row.

The locked `rho = 0.75` is a support-policy threshold, not a scalar cost weight.
The endpoint-aware GTSP comparison therefore reports both `C_plan` and
support-policy penalty. It must not construct a post-hoc combined score.

## 4. Confirmatory comparisons

The proposed method is
`process_aware_beam_adaptive_polished`.

The two planned confirmatory comparisons are:

1. proposed versus `topology_process_aware`: paired task-level `C_plan`;
2. proposed versus `endpoint_aware_gtsp`: paired task-level `C_plan`, reported
   together with support-policy penalty at `rho = 0.75` as a cost-policy
   tradeoff.

For each comparison, the task-level percentage reduction is:

`100 × (baseline - proposed) / baseline`.

The estimand is the equally weighted mean of the 20 task-level percentage
reductions. The median, absolute paired difference, baseline and proposed task
means, and the ratio-of-total-sums are descriptive companions; the
ratio-of-total-sums is not the confirmatory estimand.

## 5. Inference and numerical rules

- Cluster bootstrap unit: factory task.
- Bootstrap statistic: mean task-level percentage reduction.
- Replicates: 100,000.
- Random seed: `20260726`.
- Interval: percentile 95% interval (2.5th and 97.5th percentiles).
- Robust test: exact two-sided paired sign test after removing numerical ties.
- Multiplicity: report raw sign-test p-values and Holm-adjusted p-values for the
  two planned `C_plan` comparisons.
- A numerical tie satisfies
  `abs(proposed - baseline) <= 1e-9 × max(1, abs(proposed), abs(baseline))`.
- A lower value is favorable for every cost or penalty metric.
- Percentage reduction is undefined when the paired baseline is numerically
  zero. Such cases remain in absolute-difference and W/T/L summaries but are
  excluded from percentage summaries with an explicit count.

The sign test is a robustness summary for direction, not proof of practical
importance. Effect magnitude and its interval remain mandatory.

## 6. Secondary analyses

Secondary task-level comparisons include
`process_aware_beam`, `process_local_search_multistart`, and the two primary
baselines for:

- `travel_mode_cost`;
- raw `air_move_distance`;
- tool-event count;
- support-policy penalty;
- total route runtime;
- cutting length.

Seed sensitivity is reported within task and method. Task heterogeneity and the
worst task are retained. Secondary p-values, if shown, are labeled descriptive
and are not used to redefine the confirmatory claim.

## 7. Mandatory integrity gates

The analysis must stop before producing rankings unless all of the following
hold:

- authorized v2 SHA-256 matches this freeze;
- isolated route audit status is `passed`;
- every route status is `completed`;
- exactly five frozen methods are present;
- every board has all five methods;
- exactly 20 tasks and exactly three frozen seeds per task are present;
- every `task × seed × method` contains the same board keys;
- all required numeric fields are finite;
- serialized and recomputed tool-event counts agree;
- proposed hard penalty is zero on every route;
- proposed atomic coverage audit has no geometry failures;
- the v1 file path is absent from all analysis inputs and manifests.

Any gate failure stops the analysis and creates no confirmatory summary.

## 8. Reporting boundary

These analyses support computational generalization to unseen factory tasks
under the frozen CAM-planning evaluator. They do not establish measured CNC
cycle-time, physical clamping stability, surface quality, dimensional
tolerance, tool life, or superiority to a commercial CAM system.
