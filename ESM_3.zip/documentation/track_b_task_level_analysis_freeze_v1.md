# Track B task-level analysis freeze v1

Freeze date: 2026-07-26

Status: frozen after structural and geometry audits, before comparative
route-quality statistics were computed.

## Scope and independent unit

Track B evaluates routes on fixed factory XML coordinates. A Pattern is a
nested board/layout record, not an independent sample. For each method, all
Pattern metrics are summed within a factory task. The seven tasks labelled
`confirmatory_holdout` are then analyzed with equal task weight (`n = 7`).

The four tasks labelled `excluded_prior_upstream_use` are retained as a
historical supplementary cohort. They receive task-equal descriptive
summaries, but never increase the confirmatory sample size and receive no
confirmatory p-values.

## Inputs and admission gates

Analysis is permitted only if all of the following pass:

1. XML inventory and geometry preflight;
2. the frozen 13,765-job route completeness audit;
3. the 2,753-route proposed atomic-span replay with
   `PYTHONHASHSEED=0`.

The first unpinned replay is diagnostic evidence only and is retained
separately. Its single hash-order-sensitive route is documented in
`docs/track_b_hash_seed_diagnostic.md`; no stored route result was changed.

## Metrics and comparisons

The rules are inherited unchanged from the Track A confirmatory freeze:

- `C_plan = cutting_length + travel_mode_cost`;
- primary comparisons are proposed versus `topology_process_aware` and
  proposed versus `endpoint_aware_gtsp`;
- primary outcome is task-level `C_plan`;
- support-policy penalty is a co-reported feasibility outcome, not a weight in
  `C_plan`;
- route components, tool-event count, cutting length, and total task runtime
  are secondary/descriptive outcomes.

For each task and method, tool-event count is
`pierce_count + lift_count + safe_lift_count` and must equal the serialized
`process_tool_event_count`.

## Confirmatory statistics

- Each of the seven factory tasks has equal weight.
- Differences are proposed minus baseline.
- Percentage reduction is
  `100 * (baseline - proposed) / baseline`.
- A percentage is undefined when the baseline is numerically zero.
- Numerical ties use relative tolerance `1e-9`.
- Report mean and median task differences/reductions, win/tie/loss counts, and
  a 95% percentile bootstrap interval from 100,000 task-level resamples.
- Bootstrap seed: `20260726`, identical to Track A.
- Use the exact two-sided sign test across non-tied tasks.
- Apply Holm correction across the two primary `C_plan` comparisons.

With only seven independent tasks, the smallest possible raw two-sided sign
test p-value is 0.015625. Results must therefore be interpreted with effect
sizes, task-wise consistency, and interval width rather than p-values alone.

## Prohibitions

- Do not treat Patterns, Workpieces, route actions, or methods as independent
  replicates.
- Do not pool the four historical tasks into the confirmatory cohort.
- Do not select tasks or Patterns using observed method performance.
- Do not change the XML boundary convention, route parameters, comparison set,
  or outcome formula after seeing comparative results.
