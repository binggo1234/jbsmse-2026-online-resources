# Track B original-XML coordinate freeze v1

Freeze date: 2026-07-26

Status: frozen before any Track B route-quality result.

## Scope

Track B uses all 11 factory tasks marked `xml_available=yes` in
`data/factory_task_lineage_manifest_v1.csv`. The seven tasks marked
`confirmatory_holdout` form the unseen-factory-coordinate cohort. The other
four tasks are historical supplementary checks.

Every geometrically valid XML `Pattern` is retained. Pattern density, part
count, expected route quality, and method outcome are not selection criteria.

## XML field interpretation

The interpretation is fixed from field identities and cross-file equality
checks performed without running a routing method:

- CSV `Fleng/Fwidth` corresponds to XML `Designer/clerk` and is used only for
  CSV--XML inventory lineage verification.
- XML `CutLength/CutWidth` is the nominal rectangular blank cut by the factory
  pattern.
- XML `Lineament/Points` is the compensated cutter-center contour.
- For tool diameter `d`, the lineament bounding box must match
  `CutLength/CutWidth + d`, allowing the two axis orientations.
- The nominal rectangle supplied to Stage7 is recovered by insetting the
  lineament bounding box by `d/2`. Stage7 geometric kerf compensation must
  reproduce the recorded lineament bounding box.

No coordinate is taken from the Track A repacking outputs.

## Geometric preflight

Each Pattern must pass all of the following:

1. parseable board dimensions, tool diameter, Workpieces, Lineaments, and
   finite point coordinates;
2. a positive rectangular lineament bounding box containing all four corners,
   with every point on its boundary;
3. lineament dimensions consistent with `CutLength/CutWidth + tool diameter`;
4. every cutter-center point inside the XML board domain;
5. every recovered nominal rectangle positive and inside the board;
6. no positive-area overlap between recovered nominal rectangles;
7. no positive-area overlap between compensated lineament interiors (touching
   or shared boundaries are allowed);
8. task-level WorkpieceId multiset and normalized `Designer/clerk` dimension
   multiset exactly equal the source CSV inventory.

Failed Patterns remain in the preflight report with explicit reasons. Only
passed Patterns enter the frozen route schedule.

## Boundary convention

The factory XML provides cutter-center coordinates, and some valid outer-edge
cuts have a centerline only 0.5 mm from the stock boundary. For Track B,
boundary feasibility therefore means that the cutter center remains in
`[0, board_length] × [0, board_width]`. The cutter disk may overhang the stock
on an exterior trim edge.

Accordingly, the Track B evaluator uses
`centerline_boundary_margin = 0.0`, `trim_margin = 0.0`, tool diameter from the
XML (expected 6 mm), and geometric kerf compensation enabled. This is a
coordinate-interface convention applied identically to every method and fixed
before route results; it is not a method-specific relaxation.

## Route and reporting rules

- Methods and process parameters are identical to Track A.
- The cache is cleared before every method run.
- Every passed Pattern is run once per method; there is no packing seed because
  the XML coordinates are fixed.
- Task is the independent unit for the seven holdout tasks. Patterns are summed
  within task before task-equal reporting.
- Historical XML tasks are supplementary and never increase the confirmatory
  sample size.
- Coverage, hard penalty, support-policy penalty, planning cost, route
  components, and runtime are retained.
