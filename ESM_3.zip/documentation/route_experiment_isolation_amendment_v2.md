# Route experiment isolation amendment v2

The first complete route run used the frozen Stage7 batch convention of sharing
one in-process evaluator environment across the five methods on each board.
Before any method-quality ranking or task-level confirmatory analysis, the
proposed-only atomic-span replay detected one deterministic metric mismatch:

- job: `f52e5eaa170221a6b062`
- member: `holdout/FACTORY_TASK_016/seed_1001/placements.csv`
- board: `137`

Replaying all five methods in the original within-board order reproduced the
stored result exactly. Replaying proposed alone produced a different feasible
route. The difference is caused by the module-level low-clearance detour cache
persisting across method calls. Therefore the first result file is quarantined:
it remains evidence of the isolation failure and of geometric feasibility, but
must not enter method comparisons.

The corrected run changes exactly one execution condition:

> Clear the low-clearance detour cache immediately before every method planner
> invocation.

The following remain unchanged: 20 independent factory tasks, three packing
seeds, all 11,784 boards, five methods, method parameters, algorithm seed,
58,920-job frozen schedule, and 30-second per-job timeout. The corrected
amendment is frozen before inspecting any method-quality ranking.
