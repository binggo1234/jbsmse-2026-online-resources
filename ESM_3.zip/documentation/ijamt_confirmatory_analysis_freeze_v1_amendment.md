# Confirmatory analysis freeze v1 administrative clarification

Date: 2026-07-26

This clarification resolves one internal wording conflict in the frozen analysis
specification. Section 1 records the quarantined v1 path and SHA-256 as a
negative-control identity, whereas the final integrity-gate bullet says that the
v1 path must be absent from all manifests.

The enforceable rule is:

- the v1 path and its already recorded SHA-256 may appear only in a
  `forbidden_input_identity` or equivalent negative-control manifest section;
- v1 must not appear in any authorized input list;
- the analysis program must not open, hash, parse, compare, or otherwise read
  the v1 file;
- no statistic, table, figure, or manuscript value may be derived from v1.

This clarification changes no metric, estimand, tolerance, bootstrap parameter,
test, comparison, or result. It is recorded explicitly rather than silently
editing the pre-result freeze.
