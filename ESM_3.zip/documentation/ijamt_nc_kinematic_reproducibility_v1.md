# Transparent NC-level kinematic evaluation: reproduction guide

## Evidential scope

This workflow reproduces a controller-agnostic NC-level computational validation
for the frozen 20-task factory holdout. It verifies route-to-NC semantic
preservation and evaluates disclosed kinematic scenarios. It does not estimate a
specific controller's cycle time and does not validate workpiece stability,
dimensional accuracy, surface quality, tool wear, or any other measured machining
outcome.

The independent statistical unit is the factory task (`n = 20`). Packing seeds and
boards are nested observations. The 27 kinematic settings are sensitivity
conditions, not independent replicates.

## Frozen inputs and software

The authoritative freeze is:

`outputs/nc_kinematic_evaluation_v2/nc_kinematic_freeze_manifest.json`

It records SHA-256 hashes for the 58,920-job route list, cache-isolated route
reference results, board index, protocol, NC core, runner, and analysis script.
Verify those hashes before any replay:

```bash
python3 -m scripts.prepare_nc_kinematic_evaluation verify
```

The underlying route freeze and its source-data provenance remain authoritative
for the 20 holdout tasks, three packing seeds, 11,784 boards, and five methods.

## Prespecified execution order

The pilot must pass before method timing comparisons are inspected:

```bash
python3 -m scripts.run_nc_kinematic_evaluation pilot --retain-gcode
python3 -m scripts.analyze_nc_kinematic_results pilot
python3 -m scripts.audit_nc_kinematic_evaluation pilot
```

Only after the pilot hard gate passes, run the unchanged full pipeline:

```bash
python3 -m scripts.run_nc_kinematic_evaluation full --shard-count 4 --shard-index 0
python3 -m scripts.run_nc_kinematic_evaluation full --shard-count 4 --shard-index 1
python3 -m scripts.run_nc_kinematic_evaluation full --shard-count 4 --shard-index 2
python3 -m scripts.run_nc_kinematic_evaluation full --shard-count 4 --shard-index 3
python3 -m scripts.merge_nc_kinematic_shards --shard-count 4
python3 -m scripts.analyze_nc_kinematic_results full
python3 -m scripts.audit_nc_kinematic_evaluation full
```

The four runner commands may execute concurrently. The frozen board-order modulo
rule keeps all five methods for one board in one shard. The merger refuses to
start unless the four exact job-ID sets are disjoint, their union equals the
58,920-row manifest, every job is completed, every route and NC audit passes, and
every job has all 27 scenarios.

An interrupted shard is resumed without replacing completed SQLite transactions:

```bash
python3 -m scripts.run_nc_kinematic_evaluation full \
  --shard-count 4 --shard-index 0 --resume
```

The full runner clears the route planner's detour cache before every method,
replays the method from the frozen board geometry, compares source route metrics
against the isolated frozen reference row, generates canonical NC, parses it
modally, performs the hard semantic audit, computes all 27 scenarios, and commits
one job atomically.

## Canonical NC and audit invariants

The canonical program uses `G21`, `G90`, `G40`, a 6 mm tool, 18 mm stock, three
6 mm depth passes, 3,600 mm/min cutting feed, and 800 mm/min plunge feed. Every
cutting action completes all depth passes before the next top-level action.
Alternating pass direction leaves the final pass at the directed route endpoint.
The three passes are not interleaved with another cutting action; route-level span
coverage, part release, and support-state transitions are committed after the final
pass, matching the planning evaluator's top-level action boundary.
Travel modes retain their evaluated low-clearance, detour, or safe-lift height.

The modal parser accepts only the frozen linear subset. Unsupported words,
including arcs, fail the job. The hard audit checks action order, action count,
travel mode and height, three directed cut blocks and depths per cutting action,
feed, coordinate bounds, modal units and coordinates, `G40`, spindle state, tool
change, and a maximum coordinate difference of 0.001 mm.

## Kinematic models and aggregation

The 27 scenarios cross:

- rapid speed: 100, 200, and 300 mm/s;
- XY acceleration: 500, 1,000, and 2,000 mm/s²;
- paired Z-axis rapid-limit/acceleration: (20, 200), (40, 500), and
  (60, 1,000) in mm/s and mm/s².

The rapid XY speeds and XY accelerations are isotropic path-level limits applied
to Euclidean planar block length, not independent X- and Y-motor limits. Z-only
blocks use the stated Z-axis limits.

Cut speed is fixed at 60 mm/s. Every `G1` motion is capped by its modal NC feed,
so the 800 mm/min plunge command is retained while `G0` retracts use the scenario
Z-axis limit. No uncalibrated dwell or tool-event delay is added. The continuous
model divides merged motion-class distance by effective speed. The
stop-at-junction model applies a triangular or trapezoidal profile to each
non-collinear block after merging contiguous, collinear blocks of the same class.

For each method, boards are summed within task--seed, the three seed totals are
averaged within task, and the 20 task values receive equal weight. Primary outcome
is NC non-cutting time; secondary outcome is NC total time. GTSP timing and its
modeled support-policy status must be interpreted separately.

## Authoritative outputs

The full output directory is:

`outputs/nc_kinematic_evaluation_v2/full`

Key artifacts are:

- `results.sqlite`: transactional authoritative result database;
- `job_results.csv`: action/NC hashes, route-reference audit, parser audit, and
  decomposed motion geometry for all 58,920 jobs;
- `scenario_times.csv`: both motion models for all 27 scenarios per job;
- `gate_report.json`: hard completeness and audit gate;
- `task_scenario_metrics.csv`: seed-averaged, task-level NC metrics;
- `scenario_comparisons.csv`: task-equal paired reductions and W/T/L counts;
- `scenario_robustness_summary.csv`: range across the 27 sensitivity settings;
- `task_equal_geometry_summary.csv`: task-equal NC geometry decomposition;
- `planning_nc_spearman.csv`: descriptive task-level association between the
  planning metric and NC time;
- `completion_audit.json`: exact manifest/database/artifact completion audit;
- `artifact_checksums.sha256`: checksums for the analysis and audit artifacts.

The completion audit independently verifies exact job-manifest identity,
11,784 board identities with the complete five-method set, 20 tasks with three
packing seeds each, successful route-reference and NC audits, the coordinate
tolerance, and the complete 27-scenario grid.

## Public end-to-end examples

Five complete 2DPackLib-derived examples can be generated with:

```bash
python3 -m scripts.build_public_nc_repro_examples
```

The output `outputs/public_nc_repro_examples_v1` contains one BENG, CGCUT,
NGCUT, OF, and WANG layout. Each example releases its input geometry, serialized
proposed-route actions, canonical NC, complete parsed-motion output, semantic
audit, 27-scenario table, and SHA-256 manifest. These examples contain no factory
data and reproduce the interface rather than the proprietary holdout geometry.
