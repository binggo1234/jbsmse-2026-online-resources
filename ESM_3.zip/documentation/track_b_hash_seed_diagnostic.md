# Track B Python hash-seed diagnostic

## Scope

This note records an execution-environment determinism issue found during the
independent atomic-span replay of the frozen Track B route results. It does not
change the frozen XML layouts, route results, method parameters, or Stage7
commit.

## Observation

The first full replay was launched without an explicit `PYTHONHASHSEED`.
Geometric and process-hard checks passed for all 2,753 proposed routes:

- missing atomic spans: 0;
- repeated atomic spans: 0;
- unknown cutting units: 0;
- hard failures: 0.

One route did not reproduce the stored route metrics:

- job: `9072d82fe9c028a76bb8`;
- task: `FACTORY_TASK_007`;
- pattern: `FACTORY_TASK_007:g1:p282:s0282`.

The stored route had 22 pierces, no safe lift, 26 detours, and a travel-mode
cost of 6,866.594248341. The unpinned replay produced another feasible route
with 23 pierces, one safe lift, 12 detours, and a travel-mode cost of
7,157.630573937. Cutting length was identical at 18,962.5 and both routes had
zero hard penalty.

## Diagnosis

Independent replays with `PYTHONHASHSEED` set to 0, 1, 2, 3, and 4 all
reproduced the stored metrics exactly. This isolates the discrepancy to Python
hash-order sensitivity in a near-tie path rather than to the detour cache,
input conversion, missing geometry, or a relaxed numerical comparison.

## Resolution

The failed unpinned audit artifacts are retained under
`outputs/factory_xml_routes_v1/hash_seed_unpinned_diagnostic/`. The atomic
replay entry point now refuses to run unless `PYTHONHASHSEED=0`. A new full
2,753-route replay is required; the original route result file remains
unchanged.

This is an execution-environment amendment for reproducibility, not a
post-result method or parameter change. Manuscript claims should describe the
fixed-hash replay and should not claim that the current Stage7 implementation
is invariant to every Python hash seed.
