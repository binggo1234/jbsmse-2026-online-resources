# Factory holdout reproducibility guide

This guide reproduces the confirmatory analysis from the authorized,
cache-isolated v2 route result. It does not rerun the 11,784-board Track A route
experiment unless an upstream integrity audit fails.

## Frozen identities

The Stage7 algorithm source is commit
`083d869ee132a8d6c8f4d12deacb4c78bcbdb2a0`.

The only authorized Track A route result is:

`outputs/holdout_route_experiment_v1/route_results_cache_isolated.csv`

Its SHA-256 is:

`2df56a2d5700c1356bb78745e57d3eb69d87d6507222f48730b4a3b3e375aff2`

The file `route_results.csv` is quarantined v1 evidence. Its path and previously
recorded SHA may appear under `forbidden_input_identity`, but no analysis
program may open or derive a value from it.

## Environment

Run commands from:

`<WORKSPACE>`

The aggregation and statistical analysis use the Python standard library. The
paper figures additionally require Matplotlib. The analysis manifest records
the Python implementation, version, platform, program SHA, input SHAs, and
output SHAs.

## Track A analysis

Run all tests:

```bash
python3 -m pytest -q
```

Regenerate the task--seed table, task table, pairwise comparisons,
confirmatory statistics, secondary statistics, method summary, and seed
sensitivity:

```bash
python3 scripts/analyze_holdout_results.py
```

The program stops before writing method rankings unless it verifies the v2
SHA, the passed isolation audit, 58,920 unique completed route rows, all five
methods on every one of 11,784 boards, exactly 20 tasks, exactly three frozen
packing seeds per task, finite metrics, tool-event equality, and zero proposed
hard failures.

Independently recompute all aggregation and all 100,000 bootstrap replicates,
then compare every numerical artifact:

```bash
python3 scripts/audit_holdout_analysis.py
```

Generate the two LaTeX tables and two publication figures:

```bash
python3 scripts/generate_holdout_paper_artifacts.py
```

Figures are written as vector PDF and 300 dpi PNG. Their manifest hashes the
four analysis inputs, the generator, and every table/figure output.

## Track B original XML coordinates

Regenerate and freeze the XML geometry preflight:

```bash
python3 scripts/preflight_factory_xml.py
python3 scripts/run_factory_xml_routes.py freeze
python3 scripts/run_factory_xml_routes.py verify
```

Execute or resume the frozen 2,753-pattern, five-method schedule:

```bash
python3 scripts/run_factory_xml_routes.py run --resume
python3 scripts/run_factory_xml_routes.py audit
```

Replay all proposed routes and audit atomic-span coverage:

```bash
PYTHONHASHSEED=0 python3 scripts/audit_factory_xml_routes_atomic.py run --resume
PYTHONHASHSEED=0 python3 scripts/audit_factory_xml_routes_atomic.py summarize
```

The fixed Python hash seed is mandatory. An initial unpinned replay produced
one alternative but geometrically valid route; its failed audit is retained
under `outputs/factory_xml_routes_v1/hash_seed_unpinned_diagnostic/`, and the
diagnosis is recorded in `docs/track_b_hash_seed_diagnostic.md`. The formal
fixed-environment replay must report 2,753/2,753 passed routes and zero missing,
repeated, unknown, hard-failure, or stored-mismatch counts.

Regenerate the task-level Track B analysis and independently recompute its
primary summaries:

```bash
python3 scripts/analyze_factory_xml_results.py
python3 scripts/audit_factory_xml_analysis.py
```

The seven `confirmatory_holdout` tasks are the only independent inferential
units. Patterns are summed within task. The four
`excluded_prior_upstream_use` tasks are historical supplementary evidence and
remain outside the confirmatory p-values and bootstrap.

Track B uses original XML coordinates, not Track A repacking. The frozen
factory coordinate convention requires the recorded cutter center to stay
inside the stock domain while allowing the tool disk to overhang an exterior
stock edge.

## Manuscript integration

The generated tables and figures are copied into
`paper_sci_cutting_ijamt/` only after both analysis and figure manifests pass.
The manuscript must continue to describe the independent unit as the factory
task. It must not report `n=11,784`, `n=58,920`, or three packing seeds as an
inferential sample size.

The integrated manuscript is compiled to a separate validation directory so
that an existing manuscript PDF is not overwritten:

```bash
python3 <LOCAL_HOME>/.codex/plugins/cache/openai-bundled/latex/0.2.4/scripts/compile_latex.py \
  <STAGE7_REPOSITORY>/paper_sci_cutting_ijamt/main.tex \
  --output-directory <WORKSPACE>/outputs/ijamt_build_validation
```

The final evidence supports computational generalization and modeled
CAM-planning cost. It does not support measured CNC cycle-time reduction,
physical clamping stability, surface quality, dimensional tolerance, tool
life, or commercial-CAM superiority.
