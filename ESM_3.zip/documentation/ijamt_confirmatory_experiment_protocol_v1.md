# IJAMT 工厂数据确认性实验冻结协议 v1

冻结日期：2026-07-26  
状态：设计已冻结；执行前仍需完成代码快照清洁和原始 CSV 转换器等价性校验。

## 1. 研究问题

本实验不再开发新算法，也不再使用新增工厂任务调参。目标是回答两个确认性问题：

1. 冻结的 Stage7 方法能否推广到从未参与开发的工厂任务？
2. 冻结的方法能否在工厂原始排样坐标上生成覆盖完整、满足规划级约束的路线？

本协议将“工厂原始零件任务”“旧程序生成的排样结果”和“Stage7 kerf-aware
重新排样布局”视为三个不同的数据层级，禁止把同一工厂任务产生的多个种子、板材
或路线当作相互独立的工厂样本。

## 2. 冻结边界

### 2.1 算法冻结候选

- 仓库：`<STAGE7_REPOSITORY>`
- Git 提交：`083d869ee132a8d6c8f4d12deacb4c78bcbdb2a0`
- 主方法：`process_aware_beam_adaptive_polished`
- 重复切割策略：`hard`
- 支撑边集合：`all_edges`
- 最小剩余支撑长度比例：`0.75`
- 最小剩余支撑计数：`1`
- 面积归一化支撑阈值：`0`
- 邻接支撑权重：`1.0`
- safe-lift 长度等价代价：`250`
- Event-Gate：启用，`lambda_abs=25.0`，`lambda_rel=0`
- 刀具直径：`6 mm`
- 几何 kerf compensation：启用

当前工作树包含论文、绘图及另一个研究方向的未提交改动。因此该提交只是算法冻结
候选。正式运行前必须生成干净提交或带完整 SHA-256 清单的只读归档；不得在脏工作树
中直接产生确认性结果。

### 2.2 禁止事项

查看 holdout 结果后，不得：

- 修改目标函数层级、支撑阈值、刀具事件代价或 Event-Gate；
- 修改 beam width、candidate cap、局部搜索预算或候选组合；
- 根据 holdout 表现选择排样种子、板材或任务；
- 删除表现不佳但格式有效、几何可处理的任务；
- 将重复种子或同一任务内的多张板作为独立统计样本。

若冻结方法表现不佳，保留原结果并降低论文主张。任何后续改进只能作为明确标注的
探索性实验，不能替换本协议结果。

## 3. 数据血缘与分组

原始根目录：

`<CONTROLLED_FACTORY_DATA>`

任务级清单：

`data/factory_task_lineage_manifest_v1.csv`

清单冻结结果：

- 原始 CSV 任务：27
- 零件记录：39,267
- 曾进入旧 `data1`--`data6` 的任务：6
- 继续进入 Stage7 77-layout cohort 的任务：4
- 仅1条零件记录、预先排除的任务：1
- 从未参与上游开发的非平凡 holdout 任务：20
- 含可解析 XML 原始排样的任务：11
- XML 中的原始 `Pattern` 总数：2,753
- 在20个 holdout 中同时含 XML 的任务：7

`xml_available=yes` 只表示 XML 可以解析且其 `Workpiece` 数与相应 CSV 零件记录数
一致，不表示其坐标已经通过 6 mm 刀具补偿、边界或相交检查。

## 4. 原始 CSV 转换冻结门

原始 CSV 不是 Stage7 直接使用的布局文件。必须先建立一个确定性的 inventory
converter，但转换规则只能使用6个历史任务开发：

- `FACTORY_TASK_001` -> `data1`
- `FACTORY_TASK_003` -> `data2`
- `FACTORY_TASK_004` -> `data3`
- `FACTORY_TASK_REDACTED` -> `data4`
- `FACTORY_TASK_REDACTED` -> `data5`
- `FACTORY_TASK_008` -> `data6`

转换器必须处理字段编码、尺寸字段、数量展开、旋转/纹理约束、稳定 part id 和无效
记录。其验收标准是：对上述6个任务，转换后的零件尺寸多重集合与旧上游 inventory
逐任务完全一致，记录数分别为：

`2819, 2429, 1234, 2109, 1649, 1114`。

在该门通过并记录转换器提交哈希之前，禁止运行20个 holdout。若不能达到完全一致，
必须先形成差异报告；不得依据 holdout 内容选择字段解释。

## 5. Track A：20个未见工厂任务

### 5.1 实验单位与重复

- 独立实验单位：工厂任务 `task_id`，`n=20`。
- 嵌套重复：每个任务3个冻结排样种子。
- 排样种子：`1000, 1001, 1002`。
- 每个种子生成的全部板材均进入评价，不采用“最密板”选择。
- 同一布局上的所有方法共享完全相同的几何输入。

任务内部先对全部板材求和，再形成种子级结果；三个种子再取等权平均，最终每个任务
只贡献一个确认性统计值。该规则防止大任务或多板任务产生伪重复。

### 5.2 比较方法

冻结比较集：

1. `process_aware_beam_adaptive_polished`（proposed）
2. `process_aware_beam`
3. `topology_process_aware`
4. `process_local_search_multistart`
5. `endpoint_aware_gtsp`

所有可使用共享 process evaluator 的方法必须使用同一评价器和同一规划参数。不得
只给 proposed 增加计算预算。普通 beam 额外保留一个与 proposed 平均运行时间最接近
的预先定义预算档，作为质量--运行时间解释，不作为事后挑选的最佳基线。

### 5.3 主要终点

硬验收终点，对 proposed 的每张板均要求：

- atomic-span coverage ratio = `1.0`
- missing atomic spans = `0`
- unknown units = `0`
- hard-constraint penalty = `0`
- repeated atomic spans = `0`

确认性比较终点：

1. 在满足相同硬约束和支撑策略的路线中，proposed 相对
   `topology_process_aware` 的任务级 `C_plan` 配对变化；
2. proposed 与 `endpoint_aware_gtsp` 在 `rho=0.75` 下的任务级
   `C_plan`--support-policy tradeoff。

次要终点：

- travel-mode cost
- raw air-travel distance
- tool-event count
- support-policy penalty
- wall-clock runtime
- proposed 相对 ordinary beam 和 process-LS 的任务级变化

### 5.4 统计汇总

所有推断均以20个任务为单位：

- 任务等权平均和中位数；
- 任务级 win/tie/loss；
- 对任务进行 cluster bootstrap 的95%区间；
- 双侧配对符号检验作为小样本稳健补充；
- 同时报告最差任务和失败案例，不只报告平均改进。

种子和板材仅用于计算任务内部变异，不进入独立样本量。除任务级主分析外，可以补充
以任务为随机截距的嵌套模型，但不得替代任务级结果。

### 5.5 排除与缺失

唯一预先允许的任务排除：

- 清单已标记的单记录任务 `FACTORY_TASK_REDACTED`；
- 文件哈希不匹配或文件损坏；
- 转换器无法解析且在查看方法结果前已形成错误报告；
- 在冻结 kerf-aware 排样规则下无法生成任何几何有效板材。

最后一种情况必须计入“零有效布局任务”，不能静默删除。单个方法超时、崩溃或违反
硬约束属于该方法失败，不构成任务排除理由。

## 6. Track B：工厂原始 XML 坐标

Track B 与 Track A 分开报告，不重新排样。11个 XML 任务先执行盲于路线性能的几何
预审：

1. XML 解析和 `Pattern`/`Workpiece` 计数；
2. 板材尺寸、零件坐标、旋转角和边界检查；
3. 名义件相交检查；
4. 6 mm cutter-center compensation 可行性；
5. CSV 与 XML 零件多重集合一致性。

通过预审的每个 `Pattern` 均进入路线评价，不选择高密度或高收益案例。主要报告
coverage、hard constraint、support-policy 和运行时间；成本比较只能在相同原始坐标
和相同 evaluator 下配对进行。

其中7个 `confirmatory_holdout` XML 任务构成未见原始坐标验证；4个历史使用任务只作
补充和转换一致性验证。若部分 XML 因刀径或坐标问题不适用，必须逐任务报告理由。

## 7. 执行顺序与防污染规则

1. 保存本协议与数据清单，记录文件 SHA-256。
2. 建立干净代码快照并记录 Git commit、Python版本和依赖。
3. 在6个历史任务上开发并验证 CSV converter。
4. 锁定 converter 和实验命令，生成方法运行顺序表；调度种子为 `20260726`。
5. 运行 Track A 的格式/排样预检，但不生成方法汇总。
6. 对所有通过预检的布局一次性运行冻结方法。
7. 完成任务级汇总后才查看方法排名。
8. 独立执行 Track B 几何预审和原始坐标路线实验。
9. 生成不可覆盖的完整 manifest、stdout/stderr、超时和失败清单。

每个阶段都必须保留输入 SHA-256、命令、开始/结束时间、软件版本和输出 SHA-256。

## 8. 论文解释边界

通过本协议可以支持：

- 对未见工厂任务的计算推广性；
- 原子跨度覆盖和规划级工艺约束的一致执行；
- 在冻结 evaluator 下的路线质量和运行时间比较。

不能据此直接声称：

- 实测机床节拍降低；
- 物理夹持或真空吸附稳定性；
- 表面质量、尺寸公差或刀具寿命改进；
- 相对商业 CAM 的整体优越性。

这些结论仍需受控 CNC 试验和机器级时间标定。
