# IJAMT transparent NC-level kinematic evaluation freeze v1

## Scope

This experiment evaluates deterministic, controller-neutral NC programs generated
from the already frozen holdout routes. It establishes route-to-NC preservation
and timing robustness under fully disclosed kinematic assumptions. It is not a
machine-calibrated cycle-time study and does not validate workpiece motion,
dimensional accuracy, edge quality, spindle load, or tool wear.

## Frozen experimental units

- Independent statistical unit: factory task (`n = 20`).
- Nested units: three packing seeds and their generated boards.
- Full evaluation: 11,784 board-seed instances, five frozen routing methods, and
  58,920 method-board programs.
- Pilot gate: exactly five boards per factory task and all five methods, giving
  100 boards and 500 programs.
- The pilot is selected without reading route quality or NC timing. Within each
  task, one board is selected from every available packing seed by a seeded hash;
  remaining positions are filled by a second seeded within-task hash.

## Frozen NC template

- Metric and absolute coordinates: `G21`, `G90`.
- Cutter compensation disabled: `G40`.
- Generic three-axis controller-neutral program.
- Tool diameter: 6 mm.
- Stock thickness: 18 mm.
- Three 6 mm depth passes.
- Low-clearance Z: 1 mm above the stock surface.
- Safe Z: 5 mm above the stock surface.
- Cut feed: 3,600 mm/min.
- Plunge feed: 800 mm/min.
- Fixed start point from the frozen tool configuration.
- Final retract to safe Z and return to the fixed start point.

Each cutting action is completed through all three depth passes before the next
top-level route action. Pass direction alternates, so the third and final pass ends
at the route action's directed endpoint. This preserves the top-level action
completion order used by the planning evaluator. It is a canonical comparison
template, not a claim about a particular factory's preferred multipass strategy.

Travel actions retain their evaluated mode:

- `low_clearance` and `low_clearance_detour` move at low-clearance Z;
- `safe_lift` moves at safe Z;
- detour geometry is retained as the sequence of detour travel actions emitted by
  the route planner.

## Parser and hard route-to-NC audit

The modal parser supports the frozen canonical subset:

`G0/G1`, `G17`, `G20/G21`, `G40`, `G90/G91`, `F`, `S`, `T`, `X/Y/Z`,
`M3/M5/M6/M30`.

Any unsupported word, including `G2/G3`, is a hard failure. The audit requires:

- one-to-one top-level action indices in the original order;
- exactly one XY block per travel action;
- exactly three directed XY blocks per cutting action;
- preserved travel mode;
- no missing, extra, or reversed final-pass geometry;
- `G40`, explicit units, explicit coordinate mode, spindle start/stop, and one
  tool change;
- all XY coordinates within the panel;
- maximum route-to-NC coordinate error no greater than 0.001 mm.

## Prespecified kinematic scenarios

The cut speed is fixed at 60 mm/s. The full grid contains 27 scenarios:

- rapid speed: 100, 200, or 300 mm/s;
- XY acceleration: 500, 1,000, or 2,000 mm/s²;
- paired Z-axis rapid limits: (20 mm/s, 200 mm/s²),
  (40 mm/s, 500 mm/s²), or (60 mm/s, 1,000 mm/s²).

No retract, plunge, or tool-event latency is added on top of modeled motion time;
this avoids double counting. Non-motion delays are fixed at zero because no
controller-calibrated values are available. For every `G1` block, the effective
speed is the smaller of the scenario axis limit and the modal programmed feed.
Consequently, the 800 mm/min plunge command is honored in all scenarios, whereas
`G0` Z retracts use the scenario Z-axis rapid limit.

Two transparent estimates are reported:

- ideal continuous-motion estimate, which ignores acceleration transients;
- stop-at-junction estimate, which applies a triangular or trapezoidal
  acceleration profile to every non-collinear motion block after merging
  contiguous collinear blocks with the same motion class.

These are prespecified kinematic scenarios, not certified bounds on an unknown
controller.

## Outcomes and aggregation

Primary outcome: NC non-cutting time.

Secondary outcome: NC total time.

Components retained for audit include cut distance, rapid XY distance,
low-clearance distance, safe-lift distance, return distance, retract and plunge
distance/count, direction changes, and NC block count.

Boards are summed within each task-seed, packing seeds are averaged within each
factory task, and the 20 factory tasks receive equal weight. Parameter scenarios
are sensitivity conditions and are not treated as independent replicates.
GTSP timing and support-policy compliance are reported separately.

## Pilot gate

No method timing comparison may be inspected until all conditions pass:

- 500/500 jobs completed;
- zero route/reference metric mismatches;
- zero NC audit failures;
- zero unsupported NC words;
- maximum coordinate error no greater than 0.001 mm;
- exactly 27 scenario records per completed job.

Only after this gate passes may the unchanged pipeline process the full frozen
58,920-job list.
