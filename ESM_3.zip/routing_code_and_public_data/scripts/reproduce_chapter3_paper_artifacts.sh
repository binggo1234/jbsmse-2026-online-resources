#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

MODE="${1:-artifacts}"
export PYTHONPATH="src:experiments"
PRIVATE_DATA_ROOT="${CHAPTER3_PRIVATE_DATA_DIR:-$ROOT/data/private_archives}"
REVIEW_ARCHIVE="$PRIVATE_DATA_ROOT/review_overnight_20260422.zip"
STRONG_ARCHIVE="$PRIVATE_DATA_ROOT/strong_baseline_overnight_20260407_001243.zip"

run_private_route_artifacts() {
  if [[ ! -f "$REVIEW_ARCHIVE" || ! -f "$STRONG_ARCHIVE" ]]; then
    echo "Skipping private route-case artifact regeneration."
    echo "Set CHAPTER3_PRIVATE_DATA_DIR to a directory containing:"
    echo "  - review_overnight_20260422.zip"
    echo "  - strong_baseline_overnight_20260407_001243.zip"
    return 0
  fi

  python3 experiments/visualize_route_comparison.py \
    --zip-path "$REVIEW_ARCHIVE" \
    --placements-member 'review_overnight_20260422\review_t1_ind_a_5seed_300s\review_t1_ind_a_5seed_300s__data1\rh_mcts_prefix_beam\seed_1000\placements.csv' \
    --board-id 340 \
    --methods process_aware_beam process_aware_beam_adaptive_polished \
    --support-policy all_edges \
    --min-support-ratio 0.75 \
    --adjacency-support-weight 1 \
    --metrics-output results/paper_artifacts/event_gate_board340_route_metrics.csv \
    --diagnostics-dir results/paper_artifacts/event_gate_board340_diagnostics \
    --figure-output figures/paper_artifacts/fig_event_gate_board340_route_comparison.png

  python3 experiments/visualize_route_comparison.py \
    --zip-path "$STRONG_ARCHIVE" \
    --placements-member 'strong_baseline_overnight_20260407_001243/exp_strong_repeat_ind_5seed_300s/exp_strong_repeat_ind_5seed_300s__data4/rh_mcts_ref/seed_1004/placements.csv' \
    --board-id 239 \
    --methods process_aware_beam process_aware_beam_adaptive_polished \
    --support-policy all_edges \
    --min-support-ratio 0.75 \
    --adjacency-support-weight 1 \
    --metrics-output results/paper_artifacts/route_large_gain_with_polish_metrics.csv \
    --diagnostics-dir results/paper_artifacts/route_large_gain_with_polish_diagnostics \
    --figure-output figures/paper_artifacts/fig_route_large_gain_with_polish.png

  python3 experiments/plot_route_case_pair_summary.py \
    --data-root "$PRIVATE_DATA_ROOT" \
    --support-policy all_edges \
    --min-support-ratio 0.75 \
    --adjacency-support-weight 1 \
    --metrics-output results/paper_artifacts/route_case_pair_summary_metrics.csv \
    --figure-output figures/paper_artifacts/fig_route_case_pair_summary.pdf
}

if [[ "$MODE" == "full" ]]; then
  python3 experiments/run_chapter2_batch.py \
    --max-members-per-archive 20 \
    --boards-per-member 3 \
    --min-rectangles 20 \
    --max-rectangles 50 \
    --methods path_distance_local_search topology_process_aware process_local_search_multistart process_aware_beam process_aware_beam_adaptive process_aware_beam_polished process_aware_beam_adaptive_polished \
    --experiment-preset paper-main \
    --task-timeout-seconds 120 \
	    --output results/adaptive_event_gate_protected_real_20x3_20_50.csv \
	    --summary-output results/adaptive_event_gate_protected_real_20x3_20_50_summary.csv \
	    --bin-summary-output results/adaptive_event_gate_protected_real_20x3_20_50_bin_summary.csv \
	    --progress-output results/adaptive_event_gate_protected_real_20x3_20_50_progress.csv \
    --resume

  python3 experiments/analyze_results.py \
	    --input results/adaptive_event_gate_protected_real_20x3_20_50.csv \
	    --target-method process_aware_beam_adaptive_polished \
	    --baseline-methods topology_process_aware process_local_search_multistart process_aware_beam \
	    --output-dir results/analysis_adaptive_event_gate_protected_real_20x3_20_50 \
	    --figures-dir figures/analysis_adaptive_event_gate_protected_real_20x3_20_50

	  python3 experiments/analyze_portfolio_selection.py \
	    --input results/adaptive_event_gate_protected_real_20x3_20_50.csv \
	    --target-method process_aware_beam_adaptive_polished \
	    --component-methods process_aware_beam topology_process_aware process_local_search_multistart \
	    --unmatched-label event_gate_selected_candidate \
	    --output results/adaptive_event_gate_protected_selection.csv \
	    --summary-output results/adaptive_event_gate_protected_selection_summary.csv

  python3 experiments/analyze_tool_event_cases.py \
    --input results/adaptive_event_gate_protected_real_20x3_20_50.csv \
    --baseline-method process_aware_beam \
    --target-method process_aware_beam_adaptive_polished \
    --summary-output results/adaptive_event_gate_protected_tool_event_summary.csv \
    --increase-output results/adaptive_event_gate_protected_tool_event_increase_cases.csv \
    --markdown-output docs/event_gate_tool_event_case_analysis.md

  python3 experiments/analyze_statistical_robustness.py \
    --input results/adaptive_event_gate_protected_real_20x3_20_50.csv \
    --target-method process_aware_beam_adaptive_polished \
    --baseline-methods topology_process_aware process_local_search_multistart process_aware_beam \
    --output results/statistical_robustness_real_20_50.csv \
    --markdown-output docs/statistical_robustness_summary.md

  python3 experiments/run_ablation.py \
    --max-members-per-archive 20 \
    --boards-per-member 3 \
    --min-rectangles 20 \
    --max-rectangles 50 \
    --variants full_process_aware_beam process_aware_beam_polished single_edges_only no_stability_guidance no_adjacency_support_guidance topology_no_beam process_local_search_multistart path_distance_baseline no_detour_operator no_safe_travel_modes \
    --experiment-preset paper-main \
    --task-timeout-seconds 120 \
	    --output results/ablation_after_detour_intgraph_real_20_50.csv \
	    --summary-output results/ablation_after_detour_intgraph_real_20_50_summary.csv \
	    --progress-output results/ablation_after_detour_intgraph_real_20_50_progress.csv \
    --resume

  python3 experiments/analyze_results.py \
	    --input results/ablation_after_detour_intgraph_real_20_50.csv \
    --target-method full_process_aware_beam \
    --baseline-methods process_aware_beam_polished single_edges_only no_stability_guidance no_adjacency_support_guidance topology_no_beam process_local_search_multistart path_distance_baseline no_detour_operator no_safe_travel_modes \
    --output-dir results/analysis_ablation_full_real_20_50 \
    --figures-dir figures/analysis_ablation_full_real_20_50

  python3 experiments/run_exact_gap.py \
    --experiment-preset paper-main \
    --max-members-per-archive 2 \
    --boards-per-member 2 \
    --min-rectangles 1 \
    --max-rectangles 3 \
    --max-exact-units 12 \
    --methods exact_process_dp process_aware_beam process_aware_beam_adaptive process_aware_beam_polished process_aware_beam_adaptive_polished process_local_search_multistart topology_process_aware \
    --output results/exact_gap_small_real_final.csv \
    --summary-output results/exact_gap_small_real_final_summary.csv

  python3 experiments/run_adaptive_margin_sensitivity.py \
    --experiment-preset paper-main \
    --max-members-per-archive 20 \
    --boards-per-member 3 \
    --min-rectangles 20 \
    --max-rectangles 50 \
    --margins 0 250 500 750 1000 1500 \
    --task-timeout-seconds 120 \
	    --output results/adaptive_margin_sensitivity_after_detour_intgraph_real_20_50.csv \
	    --summary-output results/adaptive_margin_sensitivity_after_detour_intgraph_real_20_50_summary.csv \
	    --figure-dir figures/adaptive_margin_sensitivity_after_detour_intgraph_real_20_50 \
	    --progress-output results/adaptive_margin_sensitivity_after_detour_intgraph_real_20_50_progress.csv \
    --resume

  python3 experiments/run_tool_event_gate_sensitivity.py \
    --experiment-preset paper-main \
    --max-members-per-archive 20 \
    --boards-per-member 3 \
    --min-rectangles 20 \
    --max-rectangles 50 \
    --strategies no_gate fixed_100 current strict \
    --task-timeout-seconds 120 \
    --output results/tool_event_gate_sensitivity_real_20_50.csv \
    --summary-output results/tool_event_gate_sensitivity_real_20_50_summary.csv \
    --increase-output results/tool_event_gate_sensitivity_real_20_50_increase_cases.csv \
    --decision-output results/tool_event_gate_current_decisions_real_20_50.csv \
    --figure-dir figures/tool_event_gate_sensitivity_real_20_50 \
    --progress-output results/tool_event_gate_sensitivity_real_20_50_progress.csv \
    --resume

  python3 experiments/run_scalability.py \
    --experiment-preset paper-main \
    --scenario clustered \
    --sizes 50 75 100 \
    --repeats 3 \
    --methods topology_process_aware process_aware_beam process_aware_beam_adaptive_polished \
    --task-timeout-seconds 120 \
    --output results/scalability_final_clustered_50_100.csv \
    --progress-output results/scalability_final_clustered_50_100_progress.csv \
    --resume

  python3 experiments/run_scalability.py \
    --experiment-preset paper-main \
    --scenario grid \
    --sizes 50 \
    --repeats 1 \
    --methods topology_process_aware \
    --task-timeout-seconds 120 \
    --output results/scalability_grid50_topology_probe.csv \
    --progress-output results/scalability_grid50_topology_probe_progress.csv \
    --resume

  python3 experiments/run_scalability.py \
    --experiment-preset paper-main \
    --scenario grid \
    --sizes 50 \
    --repeats 1 \
    --methods process_aware_beam \
    --task-timeout-seconds 120 \
    --output results/scalability_grid50_beam_probe.csv \
    --progress-output results/scalability_grid50_beam_probe_progress.csv \
    --resume

  python3 experiments/run_scalability.py \
    --experiment-preset paper-main \
    --scenario grid \
    --sizes 50 \
    --repeats 1 \
    --methods process_aware_beam_adaptive_polished \
    --task-timeout-seconds 120 \
    --output results/scalability_grid50_adaptive_polished_probe.csv \
    --progress-output results/scalability_grid50_adaptive_polished_probe_progress.csv \
    --resume

  python3 experiments/analyze_scalability_results.py \
    --inputs results/scalability_final_clustered_50_100.csv results/scalability_grid50_topology_probe.csv results/scalability_grid50_beam_probe.csv results/scalability_grid50_adaptive_polished_probe.csv \
    --summary-output results/scalability_final_50_100_summary.csv \
    --figure-dir figures/scalability_final_50_100
elif [[ "$MODE" != "artifacts" ]]; then
  echo "Usage: $0 [artifacts|full]" >&2
  exit 2
fi

python3 experiments/analyze_tool_event_cases.py \
  --input results/adaptive_event_gate_protected_real_20x3_20_50.csv \
  --baseline-method process_aware_beam \
  --target-method process_aware_beam_adaptive_polished \
  --summary-output results/adaptive_event_gate_protected_tool_event_summary.csv \
  --increase-output results/adaptive_event_gate_protected_tool_event_increase_cases.csv \
  --markdown-output docs/event_gate_tool_event_case_analysis.md

python3 experiments/analyze_statistical_robustness.py \
  --input results/adaptive_event_gate_protected_real_20x3_20_50.csv \
  --target-method process_aware_beam_adaptive_polished \
  --baseline-methods topology_process_aware process_local_search_multistart process_aware_beam \
  --output results/statistical_robustness_real_20_50.csv \
  --markdown-output docs/statistical_robustness_summary.md

run_private_route_artifacts

python3 experiments/generate_paper_artifacts.py
python3 -m compileall -q src experiments tests

echo "Paper artifacts are ready in results/paper_artifacts and figures/paper_artifacts."
