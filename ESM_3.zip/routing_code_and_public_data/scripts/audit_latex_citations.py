#!/usr/bin/env python3
"""Audit LaTeX citations for duplicate insertion and manual bbl consistency."""

from __future__ import annotations

import argparse
import collections
import re
import sys
from pathlib import Path


CITE_RE = re.compile(
    r"\\(?:cite|citet|citep|citealp|citeauthor|citeyear)"
    r"(?:\[[^\]]*\]){0,2}\{([^}]*)\}"
)
BIBITEM_RE = re.compile(r"\\bibitem\{([^}]+)\}")
BIB_ENTRY_RE = re.compile(r"@\w+\s*\{\s*([^,\s]+)")


def strip_latex_comments(text: str) -> str:
    lines: list[str] = []
    for line in text.splitlines():
        out: list[str] = []
        for idx, char in enumerate(line):
            if char == "%" and (idx == 0 or line[idx - 1] != "\\"):
                break
            out.append(char)
        lines.append("".join(out))
    return "\n".join(lines)


def parse_cites(text: str) -> list[tuple[int, list[str], str]]:
    cites: list[tuple[int, list[str], str]] = []
    for match in CITE_RE.finditer(text):
        keys = [key.strip() for key in match.group(1).split(",") if key.strip()]
        line_no = text[: match.start()].count("\n") + 1
        cites.append((line_no, keys, match.group(0)))
    return cites


def paragraph_ranges(text: str) -> list[tuple[int, int, str]]:
    paragraphs: list[tuple[int, int, str]] = []
    start = 1
    buffer: list[str] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        if line.strip():
            if not buffer:
                start = line_no
            buffer.append(line)
        elif buffer:
            paragraphs.append((start, line_no - 1, "\n".join(buffer)))
            buffer = []
            start = line_no + 1
    if buffer:
        paragraphs.append((start, len(text.splitlines()), "\n".join(buffer)))
    return paragraphs


def ordered_unique(keys: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for key in keys:
        if key not in seen:
            seen.add(key)
            result.append(key)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Check LaTeX citation commands, bibitems, and first-citation order."
    )
    parser.add_argument("--tex", type=Path, required=True)
    parser.add_argument("--bbl", type=Path, required=True)
    parser.add_argument("--bib", type=Path, default=None)
    parser.add_argument(
        "--near-lines",
        type=int,
        default=8,
        help="Warn when identical citation sets appear within this line distance.",
    )
    args = parser.parse_args()

    tex = strip_latex_comments(args.tex.read_text())
    bbl = args.bbl.read_text()
    bib = args.bib.read_text() if args.bib and args.bib.exists() else ""

    cites = parse_cites(tex)
    cited_keys = [key for _, keys, _ in cites for key in keys]
    first_citation_order = ordered_unique(cited_keys)
    cited_counter = collections.Counter(cited_keys)

    bibitems = BIBITEM_RE.findall(bbl)
    bibitem_counter = collections.Counter(bibitems)
    bib_keys = BIB_ENTRY_RE.findall(bib)
    bib_counter = collections.Counter(bib_keys)

    errors: list[str] = []
    warnings: list[str] = []

    for line_no, keys, raw in cites:
        repeated = sorted(key for key, count in collections.Counter(keys).items() if count > 1)
        if repeated:
            errors.append(
                f"Line {line_no}: duplicate key(s) inside one citation command {repeated}: {raw}"
            )

    for start, end, paragraph in paragraph_ranges(tex):
        paragraph_keys = [
            key
            for _, keys, _ in parse_cites(paragraph)
            for key in keys
        ]
        repeated = sorted(
            (key, count)
            for key, count in collections.Counter(paragraph_keys).items()
            if count > 1
        )
        if repeated:
            errors.append(
                f"Lines {start}-{end}: repeated citation key(s) within one paragraph: {repeated}"
            )

    duplicate_bibitems = sorted(
        (key, count) for key, count in bibitem_counter.items() if count > 1
    )
    if duplicate_bibitems:
        errors.append(f"Duplicate \\\\bibitem keys: {duplicate_bibitems}")

    if bib:
        duplicate_bib_entries = sorted(
            (key, count) for key, count in bib_counter.items() if count > 1
        )
        if duplicate_bib_entries:
            errors.append(f"Duplicate BibTeX entry keys: {duplicate_bib_entries}")

    missing_from_bbl = sorted(set(cited_keys) - set(bibitems))
    if missing_from_bbl:
        errors.append(f"Cited key(s) missing from references_bbl.tex: {missing_from_bbl}")

    uncited_bibitems = sorted(set(bibitems) - set(cited_keys))
    if uncited_bibitems:
        errors.append(f"Uncited \\\\bibitem key(s): {uncited_bibitems}")

    if bib:
        missing_from_bib = sorted(set(cited_keys) - set(bib_keys))
        if missing_from_bib:
            errors.append(f"Cited key(s) missing from references.bib: {missing_from_bib}")

    if first_citation_order != bibitems:
        mismatches = [
            (idx, cite_key, bbl_key)
            for idx, (cite_key, bbl_key) in enumerate(
                zip(first_citation_order, bibitems), start=1
            )
            if cite_key != bbl_key
        ]
        if len(first_citation_order) != len(bibitems):
            errors.append(
                "Manual bbl item count differs from first-citation key count: "
                f"{len(bibitems)} vs {len(first_citation_order)}"
            )
        if mismatches:
            preview = mismatches[:10]
            errors.append(
                "references_bbl.tex is not ordered by first citation. "
                f"First mismatches: {preview}"
            )

    for (line_a, keys_a, _), (line_b, keys_b, _) in zip(cites, cites[1:]):
        if set(keys_a) == set(keys_b) and set(keys_a) and line_b - line_a <= args.near_lines:
            warnings.append(
                f"Lines {line_a} and {line_b}: identical nearby citation set {keys_a}"
            )

    frequent_reuse = [
        (key, count)
        for key, count in cited_counter.most_common()
        if count >= 4
    ]
    if frequent_reuse:
        warnings.append(
            "High-frequency reused citation key(s), review manually for over-citation: "
            f"{frequent_reuse}"
        )

    print(f"Citation commands: {len(cites)}")
    print(f"Unique cited keys: {len(first_citation_order)}")
    print(f"Bibitems: {len(bibitems)}")
    if bib:
        print(f"BibTeX entries: {len(bib_keys)}")

    if warnings:
        print("\nWarnings:")
        for warning in warnings:
            print(f"- {warning}")

    if errors:
        print("\nErrors:")
        for error in errors:
            print(f"- {error}")
        return 1

    print("\nCitation audit passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
