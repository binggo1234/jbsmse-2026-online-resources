from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_final_chapter3_main import (  # noqa: E402
    DEFAULT_METHODS,
    DEFAULT_TARGET_METHOD,
    build_batch_command,
    build_statistical_command,
    final_experiment_paths,
)


def test_final_experiment_paths_use_output_stem(tmp_path: Path) -> None:
    paths = final_experiment_paths(tmp_path, "final_run")

    assert paths.route_csv == tmp_path / "final_run.csv"
    assert paths.summary_csv == tmp_path / "final_run_summary.csv"
    assert paths.bin_summary_csv == tmp_path / "final_run_bin_summary.csv"
    assert paths.manifest_json == tmp_path / "final_run_manifest.json"
    assert paths.progress_csv == tmp_path / "final_run_progress.csv"
    assert paths.statistical_csv == tmp_path / "final_run_statistical.csv"
    assert paths.statistical_md == tmp_path / "final_run_statistical.md"


def test_build_batch_command_freezes_main_experiment_parameters(tmp_path: Path) -> None:
    paths = final_experiment_paths(tmp_path, "final_run")

    command = build_batch_command(
        paths,
        python_executable="python3",
        zip_paths=(),
        methods=DEFAULT_METHODS,
        max_members_per_archive=55,
        boards_per_member=1,
        min_rectangles=20,
        max_rectangles=50,
        task_timeout_seconds=30.0,
        fresh=False,
        progress_bar=False,
    )

    assert "run_chapter2_batch.py" in command[1]
    assert command[command.index("--experiment-preset") + 1] == "paper-main"
    assert command[command.index("--repeat-cut-policy") + 1] == "hard"
    assert command[command.index("--tool-event-min-travel-saving") + 1] == "25"
    assert command[command.index("--tool-event-min-travel-saving-ratio") + 1] == "0"
    assert command[command.index("--max-members-per-archive") + 1] == "55"
    assert command[command.index("--min-rectangles") + 1] == "20"
    assert command[command.index("--max-rectangles") + 1] == "50"
    assert "--resume" in command
    assert "--no-progress-bar" in command
    assert str(paths.route_csv) in command


def test_build_statistical_command_uses_adaptive_polished_as_target(
    tmp_path: Path,
) -> None:
    paths = final_experiment_paths(tmp_path, "final_run")
    baselines = tuple(method for method in DEFAULT_METHODS if method != DEFAULT_TARGET_METHOD)

    command = build_statistical_command(
        paths,
        python_executable="python3",
        target_method=DEFAULT_TARGET_METHOD,
        baseline_methods=baselines,
        metrics=("process_key", "travel_mode_cost"),
        bootstrap_samples=100,
        bootstrap_seed=7,
    )

    assert "analyze_statistical_robustness.py" in command[1]
    assert command[command.index("--target-method") + 1] == DEFAULT_TARGET_METHOD
    assert command[command.index("--bootstrap-samples") + 1] == "100"
    assert command[command.index("--bootstrap-seed") + 1] == "7"
    assert str(paths.statistical_csv) in command
    assert str(paths.statistical_md) in command
    assert all(method in command for method in baselines)
