from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_certified_exact_gap import structured_grid_layout  # noqa: E402


def test_small_structured_layout_uses_locked_kerf_channel() -> None:
    layout, tool = structured_grid_layout(3)

    assert tool.geometric_kerf_compensation
    assert tool.tool_diameter == 6.0
    assert len(layout.rectangles) == 3
    assert (
        layout.rectangles[1].x
        - (layout.rectangles[0].x + layout.rectangles[0].width)
        == 6.0
    )
    assert (
        layout.rectangles[2].x
        - (layout.rectangles[1].x + layout.rectangles[1].width)
        == 6.0
    )


def test_two_row_layout_reserves_vertical_tool_channel() -> None:
    layout, _tool = structured_grid_layout(4)
    lower_left, _lower_right, upper_left, _upper_right = layout.rectangles

    assert upper_left.y - (lower_left.y + lower_left.height) == 6.0
