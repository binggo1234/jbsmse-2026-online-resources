from __future__ import annotations

import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_multiseed_stochastic_baselines import (  # noqa: E402
    append_target_rows,
    combine_seed_rows,
)


def _row(case: str, method: str) -> dict[str, str]:
    return {
        "archive": "archive.zip",
        "placements_member": f"{case}/placements.csv",
        "board_id": case,
        "method": method,
    }


def test_combine_seed_rows_adds_algorithm_seed() -> None:
    methods = ("contour_aco", "process_aware_sa")
    rows = [_row("1", method) for method in methods]

    fields, combined = combine_seed_rows(
        ((11, rows), (12, rows)),
        methods,
    )

    assert "algorithm_seed" in fields
    assert len(combined) == 4
    assert {row["algorithm_seed"] for row in combined} == {"11", "12"}


def test_combine_seed_rows_rejects_unpaired_seed() -> None:
    with pytest.raises(ValueError, match="not fully paired"):
        combine_seed_rows(
            ((11, [_row("1", "contour_aco")]),),
            ("contour_aco", "process_aware_sa"),
        )


def test_append_target_rows_requires_matching_layouts() -> None:
    stochastic = [
        {
            **_row("1", "process_aware_sa"),
            "algorithm_seed": "11",
        }
    ]
    target = [_row("1", "process_aware_beam_adaptive_polished")]

    fields, combined = append_target_rows(
        list(stochastic[0]),
        stochastic,
        target,
    )

    assert "algorithm_seed" in fields
    assert combined[-1]["algorithm_seed"] == "deterministic"
