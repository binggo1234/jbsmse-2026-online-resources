from __future__ import annotations

import csv
import sys
from argparse import Namespace
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from plot_corrected_ablation_summary import build_summary  # noqa: E402


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def test_repeat_policy_panel_uses_process_span_count(tmp_path: Path) -> None:
    search = tmp_path / "search.csv"
    gate = tmp_path / "gate.csv"
    repeat_paths = {policy: tmp_path / f"{policy}.csv" for policy in ("hard", "soft", "off")}

    write_rows(
        search,
        [
            {"method": method, "cutting_length": 100.0, "travel_mode_cost": travel}
            for method, travel in (
                ("topology_process_aware", 50.0),
                ("process_aware_beam", 40.0),
                ("process_aware_beam_polished", 40.0),
                ("process_aware_beam_adaptive_polished", 35.0),
            )
        ],
    )
    write_rows(
        gate,
        [
            {
                "strategy": "current",
                "machining_cost_reduction_pct_mean": 1.0,
                "travel_mode_cost_reduction_pct_mean": 2.0,
                "tool_event_increase_count": 0,
                "tool_event_delta_mean": 0.0,
            }
        ],
    )
    for index, policy in enumerate(("hard", "soft", "off"), start=1):
        write_rows(
            repeat_paths[policy],
            [
                {
                    "cutting_length": 100.0,
                    "travel_mode_cost": 50.0,
                    "cut_repeated_segment_count": 99,
                    "process_repeated_span_count": index,
                }
            ],
        )

    summary = build_summary(
        Namespace(
            search_input=search,
            gate_input=gate,
            repeat_hard_input=repeat_paths["hard"],
            repeat_soft_input=repeat_paths["soft"],
            repeat_off_input=repeat_paths["off"],
        )
    )
    repeat = [row for row in summary if row["panel"] == "repeat_policy"]

    assert [row["repeated_spans_mean"] for row in repeat] == [1.0, 2.0, 3.0]
