from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from cnc_cutting.models import ToolConfig  # noqa: E402
from run_weight_sensitivity import (  # noqa: E402
    WeightSensitivityRow,
    build_weight_profiles,
    paired_summary_rows,
    summarize_rows,
    weighted_tool_config,
)


def test_weight_profiles_cross_travel_scale_and_safe_lift_cost() -> None:
    profiles = build_weight_profiles((0.5, 2.0), (100.0, 250.0))

    assert [profile.profile_name for profile in profiles] == [
        "travel0p5_lift100",
        "travel0p5_lift250",
        "travel2_lift100",
        "travel2_lift250",
    ]


def test_weighted_tool_config_scales_travel_weights_only() -> None:
    profile = build_weight_profiles((2.0,), (500.0,))[0]
    base_tool = ToolConfig(
        low_clearance_travel_weight=1.0,
        detour_travel_weight=1.5,
        safe_lift_travel_weight=2.0,
        safe_lift_fixed_cost=250.0,
    )

    tool = weighted_tool_config(base_tool, profile)

    assert tool.low_clearance_travel_weight == 2.0
    assert tool.detour_travel_weight == 3.0
    assert tool.safe_lift_travel_weight == 4.0
    assert tool.safe_lift_fixed_cost == 500.0


def row(method: str, machining_cost: float, profile: str = "travel1_lift250") -> WeightSensitivityRow:
    cutting_length = 100.0 if method == "target" else 130.0
    travel_mode_cost = machining_cost - cutting_length
    return WeightSensitivityRow(
        archive="a.zip",
        case_name="case",
        placement_method="rh",
        seed="seed_1",
        placements_member="placements.csv",
        board_id="1",
        profile_name=profile,
        travel_cost_scale=1.0,
        safe_lift_fixed_cost=250.0,
        low_clearance_travel_weight=1.0,
        detour_travel_weight=1.0,
        safe_lift_travel_weight=1.0,
        support_policy="all_edges",
        min_support_count=1,
        min_support_ratio=0.75,
        min_area_normalized_support=0.0,
        adjacency_support_weight=1.0,
        tool_event_gate_enabled=True,
        tool_event_min_travel_saving=25.0,
        tool_event_min_travel_saving_ratio=0.0,
        tool_event_min_machining_saving=1e-9,
        repeat_cut_policy="hard",
        method=method,
        runtime_ms=10.0,
        rectangle_count=20,
        candidate_unit_count=80,
        selected_unit_count=70,
        action_count=90,
        selected_composite_coverage_ratio=0.5,
        cut_repeated_segment_count=0,
        cut_duplicate_segment_length=0.0,
        redundant_cut_action_count=0,
        cutting_length=cutting_length,
        travel_mode_cost=travel_mode_cost,
        machining_cost=machining_cost,
        air_move_distance=travel_mode_cost,
        pierce_count=1,
        lift_count=1,
        safe_lift_count=0,
        safe_lift_distance=0.0,
        detour_count=1,
        detour_distance=travel_mode_cost,
        hard_penalty=0.0,
        stability_penalty=0.0,
    )


def test_summarize_rows_groups_by_profile_and_method() -> None:
    summary = summarize_rows((row("target", 150.0), row("target", 130.0)))

    assert len(summary) == 1
    assert summary[0].profile_name == "travel1_lift250"
    assert summary[0].method == "target"
    assert summary[0].n == 2
    assert summary[0].machining_cost_mean == 140.0


def test_paired_summary_reports_reduction_against_baseline() -> None:
    rows = (
        row("baseline", 200.0),
        row("target", 150.0),
        row("baseline", 180.0, profile="travel2_lift250"),
        row("target", 90.0, profile="travel2_lift250"),
    )

    paired = paired_summary_rows(
        rows,
        target_method="target",
        baseline_methods=("baseline",),
    )

    assert [item.profile_name for item in paired] == [
        "travel1_lift250",
        "travel2_lift250",
    ]
    assert paired[0].machining_cost_reduction_pct_mean == 25.0
    assert paired[1].machining_cost_reduction_pct_mean == 50.0
