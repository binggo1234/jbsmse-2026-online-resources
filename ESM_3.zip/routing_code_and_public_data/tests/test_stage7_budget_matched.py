from __future__ import annotations

from cnc_cutting.local_search import BeamSearchConfig

from experiments.run_stage7_budget_matched import (
    runtime_matched_variant,
    scaled_beam_config,
)
from experiments.analyze_stage7_budget_matched import summarize_matched_pair


def test_scaled_beam_config_scales_all_search_caps() -> None:
    base = BeamSearchConfig(
        beam_width=6,
        candidate_pool_size=18,
        max_expansions_per_node=36,
        max_layer_expansions=42,
        diversity_bucket_limit=1,
        min_expansions_per_parent=0,
        unstable_min_expansions_per_parent=2,
        unstable_layer_expansion_multiplier=1.0,
        repeat_cut_policy="hard",
    )

    scaled = scaled_beam_config(base, 2.0)

    assert scaled.beam_width == 12
    assert scaled.candidate_pool_size == 36
    assert scaled.max_expansions_per_node == 72
    assert scaled.max_layer_expansions == 84
    assert scaled.diversity_bucket_limit == 1
    assert scaled.unstable_min_expansions_per_parent == 2
    assert scaled.repeat_cut_policy == "hard"


def test_runtime_matched_variant_uses_runtime_not_quality() -> None:
    summaries = [
        {"variant": "beam_1x", "runtime_ms_mean": 700.0, "cplan_mean": 31000.0},
        {"variant": "beam_2x", "runtime_ms_mean": 1800.0, "cplan_mean": 32000.0},
        {"variant": "beam_3x", "runtime_ms_mean": 2500.0, "cplan_mean": 30000.0},
    ]

    selected = runtime_matched_variant(summaries, target_runtime_ms=1974.2)

    assert selected["variant"] == "beam_2x"


def test_summarize_matched_pair_groups_by_inventory() -> None:
    rows = [
        {
            "record_id": "r1",
            "inventory_sha256": "a",
            "variant": "beam_2p5x",
            "cplan": "100",
            "runtime_ms": "90",
        },
        {
            "record_id": "r1",
            "inventory_sha256": "a",
            "variant": "adaptive_portfolio",
            "cplan": "90",
            "runtime_ms": "100",
        },
        {
            "record_id": "r2",
            "inventory_sha256": "a",
            "variant": "beam_2p5x",
            "cplan": "100",
            "runtime_ms": "90",
        },
        {
            "record_id": "r2",
            "inventory_sha256": "a",
            "variant": "adaptive_portfolio",
            "cplan": "100",
            "runtime_ms": "100",
        },
        {
            "record_id": "r3",
            "inventory_sha256": "b",
            "variant": "beam_2p5x",
            "cplan": "100",
            "runtime_ms": "90",
        },
        {
            "record_id": "r3",
            "inventory_sha256": "b",
            "variant": "adaptive_portfolio",
            "cplan": "110",
            "runtime_ms": "100",
        },
    ]

    summary = summarize_matched_pair(
        rows,
        target_variant="adaptive_portfolio",
        baseline_variant="beam_2p5x",
    )

    assert summary["layout_wins"] == 1
    assert summary["layout_ties"] == 1
    assert summary["layout_losses"] == 1
    assert summary["inventory_wins"] == 1
    assert summary["inventory_losses"] == 1
    assert summary["inventory_equal_reduction_pct"] == -2.5
    assert summary["inventory_sign_test_p"] == 1.0
