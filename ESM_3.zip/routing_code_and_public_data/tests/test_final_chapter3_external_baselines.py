from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_final_chapter3_external_baselines import (  # noqa: E402
    DEFAULT_METHODS,
    DEFAULT_TARGET_METHOD,
)
from run_final_chapter3_main import build_batch_command, final_experiment_paths  # noqa: E402


def test_external_baseline_methods_include_standard_literature_baselines() -> None:
    assert DEFAULT_METHODS[0] == "greedy"
    assert "contour_tsp_2opt" in DEFAULT_METHODS
    assert "contour_aco" in DEFAULT_METHODS
    assert "endpoint_aware_gtsp" in DEFAULT_METHODS
    assert "path_distance_local_search" in DEFAULT_METHODS
    assert "topology" in DEFAULT_METHODS
    assert "process_aware_beam" in DEFAULT_METHODS
    assert DEFAULT_METHODS[-1] == DEFAULT_TARGET_METHOD


def test_external_baseline_batch_command_keeps_main_process_settings(
    tmp_path: Path,
) -> None:
    paths = final_experiment_paths(tmp_path, "external_baselines")

    command = build_batch_command(
        paths,
        python_executable="python3",
        zip_paths=(),
        methods=DEFAULT_METHODS,
        max_members_per_archive=55,
        boards_per_member=1,
        min_rectangles=20,
        max_rectangles=50,
        task_timeout_seconds=60.0,
        fresh=True,
        progress_bar=False,
    )

    assert command[command.index("--experiment-preset") + 1] == "paper-main"
    assert command[command.index("--repeat-cut-policy") + 1] == "hard"
    assert command[command.index("--tool-event-min-travel-saving") + 1] == "25"
    assert command[command.index("--tool-event-min-travel-saving-ratio") + 1] == "0"
    assert "--resume" not in command
    assert all(method in command for method in DEFAULT_METHODS)
