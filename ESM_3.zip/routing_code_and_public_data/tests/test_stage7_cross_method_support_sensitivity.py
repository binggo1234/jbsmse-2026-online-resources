from __future__ import annotations

from experiments.run_stage7_cross_method_support_sensitivity import (
    SUPPORT_RATIOS,
    summarize_cross_method_rows,
    summarize_inventory_rows,
)


def _row(
    record: str,
    method: str,
    rho: float,
    cplan: float,
    support_penalty: float,
) -> dict[str, str]:
    return {
        "placements_member": record,
        "board_id": "1",
        "method": method,
        "min_support_ratio": str(rho),
        "cutting_length": str(cplan - 10.0),
        "travel_mode_cost": "10.0",
        "stability_penalty": str(support_penalty),
        "hard_penalty": "0",
        "cut_missing_segment_count": "0",
        "runtime_ms": "100",
    }


def test_support_ratio_grid_includes_unrestricted_and_strict_settings() -> None:
    assert SUPPORT_RATIOS == (0.0, 0.25, 0.5, 0.75, 0.9)


def test_summary_reports_layout_and_inventory_equal_results() -> None:
    rows = [
        _row("r1", "process_aware_beam_adaptive_polished", 0.75, 90, 0),
        _row("r1", "topology_process_aware", 0.75, 100, 0),
        _row("r1", "endpoint_aware_gtsp", 0.75, 80, 2),
        _row("r2", "process_aware_beam_adaptive_polished", 0.75, 100, 0),
        _row("r2", "topology_process_aware", 0.75, 100, 0),
        _row("r2", "endpoint_aware_gtsp", 0.75, 90, 4),
        _row("r3", "process_aware_beam_adaptive_polished", 0.75, 110, 0),
        _row("r3", "topology_process_aware", 0.75, 100, 0),
        _row("r3", "endpoint_aware_gtsp", 0.75, 100, 6),
    ]
    inventories = {"r1": "a", "r2": "a", "r3": "b"}

    method_rows, paired_rows = summarize_cross_method_rows(rows, inventories)

    gtsp = next(row for row in method_rows if row["method"] == "endpoint_aware_gtsp")
    assert gtsp["layout_count"] == 3
    assert gtsp["inventory_count"] == 2
    assert gtsp["positive_support_penalty_layouts"] == 3
    assert gtsp["support_penalty_layout_mean"] == 4.0
    assert gtsp["support_penalty_inventory_equal_mean"] == 4.5

    topology_pair = next(
        row for row in paired_rows if row["baseline_method"] == "topology_process_aware"
    )
    assert topology_pair["layout_wins"] == 1
    assert topology_pair["layout_ties"] == 1
    assert topology_pair["layout_losses"] == 1
    assert topology_pair["inventory_count"] == 2
    assert topology_pair["inventory_equal_cplan_reduction_pct"] == -2.5

    inventory_rows = summarize_inventory_rows(rows, inventories)
    gtsp_a = next(
        row
        for row in inventory_rows
        if row["method"] == "endpoint_aware_gtsp"
        and row["inventory_sha256"] == "a"
    )
    assert gtsp_a["layout_count"] == 2
    assert gtsp_a["support_penalty_mean"] == 3.0
    assert gtsp_a["positive_support_penalty_layouts"] == 2
