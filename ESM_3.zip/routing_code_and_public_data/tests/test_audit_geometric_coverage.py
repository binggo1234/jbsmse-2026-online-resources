from __future__ import annotations

import csv
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from audit_geometric_coverage import discover_jobs  # noqa: E402


def test_discover_jobs_prefers_explicit_diagnostics_file(tmp_path: Path) -> None:
    diagnostics = tmp_path / "diagnostics" / "route.csv"
    diagnostics.parent.mkdir()
    diagnostics.write_text(
        "action_index,action_type,travel_mode,start_x,start_y,end_x,end_y,"
        "length,cutting_unit_id,segment_id,low_clearance_collision_penalty,"
        "collision_penalty,boundary_penalty,safe_lift_count,safe_lift_distance,"
        "detour_count,detour_distance,travel_mode_cost,stability_penalty_delta,"
        "released_parts_before,released_parts_after,unstable_parts_before,"
        "unstable_parts_after,unstable_part_ids_before,unstable_part_ids_after,"
        "processed_segments_before,processed_segments_after\n",
        encoding="utf-8",
    )
    metrics = tmp_path / "routes_metrics.csv"
    with metrics.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "archive",
                "placements_member",
                "board_id",
                "method",
                "diagnostics_file",
            ],
        )
        writer.writeheader()
        writer.writerow(
            {
                "archive": "archive.zip",
                "placements_member": "case/method/seed_1/placements.csv",
                "board_id": "340",
                "method": "process_aware_beam",
                "diagnostics_file": str(diagnostics),
            }
        )

    jobs, skipped = discover_jobs([metrics])

    assert skipped == []
    assert len(jobs) == 1
    assert jobs[0].diagnostics_file == diagnostics
