from __future__ import annotations

import csv
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_final_chapter3_ablations import (  # noqa: E402
    DEFAULT_TARGET_METHOD,
    build_variant_batch_command,
    default_ablation_groups,
    merge_variant_results,
)
from run_final_chapter3_main import final_experiment_paths  # noqa: E402


def test_default_ablation_groups_cover_core_experiments() -> None:
    groups = default_ablation_groups("ablate")

    assert set(groups) == {"repeat_policy", "tool_event_gate", "search_components"}
    assert [variant.repeat_cut_policy for variant in groups["repeat_policy"].variants] == [
        "hard",
        "soft",
        "off",
    ]
    assert groups["repeat_policy"].comparison_target == "repeat_policy_hard"
    assert [variant.name for variant in groups["tool_event_gate"].variants] == [
        "gate25",
        "gate_off",
        "old_gate100_rel2",
    ]
    assert groups["search_components"].component_target_method == DEFAULT_TARGET_METHOD


def test_build_variant_batch_command_applies_variant_parameters(tmp_path: Path) -> None:
    variant = default_ablation_groups("ablate")["tool_event_gate"].variants[2]

    command = build_variant_batch_command(
        variant,
        results_dir=tmp_path,
        python_executable="python3",
        zip_paths=(),
        max_members_per_archive=55,
        boards_per_member=1,
        min_rectangles=20,
        max_rectangles=50,
        task_timeout_seconds=30.0,
        fresh=False,
        progress_bar=False,
    )

    assert command[command.index("--repeat-cut-policy") + 1] == "hard"
    assert command[command.index("--tool-event-min-travel-saving") + 1] == "100"
    assert command[command.index("--tool-event-min-travel-saving-ratio") + 1] == "0.02"
    assert "--disable-tool-event-gate" not in command


def test_merge_variant_results_renames_method_and_drops_repeat_policy(
    tmp_path: Path,
) -> None:
    variants = default_ablation_groups("ablate")["repeat_policy"].variants[:2]
    for variant in variants:
        path = final_experiment_paths(tmp_path, variant.output_stem).route_csv
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=(
                    "archive",
                    "placements_member",
                    "board_id",
                    "repeat_cut_policy",
                    "method",
                    "travel_mode_cost",
                ),
            )
            writer.writeheader()
            writer.writerow(
                {
                    "archive": "a.zip",
                    "placements_member": "placements.csv",
                    "board_id": "1",
                    "repeat_cut_policy": variant.repeat_cut_policy,
                    "method": DEFAULT_TARGET_METHOD,
                    "travel_mode_cost": "10.0",
                }
            )

    output_path = tmp_path / "merged.csv"
    merge_variant_results(variants, results_dir=tmp_path, output_path=output_path)

    with output_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)

    assert "repeat_cut_policy" not in (reader.fieldnames or ())
    assert [row["method"] for row in rows] == ["repeat_policy_hard", "repeat_policy_soft"]
    assert [row["ablation_variant"] for row in rows] == [
        "repeat_policy_hard",
        "repeat_policy_soft",
    ]
