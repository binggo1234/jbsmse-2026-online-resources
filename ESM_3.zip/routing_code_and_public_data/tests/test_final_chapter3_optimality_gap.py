from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_final_chapter3_optimality_gap import (  # noqa: E402
    REFERENCE_EXACT,
    REFERENCE_PORTFOLIO,
    OptimalityGapRow,
    reference_kind_for_unit_count,
    summarize_rows,
)


def gap_row(
    *,
    method: str,
    reference_kind: str,
    selected_unit_count: int,
    runtime_ms: float,
    travel_mode_cost: float,
    reference_travel_mode_cost: float,
    process_key_winner: str,
) -> OptimalityGapRow:
    return OptimalityGapRow(
        archive="a.zip",
        case_name="case",
        placement_method="placement",
        seed="seed_1",
        placements_member="member/placements.csv",
        board_id="1",
        method=method,
        reference_kind=reference_kind,
        reference_method="exact_process_dp"
        if reference_kind == REFERENCE_EXACT
        else "process_aware_beam_adaptive_polished",
        reference_is_exact=reference_kind == REFERENCE_EXACT,
        rectangle_count=8,
        candidate_unit_count=40,
        selected_unit_count=selected_unit_count,
        action_count=20,
        runtime_ms=runtime_ms,
        reference_runtime_ms=100.0,
        exact_expanded_nodes=1000 if reference_kind == REFERENCE_EXACT else None,
        exact_retained_states=100 if reference_kind == REFERENCE_EXACT else None,
        hard_penalty=0.0,
        stability_penalty=0.0,
        repeated_cut_segment_count=0,
        repeated_cut_length=0.0,
        redundant_cut_action_count=0,
        travel_mode_cost=travel_mode_cost,
        machining_cost=travel_mode_cost + 1000.0,
        air_move_distance=travel_mode_cost,
        tool_event_count=10,
        reference_hard_penalty=0.0,
        reference_stability_penalty=0.0,
        reference_repeated_cut_segment_count=0,
        reference_repeated_cut_length=0.0,
        reference_redundant_cut_action_count=0,
        reference_travel_mode_cost=reference_travel_mode_cost,
        reference_machining_cost=reference_travel_mode_cost + 1000.0,
        travel_mode_cost_gap=travel_mode_cost - reference_travel_mode_cost,
        machining_cost_gap=travel_mode_cost - reference_travel_mode_cost,
        travel_mode_cost_gap_ratio=(
            travel_mode_cost - reference_travel_mode_cost
        )
        / reference_travel_mode_cost,
        travel_gap_comparable=True,
        comparable_travel_mode_cost_gap=travel_mode_cost
        - reference_travel_mode_cost,
        comparable_travel_mode_cost_gap_ratio=(
            travel_mode_cost - reference_travel_mode_cost
        )
        / reference_travel_mode_cost,
        process_key_winner=process_key_winner,
    )


def test_reference_kind_prefers_exact_when_unit_count_fits_cap() -> None:
    assert reference_kind_for_unit_count(12, 12, True) == REFERENCE_EXACT
    assert reference_kind_for_unit_count(13, 12, True) == REFERENCE_PORTFOLIO
    assert reference_kind_for_unit_count(13, 12, False) is None


def test_summarize_rows_groups_by_reference_kind_and_method() -> None:
    rows = (
        gap_row(
            method="process_aware_beam_adaptive_polished",
            reference_kind=REFERENCE_PORTFOLIO,
            selected_unit_count=18,
            runtime_ms=30.0,
            travel_mode_cost=1050.0,
            reference_travel_mode_cost=1000.0,
            process_key_winner="reference",
        ),
        gap_row(
            method="process_aware_beam_adaptive_polished",
            reference_kind=REFERENCE_PORTFOLIO,
            selected_unit_count=20,
            runtime_ms=50.0,
            travel_mode_cost=1000.0,
            reference_travel_mode_cost=1000.0,
            process_key_winner="tie",
        ),
    )

    summary = summarize_rows(rows)

    assert len(summary) == 1
    row = summary[0]
    assert row.reference_kind == REFERENCE_PORTFOLIO
    assert row.method == "process_aware_beam_adaptive_polished"
    assert row.n == 2
    assert row.runtime_ms_mean == 40.0
    assert row.selected_unit_count_mean == 19.0
    assert row.travel_mode_cost_gap_mean == 25.0
    assert row.comparable_case_count == 2
    assert row.comparable_travel_mode_cost_gap_mean == 25.0
    assert row.process_key_tie_count == 1
    assert row.process_key_loss_count == 1
