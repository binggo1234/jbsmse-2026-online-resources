from types import SimpleNamespace

import cnc_cutting.optimizer as optimizer
from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.models import (
    CuttingUnit,
    CuttingUnitType,
    EdgeRole,
    EdgeSegment,
    Layout,
    Panel,
    PathMetrics,
    PlacedRectangle,
    Point,
    ToolConfig,
)
from cnc_cutting.optimizer import (
    RoutePlan,
    ToolEventGateConfig,
    _best_process_route,
    contour_aco_unit_actions,
    contour_tsp_2opt_unit_actions,
    endpoint_aware_gtsp_unit_actions,
    greedy_unit_actions,
    plan_exact_process_dp_route,
    plan_process_aware_genetic_route,
    plan_process_aware_simulated_annealing_route,
    plan_contour_aco_route,
    plan_contour_tsp_2opt_route,
    plan_endpoint_aware_gtsp_route,
    plan_path_distance_local_search_route,
    plan_greedy_route,
    plan_local_search_route,
    plan_process_local_search_multistart_route,
    plan_process_aware_beam_adaptive_route,
    plan_process_aware_beam_adaptive_polished_route,
    plan_process_aware_beam_polished_route,
    plan_process_aware_beam_route,
    plan_topology_route,
    select_coverage_units,
)


def _single_unit(unit_id: str, start: Point, end: Point) -> CuttingUnit:
    segment = EdgeSegment(f"{unit_id}:edge", unit_id, EdgeRole.BOTTOM, start, end)
    return CuttingUnit(
        unit_id=unit_id,
        unit_type=CuttingUnitType.SINGLE_EDGE,
        segments=(segment,),
        start=start,
        end=end,
        covered_segment_ids=(segment.segment_id,),
    )


def _segment(segment_id: str, start: Point, end: Point) -> EdgeSegment:
    part_id, role = segment_id.split(":")
    return EdgeSegment(segment_id, part_id, EdgeRole(role), start, end)


def _composite_unit(
    unit_id: str,
    segment_ids: tuple[str, ...],
    unit_type: CuttingUnitType,
) -> CuttingUnit:
    segments = tuple(
        _segment(
            segment_id,
            Point(index * 20.0, 0.0),
            Point(index * 20.0 + 10.0, 0.0),
        )
        for index, segment_id in enumerate(segment_ids)
    )
    return CuttingUnit(
        unit_id=unit_id,
        unit_type=unit_type,
        segments=segments,
        start=segments[0].start,
        end=segments[-1].end,
        covered_segment_ids=segment_ids,
    )


def test_best_process_route_rejects_extra_tool_events_for_small_travel_gain() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    incumbent = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            travel_mode_cost=100,
            pierce_count=1,
            lift_count=1,
        ),
    )
    lower_travel_more_events = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            travel_mode_cost=80,
            pierce_count=3,
            lift_count=3,
        ),
    )

    assert _best_process_route((incumbent, lower_travel_more_events)) is incumbent


def test_best_process_route_accepts_extra_tool_events_for_large_travel_gain() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    incumbent = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            travel_mode_cost=400,
            pierce_count=1,
            lift_count=1,
        ),
    )
    lower_travel_more_events = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            travel_mode_cost=150,
            pierce_count=2,
            lift_count=2,
        ),
    )

    assert _best_process_route((incumbent, lower_travel_more_events)) is (
        lower_travel_more_events
    )


def test_best_process_route_rejects_extra_tool_events_below_relative_gain() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    incumbent = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            travel_mode_cost=10000,
            pierce_count=1,
            lift_count=1,
        ),
    )
    lower_travel_more_events = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            travel_mode_cost=9500,
            pierce_count=2,
            lift_count=3,
        ),
    )

    assert (
        _best_process_route(
            (incumbent, lower_travel_more_events),
            tool_event_gate=ToolEventGateConfig(
                min_travel_saving_per_extra_event=100.0,
                min_travel_saving_ratio_per_extra_event=0.02,
            ),
        )
        is incumbent
    )


def test_best_process_route_can_disable_tool_event_gate() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    incumbent = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=5000,
            travel_mode_cost=10000,
            pierce_count=1,
            lift_count=1,
        ),
    )
    lower_travel_more_events = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=5000,
            travel_mode_cost=9500,
            pierce_count=2,
            lift_count=3,
        ),
    )

    assert (
        _best_process_route(
            (incumbent, lower_travel_more_events),
            tool_event_gate=ToolEventGateConfig(enabled=False),
        )
        is lower_travel_more_events
    )


def test_process_aware_metaheuristic_planners_return_process_evaluated_routes() -> None:
    units = (
        _single_unit("near_start", Point(10, 10), Point(20, 10)),
        _single_unit("far", Point(110, 10), Point(120, 10)),
        _single_unit("middle", Point(30, 10), Point(40, 10)),
    )
    panel = Panel("P", 200, 100)
    tool = ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(10, 10))

    sa_plan = plan_process_aware_simulated_annealing_route(units, panel, tool)
    ga_plan = plan_process_aware_genetic_route(units, panel, tool)

    assert len(sa_plan.selected_units) == len(units)
    assert len(ga_plan.selected_units) == len(units)
    assert sa_plan.metrics.hard_penalty == 0
    assert ga_plan.metrics.hard_penalty == 0


def test_best_process_route_uses_configured_tool_event_gate_threshold() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    incumbent = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=5000,
            travel_mode_cost=400,
            pierce_count=1,
            lift_count=1,
        ),
    )
    lower_travel_more_events = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=5000,
            travel_mode_cost=150,
            pierce_count=2,
            lift_count=2,
        ),
    )

    assert (
        _best_process_route(
            (incumbent, lower_travel_more_events),
            tool_event_gate=ToolEventGateConfig(
                min_travel_saving_per_extra_event=200.0,
                min_travel_saving_ratio_per_extra_event=0.0,
            ),
        )
        is incumbent
    )


def test_best_process_route_keeps_protected_plan_even_below_relative_gain() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    incumbent = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=5000,
            travel_mode_cost=10000,
            pierce_count=1,
            lift_count=1,
        ),
    )
    protected_lower_travel_more_events = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=5000,
            travel_mode_cost=9500,
            pierce_count=2,
            lift_count=3,
        ),
    )

    assert (
        _best_process_route(
            (incumbent, protected_lower_travel_more_events),
            protected_plans=(protected_lower_travel_more_events,),
        )
        is protected_lower_travel_more_events
    )


def test_best_process_route_uses_process_key_when_tool_events_do_not_increase() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    incumbent = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=100,
            travel_mode_cost=100,
            pierce_count=1,
            lift_count=1,
        ),
    )
    lower_cutting_length = RoutePlan(
        selected_units=(unit,),
        actions=(),
        metrics=PathMetrics(
            cutting_length=90,
            travel_mode_cost=100,
            pierce_count=1,
            lift_count=1,
        ),
    )

    assert _best_process_route((incumbent, lower_cutting_length)) is lower_cutting_length


def test_select_coverage_units_prefers_near_shared_unit_over_duplicate_edges() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 0, 0, 10, 10),
            PlacedRectangle("B", 16, 0, 10, 10),
        ),
    )
    units = build_candidate_cutting_units(layout, ToolConfig(tool_diameter=6))

    selected = select_coverage_units(units)
    selected_unit_ids = {unit.unit_id for unit in selected}

    assert any(unit.unit_type == CuttingUnitType.NEAR_SHARED_CHANNEL for unit in selected)
    assert "single:A:right" not in selected_unit_ids
    assert "single:B:left" not in selected_unit_ids


def test_select_coverage_units_avoids_partial_overlap_when_single_edge_can_cover_gap() -> None:
    single_a = _composite_unit(
        "single:A:bottom",
        ("A:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    single_b = _composite_unit(
        "single:B:bottom",
        ("B:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    single_c = _composite_unit(
        "single:C:bottom",
        ("C:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    shared_ab = _composite_unit(
        "shared:A:B",
        ("A:bottom", "B:bottom"),
        CuttingUnitType.SHARED_EDGE,
    )
    chain_bc = _composite_unit(
        "chain:B:C",
        ("B:bottom", "C:bottom"),
        CuttingUnitType.COLLINEAR_CHAIN,
    )

    selected = select_coverage_units(
        (single_a, single_b, single_c, shared_ab, chain_bc)
    )
    selected_ids = {unit.unit_id for unit in selected}

    assert "shared:A:B" in selected_ids
    assert "single:C:bottom" in selected_ids
    assert "chain:B:C" not in selected_ids


def test_select_coverage_units_policy_off_keeps_relation_priority() -> None:
    single_a = _composite_unit(
        "single:A:bottom",
        ("A:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    single_b = _composite_unit(
        "single:B:bottom",
        ("B:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    single_c = _composite_unit(
        "single:C:bottom",
        ("C:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    shared_ab = _composite_unit(
        "shared:A:B",
        ("A:bottom", "B:bottom"),
        CuttingUnitType.SHARED_EDGE,
    )
    chain_bc = _composite_unit(
        "chain:B:C",
        ("B:bottom", "C:bottom"),
        CuttingUnitType.COLLINEAR_CHAIN,
    )

    selected = select_coverage_units(
        (single_a, single_b, single_c, shared_ab, chain_bc),
        repeat_cut_policy="off",
    )
    selected_ids = {unit.unit_id for unit in selected}

    assert "shared:A:B" in selected_ids
    assert "chain:B:C" in selected_ids
    assert "single:C:bottom" not in selected_ids


def test_select_coverage_units_soft_policy_keeps_composite_when_it_adds_coverage() -> None:
    single_a = _composite_unit(
        "single:A:bottom",
        ("A:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    single_b = _composite_unit(
        "single:B:bottom",
        ("B:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    single_c = _composite_unit(
        "single:C:bottom",
        ("C:bottom",),
        CuttingUnitType.SINGLE_EDGE,
    )
    shared_ab = _composite_unit(
        "shared:A:B",
        ("A:bottom", "B:bottom"),
        CuttingUnitType.SHARED_EDGE,
    )
    chain_bc = _composite_unit(
        "chain:B:C",
        ("B:bottom", "C:bottom"),
        CuttingUnitType.COLLINEAR_CHAIN,
    )

    selected = select_coverage_units(
        (single_a, single_b, single_c, shared_ab, chain_bc),
        repeat_cut_policy="soft",
    )
    selected_ids = {unit.unit_id for unit in selected}

    assert "shared:A:B" in selected_ids
    assert "chain:B:C" in selected_ids
    assert "single:C:bottom" not in selected_ids


def test_greedy_unit_actions_chooses_reversed_direction_when_closer() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    actions = greedy_unit_actions((unit,), Point(9, 0))

    assert actions[0].start == Point(9, 0)
    assert actions[0].end == Point(10, 0)
    assert actions[1].start == Point(10, 0)
    assert actions[1].end == Point(0, 0)


def test_contour_tsp_2opt_baseline_cuts_rectangle_as_continuous_contour() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(PlacedRectangle("A", 10, 10, 20, 10),),
    )
    units = build_candidate_cutting_units(layout, ToolConfig(trim_margin=0))

    actions = contour_tsp_2opt_unit_actions(units, Point(10, 10))

    assert [action.action_type.value for action in actions] == ["cut", "cut", "cut", "cut"]
    assert actions[0].start == Point(10, 10)
    assert actions[-1].end == Point(10, 10)


def test_contour_aco_baseline_cuts_rectangle_as_continuous_contour() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(PlacedRectangle("A", 10, 10, 20, 10),),
    )
    units = build_candidate_cutting_units(layout, ToolConfig(trim_margin=0))

    actions = contour_aco_unit_actions(units, Point(10, 10))

    assert [action.action_type.value for action in actions] == ["cut", "cut", "cut", "cut"]
    assert actions[0].start == Point(10, 10)
    assert actions[-1].end == Point(10, 10)


def test_endpoint_aware_gtsp_baseline_cuts_rectangle_as_continuous_contour() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(PlacedRectangle("A", 10, 10, 20, 10),),
    )
    units = build_candidate_cutting_units(layout, ToolConfig(trim_margin=0))

    actions = endpoint_aware_gtsp_unit_actions(units, Point(10, 10))

    assert [action.action_type.value for action in actions] == ["cut"] * 4
    assert actions[0].start == Point(10, 10)
    assert actions[-1].end == Point(10, 10)


def test_contour_tsp_2opt_baseline_uses_primitive_edges_not_shared_units() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 10, 10, 20, 10),
            PlacedRectangle("B", 30, 10, 20, 10),
        ),
    )
    units = build_candidate_cutting_units(layout, ToolConfig(trim_margin=0))

    plan = plan_contour_tsp_2opt_route(
        units,
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(10, 10)),
    )

    assert len(plan.selected_units) == 8
    assert {unit.unit_type for unit in plan.selected_units} == {CuttingUnitType.SINGLE_EDGE}
    assert plan.metrics.cutting_length == 120


def test_contour_aco_baseline_uses_primitive_edges_not_shared_units() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 10, 10, 20, 10),
            PlacedRectangle("B", 30, 10, 20, 10),
        ),
    )
    units = build_candidate_cutting_units(layout, ToolConfig(trim_margin=0))

    plan = plan_contour_aco_route(
        units,
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(10, 10)),
    )

    assert len(plan.selected_units) == 8
    assert {unit.unit_type for unit in plan.selected_units} == {CuttingUnitType.SINGLE_EDGE}
    assert plan.metrics.cutting_length == 120


def test_endpoint_aware_gtsp_baseline_uses_primitive_edges_not_shared_units() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 10, 10, 20, 10),
            PlacedRectangle("B", 30, 10, 20, 10),
        ),
    )
    units = build_candidate_cutting_units(layout, ToolConfig(trim_margin=0))

    plan = plan_endpoint_aware_gtsp_route(
        units,
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(10, 10)),
    )

    assert len(plan.selected_units) == 8
    assert {unit.unit_type for unit in plan.selected_units} == {
        CuttingUnitType.SINGLE_EDGE
    }
    assert plan.metrics.cutting_length == 120


def test_plan_greedy_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_greedy_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_topology_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_topology_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_local_search_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_local_search_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_path_distance_local_search_route_returns_process_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_path_distance_local_search_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_process_aware_beam_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_process_aware_beam_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_process_aware_beam_adaptive_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_process_aware_beam_adaptive_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_process_aware_beam_adaptive_polished_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_process_aware_beam_adaptive_polished_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_adaptive_polished_protects_multistart_candidate(monkeypatch) -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    panel = Panel("P", 100, 100)
    tool = ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0))

    def route(cost: float, events: int) -> RoutePlan:
        return RoutePlan(
            selected_units=(unit,),
            actions=(),
            metrics=PathMetrics(
                cutting_length=10,
                travel_mode_cost=cost,
                pierce_count=events,
                lift_count=events,
            ),
        )

    def result(cost: float, events: int):
        return SimpleNamespace(
            directed_units=(),
            actions=(),
            metrics=PathMetrics(
                cutting_length=10,
                travel_mode_cost=cost,
                pierce_count=events,
                lift_count=events,
            ),
            expanded_nodes=0,
            diagnostics=(),
        )

    monkeypatch.setattr(optimizer, "plan_topology_route", lambda *args, **kwargs: route(2000, 1))
    monkeypatch.setattr(
        optimizer,
        "process_aware_beam_search_order",
        lambda *args, **kwargs: result(1800, 1),
    )
    monkeypatch.setattr(
        optimizer,
        "process_local_search_multistart_order",
        lambda *args, **kwargs: result(0, 10),
    )

    plan = optimizer.plan_process_aware_beam_adaptive_polished_route(
        (unit,),
        panel,
        tool,
        tool_event_gate=ToolEventGateConfig(
            min_travel_saving_per_extra_event=1000.0,
            min_travel_saving_ratio_per_extra_event=0.0,
        ),
    )

    assert plan.metrics.travel_mode_cost == 0
    assert plan.metrics.pierce_count == 10


def test_adaptive_polished_fallback_is_not_suppressed_by_multistart(monkeypatch) -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))
    panel = Panel("P", 100, 100)
    tool = ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0))

    def route(cost: float, events: int) -> RoutePlan:
        return RoutePlan(
            selected_units=(unit,),
            actions=(),
            metrics=PathMetrics(
                cutting_length=10,
                travel_mode_cost=cost,
                pierce_count=events,
                lift_count=events,
            ),
        )

    def result(cost: float, events: int):
        return SimpleNamespace(
            directed_units=(),
            actions=(),
            metrics=PathMetrics(
                cutting_length=10,
                travel_mode_cost=cost,
                pierce_count=events,
                lift_count=events,
            ),
            expanded_nodes=0,
            diagnostics=(),
        )

    beam_results = iter((result(1800, 1), result(0, 12)))
    monkeypatch.setattr(optimizer, "plan_topology_route", lambda *args, **kwargs: route(2000, 1))
    monkeypatch.setattr(
        optimizer,
        "process_aware_beam_search_order",
        lambda *args, **kwargs: next(beam_results),
    )
    monkeypatch.setattr(
        optimizer,
        "process_local_search_multistart_order",
        lambda *args, **kwargs: result(500, 1),
    )

    plan = optimizer.plan_process_aware_beam_adaptive_polished_route(
        (unit,),
        panel,
        tool,
    )

    assert plan.metrics.travel_mode_cost == 0
    assert plan.metrics.pierce_count == 12


def test_plan_process_local_search_multistart_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_process_local_search_multistart_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_exact_process_dp_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_exact_process_dp_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1


def test_plan_process_aware_beam_polished_route_returns_incremental_metrics() -> None:
    unit = _single_unit("u1", Point(0, 0), Point(10, 0))

    plan = plan_process_aware_beam_polished_route(
        (unit,),
        Panel("P", 100, 100),
        ToolConfig(trim_margin=0, tool_diameter=6, start_point=Point(0, 0)),
    )

    assert len(plan.selected_units) == 1
    assert plan.metrics.cutting_length == 10
    assert plan.metrics.pierce_count == 1
    assert plan.metrics.lift_count == 1
