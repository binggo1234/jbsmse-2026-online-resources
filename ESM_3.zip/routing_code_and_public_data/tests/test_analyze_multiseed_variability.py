from experiments.analyze_multiseed_variability import SeedRow, summarize


def _row(case: str, method: str, seed: str, cost: float) -> SeedRow:
    return SeedRow(
        case_id=case,
        method=method,
        algorithm_seed=seed,
        values={
            "composite_planning_cost": cost,
            "travel_mode_cost": cost / 2.0,
            "air_move_distance": cost / 3.0,
            "tool_event_count": 4.0,
            "runtime_ms": 10.0,
        },
        hard_penalty=0.0,
        support_rule_penalty=0.0,
    )


def test_summarize_aggregates_seeds_within_layout_first() -> None:
    rows = (
        _row("A", "sa", "1", 10.0),
        _row("A", "sa", "2", 14.0),
        _row("B", "sa", "1", 20.0),
        _row("B", "sa", "2", 24.0),
    )

    summary = summarize(rows)[0]

    assert summary["layout_records"] == "2"
    assert summary["algorithm_seeds"] == "2"
    assert float(summary["composite_planning_cost_mean"]) == 17.0
    assert float(
        summary["composite_planning_cost_within_layout_std_mean"]
    ) == 2.0
