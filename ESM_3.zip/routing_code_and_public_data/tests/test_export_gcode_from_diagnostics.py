from pathlib import Path

from experiments.export_gcode_from_diagnostics import NcTemplate, emit_header


def test_nc_header_disables_controller_compensation_for_geometric_centerlines() -> None:
    lines = []

    emit_header(lines, Path("diagnostics.csv"), NcTemplate())

    assert "G40" in lines
    assert lines.index("G40") > lines.index("G17")
