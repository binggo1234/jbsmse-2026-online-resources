from experiments.abstraction_failure import (
    AbstractionVariant,
    audit_layout_abstraction,
)
from cnc_cutting.models import Layout, PlacedRectangle, ToolConfig


def partial_overlap_layout() -> Layout:
    return Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 10, 10, 20, 40),
            PlacedRectangle("B", 36, 20, 20, 10),
        ),
    )


def stage7_tool() -> ToolConfig:
    return ToolConfig(tool_diameter=6, geometric_kerf_compensation=True)


def test_nominal_whole_segment_control_fails_manufacturability() -> None:
    audit = audit_layout_abstraction(
        partial_overlap_layout(),
        stage7_tool(),
        AbstractionVariant.NOMINAL_WHOLE_SEGMENT,
    )

    assert audit.claimed_complete
    assert audit.missing_atomic_span_count == 0
    assert audit.finished_dimension_violation_count > 0
    assert audit.swept_disk_gouge_count > 0
    assert audit.false_completion


def test_compensated_whole_segment_hides_partial_overlap_residuals() -> None:
    audit = audit_layout_abstraction(
        partial_overlap_layout(),
        stage7_tool(),
        AbstractionVariant.COMPENSATED_WHOLE_SEGMENT,
    )

    assert audit.claimed_complete
    assert audit.missing_atomic_span_count > 0
    assert audit.partial_primitive_segment_count > 0
    assert audit.finished_dimension_violation_count == 0
    assert audit.swept_disk_gouge_count == 0
    assert audit.false_completion


def test_compensated_atomic_span_retains_residuals_and_passes() -> None:
    audit = audit_layout_abstraction(
        partial_overlap_layout(),
        stage7_tool(),
        AbstractionVariant.COMPENSATED_ATOMIC_SPAN,
    )

    assert audit.claimed_complete
    assert audit.missing_atomic_span_count == 0
    assert audit.repeated_atomic_span_count == 0
    assert audit.finished_dimension_violation_count == 0
    assert audit.swept_disk_gouge_count == 0
    assert not audit.false_completion
    assert audit.passed_all_audits

