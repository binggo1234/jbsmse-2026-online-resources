from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.manufacturability import (
    audit_cutting_units,
    finished_dimension_violations,
    swept_disk_no_gouge_violations,
)
from cnc_cutting.models import (
    CuttingUnit,
    CuttingUnitType,
    Layout,
    PlacedRectangle,
    Point,
    ToolConfig,
)


def test_compensated_units_pass_finished_dimension_and_no_gouge_audit() -> None:
    layout = Layout(
        "P",
        100,
        100,
        (
            PlacedRectangle("A", 10, 10, 20, 20),
            PlacedRectangle("B", 36, 10, 20, 20),
        ),
    )
    tool = ToolConfig(tool_diameter=6, geometric_kerf_compensation=True)
    units = build_candidate_cutting_units(layout, tool)

    assert audit_cutting_units(units, layout, tool.tool_radius) == ()


def test_uncompensated_centerline_fails_finished_dimension_audit() -> None:
    layout = Layout("P", 100, 100, (PlacedRectangle("A", 10, 10, 20, 20),))
    unit = build_candidate_cutting_units(layout, ToolConfig(tool_diameter=6))[0]

    violations = finished_dimension_violations(
        unit,
        {"A": layout.rectangles[0]},
        3,
    )

    assert {violation.violation_type for violation in violations} == {
        "incorrect_centerline_offset"
    }


def test_cut_through_part_fails_swept_disk_no_gouge_audit() -> None:
    layout = Layout("P", 100, 100, (PlacedRectangle("A", 10, 10, 20, 20),))
    unit = CuttingUnit(
        unit_id="bad",
        unit_type=CuttingUnitType.SINGLE_EDGE,
        segments=(),
        start=Point(0, 20),
        end=Point(40, 20),
    )

    violations = swept_disk_no_gouge_violations(unit, layout, 3)

    assert len(violations) == 1
    assert violations[0].violation_type == "swept_disk_gouges_nominal_part"
