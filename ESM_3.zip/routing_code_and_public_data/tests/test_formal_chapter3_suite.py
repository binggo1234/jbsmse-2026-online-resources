from __future__ import annotations

import sys
import argparse
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from chapter3_formal_config import (  # noqa: E402
    FORMAL_ARCHIVES,
    FORMAL_OUTPUT_STEMS,
    FORMAL_REPEAT_CUT_POLICY,
    FORMAL_TARGET_METHOD,
    FormalSuiteConfig,
    archive_args,
    formal_layout_args,
)
from run_formal_chapter3_suite import (  # noqa: E402
    build_formal_commands,
    default_suite_manifest_path,
    write_suite_manifest,
)


def test_formal_archive_args_include_all_archives() -> None:
    args = archive_args(FORMAL_ARCHIVES)

    assert args.count("--zip-path") == len(FORMAL_ARCHIVES)
    assert all(str(path) in args for path in FORMAL_ARCHIVES)


def test_formal_layout_args_freeze_record_selection(tmp_path: Path) -> None:
    config = FormalSuiteConfig(results_dir=tmp_path)
    args = formal_layout_args(config)

    assert args[args.index("--max-members-per-archive") + 1] == "55"
    assert args[args.index("--boards-per-member") + 1] == "1"
    assert args[args.index("--min-rectangles") + 1] == "20"
    assert args[args.index("--max-rectangles") + 1] == "50"


def test_formal_suite_builds_main_external_and_meta_commands(tmp_path: Path) -> None:
    config = FormalSuiteConfig(results_dir=tmp_path)
    commands = {item.name: item for item in build_formal_commands(config, fresh=True)}

    assert {"main", "external", "metaheuristic"} <= set(commands)
    main = commands["main"].command
    external = commands["external"].command
    meta = commands["metaheuristic"].command

    assert "run_final_chapter3_main.py" in main[1]
    assert main[main.index("--output-stem") + 1] == FORMAL_OUTPUT_STEMS["main"]
    assert main[main.index("--repeat-cut-policy") + 1] == FORMAL_REPEAT_CUT_POLICY
    assert main[main.index("--tool-event-min-travel-saving") + 1] == "25"
    assert main[main.index("--tool-event-min-machining-saving") + 1] == "1e-09"
    assert "--fresh" in main

    assert "run_final_chapter3_external_baselines.py" in external[1]
    assert external[external.index("--target-method") + 1] == FORMAL_TARGET_METHOD
    assert "--no-progress-bar" in external
    assert "--resume" not in external

    assert "run_meta_heuristic_sa.py" in meta[1]
    assert meta[meta.index("--task-timeout-seconds") + 1] == "90"


def test_formal_suite_default_is_resume_safe(tmp_path: Path) -> None:
    config = FormalSuiteConfig(results_dir=tmp_path)
    commands = {item.name: item for item in build_formal_commands(config, fresh=False)}

    assert "--fresh" not in commands["main"].command
    assert "--resume" in commands["external"].command
    assert "--resume" in commands["metaheuristic"].command
    assert "--resume" in commands["weight"].command


def test_formal_suite_freezes_sensitivity_and_detour_commands(tmp_path: Path) -> None:
    config = FormalSuiteConfig(results_dir=tmp_path, figure_dir=tmp_path / "figures")
    commands = {item.name: item for item in build_formal_commands(config, fresh=False)}

    weight = commands["weight"].command
    event_gate = commands["event_gate"].command
    detour = commands["detour_cache"].command

    assert weight[weight.index("--travel-cost-scales") + 1 : weight.index("--safe-lift-fixed-costs")] == (
        "0.5",
        "1",
        "2",
    )
    assert weight[weight.index("--safe-lift-fixed-costs") + 1] == "250"
    assert str(tmp_path / f"{FORMAL_OUTPUT_STEMS['weight']}_manifest.json") in weight

    assert "run_tool_event_gate_sensitivity.py" in event_gate[1]
    assert event_gate[event_gate.index("--decision-output") + 1].endswith("_decisions.csv")

    assert "run_detour_cache_sensitivity.py" in detour[1]
    assert detour[detour.index("--obstacle-counts") + 1 :] == (
        "1",
        "4",
        "9",
        "16",
        "25",
        "36",
        "49",
        "64",
    )


def test_write_suite_manifest_records_commands_and_expected_outputs(
    tmp_path: Path,
) -> None:
    config = FormalSuiteConfig(results_dir=tmp_path, figure_dir=tmp_path / "figures")
    commands = build_formal_commands(config, fresh=False)
    manifest = default_suite_manifest_path(config)

    write_suite_manifest(
        manifest,
        config=config,
        args=argparse.Namespace(tasks=("main",), dry_run=False),
        commands=commands[:2],
    )

    data = json.loads(manifest.read_text(encoding="utf-8"))
    assert data["experiment_name"] == "chapter3_formal_suite"
    assert data["extra"]["formal_run_id"] == config.run_id
    assert data["extra"]["command_count"] == 2
    assert [item["name"] for item in data["extra"]["commands"]] == ["main", "external"]
    assert any(
        str(tmp_path / f"{FORMAL_OUTPUT_STEMS['main']}.csv") == item["path"]
        for item in data["outputs"]
    )
