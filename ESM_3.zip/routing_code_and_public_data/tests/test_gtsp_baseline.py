from itertools import product

import pytest

from cnc_cutting.gtsp_baseline import (
    EndpointAwareGTSPConfig,
    _best_options_for_order,
    endpoint_aware_gtsp_order,
)
from cnc_cutting.models import CuttingUnit, CuttingUnitType, EdgeRole, EdgeSegment, Point
from cnc_cutting.topology_operators import DirectedUnitCandidate


def _candidate(
    unit_id: str,
    start: Point,
    end: Point,
) -> DirectedUnitCandidate:
    segment = EdgeSegment(
        segment_id=f"{unit_id}:edge",
        part_id=unit_id.split(":")[0],
        role=EdgeRole.BOTTOM,
        start=start,
        end=end,
    )
    unit = CuttingUnit(
        unit_id=unit_id,
        unit_type=CuttingUnitType.SINGLE_EDGE,
        segments=(segment,),
        start=start,
        end=end,
        covered_segment_ids=(segment.segment_id,),
    )
    return DirectedUnitCandidate(
        unit=unit,
        start=start,
        end=end,
        direction=(1.0, 0.0),
    )


def test_fixed_order_dynamic_program_matches_brute_force() -> None:
    options = {
        "A": (
            (_candidate("A:0", Point(0, 0), Point(0, 0)),),
            (_candidate("A:1", Point(10, 0), Point(10, 0)),),
        ),
        "B": (
            (_candidate("B:0", Point(1, 0), Point(1, 0)),),
            (_candidate("B:1", Point(11, 0), Point(11, 0)),),
        ),
        "C": (
            (_candidate("C:0", Point(2, 0), Point(2, 0)),),
            (_candidate("C:1", Point(12, 0), Point(12, 0)),),
        ),
    }
    order = ("A", "B", "C")

    selected, distance = _best_options_for_order(order, options, Point(0, 0))
    brute_force = min(
        abs(choice[0][0].start.x)
        + sum(
            abs(previous[0].end.x - current[0].start.x)
            for previous, current in zip(choice, choice[1:])
        )
        for choice in product(*(options[part_id] for part_id in order))
    )

    assert distance == pytest.approx(brute_force)
    assert tuple(option[0].unit.unit_id for option in selected) == (
        "A:0",
        "B:0",
        "C:0",
    )


def test_endpoint_aware_search_is_deterministic() -> None:
    options = {
        "A": ((_candidate("A:0", Point(20, 0), Point(20, 0)),),),
        "B": ((_candidate("B:0", Point(5, 0), Point(5, 0)),),),
        "C": ((_candidate("C:0", Point(10, 0), Point(10, 0)),),),
    }
    config = EndpointAwareGTSPConfig(max_iterations=3, max_neighbors_per_iteration=20)

    first = endpoint_aware_gtsp_order(options, Point(0, 0), config=config)
    second = endpoint_aware_gtsp_order(options, Point(0, 0), config=config)

    assert first == second
    assert first.part_order == ("B", "C", "A")
    assert first.travel_distance == pytest.approx(20.0)
