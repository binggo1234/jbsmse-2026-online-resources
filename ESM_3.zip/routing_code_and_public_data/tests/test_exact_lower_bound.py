from itertools import permutations, product

import pytest

pytest.importorskip("ortools")

from cnc_cutting.exact_lower_bound import exact_static_routing_lower_bound
from cnc_cutting.geometry import euclidean_distance
from cnc_cutting.models import (
    CuttingUnit,
    CuttingUnitType,
    EdgeRole,
    EdgeSegment,
    Point,
)
from cnc_cutting.topology_operators import directed_unit_candidates


def unit(unit_id: str, start: Point, end: Point) -> CuttingUnit:
    segment = EdgeSegment(
        f"{unit_id}:edge",
        unit_id,
        EdgeRole.BOTTOM,
        start,
        end,
    )
    return CuttingUnit(
        unit_id=unit_id,
        unit_type=CuttingUnitType.SINGLE_EDGE,
        segments=(segment,),
        start=start,
        end=end,
        covered_segment_ids=(segment.segment_id,),
    )


def test_static_lower_bound_matches_bruteforce_oriented_path() -> None:
    units = (
        unit("a", Point(0, 0), Point(10, 0)),
        unit("b", Point(30, 0), Point(40, 0)),
        unit("c", Point(15, 10), Point(25, 10)),
    )
    start = Point(0, 0)

    result = exact_static_routing_lower_bound(units, start)
    brute_force = []
    for order in permutations(units):
        for choices in product((0, 1), repeat=len(order)):
            directed = tuple(
                directed_unit_candidates(item)[choice]
                for item, choice in zip(order, choices)
            )
            distance = euclidean_distance(start, directed[0].start)
            distance += sum(
                euclidean_distance(first.end, second.start)
                for first, second in zip(directed, directed[1:])
            )
            brute_force.append(distance)

    assert result.optimality_proven
    assert result.travel_distance_lower_bound == pytest.approx(min(brute_force))
    assert len(result.directed_units) == len(units)
