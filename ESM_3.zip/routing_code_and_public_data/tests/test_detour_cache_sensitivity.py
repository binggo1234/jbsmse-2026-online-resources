from __future__ import annotations

import csv
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_detour_cache_sensitivity import run_sensitivity, write_rows  # noqa: E402


def test_detour_cache_sensitivity_writes_runtime_rows(tmp_path: Path) -> None:
    rows = run_sensitivity((1, 4), repeats=1)
    output_csv = tmp_path / "detour_cache.csv"

    write_rows(rows, output_csv)

    with output_csv.open(newline="", encoding="utf-8") as handle:
        loaded = list(csv.DictReader(handle))

    assert len(loaded) == 2
    assert {row["obstacle_count"] for row in loaded} == {"1", "4"}
    assert all(float(row["cold_ms_mean"]) >= 0.0 for row in loaded)
    assert all(float(row["cached_ms_mean"]) >= 0.0 for row in loaded)
    assert all(int(row["estimated_grid_nodes"]) > 0 for row in loaded)
