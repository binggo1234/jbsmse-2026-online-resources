from experiments.audit_stage7_route_spans import audit_span_ids


def test_atomic_span_audit_accepts_complete_nonrepeated_route() -> None:
    missing, repeated, unknown, ratio = audit_span_ids(
        {"a", "b", "c"},
        ["shared", "residual"],
        {"shared": ("a", "b"), "residual": ("c",)},
    )

    assert (missing, repeated, unknown, ratio) == (0, 0, 0, 1.0)


def test_atomic_span_audit_reports_missing_repeat_and_unknown_unit() -> None:
    missing, repeated, unknown, ratio = audit_span_ids(
        {"a", "b", "c"},
        ["shared", "shared", "unknown"],
        {"shared": ("a", "b")},
    )

    assert missing == 1
    assert repeated == 2
    assert unknown == 1
    assert ratio == 2 / 3
