from __future__ import annotations

import csv
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from analyze_optimality_gap_failures import (  # noqa: E402
    collect_failures,
    summarize_failures,
    write_markdown,
)


FIELDS = (
    "archive",
    "case_name",
    "placement_method",
    "seed",
    "placements_member",
    "board_id",
    "method",
    "reference_kind",
    "reference_method",
    "rectangle_count",
    "candidate_unit_count",
    "selected_unit_count",
    "action_count",
    "runtime_ms",
    "reference_runtime_ms",
    "hard_penalty",
    "reference_hard_penalty",
    "stability_penalty",
    "reference_stability_penalty",
    "repeated_cut_segment_count",
    "reference_repeated_cut_segment_count",
    "repeated_cut_length",
    "reference_repeated_cut_length",
    "redundant_cut_action_count",
    "reference_redundant_cut_action_count",
    "tool_event_count",
    "travel_mode_cost",
    "reference_travel_mode_cost",
    "travel_mode_cost_gap",
    "travel_mode_cost_gap_ratio",
    "travel_gap_comparable",
    "comparable_travel_mode_cost_gap",
    "comparable_travel_mode_cost_gap_ratio",
    "machining_cost",
    "reference_machining_cost",
    "machining_cost_gap",
    "process_key_winner",
)


def row(
    *,
    method: str,
    process_key_winner: str,
    reference_kind: str = "portfolio_upper_bound",
    reference_method: str = "process_local_search_multistart",
    gap: float = 10.0,
) -> dict[str, str]:
    values = {
        "archive": "a.zip",
        "case_name": "case",
        "placement_method": "placement",
        "seed": "seed_1",
        "placements_member": "member/placements.csv",
        "board_id": "1",
        "method": method,
        "reference_kind": reference_kind,
        "reference_method": reference_method,
        "rectangle_count": "8",
        "candidate_unit_count": "40",
        "selected_unit_count": "20",
        "action_count": "30",
        "runtime_ms": "50",
        "reference_runtime_ms": "100",
        "hard_penalty": "0",
        "reference_hard_penalty": "0",
        "stability_penalty": "0",
        "reference_stability_penalty": "0",
        "repeated_cut_segment_count": "0",
        "reference_repeated_cut_segment_count": "0",
        "repeated_cut_length": "0",
        "reference_repeated_cut_length": "0",
        "redundant_cut_action_count": "0",
        "reference_redundant_cut_action_count": "0",
        "tool_event_count": "12",
        "travel_mode_cost": str(1000 + gap),
        "reference_travel_mode_cost": "1000",
        "travel_mode_cost_gap": str(gap),
        "travel_mode_cost_gap_ratio": str(gap / 1000),
        "travel_gap_comparable": "True",
        "comparable_travel_mode_cost_gap": str(gap),
        "comparable_travel_mode_cost_gap_ratio": str(gap / 1000),
        "machining_cost": str(2000 + gap),
        "reference_machining_cost": "2000",
        "machining_cost_gap": str(gap),
        "process_key_winner": process_key_winner,
    }
    return {field: values[field] for field in FIELDS}


def write_gap_csv(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def test_collect_failures_filters_target_reference_losses(tmp_path: Path) -> None:
    path = tmp_path / "gap.csv"
    write_gap_csv(
        path,
        [
            row(
                method="process_aware_beam_adaptive_polished",
                process_key_winner="reference",
                reference_method="process_local_search_multistart",
                gap=20,
            ),
            row(
                method="process_aware_beam_adaptive_polished",
                process_key_winner="tie",
                reference_method="process_aware_beam",
                gap=0,
            ),
            row(
                method="process_aware_beam",
                process_key_winner="reference",
                reference_method="exact_process_dp",
                gap=5,
            ),
        ],
    )

    failures = collect_failures((path,), "process_aware_beam_adaptive_polished")

    assert len(failures) == 1
    assert failures[0].reference_method == "process_local_search_multistart"
    assert failures[0].attribution_category == "missing multistart local-search candidate"
    assert failures[0].travel_mode_cost_gap == 20


def test_summarize_failures_groups_by_category_and_writes_markdown(tmp_path: Path) -> None:
    path = tmp_path / "gap.csv"
    write_gap_csv(
        path,
        [
            row(
                method="process_aware_beam_adaptive_polished",
                process_key_winner="reference",
                reference_method="process_aware_beam_polished",
                gap=4,
            ),
            row(
                method="process_aware_beam_adaptive_polished",
                process_key_winner="reference",
                reference_method="process_aware_beam_polished",
                gap=6,
            ),
        ],
    )

    failures = collect_failures((path,), "process_aware_beam_adaptive_polished")
    summaries = summarize_failures(failures)
    markdown_path = tmp_path / "report.md"
    write_markdown(failures, summaries, markdown_path)

    assert len(summaries) == 1
    assert summaries[0].n == 2
    assert summaries[0].travel_mode_cost_gap_mean == 5
    assert summaries[0].comparable_travel_mode_cost_gap_mean == 5
    assert "fixed polished-beam variant gap" in markdown_path.read_text(encoding="utf-8")
