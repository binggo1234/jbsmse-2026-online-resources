from cnc_cutting.kerf_packing import (
    KerfPackingPart,
    pack_kerf_envelopes,
    select_formal_board,
)


def part(part_id: str, width: float, height: float, diameter: float = 6.0):
    return KerfPackingPart(
        part_id=part_id,
        raw_part_id=part_id,
        nominal_width=width,
        nominal_height=height,
        envelope_width=width + diameter,
        envelope_height=height + diameter,
    )


def test_pack_kerf_envelopes_keeps_every_part_and_prevents_overlap() -> None:
    boards = pack_kerf_envelopes(
        (part("A", 40, 20), part("B", 40, 20), part("C", 40, 20)),
        panel_width=110,
        panel_height=70,
        trim=5,
    )

    assert sum(len(board.placed) for board in boards) == 3
    assert {packed.part.part_id for board in boards for packed in board.placed} == {
        "A",
        "B",
        "C",
    }
    for board in boards:
        for index, first in enumerate(board.placed):
            for second in board.placed[index + 1 :]:
                assert (
                    first.envelope.max_x <= second.envelope.x
                    or second.envelope.max_x <= first.envelope.x
                    or first.envelope.max_y <= second.envelope.y
                    or second.envelope.max_y <= first.envelope.y
                )


def test_select_formal_board_uses_part_count_then_nominal_area() -> None:
    boards = pack_kerf_envelopes(
        tuple(part(str(index), 20, 20) for index in range(8)),
        panel_width=60,
        panel_height=60,
        trim=4,
    )

    selected = select_formal_board(boards, minimum_parts=1, maximum_parts=10)

    assert len(selected.placed) == max(len(board.placed) for board in boards)


def test_seeded_equal_size_tie_break_is_deterministic() -> None:
    parts = tuple(part(str(index), 20, 20) for index in range(12))

    first = pack_kerf_envelopes(parts, 90, 90, 4, order_seed=123, order_top_k=3)
    second = pack_kerf_envelopes(parts, 90, 90, 4, order_seed=123, order_top_k=3)

    first_signature = tuple(
        (packed.part.part_id, packed.envelope.x, packed.envelope.y)
        for board in first
        for packed in board.placed
    )
    second_signature = tuple(
        (packed.part.part_id, packed.envelope.x, packed.envelope.y)
        for board in second
        for packed in board.placed
    )
    assert first_signature == second_signature
