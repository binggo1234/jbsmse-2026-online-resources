from experiments.audit_kerf_dimensional_feasibility import (
    NominalRectangle,
    classify_pair_conflict,
    dimension_semantics,
    nominal_dimensions,
)
from typing import Optional


def rectangle(
    part_id: str,
    x: float,
    y: float,
    width: float,
    height: float,
    *,
    stored_width: Optional[float] = None,
    stored_height: Optional[float] = None,
) -> NominalRectangle:
    return NominalRectangle(
        part_id=part_id,
        x=x,
        y=y,
        width=width,
        height=height,
        stored_width=width if stored_width is None else stored_width,
        stored_height=height if stored_height is None else stored_height,
        rotated=False,
    )


def test_nominal_dimensions_restore_rotation() -> None:
    row = {"w0": "100", "h0": "40", "rotated": "1"}

    assert nominal_dimensions(row) == (40.0, 100.0)


def test_dimension_semantics_distinguish_nominal_and_tool_inflated() -> None:
    nominal = rectangle("A", 0, 0, 100, 40)
    inflated = rectangle(
        "B",
        0,
        0,
        100,
        40,
        stored_width=106,
        stored_height=46,
    )

    assert dimension_semantics(nominal, 6.0) == "nominal"
    assert dimension_semantics(inflated, 6.0) == "tool_inflated"


def test_zero_gap_facing_edges_are_dimensionally_infeasible() -> None:
    first = rectangle("A", 0, 0, 10, 10)
    second = rectangle("B", 10, 0, 10, 10)

    conflict = classify_pair_conflict(first, second, 6.0)

    assert conflict is not None
    assert conflict[0] == "zero_gap_edge_contact"


def test_tool_width_gap_is_not_a_conflict() -> None:
    first = rectangle("A", 0, 0, 10, 10)
    second = rectangle("B", 16, 0, 10, 10)

    assert classify_pair_conflict(first, second, 6.0) is None


def test_positive_gap_below_tool_diameter_is_reported() -> None:
    first = rectangle("A", 0, 0, 10, 10)
    second = rectangle("B", 14, 0, 10, 10)

    conflict = classify_pair_conflict(first, second, 6.0)

    assert conflict is not None
    assert conflict[0] == "positive_gap_below_tool_diameter"


def test_overlapping_rectangles_are_not_misclassified_as_edge_contact() -> None:
    first = rectangle("A", 0, 0, 10, 10)
    second = rectangle("B", 8, 0, 10, 10)

    assert classify_pair_conflict(first, second, 6.0) is None
