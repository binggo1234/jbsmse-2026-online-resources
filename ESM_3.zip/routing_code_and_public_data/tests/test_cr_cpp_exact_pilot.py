from __future__ import annotations

import pytest

from cnc_cutting.models import Layout, PlacedRectangle
from experiments.cr_cpp_exact_pilot import (
    KinematicTemplate,
    PilotMethod,
    build_pilot_problem,
    solve_all_methods,
    solve_exact,
)


def _pilot_layout(gap: float = 10.0) -> Layout:
    width = 30.0
    rectangles = tuple(
        PlacedRectangle(
            part_id=f"P{index + 1}",
            x=10.0 + index * (width + gap),
            y=10.0,
            width=width,
            height=20.0,
        )
        for index in range(3)
    )
    return Layout(
        panel_id="pilot",
        panel_width=3.0 * width + 2.0 * gap + 20.0,
        panel_height=40.0,
        rectangles=rectangles,
    )


def test_exact_pilot_audits_and_superset_relation() -> None:
    problem = build_pilot_problem(_pilot_layout(), max_parts=3)
    plans = solve_all_methods(problem)
    by_method = {plan.method: plan for plan in plans}

    assert problem.geometry_feasible
    assert all(plan.audit.all_passed for plan in plans)
    controlled = by_method[PilotMethod.CONTROLLED_RELEASE_EXACT]
    layer_first = by_method[PilotMethod.LAYER_FIRST_EXACT]
    part_local = by_method[PilotMethod.PART_LOCAL_RETAINED_EXACT]
    assert controlled.metrics.programmed_time_s <= (
        layer_first.metrics.programmed_time_s + 1e-9
    )
    assert controlled.metrics.programmed_time_s <= (
        part_local.metrics.programmed_time_s + 1e-9
    )
    assert controlled.metrics.bridge_removal_length_mm == pytest.approx(24.0)
    assert controlled.metrics.cut_length_mm == pytest.approx(
        sum(
            2.0 * (part.nominal.width + part.nominal.height + 12.0)
            for part in problem.parts
        )
        * 2.0
    )


def test_early_release_is_kept_as_policy_infeasible_reference() -> None:
    problem = build_pilot_problem(_pilot_layout(), max_parts=3)
    plan = solve_exact(problem, PilotMethod.EARLY_RELEASE_REFERENCE)

    assert plan.audit.all_passed
    assert plan.metrics.early_release_count == 2
    assert plan.metrics.early_release_exposure_mm2_s > 0.0


def test_exact_pilot_rejects_subdiameter_channels() -> None:
    problem = build_pilot_problem(
        _pilot_layout(gap=5.0),
        template=KinematicTemplate(tool_diameter_mm=6.0),
        max_parts=3,
    )

    assert not problem.geometry_feasible
    assert any(
        "cutter-center envelopes conflict for the 6.000000 mm tool" in issue
        for issue in problem.geometry_issues
    )
    with pytest.raises(ValueError, match="pilot geometry is infeasible"):
        solve_exact(problem, PilotMethod.CONTROLLED_RELEASE_EXACT)
