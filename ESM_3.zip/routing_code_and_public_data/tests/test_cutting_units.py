from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.models import (
    CuttingUnitType,
    Layout,
    PlacedRectangle,
    Point,
    ToolConfig,
)
from cnc_cutting.optimizer import select_coverage_units


def test_build_candidate_units_keeps_primitive_edges() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(PlacedRectangle("A", 0, 0, 10, 10),),
    )

    units = build_candidate_cutting_units(layout, ToolConfig(tool_diameter=6))

    assert len([unit for unit in units if unit.unit_type == CuttingUnitType.SINGLE_EDGE]) == 4


def test_build_shared_edge_candidate_unit() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 0, 0, 10, 10),
            PlacedRectangle("B", 10, 0, 10, 10),
        ),
    )

    units = build_candidate_cutting_units(layout, ToolConfig(tool_diameter=6))

    shared_units = [unit for unit in units if unit.unit_type == CuttingUnitType.SHARED_EDGE]
    assert any(
        unit.covered_segment_ids == ("A:right", "B:left")
        and unit.start == Point(10, 0)
        and unit.end == Point(10, 10)
        for unit in shared_units
    )


def test_build_near_shared_channel_candidate_unit() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 0, 0, 10, 10),
            PlacedRectangle("B", 16, 0, 10, 10),
        ),
    )

    units = build_candidate_cutting_units(layout, ToolConfig(tool_diameter=6))

    channel_units = [
        unit for unit in units if unit.unit_type == CuttingUnitType.NEAR_SHARED_CHANNEL
    ]
    assert any(
        unit.covered_segment_ids == ("A:right", "B:left")
        and unit.start == Point(13, 0)
        and unit.end == Point(13, 10)
        for unit in channel_units
    )


def test_build_collinear_chain_marks_internal_bridge_cut() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 0, 0, 10, 10),
            PlacedRectangle("B", 15, 0, 10, 10),
        ),
    )

    units = build_candidate_cutting_units(
        layout,
        ToolConfig(tool_diameter=6),
        max_collinear_gap=10,
    )

    assert any(
        unit.unit_type == CuttingUnitType.COLLINEAR_CHAIN
        and unit.covered_segment_ids == ("A:bottom", "B:bottom")
        and unit.start == Point(0, 0)
        and unit.end == Point(25, 0)
        and unit.requires_bridge_cut
        for unit in units
    )


def test_partial_shared_edge_covers_only_overlap_spans_and_leaves_residuals() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 0, 0, 10, 20),
            PlacedRectangle("B", 10, 5, 10, 5),
        ),
    )

    units = build_candidate_cutting_units(layout, ToolConfig(tool_diameter=6))
    shared = next(
        unit
        for unit in units
        if unit.unit_type == CuttingUnitType.SHARED_EDGE
        and unit.covered_segment_ids == ("A:right", "B:left")
    )

    assert shared.start == Point(10, 5)
    assert shared.end == Point(10, 10)
    assert {
        (span.segment_id, span.start_axis, span.end_axis)
        for span in shared.covered_spans
    } == {
        ("A:right", 5, 10),
        ("B:left", 5, 10),
    }

    a_right_residuals = [
        unit
        for unit in units
        if unit.unit_type == CuttingUnitType.SINGLE_EDGE
        and unit.covered_segment_ids == ("A:right",)
    ]
    assert {
        (unit.start.y, unit.end.y)
        for unit in a_right_residuals
    } == {
        (0, 5),
        (5, 10),
        (10, 20),
    }


def test_span_level_selection_keeps_residual_tails_after_shared_overlap() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 0, 0, 10, 20),
            PlacedRectangle("B", 10, 5, 10, 5),
        ),
    )

    units = build_candidate_cutting_units(layout, ToolConfig(tool_diameter=6))
    selected = select_coverage_units(units)
    required_span_ids = {
        span.span_id
        for unit in units
        if unit.unit_type == CuttingUnitType.SINGLE_EDGE
        for span in unit.covered_spans
    }
    selected_span_ids = {
        span.span_id
        for unit in selected
        for span in unit.covered_spans
    }

    assert required_span_ids <= selected_span_ids
    assert any(unit.unit_type == CuttingUnitType.SHARED_EDGE for unit in selected)
    assert {
        (unit.start.y, unit.end.y)
        for unit in selected
        if unit.unit_type == CuttingUnitType.SINGLE_EDGE
        and unit.covered_segment_ids == ("A:right",)
    } == {
        (0, 5),
        (10, 20),
    }


def test_kerf_compensation_uses_shared_centerline_between_six_mm_spaced_parts() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(
            PlacedRectangle("A", 3, 3, 10, 10),
            PlacedRectangle("B", 19, 3, 10, 10),
        ),
    )
    tool = ToolConfig(tool_diameter=6, geometric_kerf_compensation=True)

    units = build_candidate_cutting_units(layout, tool)
    shared = next(
        unit
        for unit in units
        if unit.unit_type == CuttingUnitType.SHARED_EDGE
        and unit.covered_segment_ids == ("A:right", "B:left")
    )

    assert shared.start == Point(16, 0)
    assert shared.end == Point(16, 16)
    assert {
        (span.segment_id, span.start_axis, span.end_axis)
        for span in shared.covered_spans
    } == {
        ("A:right", 3, 13),
        ("B:left", 3, 13),
    }


def test_kerf_compensated_primitive_edges_include_mitered_corners() -> None:
    layout = Layout(
        panel_id="P",
        panel_width=100,
        panel_height=100,
        rectangles=(PlacedRectangle("A", 10, 20, 100, 40),),
    )

    units = build_candidate_cutting_units(
        layout,
        ToolConfig(tool_diameter=6, geometric_kerf_compensation=True),
    )
    bottom = next(unit for unit in units if unit.unit_id == "single:A:bottom")
    right = next(unit for unit in units if unit.unit_id == "single:A:right")

    assert bottom.start == Point(7, 17)
    assert bottom.end == Point(113, 17)
    assert right.start == bottom.end
