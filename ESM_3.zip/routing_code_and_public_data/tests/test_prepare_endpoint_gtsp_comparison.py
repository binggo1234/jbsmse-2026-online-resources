from __future__ import annotations

import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from prepare_endpoint_gtsp_comparison import combine_rows  # noqa: E402


def _row(case: str, method: str) -> dict[str, str]:
    return {
        "archive": "archive.zip",
        "placements_member": f"{case}/placements.csv",
        "board_id": case,
        "method": method,
    }


def test_combine_rows_requires_fully_paired_methods() -> None:
    external = [
        _row("1", "contour_tsp_2opt"),
        _row("1", "process_aware_beam_adaptive_polished"),
    ]
    gtsp = [_row("1", "endpoint_aware_gtsp")]

    combined = combine_rows(
        external,
        gtsp,
        (
            "contour_tsp_2opt",
            "endpoint_aware_gtsp",
            "process_aware_beam_adaptive_polished",
        ),
    )

    assert [row["method"] for row in combined] == [
        "contour_tsp_2opt",
        "endpoint_aware_gtsp",
        "process_aware_beam_adaptive_polished",
    ]


def test_combine_rows_rejects_missing_method() -> None:
    with pytest.raises(ValueError, match="not fully paired"):
        combine_rows(
            [_row("1", "contour_tsp_2opt")],
            [_row("1", "endpoint_aware_gtsp")],
            (
                "contour_tsp_2opt",
                "endpoint_aware_gtsp",
                "process_aware_beam_adaptive_polished",
            ),
        )
