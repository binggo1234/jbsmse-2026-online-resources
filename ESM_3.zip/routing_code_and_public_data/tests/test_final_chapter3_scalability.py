from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from run_chapter2_batch import BatchRouteRow  # noqa: E402
from run_final_chapter3_scalability import (  # noqa: E402
    DEFAULT_SCALE_BINS,
    ScaleCandidate,
    scale_bin_for_count,
    select_balanced_candidates,
    summarize_scale_rows,
)


def route_row(
    *,
    method: str,
    rectangle_count: int,
    runtime_ms: float,
    travel_mode_cost: float,
) -> BatchRouteRow:
    return BatchRouteRow(
        archive="a.zip",
        case_name="case",
        placement_method="method",
        seed="seed_1",
        placements_member="member/placements.csv",
        board_id=str(rectangle_count),
        support_policy="all_edges",
        min_support_count=1,
        min_support_ratio=0.75,
        min_area_normalized_support=0.0,
        adjacency_support_weight=1.0,
        tool_event_gate_enabled=True,
        tool_event_min_travel_saving=25.0,
        tool_event_min_travel_saving_ratio=0.0,
        tool_event_min_machining_saving=1e-9,
        repeat_cut_policy="hard",
        method=method,
        topology_candidate_pool_size=96,
        beam_width=6,
        beam_candidate_pool_size=18,
        beam_max_expansions_per_node=36,
        beam_max_layer_expansions=42,
        beam_diversity_bucket_limit=1,
        beam_min_expansions_per_parent=0,
        beam_unstable_min_expansions_per_parent=2,
        beam_unstable_layer_expansion_multiplier=1.0,
        beam_unstable_layer_expansion_bonus=None,
        runtime_ms=runtime_ms,
        rectangle_count=rectangle_count,
        rectangle_count_bin="021_050",
        candidate_unit_count=rectangle_count * 8,
        selected_unit_count=rectangle_count * 4,
        action_count=rectangle_count * 4,
        coverage_original_segment_count=rectangle_count * 4,
        coverage_covered_segment_count=rectangle_count * 4,
        coverage_missing_segment_count=0,
        coverage_repeated_segment_count=0,
        coverage_duplicate_segment_count=0,
        coverage_duplicate_segment_length=0.0,
        cut_covered_segment_count=rectangle_count * 4,
        cut_missing_segment_count=0,
        cut_repeated_segment_count=0,
        cut_duplicate_segment_count=0,
        cut_duplicate_segment_length=0.0,
        selected_single_edge_count=0,
        selected_shared_edge_count=0,
        selected_near_shared_channel_count=0,
        selected_collinear_chain_count=0,
        selected_composite_unit_count=0,
        selected_composite_covered_segment_count=0,
        selected_composite_coverage_ratio=0.0,
        partially_overlapping_selected_unit_count=0,
        redundant_selected_unit_count=0,
        partial_repeated_cut_action_count=0,
        redundant_cut_action_count=0,
        process_repeated_span_count=0,
        process_repeated_span_length=0.0,
        process_redundant_action_count=0,
        process_tool_event_count=2,
        process_turn_penalty=0.0,
        process_negative_continuity_reward=0.0,
        air_move_distance=travel_mode_cost - 100.0,
        cutting_length=1000.0,
        pierce_count=1,
        lift_count=1,
        collision_penalty=0.0,
        boundary_penalty=0.0,
        stability_penalty=0.0,
        safe_lift_count=0,
        safe_lift_distance=0.0,
        detour_count=0,
        detour_distance=0.0,
        travel_mode_cost=travel_mode_cost,
        hard_penalty=0.0,
    )


def test_scale_bin_for_count_uses_fixed_real_data_bins() -> None:
    assert scale_bin_for_count(10).name == "010_015"
    assert scale_bin_for_count(20).name == "016_020"
    assert scale_bin_for_count(26).name == "026_030"
    assert scale_bin_for_count(50).name == "031_050"
    assert scale_bin_for_count(51) is None


def test_select_balanced_candidates_caps_each_bin() -> None:
    candidates = tuple(
        ScaleCandidate(
            scale_bin="010_015",
            archive=Path("a.zip"),
            placements_member=f"member/{index}/placements.csv",
            board_id=str(index),
            rectangle_count=10,
        )
        for index in range(3)
    ) + tuple(
        ScaleCandidate(
            scale_bin="016_020",
            archive=Path("a.zip"),
            placements_member=f"member/{index}/placements.csv",
            board_id=str(index),
            rectangle_count=16,
        )
        for index in range(2)
    )

    selected = select_balanced_candidates(
        candidates,
        bins=DEFAULT_SCALE_BINS[:2],
        max_boards_per_bin=2,
    )

    assert [candidate.scale_bin for candidate in selected].count("010_015") == 2
    assert [candidate.scale_bin for candidate in selected].count("016_020") == 2


def test_select_balanced_candidates_prefers_unique_archive_board_layouts() -> None:
    candidates = (
        ScaleCandidate(
            scale_bin="010_015",
            archive=Path("a.zip"),
            placements_member="member/0/placements.csv",
            board_id="1",
            rectangle_count=10,
        ),
        ScaleCandidate(
            scale_bin="010_015",
            archive=Path("a.zip"),
            placements_member="member/1/placements.csv",
            board_id="1",
            rectangle_count=10,
        ),
        ScaleCandidate(
            scale_bin="010_015",
            archive=Path("a.zip"),
            placements_member="member/2/placements.csv",
            board_id="2",
            rectangle_count=10,
        ),
    )

    selected = select_balanced_candidates(
        candidates,
        bins=DEFAULT_SCALE_BINS[:1],
        max_boards_per_bin=2,
    )

    assert [(candidate.board_id, candidate.placements_member) for candidate in selected] == [
        ("1", "member/0/placements.csv"),
        ("2", "member/2/placements.csv"),
    ]


def test_summarize_scale_rows_groups_by_scale_bin_and_method() -> None:
    rows = (
        route_row(
            method="process_aware_beam_adaptive_polished",
            rectangle_count=21,
            runtime_ms=200.0,
            travel_mode_cost=1000.0,
        ),
        route_row(
            method="process_aware_beam_adaptive_polished",
            rectangle_count=25,
            runtime_ms=300.0,
            travel_mode_cost=1200.0,
        ),
        route_row(
            method="topology_process_aware",
            rectangle_count=31,
            runtime_ms=100.0,
            travel_mode_cost=1500.0,
        ),
    )

    summary = summarize_scale_rows(rows)
    adaptive_21_25 = [
        row
        for row in summary
        if row.scale_bin == "021_025"
        and row.method == "process_aware_beam_adaptive_polished"
    ][0]

    assert adaptive_21_25.n == 2
    assert adaptive_21_25.runtime_ms_mean == 250.0
    assert adaptive_21_25.travel_mode_cost_mean == 1100.0
