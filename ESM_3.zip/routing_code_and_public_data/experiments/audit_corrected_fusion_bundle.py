from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BUNDLE_DIR = ROOT / "results" / "corrected_model_stage4" / "fusion_validation_bundle"
DEFAULT_COVERAGE_SUMMARY = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "geometric_coverage_audit"
    / "geometric_coverage_route_summary.csv"
)


@dataclass(frozen=True)
class ExpectedCase:
    case_id: str
    board_id: str
    method: str
    primitive_segments: int


EXPECTED_CASES: tuple[ExpectedCase, ...] = (
    ExpectedCase("case_large_board340_beam", "340", "process_aware_beam", 120),
    ExpectedCase(
        "case_large_board340_adaptive_polished",
        "340",
        "process_aware_beam_adaptive_polished",
        120,
    ),
    ExpectedCase("case_mid_board262_beam", "262", "process_aware_beam", 84),
    ExpectedCase(
        "case_mid_board262_adaptive_polished",
        "262",
        "process_aware_beam_adaptive_polished",
        84,
    ),
    ExpectedCase("case_small_board4_beam", "4", "process_aware_beam", 44),
    ExpectedCase(
        "case_small_board4_adaptive_polished",
        "4",
        "process_aware_beam_adaptive_polished",
        44,
    ),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit the corrected span-level Fusion validation bundle."
    )
    parser.add_argument("--bundle-dir", type=Path, default=DEFAULT_BUNDLE_DIR)
    parser.add_argument(
        "--coverage-summary",
        type=Path,
        default=DEFAULT_COVERAGE_SUMMARY,
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_BUNDLE_DIR / "FUSION_PACKAGE_AUDIT.md",
    )
    parser.add_argument(
        "--stage",
        choices=("pre-fusion", "post-fusion"),
        default="pre-fusion",
        help=(
            "`pre-fusion` expects no exported Fusion NC files. `post-fusion` "
            "accepts completed exports and audits that each exported file maps "
            "to a known corrected case."
        ),
    )
    return parser.parse_args()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty CSV: {path}")
        return list(reader)


def count_dxf_lines(path: Path) -> int:
    lines = path.read_text(encoding="ascii", errors="ignore").splitlines()
    return sum(1 for index, value in enumerate(lines[:-1]) if value == "0" and lines[index + 1] == "LINE")


def rel(path: Path) -> str:
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)


def add_check(
    checks: list[tuple[str, str, str]],
    ok: bool,
    name: str,
    detail: str,
) -> None:
    checks.append(("PASS" if ok else "FAIL", name, detail))


def format_checks(checks: list[tuple[str, str, str]]) -> str:
    rows = ["| Status | Check | Detail |", "|---|---|---|"]
    for status, name, detail in checks:
        rows.append(f"| {status} | {name} | {detail} |")
    return "\n".join(rows)


def expected_fusion_export_name(case_id: str) -> str:
    return f"{case_id}_fusion_reference.nc"


def audit(args: argparse.Namespace) -> tuple[list[tuple[str, str, str]], str]:
    bundle_dir = args.bundle_dir.resolve()
    checks: list[tuple[str, str, str]] = []

    add_check(
        checks,
        "corrected_model_stage4" in bundle_dir.parts,
        "Corrected bundle path",
        f"`{rel(bundle_dir)}`",
    )
    add_check(checks, bundle_dir.exists(), "Bundle directory exists", f"`{rel(bundle_dir)}`")
    add_check(
        checks,
        args.coverage_summary.exists(),
        "Coverage summary exists",
        f"`{rel(args.coverage_summary)}`",
    )

    for subdir in ("dxf", "nc_reference", "fusion_exported_nc", "fusion_screenshots"):
        path = bundle_dir / subdir
        add_check(checks, path.exists(), f"Subdirectory `{subdir}`", f"`{rel(path)}`")

    required_files = (
        "README.md",
        "BOARD340_FIRST_RUN_CHECKLIST.md",
        "board340_first_run_template.csv",
        "case_index.csv",
        "fusion_result_template.csv",
    )
    for name in required_files:
        path = bundle_dir / name
        add_check(checks, path.exists(), f"Required file `{name}`", f"`{rel(path)}`")

    case_rows = read_rows(bundle_dir / "case_index.csv")
    template_rows = read_rows(bundle_dir / "fusion_result_template.csv")
    case_ids = [row["case_id"] for row in case_rows]
    template_ids = [row["case_id"] for row in template_rows]
    expected_ids = [case.case_id for case in EXPECTED_CASES]
    add_check(
        checks,
        case_ids == expected_ids,
        "Case index order",
        "Board340 beam/adaptive first, then Board262 and Board4",
    )
    add_check(
        checks,
        template_ids == expected_ids,
        "Fusion template order",
        "Matches `case_index.csv` exactly",
    )
    add_check(
        checks,
        not any(case_id.startswith("case_01_") for case_id in case_ids),
        "No legacy case IDs",
        "Rejects old `case_01_*` naming from the deprecated bundle",
    )

    coverage_rows = read_rows(args.coverage_summary)
    coverage_by_key = {
        (row["board_id"], row["method"]): row
        for row in coverage_rows
    }
    for expected, row in zip(EXPECTED_CASES, case_rows):
        dxf_path = bundle_dir / row["dxf_file"]
        nc_path = bundle_dir / row["corrected_nc"]
        diag_path = ROOT / "results" / "corrected_model_stage4" / row["diagnostics_csv"]
        add_check(checks, dxf_path.exists(), f"DXF exists for `{expected.case_id}`", f"`{rel(dxf_path)}`")
        add_check(
            checks,
            nc_path.exists(),
            f"Corrected NC exists for `{expected.case_id}`",
            f"`{rel(nc_path)}`",
        )
        add_check(
            checks,
            diag_path.exists(),
            f"Diagnostics exists for `{expected.case_id}`",
            f"`{rel(diag_path)}`",
        )
        if dxf_path.exists():
            expected_line_count = int(row["cut_segment_count"]) + 4
            actual_line_count = count_dxf_lines(dxf_path)
            add_check(
                checks,
                actual_line_count == expected_line_count,
                f"DXF line count for `{expected.case_id}`",
                f"{actual_line_count} LINE entities; expected {expected_line_count}",
            )
        coverage = coverage_by_key.get((expected.board_id, expected.method))
        add_check(
            checks,
            coverage is not None,
            f"Coverage row for `{expected.case_id}`",
            f"board {expected.board_id}, method `{expected.method}`",
        )
        if coverage is not None:
            ok = (
                coverage["issue_flag"] == "0"
                and coverage["geometry_coverage_ratio"] == "1.0"
                and int(coverage["primitive_segment_count"]) == expected.primitive_segments
                and int(coverage["geometry_missing_segment_count"]) == 0
                and int(coverage["geometry_partial_segment_count"]) == 0
            )
            add_check(
                checks,
                ok,
                f"Full geometric coverage for `{expected.case_id}`",
                (
                    f"{coverage['geometry_full_segment_count']}/"
                    f"{coverage['primitive_segment_count']} full; "
                    f"partial={coverage['geometry_partial_segment_count']}; "
                    f"missing={coverage['geometry_missing_segment_count']}"
                ),
            )

    board340_template = read_rows(bundle_dir / "board340_first_run_template.csv")
    board340_ids = [row["case_id"] for row in board340_template]
    add_check(
        checks,
        board340_ids == expected_ids[:2],
        "Board340 first-run template",
        "Contains only beam and adaptive-polished Board340 rows",
    )
    for row in board340_template:
        ok = (
            row.get("stock_mm") == "2440 x 1220 x 18"
            and row.get("tool_diameter_mm") == "6"
            and row.get("stepdown_mm") == "6"
            and row.get("cut_feed_mm_min") == "3600"
            and row.get("plunge_feed_mm_min") == "800"
        )
        add_check(
            checks,
            ok,
            f"Board340 template CAM fields for `{row.get('case_id', '')}`",
            (
                f"stock={row.get('stock_mm', '')}; tool={row.get('tool_diameter_mm', '')}; "
                f"stepdown={row.get('stepdown_mm', '')}; cut={row.get('cut_feed_mm_min', '')}; "
                f"plunge={row.get('plunge_feed_mm_min', '')}"
            ),
        )

    exported_nc_dir = bundle_dir / "fusion_exported_nc"
    exported_nc_files = sorted(exported_nc_dir.glob("*.nc")) if exported_nc_dir.exists() else []
    exported_nc_names = {path.name for path in exported_nc_files}
    expected_export_names = {expected_fusion_export_name(case.case_id) for case in EXPECTED_CASES}
    unexpected_export_names = sorted(exported_nc_names - expected_export_names)
    if args.stage == "pre-fusion":
        add_check(
            checks,
            len(exported_nc_files) == 0,
            "Fusion export directory is clean",
            f"{len(exported_nc_files)} existing `.nc` files before Board340 first run",
        )
    else:
        add_check(
            checks,
            len(exported_nc_files) > 0,
            "Fusion exports present",
            f"{len(exported_nc_files)} exported `.nc` files recorded after manual Fusion runs",
        )
        add_check(
            checks,
            not unexpected_export_names,
            "Fusion export names match corrected case IDs",
            ", ".join(unexpected_export_names) if unexpected_export_names else "all exported NC files are expected",
        )
        board340_export = expected_fusion_export_name("case_large_board340_beam")
        add_check(
            checks,
            board340_export in exported_nc_names,
            "Board340 beam Fusion export exists",
            f"`fusion_exported_nc/{board340_export}`",
        )

    summary = "\n".join(
        [
            "# Corrected Fusion Bundle Audit",
            "",
            f"- Bundle: `{rel(bundle_dir)}`",
            f"- Coverage summary: `{rel(args.coverage_summary)}`",
            f"- Audit stage: `{args.stage}`",
            "- Deprecated bundle: `results/fusion_validation_bundle` must not be used.",
            "- Manual Fusion progression: Board340 first, then Board262 and Board4 after Board340 passes.",
            "",
            format_checks(checks),
            "",
        ]
    )
    return checks, summary


def main() -> None:
    args = parse_args()
    checks, summary = audit(args)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(summary, encoding="utf-8")
    failures = [check for check in checks if check[0] != "PASS"]
    print(f"wrote {args.output}")
    print(f"checks={len(checks)} failures={len(failures)}")
    if failures:
        for _status, name, detail in failures:
            print(f"FAIL: {name}: {detail}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
