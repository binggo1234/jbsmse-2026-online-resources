from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
STAGE7 = ROOT / "results" / "corrected_model_stage7_kerf"
ARCHIVE = STAGE7 / "kerf_layouts" / "stage7_kerf_layouts.zip"
RECORD_MANIFEST = STAGE7 / "kerf_layouts" / "stage7_kerf_layout_manifest.csv"
BASELINE = STAGE7 / "formal" / "chapter3_stage7_main.csv"
DEFAULT_OUTPUT_DIR = STAGE7 / "support_sensitivity"
METHODS = ("topology_process_aware", "process_aware_beam_adaptive_polished")
PROPOSED = METHODS[1]


@dataclass(frozen=True)
class Setting:
    name: str
    min_support_ratio: float
    adjacency_support_weight: float


SETTINGS = (
    Setting("rho060_alpha100", 0.60, 1.00),
    Setting("rho090_alpha100", 0.90, 1.00),
    Setting("rho075_alpha050", 0.75, 0.50),
    Setting("rho075_alpha150", 0.75, 1.50),
)


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def record_key(row: dict[str, str]) -> tuple[str, str]:
    return row["placements_member"], row["board_id"]


def planning_cost(row: dict[str, str]) -> float:
    return float(row["cutting_length"]) + float(row["travel_mode_cost"])


def route_signature(row: dict[str, str]) -> tuple[tuple[str, ...], ...]:
    path = ROOT / row["diagnostics_file"]
    actions = read_rows(path)
    fields = (
        "action_type",
        "travel_mode",
        "cutting_unit_id",
        "start_x",
        "start_y",
        "end_x",
        "end_y",
    )
    return tuple(tuple(action[field] for field in fields) for action in actions)


def output_paths(output_dir: Path, setting: Setting) -> dict[str, Path]:
    stem = f"chapter3_stage7_support_{setting.name}"
    return {
        "output": output_dir / f"{stem}.csv",
        "summary": output_dir / f"{stem}_summary.csv",
        "bin_summary": output_dir / f"{stem}_bin_summary.csv",
        "manifest": output_dir / f"{stem}_manifest.json",
        "progress": output_dir / f"{stem}_progress.csv",
        "diagnostics": output_dir / f"{stem}_diagnostics",
    }


def run_setting(output_dir: Path, setting: Setting) -> Path:
    paths = output_paths(output_dir, setting)
    command = [
        sys.executable,
        str(ROOT / "experiments" / "run_chapter2_batch.py"),
        "--zip-path",
        str(ARCHIVE),
        "--record-manifest",
        str(RECORD_MANIFEST),
        "--experiment-preset",
        "paper-main",
        "--support-policy",
        "all_edges",
        "--min-support-count",
        "1",
        "--min-support-ratio",
        str(setting.min_support_ratio),
        "--min-area-normalized-support",
        "0",
        "--adjacency-support-weight",
        str(setting.adjacency_support_weight),
        "--repeat-cut-policy",
        "hard",
        "--tool-event-min-travel-saving",
        "25",
        "--tool-event-min-travel-saving-ratio",
        "0",
        "--tool-event-min-machining-saving",
        "1e-09",
        "--methods",
        *METHODS,
        "--task-timeout-seconds",
        "60",
        "--output",
        str(paths["output"]),
        "--summary-output",
        str(paths["summary"]),
        "--bin-summary-output",
        str(paths["bin_summary"]),
        "--manifest-output",
        str(paths["manifest"]),
        "--progress-output",
        str(paths["progress"]),
        "--diagnostics-dir",
        str(paths["diagnostics"]),
        "--no-progress-bar",
    ]
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join(
        (str(ROOT), str(ROOT / "src"), str(ROOT / "experiments"))
    )
    print(f"[support] start {setting.name}", flush=True)
    subprocess.run(command, cwd=ROOT, env=environment, check=True)
    rows = read_rows(paths["output"])
    if len(rows) != 77 * len(METHODS):
        raise ValueError(f"{setting.name}: expected 154 rows, found {len(rows)}")
    print(f"[support] complete {setting.name}", flush=True)
    return paths["output"]


def summarize(output_dir: Path) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    baseline_rows = [
        row
        for row in read_rows(BASELINE)
        if row["method"] in METHODS
    ]
    baseline_by_method = {
        method: {record_key(row): row for row in baseline_rows if row["method"] == method}
        for method in METHODS
    }
    all_settings = (Setting("rho075_alpha100", 0.75, 1.00), *SETTINGS)
    setting_rows: dict[str, list[dict[str, str]]] = {
        all_settings[0].name: baseline_rows,
        **{
            setting.name: read_rows(output_paths(output_dir, setting)["output"])
            for setting in SETTINGS
        },
    }
    baseline_signatures = {
        key: route_signature(row)
        for key, row in baseline_by_method[PROPOSED].items()
    }
    summaries: list[dict[str, object]] = []
    paired_rows: list[dict[str, object]] = []
    for setting in all_settings:
        rows = setting_rows[setting.name]
        by_method = {
            method: {record_key(row): row for row in rows if row["method"] == method}
            for method in METHODS
        }
        keys = sorted(set(by_method[METHODS[0]]) & set(by_method[PROPOSED]))
        reductions: list[float] = []
        wins = ties = losses = 0
        for key in keys:
            topology = by_method[METHODS[0]][key]
            proposed = by_method[PROPOSED][key]
            topology_cost = planning_cost(topology)
            proposed_cost = planning_cost(proposed)
            reduction = 100.0 * (topology_cost - proposed_cost) / topology_cost
            reductions.append(reduction)
            if proposed_cost < topology_cost - 1e-9:
                wins += 1
            elif proposed_cost > topology_cost + 1e-9:
                losses += 1
            else:
                ties += 1
            paired_rows.append(
                {
                    "setting": setting.name,
                    "min_support_ratio": setting.min_support_ratio,
                    "adjacency_support_weight": setting.adjacency_support_weight,
                    "placements_member": key[0],
                    "board_id": key[1],
                    "topology_cplan": topology_cost,
                    "proposed_cplan": proposed_cost,
                    "paired_reduction_pct": reduction,
                    "topology_support_penalty": float(topology["stability_penalty"]),
                    "proposed_support_penalty": float(proposed["stability_penalty"]),
                }
            )
        proposed_rows = list(by_method[PROPOSED].values())
        if setting.name == "rho075_alpha100":
            route_changes = 0
        else:
            route_changes = sum(
                route_signature(row) != baseline_signatures[key]
                for key, row in by_method[PROPOSED].items()
            )
        summaries.append(
            {
                "setting": setting.name,
                "min_support_ratio": setting.min_support_ratio,
                "adjacency_support_weight": setting.adjacency_support_weight,
                "n": len(keys),
                "paired_cplan_reduction_mean_pct": mean(reductions),
                "proposed_wins": wins,
                "ties": ties,
                "proposed_losses": losses,
                "proposed_route_changes_vs_locked": route_changes,
                "proposed_hard_penalty_max": max(float(row["hard_penalty"]) for row in proposed_rows),
                "proposed_support_penalty_mean": mean(float(row["stability_penalty"]) for row in proposed_rows),
                "proposed_missing_spans_max": max(float(row["cut_missing_segment_count"]) for row in proposed_rows),
                "conclusion_direction_preserved": mean(reductions) > 0.0,
            }
        )
    return summaries, paired_rows


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Stage 7 support-policy sensitivity.")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--max-workers", type=int, default=2)
    parser.add_argument("--analyze-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not args.analyze_only:
        with ThreadPoolExecutor(max_workers=args.max_workers) as executor:
            list(executor.map(lambda setting: run_setting(output_dir, setting), SETTINGS))
    summaries, paired_rows = summarize(output_dir)
    summary_path = output_dir / "chapter3_stage7_support_policy_sensitivity_summary.csv"
    paired_path = output_dir / "chapter3_stage7_support_policy_sensitivity_paired.csv"
    write_rows(summary_path, summaries)
    write_rows(paired_path, paired_rows)
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "runner": str(Path(__file__).resolve().relative_to(ROOT)),
        "runner_sha256": sha256(Path(__file__).resolve()),
        "archive": str(ARCHIVE.relative_to(ROOT)),
        "archive_sha256": sha256(ARCHIVE),
        "record_manifest": str(RECORD_MANIFEST.relative_to(ROOT)),
        "record_manifest_sha256": sha256(RECORD_MANIFEST),
        "locked_baseline": str(BASELINE.relative_to(ROOT)),
        "locked_baseline_sha256": sha256(BASELINE),
        "settings": [asdict(setting) for setting in SETTINGS],
        "setting_outputs": [
            {
                "setting": setting.name,
                "output": str(output_paths(output_dir, setting)["output"].relative_to(ROOT)),
                "output_sha256": sha256(output_paths(output_dir, setting)["output"]),
                "manifest": str(output_paths(output_dir, setting)["manifest"].relative_to(ROOT)),
                "manifest_sha256": sha256(output_paths(output_dir, setting)["manifest"]),
            }
            for setting in SETTINGS
        ],
        "methods": METHODS,
        "summary": str(summary_path.relative_to(ROOT)),
        "summary_sha256": sha256(summary_path),
        "paired": str(paired_path.relative_to(ROOT)),
        "paired_sha256": sha256(paired_path),
    }
    manifest_path = output_dir / "chapter3_stage7_support_policy_sensitivity_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    for row in summaries:
        print(row)
    print(f"manifest={manifest_path}")


if __name__ == "__main__":
    main()
