from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from cnc_cutting.geometry import rectangle_edges
from cnc_cutting.models import (
    CuttingActionType,
    CuttingUnitType,
    EdgeSegment,
    Layout,
    TravelMode,
)
from plot_route_case_pair_summary import (
    CASE_SPECS,
    DEFAULT_PRIVATE_DATA_ROOT,
    METHOD_LABELS,
    ROOT,
    load_case_runs,
    require_archives,
)
from process_options import add_stability_model_args, add_tool_event_gate_args


UNIT_COLORS = {
    CuttingUnitType.SINGLE_EDGE.value: "#6B7280",
    CuttingUnitType.SHARED_EDGE.value: "#0072B2",
    CuttingUnitType.NEAR_SHARED_CHANNEL.value: "#009E73",
    CuttingUnitType.COLLINEAR_CHAIN.value: "#E69F00",
}
TRAVEL_COLORS = {
    TravelMode.LOW_CLEARANCE.value: "#F59E0B",
    TravelMode.LOW_CLEARANCE_DETOUR.value: "#0891B2",
    TravelMode.SAFE_LIFT.value: "#7C3AED",
}


plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
        "font.size": 9.0,
        "axes.titlesize": 10.0,
        "axes.labelsize": 8.8,
        "xtick.labelsize": 7.8,
        "ytick.labelsize": 7.8,
        "legend.fontsize": 8.0,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.16,
        "grid.linestyle": "-",
    }
)


def primitive_edges_by_id(layout: Layout) -> dict[str, EdgeSegment]:
    return {
        edge.segment_id: edge
        for rectangle in layout.rectangles
        for edge in rectangle_edges(rectangle)
    }


def covered_segment_ids(run) -> set[str]:
    covered: set[str] = set()
    for unit in run.plan.selected_units:
        covered.update(unit.covered_segment_ids)
    return covered


def setup_layout_axis(ax: plt.Axes, layout: Layout, *, show_axes: bool = True) -> None:
    margin = max(layout.panel_width, layout.panel_height) * 0.025
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(-margin, layout.panel_width + margin)
    ax.set_ylim(-margin, layout.panel_height + margin)
    if show_axes:
        ax.set_xlabel("X (mm)")
        ax.set_ylabel("Y (mm)")
    else:
        ax.set_xlabel("")
        ax.set_ylabel("")
        ax.set_xticks([])
        ax.set_yticks([])
        ax.grid(False)
        for spine in ax.spines.values():
            spine.set_visible(False)
    ax.add_patch(
        Rectangle(
            (0, 0),
            layout.panel_width,
            layout.panel_height,
            fill=False,
            edgecolor="#111827",
            linewidth=1.1,
            zorder=6,
        )
    )


def draw_part_fills(ax: plt.Axes, layout: Layout, *, face_alpha: float = 0.28) -> None:
    for rectangle in layout.rectangles:
        ax.add_patch(
            Rectangle(
                (rectangle.x, rectangle.y),
                rectangle.width,
                rectangle.height,
                facecolor="#E0F2FE",
                edgecolor="none",
                alpha=face_alpha,
                zorder=0,
            )
        )


def draw_layout_outline(ax: plt.Axes, layout: Layout, *, alpha: float = 0.36) -> None:
    for rectangle in layout.rectangles:
        ax.add_patch(
            Rectangle(
                (rectangle.x, rectangle.y),
                rectangle.width,
                rectangle.height,
                fill=False,
                edgecolor="#111827",
                linewidth=0.35,
                alpha=alpha,
                zorder=5,
            )
        )


def draw_segment(
    ax: plt.Axes,
    segment: EdgeSegment,
    *,
    color: str,
    linewidth: float,
    alpha: float,
    zorder: int,
) -> None:
    ax.plot(
        [segment.start.x, segment.end.x],
        [segment.start.y, segment.end.y],
        color=color,
        linewidth=linewidth,
        alpha=alpha,
        solid_capstyle="round",
        zorder=zorder,
    )


def draw_coverage_panel(
    ax: plt.Axes,
    layout: Layout,
    run,
    *,
    title: str,
    show_axes: bool = True,
    annotation_fontsize: float = 8.2,
) -> dict[str, int]:
    edges = primitive_edges_by_id(layout)
    covered = covered_segment_ids(run)
    missing_ids = sorted(set(edges) - covered)

    draw_part_fills(ax, layout, face_alpha=0.34)
    for segment in edges.values():
        draw_segment(
            ax,
            segment,
            color="#CBD5E1",
            linewidth=0.8,
            alpha=0.68,
            zorder=1,
        )
    for segment_id, segment in edges.items():
        if segment_id in covered:
            draw_segment(
                ax,
                segment,
                color="#0072B2",
                linewidth=1.45,
                alpha=0.92,
                zorder=3,
            )
    for segment_id in missing_ids:
        draw_segment(
            ax,
            edges[segment_id],
            color="#D55E00",
            linewidth=2.5,
            alpha=0.98,
            zorder=4,
        )
    draw_layout_outline(ax, layout, alpha=0.28)
    setup_layout_axis(ax, layout, show_axes=show_axes)

    total = len(edges)
    covered_count = total - len(missing_ids)
    coverage_pct = 100.0 * covered_count / total if total else 0.0
    metrics = run.plan.metrics
    annotation = (
        f"Primitive-edge coverage: {covered_count}/{total} ({coverage_pct:.1f}%)\n"
        f"Missing edges: {len(missing_ids)}\n"
        f"Hard penalty: {metrics.hard_penalty:.0f} | "
        f"low-support penalty: {metrics.stability_penalty:.0f}"
    )
    ax.text(
        0.012,
        0.98,
        annotation,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=annotation_fontsize,
        color="#111827",
        bbox={
            "boxstyle": "round,pad=0.32",
            "facecolor": "white",
            "edgecolor": "#CBD5E1",
            "alpha": 0.94,
            "linewidth": 0.65,
        },
        zorder=10,
    )
    ax.set_title(title, pad=5)
    return {
        "total_edges": total,
        "covered_edges": covered_count,
        "missing_edges": len(missing_ids),
    }


def draw_route_panel(ax: plt.Axes, layout: Layout, run, *, title: str) -> None:
    draw_part_fills(ax, layout, face_alpha=0.20)
    draw_layout_outline(ax, layout, alpha=0.32)
    for action in run.plan.actions:
        if action.action_type == CuttingActionType.CUT:
            color = UNIT_COLORS.get(
                run.unit_type_by_id.get(action.cutting_unit_id or "", ""),
                "#6B7280",
            )
            linestyle = "-"
            linewidth = 1.25
            alpha = 0.86
            zorder = 3
        else:
            color = TRAVEL_COLORS.get(action.travel_mode.value, "#F59E0B")
            linestyle = "--"
            linewidth = 0.82
            alpha = 0.34
            zorder = 2
        ax.plot(
            [action.start.x, action.end.x],
            [action.start.y, action.end.y],
            color=color,
            linewidth=linewidth,
            linestyle=linestyle,
            alpha=alpha,
            solid_capstyle="round",
            dash_capstyle="round",
            zorder=zorder,
        )

    if run.plan.actions:
        first = run.plan.actions[0]
        last = run.plan.actions[-1]
        ax.scatter([first.start.x], [first.start.y], s=24, marker="o", color="#009E73", zorder=6)
        ax.scatter([last.end.x], [last.end.y], s=22, marker="s", color="#111827", zorder=6)

    setup_layout_axis(ax, layout)
    ax.set_title(title, pad=5)


def add_clean_coverage_legend(ax: plt.Axes) -> None:
    handles = [
        Line2D([0], [0], color="#0072B2", linewidth=1.8, label="covered primitive edge"),
        Line2D([0], [0], color="#D55E00", linewidth=2.3, label="missing edge, if any"),
        Line2D([0], [0], color="#111827", linewidth=0.8, alpha=0.45, label="part outline"),
    ]
    ax.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, -0.16), ncol=3, frameon=False)


def add_route_legend(fig: plt.Figure) -> None:
    handles = [
        Line2D([0], [0], color="#0072B2", linewidth=1.5, label="shared-edge cut"),
        Line2D([0], [0], color="#009E73", linewidth=1.5, label="near-shared cut"),
        Line2D([0], [0], color="#E69F00", linewidth=1.5, label="collinear chain"),
        Line2D([0], [0], color="#6B7280", linewidth=1.5, label="single-edge cut"),
        Line2D([0], [0], color="#F59E0B", linewidth=1.0, linestyle="--", label="travel"),
        Line2D([0], [0], color="#0891B2", linewidth=1.0, linestyle="--", label="detour"),
        Line2D([0], [0], color="#7C3AED", linewidth=1.0, linestyle="--", label="safe lift"),
    ]
    fig.legend(
        handles=handles,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.015),
        ncol=7,
        frameon=False,
        fontsize=7.4,
        handlelength=1.8,
        columnspacing=0.75,
    )


def save_figure(fig: plt.Figure, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path.with_suffix(".pdf"))
    fig.savefig(path.with_suffix(".png"))
    plt.close(fig)


def plot_clean_coverage(layout: Layout, run, spec, output_prefix: Path) -> dict[str, int]:
    fig, ax = plt.subplots(figsize=(11.2, 5.8), dpi=300)
    stats = draw_coverage_panel(
        ax,
        layout,
        run,
        title=f"{spec.case_label}: coverage audit for the final route",
    )
    add_clean_coverage_legend(ax)
    fig.tight_layout(rect=(0.0, 0.06, 1.0, 1.0))
    save_figure(fig, output_prefix)
    return stats


def plot_slide_coverage(layout: Layout, run, spec, output_prefix: Path) -> dict[str, int]:
    fig, ax = plt.subplots(figsize=(12.8, 7.2), dpi=300)
    stats = draw_coverage_panel(
        ax,
        layout,
        run,
        title=f"{spec.case_label}: complete cut-edge coverage",
        show_axes=False,
        annotation_fontsize=10.8,
    )
    add_clean_coverage_legend(ax)
    fig.tight_layout(rect=(0.0, 0.06, 1.0, 0.99))
    save_figure(fig, output_prefix)
    return stats


def plot_route_vs_coverage(layout: Layout, run, spec, output_prefix: Path) -> dict[str, int]:
    fig, axes = plt.subplots(2, 1, figsize=(11.2, 8.0), dpi=300, sharex=True, sharey=True)
    stats = draw_coverage_panel(
        axes[0],
        layout,
        run,
        title=f"{spec.case_label}: primitive-edge coverage audit",
    )
    draw_route_panel(
        axes[1],
        layout,
        run,
        title="Same route as NC centerlines; travel moves are faded dashed lines",
    )
    axes[0].text(
        -0.035,
        1.03,
        "A",
        transform=axes[0].transAxes,
        fontsize=12,
        fontweight="bold",
        va="top",
    )
    axes[1].text(
        -0.035,
        1.03,
        "B",
        transform=axes[1].transAxes,
        fontsize=12,
        fontweight="bold",
        va="top",
    )
    add_route_legend(fig)
    fig.tight_layout(rect=(0.0, 0.055, 1.0, 1.0), h_pad=1.05)
    save_figure(fig, output_prefix)
    return stats


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create presentation-ready coverage audit visuals for route cases."
    )
    parser.add_argument("--data-root", type=Path, default=DEFAULT_PRIVATE_DATA_ROOT)
    parser.add_argument("--case-index", type=int, default=0, choices=range(len(CASE_SPECS)))
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results" / "presentation_visuals",
    )
    add_stability_model_args(parser)
    add_tool_event_gate_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    require_archives(CASE_SPECS, args.data_root)
    spec = CASE_SPECS[args.case_index]
    layout, runs = load_case_runs(spec, args)
    final_run = runs[1]
    method_slug = final_run.method.replace("_", "-")
    case_slug = spec.case_label.lower().replace(" ", "-")
    clean_prefix = args.output_dir / f"{case_slug}_{method_slug}_coverage_audit"
    slide_prefix = args.output_dir / f"{case_slug}_{method_slug}_coverage_audit_slide"
    paired_prefix = args.output_dir / f"{case_slug}_{method_slug}_route_vs_coverage"
    stats = plot_clean_coverage(layout, final_run, spec, clean_prefix)
    plot_slide_coverage(layout, final_run, spec, slide_prefix)
    plot_route_vs_coverage(layout, final_run, spec, paired_prefix)
    print(
        "coverage: "
        f"{stats['covered_edges']}/{stats['total_edges']} primitive edges; "
        f"missing={stats['missing_edges']}"
    )
    print(f"clean coverage: {clean_prefix.with_suffix('.png')}")
    print(f"slide coverage: {slide_prefix.with_suffix('.png')}")
    print(f"route vs coverage: {paired_prefix.with_suffix('.png')}")


if __name__ == "__main__":
    main()
