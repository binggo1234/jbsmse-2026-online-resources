from __future__ import annotations

import json
from pathlib import Path


def write_project(path: Path, nc_name: str, *, z_min: float, z_max: float) -> None:
    project = {
        "units": "metric",
        "resolution-mode": "manual",
        "resolution": 0.5,
        "tools": {
            "1": {
                "units": "metric",
                "shape": "cylindrical",
                "length": 30.0,
                "diameter": 80.0,
                "description": "Extra-wide CAMotics display sanity tool",
            }
        },
        "workpiece": {
            "automatic": False,
            "margin": 0,
            "bounds": {
                "min": [0, 0, z_min],
                "max": [2440.0, 1220.0, z_max],
            },
        },
        "files": [nc_name],
    }
    path.write_text(json.dumps(project, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_cross(
    output_dir: Path,
    *,
    stem: str,
    z_safe: float,
    z_cut: float,
    z_min: float,
    z_max: float,
) -> None:
    nc_path = output_dir / f"{stem}.nc"
    camotics_path = nc_path.with_suffix(".camotics")
    lines = [
        "(CAMotics display sanity check)",
        "(If this file opens as a solid board, CAMotics is not showing material removal in the current view.)",
        "G21",
        "G90",
        "G17",
        "T1 M6",
        f"G0 Z{z_safe:.3f}",
        "M3 S18000",
        "(Very wide horizontal slot through stock)",
        "G0 X80.000 Y610.000",
        f"G1 Z{z_cut:.3f} F600.0",
        "G1 X2360.000 Y610.000 F2400.0",
        f"G0 Z{z_safe:.3f}",
        "(Very wide vertical slot through stock)",
        "G0 X1220.000 Y80.000",
        f"G1 Z{z_cut:.3f} F600.0",
        "G1 X1220.000 Y1140.000 F2400.0",
        f"G0 Z{z_safe:.3f}",
        "M5",
        "M30",
    ]
    nc_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_project(camotics_path, nc_path.name, z_min=z_min, z_max=z_max)
    print(f"nc: {nc_path}")
    print(f"camotics: {camotics_path}")


def main() -> None:
    output_dir = Path("results/corrected_model_stage4/camotics_sanity_cross")
    output_dir.mkdir(parents=True, exist_ok=True)
    write_cross(
        output_dir,
        stem="case_camotics_sanity_cross_positive_z",
        z_safe=25.0,
        z_cut=0.0,
        z_min=0.0,
        z_max=18.0,
    )
    write_cross(
        output_dir,
        stem="case_camotics_sanity_cross_negative_z",
        z_safe=5.0,
        z_cut=-18.0,
        z_min=-18.0,
        z_max=0.0,
    )


if __name__ == "__main__":
    main()
