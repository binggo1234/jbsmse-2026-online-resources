from __future__ import annotations

import argparse
import csv
import math
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DIAGNOSTICS = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "case_large_board340"
    / "process_aware_beam_diagnostics.csv"
)
DEFAULT_METRICS = ROOT / "results" / "corrected_model_stage4" / "case_large_board340_metrics.csv"
DEFAULT_COVERAGE_DETAILS = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "geometric_coverage_audit"
    / "geometric_coverage_segment_details.csv"
)
DEFAULT_DXF = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "fusion_validation_bundle"
    / "dxf"
    / "case_large_board340_beam.dxf"
)
DEFAULT_FUSION_NC = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "fusion_validation_bundle"
    / "fusion_exported_nc"
    / "case_large_board340_beam_fusion_reference.nc"
)
DEFAULT_OUTPUT_PREFIX = (
    ROOT / "figures" / "corrected_model_stage4" / "board340_beam_route_fusion_summary"
)


plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
        "font.size": 9.0,
        "axes.titlesize": 11.0,
        "axes.labelsize": 8.8,
        "xtick.labelsize": 7.8,
        "ytick.labelsize": 7.8,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.color": "#CBD5E1",
        "grid.alpha": 0.22,
        "grid.linewidth": 0.45,
    }
)


@dataclass(frozen=True)
class Segment:
    x1: float
    y1: float
    x2: float
    y2: float

    @property
    def length(self) -> float:
        return math.hypot(self.x2 - self.x1, self.y2 - self.y1)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Plot Board340 route order, coverage audit, and Fusion NC validation summary."
    )
    parser.add_argument("--diagnostics", type=Path, default=DEFAULT_DIAGNOSTICS)
    parser.add_argument("--metrics", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--coverage-details", type=Path, default=DEFAULT_COVERAGE_DETAILS)
    parser.add_argument("--dxf", type=Path, default=DEFAULT_DXF)
    parser.add_argument("--fusion-nc", type=Path, default=DEFAULT_FUSION_NC)
    parser.add_argument("--method", default="process_aware_beam")
    parser.add_argument("--board-id", default="340")
    parser.add_argument("--output-prefix", type=Path, default=DEFAULT_OUTPUT_PREFIX)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty CSV: {path}")
        return list(reader)


def num(row: dict[str, str], field: str) -> float:
    value = row.get(field, "")
    return float(value) if value else 0.0


def load_diagnostics(path: Path) -> list[dict[str, str]]:
    rows = read_csv(path)
    if not rows:
        raise ValueError(f"no diagnostics rows: {path}")
    return rows


def load_metrics(path: Path, method: str) -> dict[str, str]:
    for row in read_csv(path):
        if row.get("method") == method:
            return row
    raise KeyError(f"method not found in metrics: {method}")


def load_coverage_segments(path: Path, board_id: str, method: str) -> list[dict[str, str]]:
    rows = [
        row
        for row in read_csv(path)
        if row.get("board_id") == board_id and row.get("method") == method
    ]
    if not rows:
        raise ValueError(f"no coverage rows for board={board_id}, method={method}")
    return rows


def rectangles_from_coverage(rows: list[dict[str, str]]) -> list[tuple[float, float, float, float]]:
    by_part: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for row in rows:
        part_id = row["part_id"]
        by_part[part_id].append((num(row, "start_x"), num(row, "start_y")))
        by_part[part_id].append((num(row, "end_x"), num(row, "end_y")))
    rectangles: list[tuple[float, float, float, float]] = []
    for points in by_part.values():
        xs = [x for x, _y in points]
        ys = [y for _x, y in points]
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        rectangles.append((x0, y0, x1 - x0, y1 - y0))
    return sorted(rectangles)


def primitive_segments_from_coverage(rows: list[dict[str, str]]) -> list[Segment]:
    seen: set[str] = set()
    segments: list[Segment] = []
    for row in rows:
        segment_id = row["segment_id"]
        if segment_id in seen:
            continue
        seen.add(segment_id)
        segments.append(
            Segment(
                num(row, "start_x"),
                num(row, "start_y"),
                num(row, "end_x"),
                num(row, "end_y"),
            )
        )
    return segments


def draw_stock_and_parts(
    ax: plt.Axes,
    rectangles: list[tuple[float, float, float, float]],
    *,
    facecolor: str = "#EAF6FF",
    edgecolor: str = "#94A3B8",
    alpha: float = 0.52,
) -> None:
    for x, y, w, h in rectangles:
        ax.add_patch(
            Rectangle(
                (x, y),
                w,
                h,
                facecolor=facecolor,
                edgecolor=edgecolor,
                linewidth=0.45,
                alpha=alpha,
                zorder=0,
            )
        )
    ax.add_patch(
        Rectangle(
            (0, 0),
            2440,
            1220,
            fill=False,
            edgecolor="#111827",
            linewidth=1.15,
            zorder=8,
        )
    )
    ax.set_xlim(-45, 2485)
    ax.set_ylim(-45, 1265)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("X (mm)")
    ax.set_ylabel("Y (mm)")


def route_segments(rows: list[dict[str, str]]) -> tuple[list[Segment], list[int], list[Segment]]:
    cuts: list[Segment] = []
    cut_indices: list[int] = []
    travels: list[Segment] = []
    for row in rows:
        segment = Segment(
            num(row, "start_x"),
            num(row, "start_y"),
            num(row, "end_x"),
            num(row, "end_y"),
        )
        if segment.length <= 1e-9:
            continue
        if row.get("action_type") == "cut":
            cuts.append(segment)
            cut_indices.append(len(cuts))
        elif row.get("action_type") == "travel":
            travels.append(segment)
    return cuts, cut_indices, travels


def draw_route_panel(
    ax: plt.Axes,
    rectangles: list[tuple[float, float, float, float]],
    diagnostics: list[dict[str, str]],
    metrics: dict[str, str],
) -> None:
    draw_stock_and_parts(ax, rectangles, facecolor="#EFF6FF", edgecolor="#CBD5E1", alpha=0.44)
    cuts, cut_indices, travels = route_segments(diagnostics)
    if travels:
        travel_lines = [[(s.x1, s.y1), (s.x2, s.y2)] for s in travels]
        ax.add_collection(
            LineCollection(
                travel_lines,
                colors="#EF4444",
                linewidths=0.55,
                linestyles="dashed",
                alpha=0.28,
                zorder=2,
            )
        )
    cut_lines = [[(s.x1, s.y1), (s.x2, s.y2)] for s in cuts]
    norm = Normalize(vmin=min(cut_indices), vmax=max(cut_indices))
    collection = LineCollection(
        cut_lines,
        cmap="viridis",
        norm=norm,
        linewidths=1.65,
        alpha=0.95,
        zorder=5,
    )
    collection.set_array(cut_indices)
    ax.add_collection(collection)
    if cuts:
        ax.scatter([cuts[0].x1], [cuts[0].y1], s=42, color="#16A34A", edgecolor="white", zorder=9)
        ax.scatter([cuts[-1].x2], [cuts[-1].y2], s=42, color="#DC2626", edgecolor="white", zorder=9)
        ax.text(cuts[0].x1 + 22, cuts[0].y1 + 22, "start", color="#166534", fontsize=8.2)
        ax.text(cuts[-1].x2 + 22, cuts[-1].y2 + 22, "end", color="#991B1B", fontsize=8.2)
    cbar = plt.colorbar(collection, ax=ax, fraction=0.031, pad=0.012)
    cbar.set_label(f"cut action order (1-{len(cuts)})")
    ax.set_title("A. Corrected route execution order")
    legend_handles = [
        Line2D([0], [0], color="#2A9D8F", lw=1.8, label="cutting move"),
        Line2D([0], [0], color="#EF4444", lw=0.9, ls="--", alpha=0.55, label="rapid travel"),
        Line2D(
            [0],
            [0],
            marker="o",
            color="none",
            markerfacecolor="#16A34A",
            markeredgecolor="white",
            markersize=5.8,
            label="start",
        ),
        Line2D(
            [0],
            [0],
            marker="o",
            color="none",
            markerfacecolor="#DC2626",
            markeredgecolor="white",
            markersize=5.8,
            label="end",
        ),
    ]
    ax.legend(
        handles=legend_handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.12),
        ncol=4,
        frameon=True,
        framealpha=0.92,
        facecolor="white",
        edgecolor="#CBD5E1",
        fontsize=7.1,
        handlelength=1.8,
        borderpad=0.45,
        labelspacing=0.28,
        columnspacing=0.9,
    )
    text = (
        f"cut actions: {len(cuts)} | travel moves: {len(travels)}\n"
        f"cut length: {num(metrics, 'cutting_length')/1000:.2f} m\n"
        f"travel-mode cost: {num(metrics, 'travel_mode_cost')/1000:.2f} m"
    )
    ax.text(
        0.015,
        0.98,
        text,
        transform=ax.transAxes,
        ha="left",
        va="top",
        bbox={
            "boxstyle": "round,pad=0.32",
            "facecolor": "white",
            "edgecolor": "#CBD5E1",
            "alpha": 0.93,
            "linewidth": 0.7,
        },
        fontsize=8.3,
        zorder=10,
    )


def draw_coverage_panel(
    ax: plt.Axes,
    rectangles: list[tuple[float, float, float, float]],
    coverage_rows: list[dict[str, str]],
) -> None:
    draw_stock_and_parts(ax, rectangles, facecolor="#ECFDF5", edgecolor="#CBD5E1", alpha=0.42)
    segments = primitive_segments_from_coverage(coverage_rows)
    full = [row for row in coverage_rows if row.get("status") == "full"]
    partial = [row for row in coverage_rows if row.get("status") == "partial"]
    missing = [row for row in coverage_rows if row.get("status") == "missing"]
    line_data = [[(s.x1, s.y1), (s.x2, s.y2)] for s in segments]
    ax.add_collection(
        LineCollection(
            line_data,
            colors="#0284C7",
            linewidths=1.35,
            alpha=0.92,
            zorder=5,
        )
    )
    ax.set_title("B. Primitive-edge coverage audit")
    text = (
        f"full primitive edges: {len(full)}/{len(coverage_rows)}\n"
        f"partial: {len(partial)} | missing: {len(missing)}\n"
        "all 30 parts complete\n"
        "120 primitive edges -> 97 Fusion cut curves"
    )
    ax.text(
        0.015,
        0.98,
        text,
        transform=ax.transAxes,
        ha="left",
        va="top",
        bbox={
            "boxstyle": "round,pad=0.32",
            "facecolor": "white",
            "edgecolor": "#A7F3D0",
            "alpha": 0.94,
            "linewidth": 0.75,
        },
        fontsize=8.3,
        zorder=10,
    )


def strip_gcode_comments(line: str) -> str:
    line = re.sub(r"\([^)]*\)", "", line)
    line = re.sub(r";.*", "", line)
    return line.strip().upper()


def gcode_words(line: str) -> dict[str, float]:
    return {
        match.group(1): float(match.group(2))
        for match in re.finditer(r"([A-Z])\s*([-+]?\d+(?:\.\d*)?)", line)
    }


def norm_axis_segment(x1: float, y1: float, x2: float, y2: float):
    if abs(y1 - y2) < 1e-6:
        return ("H", round(y1, 3), tuple(sorted((round(x1, 3), round(x2, 3)))))
    if abs(x1 - x2) < 1e-6:
        return ("V", round(x1, 3), tuple(sorted((round(y1, 3), round(y2, 3)))))
    return ("D", None, tuple(sorted(((round(x1, 3), round(y1, 3)), (round(x2, 3), round(y2, 3))))))


def merge_intervals(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
    intervals = sorted(intervals)
    merged: list[list[float]] = []
    for a, b in intervals:
        if b < a:
            a, b = b, a
        if not merged or a > merged[-1][1] + 1e-6:
            merged.append([a, b])
        else:
            merged[-1][1] = max(merged[-1][1], b)
    return [(a, b) for a, b in merged]


def covered_length(target: tuple[float, float], covers: list[tuple[float, float]]) -> float:
    a, b = target
    total = 0.0
    for c, d in merge_intervals(covers):
        lo, hi = max(a, c), min(b, d)
        if hi > lo + 1e-6:
            total += hi - lo
    return total


def load_dxf_cut_segments(path: Path):
    lines = path.read_text(encoding="ascii", errors="ignore").splitlines()
    segments = []
    i = 0
    while i < len(lines):
        if lines[i].strip() == "0" and i + 1 < len(lines) and lines[i + 1].strip() == "LINE":
            j = i + 2
            data: dict[str, str] = {}
            while j + 1 < len(lines) and not (
                lines[j].strip() == "0"
                and lines[j + 1].strip() in {"LINE", "TEXT", "ENDSEC", "EOF"}
            ):
                data[lines[j].strip()] = lines[j + 1].strip()
                j += 2
            if data.get("8", "") != "STOCK":
                x1, y1 = float(data["10"]), float(data["20"])
                x2, y2 = float(data["11"]), float(data["21"])
                segments.append(norm_axis_segment(x1, y1, x2, y2))
            i = j
        else:
            i += 1
    return segments


def analyze_fusion_nc(nc_path: Path, dxf_path: Path) -> dict[str, object]:
    pos = (0.0, 0.0, 0.0)
    mode = 0
    xy_segments = []
    z_counts: dict[float, int] = defaultdict(int)
    z_lengths: dict[float, float] = defaultdict(float)
    xs: list[float] = []
    ys: list[float] = []
    for raw in nc_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = strip_gcode_comments(raw)
        if not line:
            continue
        for value in re.findall(r"\bG\s*([-+]?\d+(?:\.\d*)?)", line):
            code = int(float(value))
            if code in (0, 1, 2, 3):
                mode = code
        words = gcode_words(line)
        target = (
            words.get("X", pos[0]),
            words.get("Y", pos[1]),
            words.get("Z", pos[2]),
        )
        if math.dist(pos, target) > 1e-9:
            xs.extend([pos[0], target[0]])
            ys.extend([pos[1], target[1]])
            if mode == 1:
                xy_len = math.hypot(target[0] - pos[0], target[1] - pos[1])
                if xy_len > 1e-6:
                    z = round(target[2], 3)
                    xy_segments.append((*norm_axis_segment(pos[0], pos[1], target[0], target[1]), z, xy_len))
                    z_counts[z] += 1
                    z_lengths[z] += xy_len
            pos = target

    dxf_segments = load_dxf_cut_segments(dxf_path)
    all_cover: dict[tuple[str, float], list[tuple[float, float]]] = defaultdict(list)
    per_z_cover: dict[float, dict[tuple[str, float], list[tuple[float, float]]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for orientation, axis, interval, z, _length in xy_segments:
        if orientation == "D":
            continue
        all_cover[(orientation, axis)].append(interval)
        per_z_cover[z][(orientation, axis)].append(interval)

    def coverage_counts(cover_map) -> tuple[int, int, int, float]:
        full = partial = missing = 0
        covered = 0.0
        for orientation, axis, interval in dxf_segments:
            if orientation == "D":
                continue
            length = abs(interval[1] - interval[0])
            got = covered_length(interval, cover_map[(orientation, axis)])
            covered += min(length, got)
            ratio = got / length if length else 1.0
            if ratio >= 0.999999:
                full += 1
            elif ratio <= 1e-9:
                missing += 1
            else:
                partial += 1
        return full, partial, missing, covered

    full, partial, missing, covered = coverage_counts(all_cover)
    per_z = {}
    for z in sorted(z_counts):
        per_z[z] = coverage_counts(per_z_cover[z])

    total_dxf_length = sum(abs(interval[1] - interval[0]) for _o, _a, interval in dxf_segments)
    return {
        "file_size": nc_path.stat().st_size,
        "line_count": len(nc_path.read_text(encoding="utf-8", errors="ignore").splitlines()),
        "xy_g1_count": len(xy_segments),
        "z_counts": dict(sorted(z_counts.items())),
        "z_lengths": {z: z_lengths[z] for z in sorted(z_lengths)},
        "dxf_line_count": len(dxf_segments),
        "full": full,
        "partial": partial,
        "missing": missing,
        "covered_length": covered,
        "total_dxf_length": total_dxf_length,
        "per_z": per_z,
        "x_range": (min(xs), max(xs)) if xs else (0.0, 0.0),
        "y_range": (min(ys), max(ys)) if ys else (0.0, 0.0),
    }


def draw_fusion_summary(ax: plt.Axes, fusion: dict[str, object]) -> None:
    ax.axis("off")
    z_counts = fusion["z_counts"]
    z_lengths = fusion["z_lengths"]
    z_order = sorted(z_counts, reverse=True)
    full = fusion["full"]
    dxf_line_count = fusion["dxf_line_count"]
    covered_length = fusion["covered_length"]
    total_length = fusion["total_dxf_length"]
    lines = [
        ("Result", "PASS: complete selected-curve coverage on all depth passes"),
        ("Fusion NC reference", "Board340 beam, Autodesk Fusion Manufacture export"),
        ("Geometry selection", f"{full}/{dxf_line_count} DXF cut lines covered; partial=0, missing=0"),
        ("Depth passes", ", ".join(f"Z={z:g}: {z_counts[z]} XY cuts" for z in z_order)),
        ("Per-pass length", ", ".join(f"{z_lengths[z]/1000:.2f} m at Z={z:g}" for z in z_order)),
        ("Total target coverage", f"{covered_length:.1f}/{total_length:.1f} mm across each pass"),
        ("NC file", f"{fusion['line_count']} lines, {fusion['file_size']/1024:.1f} KiB"),
    ]
    ax.text(
        0.0,
        1.02,
        "C. Fusion NC three-pass reference check",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color="#111827",
    )
    ax.text(
        0.985,
        1.015,
        "PASS",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=10.5,
        fontweight="bold",
        color="#047857",
        bbox={
            "boxstyle": "round,pad=0.32",
            "facecolor": "#ECFDF5",
            "edgecolor": "#A7F3D0",
            "linewidth": 0.8,
        },
    )
    x0, y0 = 0.0, 0.91
    row_h = 0.098
    for idx, (label, value) in enumerate(lines):
        y = y0 - idx * row_h
        fill = "#F8FAFC" if idx % 2 == 0 else "#FFFFFF"
        ax.add_patch(
            Rectangle(
                (x0, y - row_h + 0.012),
                1.0,
                row_h,
                transform=ax.transAxes,
                facecolor=fill,
                edgecolor="#E2E8F0",
                linewidth=0.65,
            )
        )
        ax.text(0.02, y - 0.048, label, transform=ax.transAxes, ha="left", va="center", fontweight="bold")
        ax.text(0.28, y - 0.048, value, transform=ax.transAxes, ha="left", va="center", color="#1F2937")
    ax.text(
        0.02,
        0.025,
        "Use: presentation evidence for route readability, geometric coverage, and auxiliary commercial-CAM NC export. "
        "Not measured machine cycle time.",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8.0,
        color="#475569",
    )


def main() -> None:
    args = parse_args()
    diagnostics = load_diagnostics(args.diagnostics)
    metrics = load_metrics(args.metrics, args.method)
    coverage_rows = load_coverage_segments(args.coverage_details, args.board_id, args.method)
    rectangles = rectangles_from_coverage(coverage_rows)
    fusion = analyze_fusion_nc(args.fusion_nc, args.dxf)

    if fusion["full"] != fusion["dxf_line_count"] or fusion["partial"] or fusion["missing"]:
        raise RuntimeError("Fusion NC does not fully cover the DXF cut-line network")
    expected_z = {-6.0, -12.0, -18.0}
    if set(fusion["z_counts"]) != expected_z:
        raise RuntimeError(f"Fusion NC depth levels are {sorted(fusion['z_counts'])}, expected {sorted(expected_z)}")
    for z, (full, partial, missing, _covered) in fusion["per_z"].items():
        if full != fusion["dxf_line_count"] or partial or missing:
            raise RuntimeError(f"Fusion NC does not fully cover DXF at Z={z}")

    fig = plt.figure(figsize=(13.8, 8.4), constrained_layout=True)
    grid = fig.add_gridspec(2, 2, height_ratios=[1.0, 0.43])
    ax_route = fig.add_subplot(grid[0, 0])
    ax_coverage = fig.add_subplot(grid[0, 1])
    ax_fusion = fig.add_subplot(grid[1, :])

    draw_route_panel(ax_route, rectangles, diagnostics, metrics)
    draw_coverage_panel(ax_coverage, rectangles, coverage_rows)
    draw_fusion_summary(ax_fusion, fusion)
    fig.suptitle(
        "Board340 corrected route: order, full coverage, and Fusion NC check",
        fontsize=13.5,
        fontweight="bold",
    )

    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    png_path = args.output_prefix.with_suffix(".png")
    pdf_path = args.output_prefix.with_suffix(".pdf")
    fig.savefig(png_path)
    fig.savefig(pdf_path)
    print(f"wrote {png_path}")
    print(f"wrote {pdf_path}")
    print(
        "fusion_check",
        f"dxf={fusion['full']}/{fusion['dxf_line_count']}",
        f"z={sorted(fusion['z_counts'])}",
    )


if __name__ == "__main__":
    main()
