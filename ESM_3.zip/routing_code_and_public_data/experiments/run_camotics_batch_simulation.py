from __future__ import annotations

import argparse
import csv
import os
import subprocess
import time
from pathlib import Path


DEFAULT_CAMSIM = Path("/Applications/CAMotics.app/Contents/MacOS/camsim")
DEFAULT_FRAMEWORKS = Path("/Applications/CAMotics.app/Contents/Frameworks")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run CAMotics command-line simulation for every .camotics project "
            "in the validation bundle and write STL/log artifacts."
        )
    )
    parser.add_argument(
        "--bundle-dir",
        type=Path,
        default=Path("results/camotics_validation_bundle"),
    )
    parser.add_argument("--camsim", type=Path, default=DEFAULT_CAMSIM)
    parser.add_argument("--frameworks", type=Path, default=DEFAULT_FRAMEWORKS)
    parser.add_argument("--resolution", default="low")
    parser.add_argument("--threads", default="4")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    bundle_dir = args.bundle_dir
    if not bundle_dir.exists():
        raise FileNotFoundError(bundle_dir)
    if not args.camsim.exists():
        raise FileNotFoundError(args.camsim)

    stl_dir = bundle_dir / "stl"
    log_dir = bundle_dir / "camsim_logs"
    stl_dir.mkdir(exist_ok=True)
    log_dir.mkdir(exist_ok=True)

    env = os.environ.copy()
    env["DYLD_LIBRARY_PATH"] = str(args.frameworks)
    command_prefix = [
        str(args.camsim),
        "--resolution",
        str(args.resolution),
        "--threads",
        str(args.threads),
    ]

    rows: list[dict[str, object]] = []
    for project in sorted(bundle_dir.glob("case_*.camotics")):
        stem = project.stem
        stl_path = stl_dir / f"{stem}.stl"
        log_path = log_dir / f"{stem}.log"
        command = command_prefix + [str(project), str(stl_path)]
        start = time.time()
        proc = subprocess.run(command, text=True, capture_output=True, env=env)
        elapsed = time.time() - start
        text = proc.stdout + proc.stderr
        log_path.write_text(text, encoding="utf-8")
        row = {
            "project": project.name,
            "stl": str(stl_path.relative_to(bundle_dir)),
            "log": str(log_path.relative_to(bundle_dir)),
            "returncode": proc.returncode,
            "elapsed_s": f"{elapsed:.3f}",
            "stl_exists": stl_path.exists(),
            "stl_size_bytes": stl_path.stat().st_size if stl_path.exists() else 0,
            "warning_count": text.count("WARNING"),
            "error_count": text.lower().count("error"),
        }
        rows.append(row)
        print(
            project.name,
            f"return={proc.returncode}",
            f"elapsed={elapsed:.2f}s",
            f"warnings={row['warning_count']}",
            f"errors={row['error_count']}",
        )

    if not rows:
        raise RuntimeError(f"no .camotics projects found in {bundle_dir}")

    summary_path = bundle_dir / "camsim_batch_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(rows[0].keys()),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {summary_path}")


if __name__ == "__main__":
    main()
