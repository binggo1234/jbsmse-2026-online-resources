from __future__ import annotations

import csv
import json
import shutil
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.export_gcode_from_diagnostics import NcTemplate, export_route


METHODS = (
    ("baseline", "process_aware_beam_diagnostics.csv"),
    ("proposed", "process_aware_beam_adaptive_polished_diagnostics.csv"),
)

SELECTED_CASES = (
    (
        "case_01_large_board",
        "Large production-derived route pair",
        Path("results/chapter3_route_cases/case_large_board340"),
    ),
    (
        "case_02_medium_board",
        "Medium production-derived route pair",
        Path("results/chapter3_route_cases/case_mid_board262"),
    ),
    (
        "case_03_small_board",
        "Small/ordinary production-derived route pair",
        Path("results/chapter3_route_cases/case_small_board4"),
    ),
    (
        "case_04_high_gain",
        "High rapid-XY-reduction route pair",
        Path("results/paper_artifacts_final_selector/route_case_large_gain_diagnostics"),
    ),
    (
        "case_05_low_gain",
        "Low NC-time-gain route pair used as a conservative control",
        Path("results/representative_route_cases_after_runtime_opt/main_adaptive_gain_diagnostics"),
    ),
)


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def pct_delta(before: float, after: float) -> float:
    if before == 0:
        return 0.0
    return 100.0 * (before - after) / before


def rewrite_camotics_project(path: Path, nc_name: str) -> None:
    project = json.loads(path.read_text(encoding="utf-8"))
    project["files"] = [nc_name]
    path.write_text(json.dumps(project, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def copy_source_diagnostics(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def build_readme(output_dir: Path, template: NcTemplate, pair_rows: list[dict[str, object]]) -> None:
    mean_time = sum(float(row["estimated_time_reduction_pct"]) for row in pair_rows) / len(pair_rows)
    mean_xy = sum(float(row["rapid_xy_reduction_pct"]) for row in pair_rows) / len(pair_rows)
    text = f"""# CAMotics Validation Bundle

This folder is a compact, reproducible NC-level inspection bundle for the
panel-furniture CNC routing manuscript. It contains five representative route
pairs selected from the eight generic NC exports used in the paper:

1. a large production-derived route pair;
2. a medium production-derived route pair;
3. a small/ordinary production-derived route pair;
4. a high rapid-XY-reduction route pair; and
5. a low NC-time-gain route pair used as a conservative control.

The files are generic 3-axis G-code programs and CAMotics project files. They
are not machine-specific post-processor outputs and do not replace
controller-level verification, commercial CAM simulation, or physical cutting
tests.

## Template

- Units: millimetres (`G21`)
- Coordinate mode: absolute (`G90`)
- Stock: {template.stock_width_mm:g} x {template.stock_height_mm:g} x {template.stock_thickness_mm:g} mm
- Tool diameter: {template.tool_diameter_mm:g} mm
- Safe Z: {template.z_safe_mm:g} mm
- Step-down: {template.step_down_mm:g} mm
- Final cutting depth: -{template.stock_thickness_mm:g} mm
- Spindle: {template.spindle_rpm:g} rpm
- Cut feed: {template.feed_cut_mm_min:g} mm/min
- Plunge feed: {template.feed_plunge_mm_min:g} mm/min
- Rapid feed used for kinematic estimation: {template.feed_rapid_mm_min:g} mm/min

All compared methods use the same stock, tool, depth, feed, retract, and plunge
template. Differences therefore come from XY route order and event structure,
not from different CAM operation settings.

## Files

- `case_summary.csv`: route-level metrics for all ten exported NC programs.
- `pair_summary.csv`: paired baseline/proposed reductions for the five cases.
- `diagnostics/`: copied source route diagnostic CSV files.
- `screenshots/`: place CAMotics screenshots here after manual GUI inspection.
- `case_XX_*.nc`: generic G-code programs.
- `case_XX_*.camotics`: CAMotics project files referencing the matching `.nc`.

## Aggregate Inspection Result

Across the five selected route pairs, the mean estimated-time reduction under
the fixed template is {mean_time:.2f}%, while the mean rapid-XY reduction is
{mean_xy:.2f}%. These are kinematic inspection metrics, not measured machine
cycle-time reductions.

## Manual CAMotics Workflow

For each pair:

1. Open `case_XX_baseline.camotics` and run the simulation.
2. Save a screenshot to `screenshots/case_XX_baseline_camotics.png`.
3. Open `case_XX_proposed.camotics` with the same view settings.
4. Save a screenshot to `screenshots/case_XX_proposed_camotics.png`.
5. Confirm that the file loads, remains inside the stock envelope, reaches the
   full panel depth, and follows the expected primitive-edge paths.

On macOS, if `.camotics` files are not associated with CAMotics, open a project
explicitly, for example:

```bash
open -a /Applications/CAMotics.app case_01_large_board_baseline.camotics
```

Suggested manuscript wording: this bundle verifies that representative planning
routes can be exported as readable 3-axis NC programs under a common fixed-depth
template. It is not evidence of measured shop-floor cycle-time reduction.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def build_checklist(output_dir: Path) -> None:
    text = """# CAMotics Manual Inspection Checklist

Use this checklist for every `.camotics` project in the bundle.

- [ ] Project opens without a G-code parse error.
- [ ] Stock is `2440 x 1220 x 18 mm`.
- [ ] Tool diameter is `6 mm`.
- [ ] Toolpath remains inside the stock envelope.
- [ ] Final cutting depth reaches `-18 mm`.
- [ ] Material-removal pattern follows the expected primitive-edge segments.
- [ ] Screenshot saved with matching baseline/proposed camera settings.
- [ ] Notes recorded for any unexpected warning.

Recommended screenshot names:

- `screenshots/case_01_baseline_camotics.png`
- `screenshots/case_01_proposed_camotics.png`
- ...
- `screenshots/case_05_baseline_camotics.png`
- `screenshots/case_05_proposed_camotics.png`

If macOS does not associate `.camotics` files automatically, use:

```bash
open -a /Applications/CAMotics.app case_01_large_board_baseline.camotics
```

Do not describe these screenshots as commercial CAM validation or physical CNC
testing. They are NC-level G-code inspection artifacts.
"""
    (output_dir / "CAMOTICS_CHECKLIST.md").write_text(text, encoding="utf-8")


def main() -> None:
    output_dir = Path("results/camotics_validation_bundle")
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)
    (output_dir / "diagnostics").mkdir()
    (output_dir / "screenshots").mkdir()

    template = NcTemplate()
    route_rows: list[dict[str, object]] = []
    route_by_case_method: dict[tuple[str, str], dict[str, object]] = {}

    for case_id, description, case_dir in SELECTED_CASES:
        for method_label, filename in METHODS:
            source = case_dir / filename
            if not source.exists():
                raise FileNotFoundError(source)
            metric = export_route(source, output_dir, template)
            generated_nc = Path(metric.gcode_file)
            generated_camotics = generated_nc.with_suffix(".camotics")

            target_nc = output_dir / f"{case_id}_{method_label}.nc"
            target_camotics = output_dir / f"{case_id}_{method_label}.camotics"
            generated_nc.rename(target_nc)
            generated_camotics.rename(target_camotics)
            rewrite_camotics_project(target_camotics, target_nc.name)

            diagnostic_copy = output_dir / "diagnostics" / f"{case_id}_{method_label}_diagnostics.csv"
            copy_source_diagnostics(source, diagnostic_copy)

            row = asdict(metric)
            row.update(
                {
                    "bundle_case_id": case_id,
                    "bundle_case_description": description,
                    "bundle_method": method_label,
                    "diagnostics_csv": str(diagnostic_copy),
                    "gcode_file": str(target_nc),
                    "camotics_file": str(target_camotics),
                }
            )
            route_rows.append(row)
            route_by_case_method[(case_id, method_label)] = row

    pair_rows: list[dict[str, object]] = []
    for case_id, description, _case_dir in SELECTED_CASES:
        baseline = route_by_case_method[(case_id, "baseline")]
        proposed = route_by_case_method[(case_id, "proposed")]
        time_delta = float(baseline["estimated_total_time_s"]) - float(
            proposed["estimated_total_time_s"]
        )
        rapid_delta = float(baseline["rapid_xy_length_mm"]) - float(
            proposed["rapid_xy_length_mm"]
        )
        pair_rows.append(
            {
                "bundle_case_id": case_id,
                "bundle_case_description": description,
                "baseline_estimated_total_time_s": f"{float(baseline['estimated_total_time_s']):.6f}",
                "proposed_estimated_total_time_s": f"{float(proposed['estimated_total_time_s']):.6f}",
                "estimated_time_delta_s": f"{time_delta:.6f}",
                "estimated_time_reduction_pct": f"{pct_delta(float(baseline['estimated_total_time_s']), float(proposed['estimated_total_time_s'])):.6f}",
                "baseline_rapid_xy_length_mm": f"{float(baseline['rapid_xy_length_mm']):.6f}",
                "proposed_rapid_xy_length_mm": f"{float(proposed['rapid_xy_length_mm']):.6f}",
                "rapid_xy_delta_mm": f"{rapid_delta:.6f}",
                "rapid_xy_reduction_pct": f"{pct_delta(float(baseline['rapid_xy_length_mm']), float(proposed['rapid_xy_length_mm'])):.6f}",
                "baseline_planar_cut_length_mm": f"{float(baseline['planar_cut_length_mm']):.6f}",
                "proposed_planar_cut_length_mm": f"{float(proposed['planar_cut_length_mm']):.6f}",
                "baseline_out_of_bounds": baseline["out_of_bounds_action_count"],
                "proposed_out_of_bounds": proposed["out_of_bounds_action_count"],
                "baseline_hard_penalty": f"{float(baseline['hard_penalty_sum']):.6f}",
                "proposed_hard_penalty": f"{float(proposed['hard_penalty_sum']):.6f}",
            }
        )

    write_rows(output_dir / "case_summary.csv", route_rows)
    write_rows(output_dir / "pair_summary.csv", pair_rows)
    build_readme(output_dir, template, pair_rows)
    build_checklist(output_dir)
    print(f"wrote CAMotics validation bundle: {output_dir}")
    print(f"route programs: {len(route_rows)}")
    print(f"route pairs: {len(pair_rows)}")


if __name__ == "__main__":
    main()
