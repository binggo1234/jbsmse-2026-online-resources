from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.geometry import rectangle_edges
from cnc_cutting.io import (
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.models import CuttingUnit, EdgeOrientation, EdgeSegment, Layout, ToolConfig


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PRIVATE_DATA_ROOT = Path("<LOCAL_HOME>/Desktop/codex_handoff_20260502/data")
REQUIRED_METRIC_FIELDS = {"archive", "placements_member", "board_id", "method"}
TOLERANCE = 1e-6


@dataclass(frozen=True)
class RouteJob:
    metrics_file: Path
    diagnostics_file: Path
    archive: str
    placements_member: str
    board_id: str
    method: str
    metric_row_index: int


@dataclass(frozen=True)
class SegmentAuditRow:
    route_key: str
    metrics_file: str
    diagnostics_file: str
    archive: str
    placements_member: str
    board_id: str
    method: str
    part_id: str
    segment_id: str
    edge_role: str
    orientation: str
    start_x: float
    start_y: float
    end_x: float
    end_y: float
    segment_length_mm: float
    geometry_covered_length_mm: float
    geometry_coverage_ratio: float
    status: str
    merged_axis_intervals: str
    source_action_count: int
    source_unit_count: int
    source_unit_types: str
    source_units: str


@dataclass(frozen=True)
class RouteAuditSummary:
    route_key: str
    metrics_file: str
    diagnostics_file: str
    archive: str
    placements_member: str
    board_id: str
    method: str
    rectangle_count: int
    cut_action_count: int
    primitive_segment_count: int
    id_covered_segment_count: int
    id_missing_segment_count: int
    geometry_full_segment_count: int
    geometry_partial_segment_count: int
    geometry_missing_segment_count: int
    incomplete_part_count: int
    complete_part_count: int
    total_primitive_length_mm: float
    geometry_covered_length_mm: float
    geometry_uncovered_length_mm: float
    geometry_coverage_ratio: float
    missing_unit_reference_count: int
    zero_length_cut_action_count: int
    partial_with_single_edge_source: int
    partial_with_shared_edge_source: int
    partial_with_near_shared_source: int
    partial_with_collinear_source: int
    missing_with_no_source: int
    issue_flag: int


@dataclass(frozen=True)
class SkippedRow:
    metrics_file: str
    metric_row_index: int
    method: str
    reason: str


@dataclass(frozen=True)
class LoadedCase:
    layout: Layout
    tool: ToolConfig
    unit_by_id: dict[str, CuttingUnit]
    primitive_segments: dict[str, EdgeSegment]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Audit geometric primitive-edge coverage for stored route diagnostics. "
            "This separates old covered_segment_ids counts from actual axis-span "
            "coverage induced by the route action geometry."
        )
    )
    parser.add_argument("--data-root", type=Path, default=DEFAULT_PRIVATE_DATA_ROOT)
    parser.add_argument(
        "--metrics-glob",
        default="results/**/*_metrics.csv",
        help="Glob, relative to repo root, for route metric CSV files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results" / "geometric_coverage_audit",
    )
    parser.add_argument(
        "--fixed-tolerance-mode",
        choices=("tool-radius", "min-channel-half"),
        default="tool-radius",
        help=(
            "Maximum perpendicular distance for counting a route centerline as "
            "covering a primitive edge. tool-radius is physical; min-channel-half "
            "matches the current near-shared unit abstraction."
        ),
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Optional limit on audited route rows after filtering; 0 means all.",
    )
    return parser.parse_args()


def read_csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            return [], []
        return reader.fieldnames, list(reader)


def write_csv(path: Path, rows: Iterable[object], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            if hasattr(row, "__dataclass_fields__"):
                writer.writerow(asdict(row))
            else:
                writer.writerow(row)  # type: ignore[arg-type]


def relative(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT))
    except ValueError:
        return str(path)


def diagnostic_dir_candidates(metrics_file: Path) -> tuple[Path, ...]:
    stem = metrics_file.stem
    base = stem[: -len("_metrics")] if stem.endswith("_metrics") else stem
    bases = [base]
    if base.endswith("_route"):
        bases.append(base[: -len("_route")])
    candidates: list[Path] = []
    for item in bases:
        candidates.extend(
            [
                metrics_file.parent / item,
                metrics_file.parent / f"{item}_diagnostics",
            ]
        )
    return tuple(dict.fromkeys(candidates))


def find_diagnostics_file(metrics_file: Path, method: str) -> Path | None:
    filename = f"{method}_diagnostics.csv"
    for directory in diagnostic_dir_candidates(metrics_file):
        candidate = directory / filename
        if candidate.exists():
            return candidate
    return None


def resolve_explicit_diagnostics_file(value: str, metrics_file: Path) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    root_candidate = ROOT / path
    if root_candidate.exists():
        return root_candidate
    metrics_candidate = metrics_file.parent / path
    if metrics_candidate.exists():
        return metrics_candidate
    return root_candidate


def discover_jobs(metrics_files: list[Path]) -> tuple[list[RouteJob], list[SkippedRow]]:
    jobs: list[RouteJob] = []
    skipped: list[SkippedRow] = []
    for metrics_file in metrics_files:
        fieldnames, rows = read_csv_rows(metrics_file)
        if not rows:
            skipped.append(
                SkippedRow(relative(metrics_file), -1, "", "empty or unreadable metrics CSV")
            )
            continue
        if not REQUIRED_METRIC_FIELDS <= set(fieldnames):
            skipped.append(
                SkippedRow(
                    relative(metrics_file),
                    -1,
                    "",
                    "missing required archive/placements_member/board_id/method fields",
                )
            )
            continue
        for index, row in enumerate(rows):
            method = row.get("method", "")
            diagnostics_file = None
            explicit_diagnostics = row.get("diagnostics_file", "").strip()
            if explicit_diagnostics:
                diagnostics_file = resolve_explicit_diagnostics_file(
                    explicit_diagnostics,
                    metrics_file,
                )
                if not diagnostics_file.exists():
                    skipped.append(
                        SkippedRow(
                            relative(metrics_file),
                            index,
                            method,
                            (
                                "diagnostics_file path not found: "
                                f"{explicit_diagnostics}"
                            ),
                        )
                    )
                    continue
            else:
                diagnostics_file = find_diagnostics_file(metrics_file, method)
            if diagnostics_file is None:
                skipped.append(
                    SkippedRow(
                        relative(metrics_file),
                        index,
                        method,
                        f"diagnostics file not found for method {method}",
                    )
                )
                continue
            jobs.append(
                RouteJob(
                    metrics_file=metrics_file,
                    diagnostics_file=diagnostics_file,
                    archive=row["archive"],
                    placements_member=row["placements_member"],
                    board_id=row["board_id"],
                    method=method,
                    metric_row_index=index,
                )
            )
    return jobs, skipped


def load_case(
    job: RouteJob,
    data_root: Path,
    cache: dict[tuple[str, str, str], LoadedCase],
) -> LoadedCase:
    key = (job.archive, job.placements_member, job.board_id)
    cached = cache.get(key)
    if cached is not None:
        return cached
    zip_path = data_root / job.archive
    if not zip_path.exists():
        raise FileNotFoundError(zip_path)
    cfg = load_chapter2_config_from_zip(
        zip_path,
        placements_member=job.placements_member,
    )
    tool = tool_config_from_chapter2_config(cfg)
    layout = load_chapter2_layouts_from_zip(
        zip_path,
        placements_member=job.placements_member,
        board_ids=(job.board_id,),
    )[0]
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    primitive_segments = {
        edge.segment_id: edge
        for rectangle in layout.rectangles
        for edge in rectangle_edges(rectangle)
    }
    loaded = LoadedCase(
        layout=layout,
        tool=tool,
        unit_by_id={unit.unit_id: unit for unit in units},
        primitive_segments=primitive_segments,
    )
    cache[key] = loaded
    return loaded


def number(row: dict[str, str], field: str, default: float = 0.0) -> float:
    value = row.get(field, "")
    if value == "":
        return default
    return float(value)


def edge_orientation(segment: EdgeSegment) -> EdgeOrientation:
    return segment.orientation


def point_orientation(x1: float, y1: float, x2: float, y2: float) -> EdgeOrientation | None:
    if abs(y1 - y2) <= TOLERANCE and abs(x1 - x2) > TOLERANCE:
        return EdgeOrientation.HORIZONTAL
    if abs(x1 - x2) <= TOLERANCE and abs(y1 - y2) > TOLERANCE:
        return EdgeOrientation.VERTICAL
    return None


def segment_axis_interval(segment: EdgeSegment) -> tuple[float, float]:
    if segment.orientation == EdgeOrientation.HORIZONTAL:
        return min(segment.start.x, segment.end.x), max(segment.start.x, segment.end.x)
    return min(segment.start.y, segment.end.y), max(segment.start.y, segment.end.y)


def action_axis_interval(
    orientation: EdgeOrientation,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
) -> tuple[float, float]:
    if orientation == EdgeOrientation.HORIZONTAL:
        return min(x1, x2), max(x1, x2)
    return min(y1, y2), max(y1, y2)


def segment_fixed_coordinate(segment: EdgeSegment) -> float:
    if segment.orientation == EdgeOrientation.HORIZONTAL:
        return segment.start.y
    return segment.start.x


def action_fixed_coordinate(orientation: EdgeOrientation, x1: float, y1: float) -> float:
    if orientation == EdgeOrientation.HORIZONTAL:
        return y1
    return x1


def merge_intervals(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
    merged: list[list[float]] = []
    for left, right in sorted(intervals):
        if right <= left + TOLERANCE:
            continue
        if not merged or left > merged[-1][1] + TOLERANCE:
            merged.append([left, right])
        else:
            merged[-1][1] = max(merged[-1][1], right)
    return [(left, right) for left, right in merged]


def route_key(job: RouteJob) -> str:
    return (
        f"{relative(job.metrics_file)}::row{job.metric_row_index}::"
        f"board{job.board_id}::{job.method}"
    )


def single_unit_id_for_segment(segment_id: str) -> str:
    return f"single:{segment_id}"


def unit_for_row(row: dict[str, str], unit_by_id: dict[str, CuttingUnit]) -> CuttingUnit | None:
    unit_id = row.get("cutting_unit_id", "")
    if unit_id and unit_id in unit_by_id:
        return unit_by_id[unit_id]
    segment_id = row.get("segment_id", "")
    if segment_id:
        return unit_by_id.get(single_unit_id_for_segment(segment_id))
    return None


def fixed_tolerance(tool: ToolConfig, mode: str) -> float:
    if mode == "min-channel-half":
        return tool.min_channel_width / 2.0
    return tool.tool_radius


def audit_route(
    job: RouteJob,
    loaded: LoadedCase,
    fixed_tolerance_mode: str,
) -> tuple[RouteAuditSummary, list[SegmentAuditRow]]:
    _, diagnostic_rows = read_csv_rows(job.diagnostics_file)
    axis_intervals_by_segment: dict[str, list[tuple[float, float]]] = defaultdict(list)
    source_actions_by_segment: dict[str, set[int]] = defaultdict(set)
    source_units_by_segment: dict[str, set[str]] = defaultdict(set)
    source_types_by_segment: dict[str, set[str]] = defaultdict(set)
    id_covered: set[str] = set()
    missing_unit_reference_count = 0
    zero_length_cut_action_count = 0
    cut_action_count = 0
    max_fixed_gap = fixed_tolerance(loaded.tool, fixed_tolerance_mode) + TOLERANCE

    for row in diagnostic_rows:
        if row.get("action_type") != "cut":
            continue
        cut_action_count += 1
        x1 = number(row, "start_x")
        y1 = number(row, "start_y")
        x2 = number(row, "end_x")
        y2 = number(row, "end_y")
        orientation = point_orientation(x1, y1, x2, y2)
        if orientation is None:
            zero_length_cut_action_count += 1
            continue
        unit = unit_for_row(row, loaded.unit_by_id)
        if unit is None:
            missing_unit_reference_count += 1
            continue
        id_covered.update(unit.covered_segment_ids)
        action_left, action_right = action_axis_interval(orientation, x1, y1, x2, y2)
        action_fixed = action_fixed_coordinate(orientation, x1, y1)
        action_index = int(row["action_index"])
        unit_type = unit.unit_type.value
        for segment in unit.segments:
            if segment.segment_id not in loaded.primitive_segments:
                continue
            if edge_orientation(segment) != orientation:
                continue
            fixed_gap = abs(segment_fixed_coordinate(segment) - action_fixed)
            if fixed_gap > max_fixed_gap:
                continue
            segment_left, segment_right = segment_axis_interval(segment)
            left = max(action_left, segment_left)
            right = min(action_right, segment_right)
            if right <= left + TOLERANCE:
                continue
            axis_intervals_by_segment[segment.segment_id].append((left, right))
            source_actions_by_segment[segment.segment_id].add(action_index)
            source_units_by_segment[segment.segment_id].add(unit.unit_id)
            source_types_by_segment[segment.segment_id].add(unit_type)

    segment_rows: list[SegmentAuditRow] = []
    full_count = 0
    partial_count = 0
    missing_count = 0
    incomplete_parts: set[str] = set()
    complete_parts: set[str] = set()
    partial_type_counts = Counter()
    missing_with_no_source = 0
    total_length = 0.0
    covered_length = 0.0

    part_to_statuses: dict[str, list[str]] = defaultdict(list)
    for segment_id, segment in sorted(loaded.primitive_segments.items()):
        merged = merge_intervals(axis_intervals_by_segment[segment_id])
        segment_covered_length = sum(right - left for left, right in merged)
        total_length += segment.length
        covered_length += min(segment.length, segment_covered_length)
        if segment_covered_length <= TOLERANCE:
            status = "missing"
            missing_count += 1
            if not source_units_by_segment[segment_id]:
                missing_with_no_source += 1
        elif segment_covered_length < segment.length - TOLERANCE:
            status = "partial"
            partial_count += 1
            partial_type_counts.update(source_types_by_segment[segment_id])
        else:
            status = "full"
            full_count += 1
        part_to_statuses[segment.part_id].append(status)
        segment_rows.append(
            SegmentAuditRow(
                route_key=route_key(job),
                metrics_file=relative(job.metrics_file),
                diagnostics_file=relative(job.diagnostics_file),
                archive=job.archive,
                placements_member=job.placements_member,
                board_id=job.board_id,
                method=job.method,
                part_id=segment.part_id,
                segment_id=segment_id,
                edge_role=segment.role.value,
                orientation=segment.orientation.value,
                start_x=segment.start.x,
                start_y=segment.start.y,
                end_x=segment.end.x,
                end_y=segment.end.y,
                segment_length_mm=segment.length,
                geometry_covered_length_mm=segment_covered_length,
                geometry_coverage_ratio=(
                    min(1.0, segment_covered_length / segment.length)
                    if segment.length
                    else 1.0
                ),
                status=status,
                merged_axis_intervals=";".join(
                    f"{left:.6f}-{right:.6f}" for left, right in merged
                ),
                source_action_count=len(source_actions_by_segment[segment_id]),
                source_unit_count=len(source_units_by_segment[segment_id]),
                source_unit_types=";".join(sorted(source_types_by_segment[segment_id])),
                source_units=";".join(sorted(source_units_by_segment[segment_id])),
            )
        )

    for part_id, statuses in part_to_statuses.items():
        if all(status == "full" for status in statuses):
            complete_parts.add(part_id)
        else:
            incomplete_parts.add(part_id)

    primitive_ids = set(loaded.primitive_segments)
    id_covered_original = id_covered & primitive_ids
    summary = RouteAuditSummary(
        route_key=route_key(job),
        metrics_file=relative(job.metrics_file),
        diagnostics_file=relative(job.diagnostics_file),
        archive=job.archive,
        placements_member=job.placements_member,
        board_id=job.board_id,
        method=job.method,
        rectangle_count=len(loaded.layout.rectangles),
        cut_action_count=cut_action_count,
        primitive_segment_count=len(loaded.primitive_segments),
        id_covered_segment_count=len(id_covered_original),
        id_missing_segment_count=len(primitive_ids - id_covered_original),
        geometry_full_segment_count=full_count,
        geometry_partial_segment_count=partial_count,
        geometry_missing_segment_count=missing_count,
        incomplete_part_count=len(incomplete_parts),
        complete_part_count=len(complete_parts),
        total_primitive_length_mm=total_length,
        geometry_covered_length_mm=covered_length,
        geometry_uncovered_length_mm=max(0.0, total_length - covered_length),
        geometry_coverage_ratio=covered_length / total_length if total_length else 1.0,
        missing_unit_reference_count=missing_unit_reference_count,
        zero_length_cut_action_count=zero_length_cut_action_count,
        partial_with_single_edge_source=partial_type_counts["single_edge"],
        partial_with_shared_edge_source=partial_type_counts["shared_edge"],
        partial_with_near_shared_source=partial_type_counts["near_shared_channel"],
        partial_with_collinear_source=partial_type_counts["collinear_chain"],
        missing_with_no_source=missing_with_no_source,
        issue_flag=1 if partial_count or missing_count else 0,
    )
    return summary, segment_rows


def aggregate_by_method(summaries: list[RouteAuditSummary]) -> list[dict[str, object]]:
    by_method: dict[str, list[RouteAuditSummary]] = defaultdict(list)
    for row in summaries:
        by_method[row.method].append(row)
    rows: list[dict[str, object]] = []
    for method, items in sorted(by_method.items()):
        rows.append(
            {
                "method": method,
                "route_count": len(items),
                "issue_route_count": sum(item.issue_flag for item in items),
                "mean_geometry_coverage_ratio": (
                    sum(item.geometry_coverage_ratio for item in items) / len(items)
                ),
                "mean_partial_segments": (
                    sum(item.geometry_partial_segment_count for item in items) / len(items)
                ),
                "mean_incomplete_parts": (
                    sum(item.incomplete_part_count for item in items) / len(items)
                ),
            }
        )
    return rows


def write_markdown_summary(
    output_path: Path,
    summaries: list[RouteAuditSummary],
    skipped: list[SkippedRow],
    method_rows: list[dict[str, object]],
) -> None:
    audited = len(summaries)
    issue_routes = [row for row in summaries if row.issue_flag]
    mean_ratio = (
        sum(row.geometry_coverage_ratio for row in summaries) / audited
        if audited
        else 0.0
    )
    worst = sorted(
        summaries,
        key=lambda row: (
            row.geometry_coverage_ratio,
            -row.geometry_partial_segment_count,
            row.method,
        ),
    )[:20]
    lines = [
        "# Geometric Coverage Audit",
        "",
        f"Generated: {datetime.now(timezone.utc).isoformat()}",
        "",
        "This audit compares the old `covered_segment_ids` route-level count with "
        "actual primitive-edge axis-span coverage induced by stored cut-action "
        "geometry.",
        "",
        "## Overall",
        "",
        f"- Audited routes: {audited}",
        f"- Routes with partial/missing geometric edge coverage: {len(issue_routes)}",
        f"- Mean geometric coverage ratio: {mean_ratio:.6f}",
        f"- Skipped metric rows: {len(skipped)}",
        "",
        "## By Method",
        "",
        "| Method | Routes | Issue routes | Mean coverage | Mean partial edges | Mean incomplete parts |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in method_rows:
        lines.append(
            "| {method} | {route_count} | {issue_route_count} | "
            "{mean_geometry_coverage_ratio:.6f} | {mean_partial_segments:.2f} | "
            "{mean_incomplete_parts:.2f} |".format(**row)
        )
    lines.extend(
        [
            "",
            "## Worst Routes",
            "",
            "| Metrics file | Board | Method | Coverage | Full | Partial | Missing | Incomplete parts |",
            "|---|---:|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in worst:
        lines.append(
            f"| `{row.metrics_file}` | {row.board_id} | `{row.method}` | "
            f"{row.geometry_coverage_ratio:.6f} | {row.geometry_full_segment_count} | "
            f"{row.geometry_partial_segment_count} | {row.geometry_missing_segment_count} | "
            f"{row.incomplete_part_count} |"
        )
    lines.append("")
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    metrics_files = sorted(ROOT.glob(args.metrics_glob))
    jobs, skipped = discover_jobs(metrics_files)
    if args.limit:
        jobs = jobs[: args.limit]
    summaries: list[RouteAuditSummary] = []
    segment_rows: list[SegmentAuditRow] = []
    case_cache: dict[tuple[str, str, str], LoadedCase] = {}
    for job in jobs:
        try:
            loaded = load_case(job, args.data_root, case_cache)
            summary, details = audit_route(job, loaded, args.fixed_tolerance_mode)
        except Exception as exc:  # audit artifact: preserve failure as data
            skipped.append(
                SkippedRow(
                    metrics_file=relative(job.metrics_file),
                    metric_row_index=job.metric_row_index,
                    method=job.method,
                    reason=f"audit failed: {type(exc).__name__}: {exc}",
                )
            )
            continue
        summaries.append(summary)
        segment_rows.extend(details)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(
        args.output_dir / "geometric_coverage_route_summary.csv",
        summaries,
        list(RouteAuditSummary.__dataclass_fields__),
    )
    write_csv(
        args.output_dir / "geometric_coverage_segment_details.csv",
        segment_rows,
        list(SegmentAuditRow.__dataclass_fields__),
    )
    write_csv(
        args.output_dir / "geometric_coverage_skipped_rows.csv",
        skipped,
        list(SkippedRow.__dataclass_fields__),
    )
    method_rows = aggregate_by_method(summaries)
    write_csv(
        args.output_dir / "geometric_coverage_by_method.csv",
        method_rows,
        [
            "method",
            "route_count",
            "issue_route_count",
            "mean_geometry_coverage_ratio",
            "mean_partial_segments",
            "mean_incomplete_parts",
        ],
    )
    write_markdown_summary(
        args.output_dir / "geometric_coverage_audit_summary.md",
        summaries,
        skipped,
        method_rows,
    )
    print(f"audited_routes={len(summaries)}")
    print(f"issue_routes={sum(row.issue_flag for row in summaries)}")
    print(f"skipped_rows={len(skipped)}")
    print(f"output_dir={args.output_dir}")


if __name__ == "__main__":
    main()
