from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parents[1]

DEFAULT_TARGET_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_INPUTS = (
    ROOT / "results" / "chapter3_optimality_gap_real_8_12.csv",
    ROOT / "results" / "chapter3_optimality_gap_exact_real_1_3.csv",
)
DEFAULT_DETAIL_OUTPUT = (
    ROOT / "results" / "chapter3_optimality_gap_failure_cases.csv"
)
DEFAULT_SUMMARY_OUTPUT = (
    ROOT / "results" / "chapter3_optimality_gap_failure_attribution_summary.csv"
)
DEFAULT_MARKDOWN_OUTPUT = (
    ROOT / "results" / "chapter3_optimality_gap_failure_attribution.md"
)


@dataclass(frozen=True)
class FailureCase:
    source_file: str
    archive: str
    case_name: str
    placement_method: str
    seed: str
    placements_member: str
    board_id: str
    target_method: str
    reference_kind: str
    reference_method: str
    rectangle_count: int
    candidate_unit_count: int
    selected_unit_count: int
    action_count: int
    target_runtime_ms: float
    reference_runtime_ms: float
    target_hard_penalty: float
    reference_hard_penalty: float
    hard_penalty_delta: float
    target_stability_penalty: float
    reference_stability_penalty: float
    stability_penalty_delta: float
    target_repeated_cut_segment_count: int
    reference_repeated_cut_segment_count: int
    repeated_cut_segment_count_delta: int
    target_repeated_cut_length: float
    reference_repeated_cut_length: float
    repeated_cut_length_delta: float
    target_redundant_cut_action_count: int
    reference_redundant_cut_action_count: int
    redundant_cut_action_count_delta: int
    target_tool_event_count: int
    target_travel_mode_cost: float
    reference_travel_mode_cost: float
    travel_mode_cost_gap: float
    travel_mode_cost_gap_ratio: float
    travel_gap_comparable: bool
    comparable_travel_mode_cost_gap: float | None
    comparable_travel_mode_cost_gap_ratio: float | None
    target_machining_cost: float
    reference_machining_cost: float
    machining_cost_gap: float
    attribution_category: str
    recommended_action: str


@dataclass(frozen=True)
class FailureAttributionSummary:
    attribution_category: str
    reference_kind: str
    reference_method: str
    n: int
    rectangle_count_mean: float
    selected_unit_count_mean: float
    target_runtime_ms_mean: float
    reference_runtime_ms_mean: float
    travel_mode_cost_gap_mean: float
    travel_mode_cost_gap_max: float
    comparable_case_count: int
    comparable_travel_mode_cost_gap_mean: float | None
    comparable_travel_mode_cost_gap_ratio_mean: float | None
    machining_cost_gap_mean: float
    target_tool_event_count_mean: float


def number(row: dict[str, str], key: str, default: float = 0.0) -> float:
    value = row.get(key, "")
    if value == "":
        return default
    return float(value)


def integer(row: dict[str, str], key: str, default: int = 0) -> int:
    return int(round(number(row, key, float(default))))


def boolean(row: dict[str, str], key: str) -> bool:
    return row.get(key, "").strip().lower() in {"1", "true", "yes"}


def classify_failure(row: dict[str, str]) -> tuple[str, str]:
    hard_delta = number(row, "hard_penalty") - number(row, "reference_hard_penalty")
    stability_delta = number(row, "stability_penalty") - number(
        row,
        "reference_stability_penalty",
    )
    repeated_delta = integer(row, "repeated_cut_segment_count") - integer(
        row,
        "reference_repeated_cut_segment_count",
    )
    repeated_length_delta = number(row, "repeated_cut_length") - number(
        row,
        "reference_repeated_cut_length",
    )
    redundant_delta = integer(row, "redundant_cut_action_count") - integer(
        row,
        "reference_redundant_cut_action_count",
    )
    reference_kind = row["reference_kind"]
    reference_method = row["reference_method"]

    if hard_delta > 1e-9:
        return (
            "hard-feasibility gap",
            "inspect collision/boundary filtering before route selection",
        )
    if stability_delta > 1e-9:
        return (
            "stability-priority gap",
            "tighten stability-aware acceptance or support-aware candidate ranking",
        )
    if repeated_delta > 0 or repeated_length_delta > 1e-9 or redundant_delta > 0:
        return (
            "repeat-cut-priority gap",
            "strengthen repeated-cut penalties in unit selection and local search",
        )
    if reference_kind == "exact_dp":
        return (
            "strict exact-search gap",
            "use the exact cases to tune local ordering and beam candidate diversity",
        )
    if reference_method == "process_local_search_multistart":
        return (
            "missing multistart local-search candidate",
            "add multistart local-search as an optional final portfolio candidate",
        )
    if reference_method == "process_aware_beam_polished":
        return (
            "fixed polished-beam variant gap",
            "keep fixed polished beam as a protected candidate in the final selector",
        )
    if reference_method in {"process_aware_beam", "process_aware_beam_adaptive"}:
        return (
            "parent beam variant gap",
            "audit adaptive-polish acceptance so it never discards a better parent route",
        )
    return (
        "same-process travel gap",
        "compare route diagrams and add the winning source as a protected candidate",
    )


def failure_case_from_row(path: Path, row: dict[str, str]) -> FailureCase:
    category, action = classify_failure(row)
    target_tool_events = integer(row, "tool_event_count")
    return FailureCase(
        source_file=path.name,
        archive=row["archive"],
        case_name=row["case_name"],
        placement_method=row["placement_method"],
        seed=row["seed"],
        placements_member=row["placements_member"],
        board_id=row["board_id"],
        target_method=row["method"],
        reference_kind=row["reference_kind"],
        reference_method=row["reference_method"],
        rectangle_count=integer(row, "rectangle_count"),
        candidate_unit_count=integer(row, "candidate_unit_count"),
        selected_unit_count=integer(row, "selected_unit_count"),
        action_count=integer(row, "action_count"),
        target_runtime_ms=number(row, "runtime_ms"),
        reference_runtime_ms=number(row, "reference_runtime_ms"),
        target_hard_penalty=number(row, "hard_penalty"),
        reference_hard_penalty=number(row, "reference_hard_penalty"),
        hard_penalty_delta=number(row, "hard_penalty")
        - number(row, "reference_hard_penalty"),
        target_stability_penalty=number(row, "stability_penalty"),
        reference_stability_penalty=number(row, "reference_stability_penalty"),
        stability_penalty_delta=number(row, "stability_penalty")
        - number(row, "reference_stability_penalty"),
        target_repeated_cut_segment_count=integer(row, "repeated_cut_segment_count"),
        reference_repeated_cut_segment_count=integer(
            row,
            "reference_repeated_cut_segment_count",
        ),
        repeated_cut_segment_count_delta=integer(row, "repeated_cut_segment_count")
        - integer(row, "reference_repeated_cut_segment_count"),
        target_repeated_cut_length=number(row, "repeated_cut_length"),
        reference_repeated_cut_length=number(row, "reference_repeated_cut_length"),
        repeated_cut_length_delta=number(row, "repeated_cut_length")
        - number(row, "reference_repeated_cut_length"),
        target_redundant_cut_action_count=integer(row, "redundant_cut_action_count"),
        reference_redundant_cut_action_count=integer(
            row,
            "reference_redundant_cut_action_count",
        ),
        redundant_cut_action_count_delta=integer(row, "redundant_cut_action_count")
        - integer(row, "reference_redundant_cut_action_count"),
        target_tool_event_count=target_tool_events,
        target_travel_mode_cost=number(row, "travel_mode_cost"),
        reference_travel_mode_cost=number(row, "reference_travel_mode_cost"),
        travel_mode_cost_gap=number(row, "travel_mode_cost_gap"),
        travel_mode_cost_gap_ratio=number(row, "travel_mode_cost_gap_ratio"),
        travel_gap_comparable=boolean(row, "travel_gap_comparable"),
        comparable_travel_mode_cost_gap=(
            number(row, "comparable_travel_mode_cost_gap")
            if row.get("comparable_travel_mode_cost_gap")
            else None
        ),
        comparable_travel_mode_cost_gap_ratio=(
            number(row, "comparable_travel_mode_cost_gap_ratio")
            if row.get("comparable_travel_mode_cost_gap_ratio")
            else None
        ),
        target_machining_cost=number(row, "machining_cost"),
        reference_machining_cost=number(row, "reference_machining_cost"),
        machining_cost_gap=number(row, "machining_cost_gap"),
        attribution_category=category,
        recommended_action=action,
    )


def collect_failures(
    input_paths: tuple[Path, ...],
    target_method: str,
) -> tuple[FailureCase, ...]:
    failures: list[FailureCase] = []
    for path in input_paths:
        with path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                if row["method"] != target_method:
                    continue
                if row["process_key_winner"] != "reference":
                    continue
                failures.append(failure_case_from_row(path, row))
    return tuple(
        sorted(
            failures,
            key=lambda item: (
                item.reference_kind,
                item.reference_method,
                -item.travel_mode_cost_gap,
                item.archive,
                item.board_id,
            ),
        )
    )


def summarize_failures(
    failures: tuple[FailureCase, ...],
) -> tuple[FailureAttributionSummary, ...]:
    grouped: dict[tuple[str, str, str], list[FailureCase]] = {}
    for failure in failures:
        grouped.setdefault(
            (
                failure.attribution_category,
                failure.reference_kind,
                failure.reference_method,
            ),
            [],
        ).append(failure)

    summaries: list[FailureAttributionSummary] = []
    for (category, reference_kind, reference_method), items in sorted(grouped.items()):
        comparable_items = [
            item
            for item in items
            if item.comparable_travel_mode_cost_gap is not None
            and item.comparable_travel_mode_cost_gap_ratio is not None
        ]
        summaries.append(
            FailureAttributionSummary(
                attribution_category=category,
                reference_kind=reference_kind,
                reference_method=reference_method,
                n=len(items),
                rectangle_count_mean=mean(item.rectangle_count for item in items),
                selected_unit_count_mean=mean(
                    item.selected_unit_count for item in items
                ),
                target_runtime_ms_mean=mean(item.target_runtime_ms for item in items),
                reference_runtime_ms_mean=mean(
                    item.reference_runtime_ms for item in items
                ),
                travel_mode_cost_gap_mean=mean(
                    item.travel_mode_cost_gap for item in items
                ),
                travel_mode_cost_gap_max=max(
                    item.travel_mode_cost_gap for item in items
                ),
                comparable_case_count=len(comparable_items),
                comparable_travel_mode_cost_gap_mean=(
                    mean(
                        item.comparable_travel_mode_cost_gap
                        for item in comparable_items
                        if item.comparable_travel_mode_cost_gap is not None
                    )
                    if comparable_items
                    else None
                ),
                comparable_travel_mode_cost_gap_ratio_mean=(
                    mean(
                        item.comparable_travel_mode_cost_gap_ratio
                        for item in comparable_items
                        if item.comparable_travel_mode_cost_gap_ratio is not None
                    )
                    if comparable_items
                    else None
                ),
                machining_cost_gap_mean=mean(item.machining_cost_gap for item in items),
                target_tool_event_count_mean=mean(
                    item.target_tool_event_count for item in items
                ),
            )
        )
    return tuple(
        sorted(
            summaries,
            key=lambda item: (-item.n, -item.travel_mode_cost_gap_mean),
        )
    )


def write_dataclass_rows(rows: tuple, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def write_markdown(
    failures: tuple[FailureCase, ...],
    summaries: tuple[FailureAttributionSummary, ...],
    path: Path,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Optimality Gap Failure Attribution",
        "",
        f"Failure cases: {len(failures)}",
        "",
        "## Summary",
        "",
        "| category | reference | n | mean gap | comparable mean gap | recommendation |",
        "|---|---:|---:|---:|---:|---|",
    ]
    action_by_category = {
        failure.attribution_category: failure.recommended_action for failure in failures
    }
    for summary in summaries:
        comparable_gap = (
            ""
            if summary.comparable_travel_mode_cost_gap_mean is None
            else f"{summary.comparable_travel_mode_cost_gap_mean:.3f}"
        )
        lines.append(
            "| "
            f"{summary.attribution_category} | "
            f"{summary.reference_kind}:{summary.reference_method} | "
            f"{summary.n} | "
            f"{summary.travel_mode_cost_gap_mean:.3f} | "
            f"{comparable_gap} | "
            f"{action_by_category.get(summary.attribution_category, '')} |"
        )

    lines.extend(
        [
            "",
            "## Largest Gaps",
            "",
            "| source | board | reference | rectangles | units | gap | category |",
            "|---|---:|---|---:|---:|---:|---|",
        ]
    )
    for failure in sorted(
        failures,
        key=lambda item: item.travel_mode_cost_gap,
        reverse=True,
    )[:10]:
        lines.append(
            "| "
            f"{failure.source_file} | "
            f"{failure.board_id} | "
            f"{failure.reference_kind}:{failure.reference_method} | "
            f"{failure.rectangle_count} | "
            f"{failure.selected_unit_count} | "
            f"{failure.travel_mode_cost_gap:.3f} | "
            f"{failure.attribution_category} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Attribute final-method losses in optimality-gap experiments.",
    )
    parser.add_argument(
        "--input",
        type=Path,
        action="append",
        dest="inputs",
        help="Gap detail CSV. Can be provided multiple times.",
    )
    parser.add_argument("--target-method", default=DEFAULT_TARGET_METHOD)
    parser.add_argument("--detail-output", type=Path, default=DEFAULT_DETAIL_OUTPUT)
    parser.add_argument("--summary-output", type=Path, default=DEFAULT_SUMMARY_OUTPUT)
    parser.add_argument("--markdown-output", type=Path, default=DEFAULT_MARKDOWN_OUTPUT)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_paths = tuple(args.inputs) if args.inputs else DEFAULT_INPUTS
    failures = collect_failures(input_paths, args.target_method)
    summaries = summarize_failures(failures)
    write_dataclass_rows(failures, args.detail_output)
    write_dataclass_rows(summaries, args.summary_output)
    write_markdown(failures, summaries, args.markdown_output)
    print(f"failure_cases: {len(failures)}")
    print(f"wrote: {args.detail_output}")
    print(f"wrote: {args.summary_output}")
    print(f"wrote: {args.markdown_output}")
    for summary in summaries:
        comparable_gap = (
            "n/a"
            if summary.comparable_travel_mode_cost_gap_mean is None
            else f"{summary.comparable_travel_mode_cost_gap_mean:.3f}"
        )
        print(
            f"{summary.attribution_category:<42} "
            f"ref={summary.reference_method:<32} n={summary.n:<3} "
            f"gap={summary.travel_mode_cost_gap_mean:>8.3f} "
            f"comparable_gap={comparable_gap:>8}"
        )


if __name__ == "__main__":
    main()
