from __future__ import annotations

import argparse
import csv
import hashlib
import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean, pstdev
from time import perf_counter
from typing import Iterable

from cnc_cutting.coverage_diagnostics import diagnose_route_coverage
from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.io import (
    PLACEMENT_GEOMETRY_STORED,
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.local_search import BeamSearchConfig
from cnc_cutting.models import EdgeRole, Panel
from cnc_cutting.optimizer import (
    plan_process_aware_beam_adaptive_polished_route,
    plan_process_aware_beam_route,
    wider_beam_search_config,
)
from cnc_cutting.process_model import build_process_model

from run_chapter2_batch import (
    compact_beam_search_config,
    compact_local_search_config,
    topology_pool_size,
)


ROOT = Path(__file__).resolve().parents[1]
STAGE7 = ROOT / "results" / "corrected_model_stage7_kerf"
DEFAULT_ARCHIVE = STAGE7 / "kerf_layouts" / "stage7_kerf_layouts.zip"
DEFAULT_RECORD_MANIFEST = STAGE7 / "kerf_layouts" / "stage7_kerf_layout_manifest.csv"
DEFAULT_OUTPUT_DIR = STAGE7 / "budget_matched_search"
PORTFOLIO_VARIANT = "adaptive_portfolio"


@dataclass(frozen=True)
class BudgetRow:
    record_id: str
    inventory_sha256: str
    placements_member: str
    board_id: str
    rectangle_count: int
    variant: str
    scale: float
    beam_width: int
    candidate_pool_size: int
    max_expansions_per_node: int
    max_layer_expansions: int
    runtime_ms: float
    cplan: float
    travel_mode_cost: float
    hard_penalty: float
    support_policy_penalty: float
    missing_span_count: int


def _scale_optional(value: int | None, scale: float) -> int | None:
    if value is None:
        return None
    return max(1, round(value * scale))


def scaled_beam_config(base: BeamSearchConfig, scale: float) -> BeamSearchConfig:
    if scale <= 0.0:
        raise ValueError("beam scale must be positive")
    return replace(
        base,
        beam_width=max(1, round(base.beam_width * scale)),
        candidate_pool_size=_scale_optional(base.candidate_pool_size, scale),
        max_expansions_per_node=_scale_optional(base.max_expansions_per_node, scale),
        max_layer_expansions=_scale_optional(base.max_layer_expansions, scale),
    )


def runtime_matched_variant(
    summaries: Iterable[dict[str, object]],
    *,
    target_runtime_ms: float,
) -> dict[str, object]:
    candidates = [row for row in summaries if row["variant"] != PORTFOLIO_VARIANT]
    if not candidates:
        raise ValueError("no ordinary-beam variants are available")
    return min(
        candidates,
        key=lambda row: (
            abs(float(row["runtime_ms_mean"]) - target_runtime_ms),
            str(row["variant"]),
        ),
    )


def _read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def _write_rows(path: Path, rows: list[object]) -> None:
    payload = [asdict(row) if not isinstance(row, dict) else row for row in rows]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(payload[0]))
        writer.writeheader()
        writer.writerows(payload)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _variant_name(scale: float) -> str:
    return f"beam_{scale:g}x".replace(".", "p")


def _summaries(rows: list[BudgetRow]) -> list[dict[str, object]]:
    variants = sorted({row.variant for row in rows})
    output: list[dict[str, object]] = []
    for variant in variants:
        group = [row for row in rows if row.variant == variant]
        output.append(
            {
                "variant": variant,
                "n": len(group),
                "scale": group[0].scale,
                "beam_width_mean": mean(row.beam_width for row in group),
                "candidate_pool_size_mean": mean(
                    row.candidate_pool_size for row in group
                ),
                "runtime_ms_mean": mean(row.runtime_ms for row in group),
                "runtime_ms_std": pstdev(row.runtime_ms for row in group),
                "cplan_mean": mean(row.cplan for row in group),
                "travel_mode_cost_mean": mean(
                    row.travel_mode_cost for row in group
                ),
                "hard_penalty_mean": mean(row.hard_penalty for row in group),
                "support_policy_penalty_mean": mean(
                    row.support_policy_penalty for row in group
                ),
                "missing_span_count_sum": sum(
                    row.missing_span_count for row in group
                ),
            }
        )
    return output


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run Stage 7 ordinary-beam quality/runtime scaling checks."
    )
    parser.add_argument("--archive", type=Path, default=DEFAULT_ARCHIVE)
    parser.add_argument(
        "--record-manifest", type=Path, default=DEFAULT_RECORD_MANIFEST
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--record-limit", type=int, default=None)
    parser.add_argument(
        "--beam-scales", type=float, nargs="+", default=(1.0, 1.5, 2.0, 3.0)
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    records = _read_rows(args.record_manifest)
    if args.record_limit is not None:
        records = records[: args.record_limit]
    if not records:
        raise ValueError("record manifest is empty")
    scales = tuple(dict.fromkeys(args.beam_scales))
    if any(scale <= 0.0 for scale in scales):
        raise ValueError("all beam scales must be positive")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[BudgetRow] = []
    for record_index, record in enumerate(records):
        config = load_chapter2_config_from_zip(
            args.archive, placements_member=record["placements_member"]
        )
        tool = tool_config_from_chapter2_config(config)
        geometry_mode = str(
            config.get("PLACEMENT_GEOMETRY_MODE", PLACEMENT_GEOMETRY_STORED)
        )
        layout = load_chapter2_layouts_from_zip(
            args.archive,
            placements_member=record["placements_member"],
            board_ids=(record["selected_board_id"],),
            placement_geometry_mode=geometry_mode,
            tool_diameter=tool.tool_diameter,
        )[0]
        panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
        process_model = build_process_model(
            layout,
            tool=tool,
            support_edge_roles=(
                EdgeRole.BOTTOM,
                EdgeRole.RIGHT,
                EdgeRole.TOP,
                EdgeRole.LEFT,
            ),
            min_remaining_support_count=1,
            min_remaining_support_length_ratio=0.75,
            min_area_normalized_support_length=0.0,
            adjacency_support_weight=1.0,
            max_collinear_gap=tool.min_channel_width,
        )
        units = build_candidate_cutting_units(
            layout, tool, max_collinear_gap=tool.min_channel_width
        )
        base = compact_beam_search_config(len(layout.rectangles), "hard")
        variants = [(PORTFOLIO_VARIANT, 0.0, base)] + [
            (_variant_name(scale), scale, scaled_beam_config(base, scale))
            for scale in scales
        ]
        rotation = record_index % len(variants)
        variants = variants[rotation:] + variants[:rotation]

        for variant, scale, beam_config in variants:
            start = perf_counter()
            if variant == PORTFOLIO_VARIANT:
                plan = plan_process_aware_beam_adaptive_polished_route(
                    units,
                    panel,
                    tool,
                    beam_config=base,
                    fallback_beam_config=wider_beam_search_config(base),
                    polish_config=compact_local_search_config(
                        len(layout.rectangles), True, "hard"
                    ),
                    topology_candidate_pool_size=topology_pool_size(
                        len(layout.rectangles)
                    ),
                    fallback_margin=1000.0,
                    process_model=process_model,
                    repeat_cut_policy="hard",
                )
            else:
                plan = plan_process_aware_beam_route(
                    units,
                    panel,
                    tool,
                    config=beam_config,
                    process_model=process_model,
                    repeat_cut_policy="hard",
                )
            runtime_ms = (perf_counter() - start) * 1000.0
            coverage = diagnose_route_coverage(
                units,
                plan.selected_units,
                plan.actions,
                process_model=process_model,
            )
            rows.append(
                BudgetRow(
                    record_id=record["record_id"],
                    inventory_sha256=record["inventory_sha256"],
                    placements_member=record["placements_member"],
                    board_id=record["selected_board_id"],
                    rectangle_count=len(layout.rectangles),
                    variant=variant,
                    scale=scale,
                    beam_width=beam_config.beam_width,
                    candidate_pool_size=beam_config.candidate_pool_size or 0,
                    max_expansions_per_node=(
                        beam_config.max_expansions_per_node or 0
                    ),
                    max_layer_expansions=beam_config.max_layer_expansions or 0,
                    runtime_ms=runtime_ms,
                    cplan=(
                        plan.metrics.cutting_length
                        + plan.metrics.travel_mode_cost
                    ),
                    travel_mode_cost=plan.metrics.travel_mode_cost,
                    hard_penalty=plan.metrics.hard_penalty,
                    support_policy_penalty=plan.metrics.stability_penalty,
                    missing_span_count=coverage.coverage_missing_segment_count,
                )
            )
        print(
            f"[{record_index + 1}/{len(records)}] {record['record_id']} complete",
            flush=True,
        )

    route_output = args.output_dir / "stage7_budget_matched_routes.csv"
    summary_output = args.output_dir / "stage7_budget_matched_summary.csv"
    _write_rows(route_output, rows)
    summaries = _summaries(rows)
    _write_rows(summary_output, summaries)
    portfolio = next(
        row for row in summaries if row["variant"] == PORTFOLIO_VARIANT
    )
    matched = runtime_matched_variant(
        summaries, target_runtime_ms=float(portfolio["runtime_ms_mean"])
    )
    matched_output = args.output_dir / "stage7_runtime_matched_selection.json"
    matched_output.write_text(
        json.dumps(
            {
                "selection_rule": (
                    "minimum absolute difference from adaptive-portfolio mean "
                    "wall-clock runtime; route quality is not used for selection"
                ),
                "portfolio": portfolio,
                "runtime_matched_ordinary_beam": matched,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "archive": str(args.archive.relative_to(ROOT)),
        "archive_sha256": _sha256(args.archive),
        "record_manifest": str(args.record_manifest.relative_to(ROOT)),
        "record_manifest_sha256": _sha256(args.record_manifest),
        "record_count": len(records),
        "beam_scales": scales,
        "execution_order": "deterministic per-record rotation",
        "outputs": {
            route_output.name: _sha256(route_output),
            summary_output.name: _sha256(summary_output),
            matched_output.name: _sha256(matched_output),
        },
    }
    (args.output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(f"runtime-matched variant: {matched['variant']}")
    print(f"output: {args.output_dir}")


if __name__ == "__main__":
    main()
