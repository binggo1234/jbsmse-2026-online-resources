from __future__ import annotations

import argparse
import csv
import hashlib
import json
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RESULTS = (
    ROOT
    / "results"
    / "chapter3_main_hard_gate25_real_77_20_50_protected_portfolio_v2.csv"
)
DEFAULT_MANIFEST = DEFAULT_RESULTS.with_name(
    "chapter3_main_hard_gate25_real_77_20_50_protected_portfolio_v2_manifest.json"
)
DEFAULT_AUDIT_CSV = ROOT / "results" / "chapter3_layout_independence_audit.csv"
DEFAULT_SUMMARY = ROOT / "docs" / "chapter3_layout_independence_audit.md"

CASE_FIELDS = ("archive", "placements_member", "board_id")
RESULT_SIGNATURE_FIELDS = (
    "rectangle_count",
    "candidate_unit_count",
    "selected_unit_count",
    "action_count",
    "coverage_repeated_segment_count",
    "cut_duplicate_segment_count",
    "cutting_length",
    "air_move_distance",
    "travel_mode_cost",
    "pierce_count",
    "lift_count",
    "safe_lift_count",
    "detour_count",
    "collision_penalty",
    "boundary_penalty",
    "stability_penalty",
    "hard_penalty",
)


@dataclass(frozen=True)
class LayoutRecord:
    case_id: str
    archive: str
    case_name: str
    placement_method: str
    seed: str
    placements_member: str
    board_id: str
    rectangle_count: int
    methods: tuple[str, ...]
    result_signature: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Audit source hierarchy, geometric duplication, and result duplication "
            "for production-derived nesting-layout records."
        )
    )
    parser.add_argument("--results", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument(
        "--archive",
        action="append",
        type=Path,
        default=[],
        help="Input zip archive. Repeat for multiple archives.",
    )
    parser.add_argument("--output-csv", type=Path, default=DEFAULT_AUDIT_CSV)
    parser.add_argument("--summary-output", type=Path, default=DEFAULT_SUMMARY)
    return parser.parse_args()


def normalized_number(value: str) -> str:
    try:
        number = Decimal(value)
    except (InvalidOperation, ValueError):
        return value.strip()
    normalized = number.quantize(Decimal("0.000001")).normalize()
    if normalized == 0:
        return "0"
    return format(normalized, "f")


def stable_hash(parts: Iterable[str]) -> str:
    digest = hashlib.sha256()
    for part in parts:
        digest.update(part.encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def load_layout_records(path: Path) -> tuple[LayoutRecord, ...]:
    grouped: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty result CSV: {path}")
        missing = [field for field in CASE_FIELDS if field not in reader.fieldnames]
        if missing:
            raise ValueError(f"result CSV is missing case fields: {missing}")
        for row in reader:
            key = tuple(row[field] for field in CASE_FIELDS)
            grouped[key].append(row)

    records: list[LayoutRecord] = []
    for (archive, member, board_id), rows in sorted(grouped.items()):
        first = rows[0]
        signature_parts: list[str] = []
        for row in sorted(rows, key=lambda item: item.get("method", "")):
            signature_parts.append(f"method={row.get('method', '')}")
            signature_parts.extend(
                f"{field}={normalized_number(row.get(field, ''))}"
                for field in RESULT_SIGNATURE_FIELDS
            )
        records.append(
            LayoutRecord(
                case_id="|".join((archive, member, board_id)),
                archive=archive,
                case_name=first.get("case_name", ""),
                placement_method=first.get("placement_method", ""),
                seed=first.get("seed", ""),
                placements_member=member,
                board_id=board_id,
                rectangle_count=int(float(first.get("rectangle_count", "0") or 0)),
                methods=tuple(
                    sorted({row.get("method", "") for row in rows if row.get("method")})
                ),
                result_signature=stable_hash(signature_parts),
            )
        )
    return tuple(records)


def archives_from_manifest(path: Path) -> tuple[Path, ...]:
    if not path.exists():
        return ()
    with path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    archive_entries = manifest.get("inputs", {}).get("archives", [])
    archives = []
    for entry in archive_entries:
        candidate = Path(entry.get("absolute_path") or entry.get("path", ""))
        if candidate.exists():
            archives.append(candidate)
    return tuple(archives)


def build_archive_map(paths: Iterable[Path]) -> dict[str, Path]:
    archive_map: dict[str, Path] = {}
    for path in paths:
        resolved = path.expanduser().resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"archive does not exist: {resolved}")
        if resolved.name in archive_map and archive_map[resolved.name] != resolved:
            raise ValueError(f"duplicate archive basename: {resolved.name}")
        archive_map[resolved.name] = resolved
    return archive_map


def geometry_signature(
    archive: zipfile.ZipFile,
    member: str,
    board_id: str,
) -> tuple[str, int]:
    with archive.open(member) as raw:
        text = (line.decode("utf-8-sig") for line in raw)
        reader = csv.DictReader(text)
        if reader.fieldnames is None:
            raise ValueError(f"empty placements CSV: {member}")
        required = ("board", "x", "y", "w", "h")
        missing = [field for field in required if field not in reader.fieldnames]
        if missing:
            raise ValueError(f"{member} is missing geometry fields: {missing}")
        target_board = normalized_number(board_id)
        rectangles = []
        for row in reader:
            if normalized_number(row["board"]) != target_board:
                continue
            rectangles.append(
                ",".join(normalized_number(row[field]) for field in ("x", "y", "w", "h"))
            )
    if not rectangles:
        raise ValueError(f"board {board_id} was not found in {member}")
    rectangles.sort()
    return stable_hash(rectangles), len(rectangles)


def audit_geometry(
    records: tuple[LayoutRecord, ...],
    archive_map: dict[str, Path],
) -> dict[str, tuple[str, int]]:
    by_archive: dict[str, list[LayoutRecord]] = defaultdict(list)
    for record in records:
        by_archive[record.archive].append(record)

    signatures: dict[str, tuple[str, int]] = {}
    for archive_name, archive_records in by_archive.items():
        archive_path = archive_map.get(archive_name)
        if archive_path is None:
            continue
        with zipfile.ZipFile(archive_path) as archive:
            available = set(archive.namelist())
            for record in archive_records:
                if record.placements_member not in available:
                    raise KeyError(
                        f"{record.placements_member} not found in {archive_path}"
                    )
                signatures[record.case_id] = geometry_signature(
                    archive,
                    record.placements_member,
                    record.board_id,
                )
    return signatures


def duplicate_group_ids(counts: Counter[str]) -> dict[str, int]:
    duplicates = sorted(signature for signature, count in counts.items() if count > 1)
    return {signature: index + 1 for index, signature in enumerate(duplicates)}


def write_audit_csv(
    path: Path,
    records: tuple[LayoutRecord, ...],
    geometry: dict[str, tuple[str, int]],
) -> None:
    geometry_counts = Counter(signature for signature, _ in geometry.values())
    result_counts = Counter(record.result_signature for record in records)
    geometry_groups = duplicate_group_ids(geometry_counts)
    result_groups = duplicate_group_ids(result_counts)

    path.parent.mkdir(parents=True, exist_ok=True)
    fields = (
        "case_id",
        "archive",
        "case_name",
        "placement_method",
        "seed",
        "placements_member",
        "board_id",
        "board_group",
        "rectangle_count",
        "method_count",
        "geometry_rectangle_count",
        "geometry_signature",
        "geometry_duplicate_group",
        "geometry_duplicate_group_size",
        "result_signature",
        "result_duplicate_group",
        "result_duplicate_group_size",
    )
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in records:
            geometry_signature_value, geometry_rectangle_count = geometry.get(
                record.case_id, ("", 0)
            )
            writer.writerow(
                {
                    "case_id": record.case_id,
                    "archive": record.archive,
                    "case_name": record.case_name,
                    "placement_method": record.placement_method,
                    "seed": record.seed,
                    "placements_member": record.placements_member,
                    "board_id": record.board_id,
                    "board_group": f"{record.case_name}|{record.board_id}",
                    "rectangle_count": record.rectangle_count,
                    "method_count": len(record.methods),
                    "geometry_rectangle_count": geometry_rectangle_count,
                    "geometry_signature": geometry_signature_value,
                    "geometry_duplicate_group": geometry_groups.get(
                        geometry_signature_value, ""
                    ),
                    "geometry_duplicate_group_size": geometry_counts[
                        geometry_signature_value
                    ],
                    "result_signature": record.result_signature,
                    "result_duplicate_group": result_groups.get(
                        record.result_signature, ""
                    ),
                    "result_duplicate_group_size": result_counts[
                        record.result_signature
                    ],
                }
            )


def write_summary(
    path: Path,
    results_path: Path,
    records: tuple[LayoutRecord, ...],
    geometry: dict[str, tuple[str, int]],
) -> None:
    case_names = {record.case_name for record in records}
    board_groups = {(record.case_name, record.board_id) for record in records}
    members = {record.placements_member for record in records}
    geometry_counts = Counter(signature for signature, _ in geometry.values())
    result_counts = Counter(record.result_signature for record in records)
    geometry_duplicate_records = sum(
        count for count in geometry_counts.values() if count > 1
    )
    result_duplicate_records = sum(
        count for count in result_counts.values() if count > 1
    )
    largest_geometry_group = max(geometry_counts.values(), default=0)
    largest_result_group = max(result_counts.values(), default=0)

    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Chapter 3 Layout Independence Audit",
        "",
        f"Source result file: `{results_path}`",
        "",
        "## Dataset hierarchy",
        "",
        f"- Production-derived layout records: **{len(records)}**",
        f"- Unique source cases: **{len(case_names)}**",
        f"- Unique `(case_name, board_id)` groups: **{len(board_groups)}**",
        f"- Unique placements members: **{len(members)}**",
        f"- Records with recovered geometry: **{len(geometry)}**",
        f"- Unique geometry signatures: **{len(geometry_counts)}**",
        "",
        "## Duplication",
        "",
        (
            f"- Records belonging to repeated geometry groups: "
            f"**{geometry_duplicate_records}**"
        ),
        f"- Largest repeated geometry group: **{largest_geometry_group}**",
        (
            f"- Records belonging to repeated complete-result groups: "
            f"**{result_duplicate_records}**"
        ),
        f"- Largest repeated complete-result group: **{largest_result_group}**",
        "",
        "Runtime is excluded from the complete-result signature. Geometry signatures",
        "are based on sorted `(x, y, w, h)` tuples and intentionally ignore part IDs,",
        "placement algorithm names, and random seeds.",
        "",
        "## Statistical implication",
        "",
        "The layout record is the computational evaluation unit, but it must not be",
        "treated automatically as an independent industrial board. Confirmatory",
        "statistics should deduplicate identical geometries and account for clustering",
        "by source case or `(case_name, board_id)` group. The manuscript should describe",
        "the dataset as production-derived nesting-layout records and report the full",
        "source hierarchy.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    records = load_layout_records(args.results)
    archive_paths = tuple(args.archive) or archives_from_manifest(args.manifest)
    archive_map = build_archive_map(archive_paths)
    geometry = audit_geometry(records, archive_map)
    write_audit_csv(args.output_csv, records, geometry)
    write_summary(args.summary_output, args.results, records, geometry)
    print(f"records={len(records)}")
    print(f"geometry_records={len(geometry)}")
    print(f"audit_csv={args.output_csv}")
    print(f"summary={args.summary_output}")


if __name__ == "__main__":
    main()
