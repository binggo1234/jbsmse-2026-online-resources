from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parents[1]
STAGE7 = ROOT / "results" / "corrected_model_stage7_kerf"
ARCHIVE = STAGE7 / "kerf_layouts" / "stage7_kerf_layouts.zip"
RECORD_MANIFEST = STAGE7 / "kerf_layouts" / "stage7_kerf_layout_manifest.csv"
DEFAULT_OUTPUT_DIR = STAGE7 / "cross_method_support_sensitivity"

SUPPORT_RATIOS = (0.0, 0.25, 0.5, 0.75, 0.9)
METHODS = (
    "topology_process_aware",
    "process_aware_beam_adaptive_polished",
    "endpoint_aware_gtsp",
)
PROPOSED = "process_aware_beam_adaptive_polished"
BASELINES = ("topology_process_aware", "endpoint_aware_gtsp")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ratio_name(ratio: float) -> str:
    return f"rho{round(100 * ratio):03d}"


def output_paths(output_dir: Path, ratio: float) -> dict[str, Path]:
    stem = f"chapter3_stage7_cross_method_support_{ratio_name(ratio)}"
    return {
        "output": output_dir / f"{stem}.csv",
        "summary": output_dir / f"{stem}_summary.csv",
        "bin_summary": output_dir / f"{stem}_bin_summary.csv",
        "manifest": output_dir / f"{stem}_manifest.json",
        "progress": output_dir / f"{stem}_progress.csv",
    }


def inventory_map(path: Path) -> dict[str, str]:
    rows = read_rows(path)
    mapping = {row["placements_member"]: row["inventory_sha256"] for row in rows}
    if len(mapping) != 77:
        raise ValueError(f"expected 77 Stage 7 records, found {len(mapping)}")
    return mapping


def planning_cost(row: dict[str, str]) -> float:
    return float(row["cutting_length"]) + float(row["travel_mode_cost"])


def _outcome(reduction: float, tolerance: float = 1e-9) -> str:
    if reduction > tolerance:
        return "win"
    if reduction < -tolerance:
        return "loss"
    return "tie"


def summarize_cross_method_rows(
    rows: list[dict[str, str]],
    inventories: dict[str, str],
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    grouped: dict[tuple[float, str], list[dict[str, str]]] = defaultdict(list)
    by_case: dict[tuple[float, str, str], dict[str, str]] = {}
    for row in rows:
        rho = float(row["min_support_ratio"])
        method = row["method"]
        member = row["placements_member"]
        if member not in inventories:
            raise ValueError(f"missing inventory mapping for {member}")
        grouped[(rho, method)].append(row)
        by_case[(rho, member, method)] = row

    method_summaries: list[dict[str, object]] = []
    for (rho, method), items in sorted(grouped.items()):
        inventory_costs: dict[str, list[float]] = defaultdict(list)
        inventory_penalties: dict[str, list[float]] = defaultdict(list)
        for row in items:
            inventory = inventories[row["placements_member"]]
            inventory_costs[inventory].append(planning_cost(row))
            inventory_penalties[inventory].append(float(row["stability_penalty"]))
        method_summaries.append(
            {
                "min_support_ratio": rho,
                "method": method,
                "layout_count": len(items),
                "inventory_count": len(inventory_costs),
                "cplan_layout_mean": mean(planning_cost(row) for row in items),
                "cplan_inventory_equal_mean": mean(
                    mean(values) for values in inventory_costs.values()
                ),
                "travel_cost_layout_mean": mean(
                    float(row["travel_mode_cost"]) for row in items
                ),
                "support_penalty_layout_mean": mean(
                    float(row["stability_penalty"]) for row in items
                ),
                "support_penalty_inventory_equal_mean": mean(
                    mean(values) for values in inventory_penalties.values()
                ),
                "positive_support_penalty_layouts": sum(
                    float(row["stability_penalty"]) > 1e-9 for row in items
                ),
                "hard_penalty_max": max(float(row["hard_penalty"]) for row in items),
                "missing_segment_count_max": max(
                    float(row["cut_missing_segment_count"]) for row in items
                ),
                "runtime_ms_layout_mean": mean(float(row["runtime_ms"]) for row in items),
            }
        )

    paired_summaries: list[dict[str, object]] = []
    members = sorted(inventories)
    for rho in sorted({float(row["min_support_ratio"]) for row in rows}):
        for baseline in BASELINES:
            reductions: list[float] = []
            inventory_reductions: dict[str, list[float]] = defaultdict(list)
            outcomes = {"win": 0, "tie": 0, "loss": 0}
            baseline_positive = proposed_positive = 0
            for member in members:
                proposed = by_case[(rho, member, PROPOSED)]
                reference = by_case[(rho, member, baseline)]
                reference_cost = planning_cost(reference)
                reduction = 100.0 * (
                    reference_cost - planning_cost(proposed)
                ) / reference_cost
                reductions.append(reduction)
                inventory_reductions[inventories[member]].append(reduction)
                outcomes[_outcome(reduction)] += 1
                baseline_positive += float(reference["stability_penalty"]) > 1e-9
                proposed_positive += float(proposed["stability_penalty"]) > 1e-9
            inventory_means = [mean(values) for values in inventory_reductions.values()]
            inventory_outcomes = {"win": 0, "tie": 0, "loss": 0}
            for reduction in inventory_means:
                inventory_outcomes[_outcome(reduction)] += 1
            paired_summaries.append(
                {
                    "min_support_ratio": rho,
                    "baseline_method": baseline,
                    "layout_count": len(reductions),
                    "inventory_count": len(inventory_means),
                    "layout_mean_cplan_reduction_pct": mean(reductions),
                    "inventory_equal_cplan_reduction_pct": mean(inventory_means),
                    "layout_wins": outcomes["win"],
                    "layout_ties": outcomes["tie"],
                    "layout_losses": outcomes["loss"],
                    "inventory_wins": inventory_outcomes["win"],
                    "inventory_ties": inventory_outcomes["tie"],
                    "inventory_losses": inventory_outcomes["loss"],
                    "baseline_positive_support_penalty_layouts": baseline_positive,
                    "proposed_positive_support_penalty_layouts": proposed_positive,
                }
            )
    return method_summaries, paired_summaries


def summarize_inventory_rows(
    rows: list[dict[str, str]],
    inventories: dict[str, str],
) -> list[dict[str, object]]:
    grouped: dict[tuple[float, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        member = row["placements_member"]
        if member not in inventories:
            raise ValueError(f"missing inventory mapping for {member}")
        grouped[
            (
                float(row["min_support_ratio"]),
                row["method"],
                inventories[member],
            )
        ].append(row)
    return [
        {
            "min_support_ratio": rho,
            "method": method,
            "inventory_sha256": inventory,
            "layout_count": len(items),
            "cplan_mean": mean(planning_cost(row) for row in items),
            "support_penalty_mean": mean(
                float(row["stability_penalty"]) for row in items
            ),
            "positive_support_penalty_layouts": sum(
                float(row["stability_penalty"]) > 1e-9 for row in items
            ),
        }
        for (rho, method, inventory), items in sorted(grouped.items())
    ]


def run_ratio(output_dir: Path, ratio: float) -> Path:
    paths = output_paths(output_dir, ratio)
    command = [
        sys.executable,
        str(ROOT / "experiments" / "run_chapter2_batch.py"),
        "--zip-path",
        str(ARCHIVE),
        "--record-manifest",
        str(RECORD_MANIFEST),
        "--experiment-preset",
        "paper-main",
        "--support-policy",
        "all_edges",
        "--min-support-count",
        "1",
        "--min-support-ratio",
        str(ratio),
        "--min-area-normalized-support",
        "0",
        "--adjacency-support-weight",
        "1",
        "--repeat-cut-policy",
        "hard",
        "--tool-event-min-travel-saving",
        "25",
        "--tool-event-min-travel-saving-ratio",
        "0",
        "--tool-event-min-machining-saving",
        "1e-09",
        "--methods",
        *METHODS,
        "--task-timeout-seconds",
        "120",
        "--output",
        str(paths["output"]),
        "--summary-output",
        str(paths["summary"]),
        "--bin-summary-output",
        str(paths["bin_summary"]),
        "--manifest-output",
        str(paths["manifest"]),
        "--progress-output",
        str(paths["progress"]),
        "--no-progress-bar",
    ]
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join(
        (str(ROOT), str(ROOT / "src"), str(ROOT / "experiments"))
    )
    print(f"[cross-support] start {ratio_name(ratio)}", flush=True)
    subprocess.run(command, cwd=ROOT, env=environment, check=True)
    rows = read_rows(paths["output"])
    expected = 77 * len(METHODS)
    if len(rows) != expected:
        raise ValueError(f"{ratio_name(ratio)}: expected {expected} rows, found {len(rows)}")
    print(f"[cross-support] complete {ratio_name(ratio)}", flush=True)
    return paths["output"]


def _write_latex(path: Path, method_rows: list[dict[str, object]]) -> None:
    labels = {
        "topology_process_aware": "Process-aware topology",
        PROPOSED: "Adaptive portfolio",
        "endpoint_aware_gtsp": "Endpoint-aware GTSP",
    }
    lines = [
        r"\begin{table*}[htbp]",
        r"\centering",
        r"\caption{Cross-method support-policy sensitivity on the 77 Stage~7 layouts. The support-span count threshold and adjacency credit remain fixed; only the remaining-support ratio $\rho$ changes. Costs and penalties are layout-level means; the final column counts layouts with a positive modeled support-policy penalty.}",
        r"\label{tab:cross-method-support-sensitivity}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3.5pt}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}clrrr@{}}",
        r"\toprule",
        r"$\rho$ & Method & $C_{\mathrm{plan}}$ & Support penalty & \shortstack{Layouts with\\penalty} \\",
        r"\midrule",
    ]
    for index, row in enumerate(sorted(method_rows, key=lambda item: (item["min_support_ratio"], METHODS.index(item["method"])))):
        if index and index % len(METHODS) == 0:
            lines.append(r"\addlinespace[2pt]")
        lines.append(
            f"{float(row['min_support_ratio']):.2f} & {labels[str(row['method'])]} & "
            f"{float(row['cplan_layout_mean']):.1f} & "
            f"{float(row['support_penalty_layout_mean']):.2f} & "
            f"{int(row['positive_support_penalty_layouts'])}/77 \\\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular*}", r"\end{table*}", ""))
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run Stage 7 cross-method support-policy sensitivity."
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--max-workers", type=int, default=2)
    parser.add_argument("--analyze-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not args.analyze_only:
        with ThreadPoolExecutor(max_workers=args.max_workers) as executor:
            list(executor.map(lambda ratio: run_ratio(output_dir, ratio), SUPPORT_RATIOS))

    raw_rows = [
        row
        for ratio in SUPPORT_RATIOS
        for row in read_rows(output_paths(output_dir, ratio)["output"])
    ]
    inventories = inventory_map(RECORD_MANIFEST)
    method_rows, paired_rows = summarize_cross_method_rows(raw_rows, inventories)
    inventory_rows = summarize_inventory_rows(raw_rows, inventories)
    combined_path = output_dir / "stage7_cross_method_support_rows.csv"
    method_path = output_dir / "stage7_cross_method_support_method_summary.csv"
    paired_path = output_dir / "stage7_cross_method_support_paired_summary.csv"
    inventory_path = output_dir / "stage7_cross_method_support_inventory_summary.csv"
    table_path = output_dir / "table_cross_method_support_sensitivity.tex"
    write_rows(combined_path, raw_rows)
    write_rows(method_path, method_rows)
    write_rows(paired_path, paired_rows)
    write_rows(inventory_path, inventory_rows)
    _write_latex(table_path, method_rows)

    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "runner": str(Path(__file__).resolve().relative_to(ROOT)),
        "runner_sha256": sha256(Path(__file__).resolve()),
        "archive": str(ARCHIVE.relative_to(ROOT)),
        "archive_sha256": sha256(ARCHIVE),
        "record_manifest": str(RECORD_MANIFEST.relative_to(ROOT)),
        "record_manifest_sha256": sha256(RECORD_MANIFEST),
        "support_ratios": SUPPORT_RATIOS,
        "fixed_policy": {
            "support_policy": "all_edges",
            "min_support_count": 1,
            "adjacency_support_weight": 1.0,
        },
        "methods": METHODS,
        "row_count": len(raw_rows),
        "inventory_count": len(set(inventories.values())),
        "outputs": {
            str(path.relative_to(ROOT)): sha256(path)
            for path in (
                combined_path,
                method_path,
                paired_path,
                inventory_path,
                table_path,
            )
        },
        "setting_outputs": {
            ratio_name(ratio): {
                "output": str(output_paths(output_dir, ratio)["output"].relative_to(ROOT)),
                "output_sha256": sha256(output_paths(output_dir, ratio)["output"]),
                "manifest": str(output_paths(output_dir, ratio)["manifest"].relative_to(ROOT)),
                "manifest_sha256": sha256(output_paths(output_dir, ratio)["manifest"]),
            }
            for ratio in SUPPORT_RATIOS
        },
    }
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"rows={len(raw_rows)}")
    print(f"method_summary={method_path}")
    print(f"paired_summary={paired_path}")
    print(f"manifest={manifest_path}")


if __name__ == "__main__":
    main()
