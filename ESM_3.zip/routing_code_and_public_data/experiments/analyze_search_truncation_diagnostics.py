from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "experiments"))

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.layout_generator import (
    ClusteredLayoutConfig,
    generate_clustered_channel_layout,
)
from cnc_cutting.local_search import (
    BeamSearchConfig,
    LocalSearchConfig,
    process_aware_beam_search_order,
)
from cnc_cutting.models import Panel, Point, ToolConfig
from cnc_cutting.optimizer import select_coverage_units
from process_options import PAPER_MAIN_STABILITY_PRESET, build_process_model_from_args
from run_scalability import compact_beam_search_config, compact_local_search_config


@dataclass(frozen=True)
class SearchTruncationRow:
    scenario: str
    size: int
    repeat: int
    candidate_unit_count: int
    selected_unit_count: int
    beam_width: int
    beam_candidate_pool_size: int
    beam_max_expansions_per_node: int
    beam_max_layer_expansions: int
    beam_directed_expansion_upper_bound: int
    beam_raw_expansion_count: int
    beam_evaluated_node_count: int
    beam_candidate_pool_reduction_pct: float
    beam_final_evaluated_share_pct: float
    beam_layer_pruned_count: int
    beam_layer_pruned_pct_of_raw: float
    beam_duplicate_pruned_count: int
    beam_diversity_pruned_count: int
    local_search_unrestricted_upper_bound: int
    local_search_span_limited_upper_bound: int
    local_search_evaluated_per_pass: int
    local_search_reduction_pct_vs_unrestricted: float
    local_search_final_share_pct: float


@dataclass(frozen=True)
class SearchTruncationSummaryRow:
    scenario: str
    size: int
    repeats: int
    selected_unit_count_mean: float
    beam_directed_expansion_upper_bound_mean: float
    beam_raw_expansion_count_mean: float
    beam_evaluated_node_count_mean: float
    beam_candidate_pool_reduction_pct_mean: float
    beam_final_evaluated_share_pct_mean: float
    beam_layer_pruned_pct_of_raw_mean: float
    local_search_unrestricted_upper_bound_mean: float
    local_search_span_limited_upper_bound_mean: float
    local_search_evaluated_per_pass_mean: float
    local_search_reduction_pct_vs_unrestricted_mean: float
    local_search_final_share_pct_mean: float


class _Args:
    support_policy = "all_edges"
    min_support_count = PAPER_MAIN_STABILITY_PRESET["min_support_count"]
    min_support_ratio = PAPER_MAIN_STABILITY_PRESET["min_support_ratio"]
    min_area_normalized_support = PAPER_MAIN_STABILITY_PRESET[
        "min_area_normalized_support"
    ]
    adjacency_support_weight = PAPER_MAIN_STABILITY_PRESET[
        "adjacency_support_weight"
    ]


def beam_directed_expansion_upper_bound(
    diagnostics,
    selected_unit_count: int,
) -> int:
    total = 0
    for diag in diagnostics:
        remaining_units = max(0, selected_unit_count - diag.depth)
        total += diag.input_beam_count * remaining_units * 2
    return total


def pair_count_with_span(n: int, span: int | None) -> int:
    if span is None:
        return n * (n - 1) // 2
    total = 0
    for first in range(n):
        total += min(span, max(0, n - first - 1))
    return total


def relocate_count_with_span(n: int, span: int | None) -> int:
    if span is None:
        return n * (n - 1)
    total = 0
    for source in range(n):
        total += min(span, source) + min(span, max(0, n - source - 1))
    return total


def local_search_unrestricted_upper_bound(n: int, config: LocalSearchConfig) -> int:
    total = 0
    if config.enable_swap:
        total += n * (n - 1) // 2
    if config.enable_relocate:
        total += n * (n - 1)
    if config.enable_two_opt:
        total += n * (n - 1) // 2
    return total


def local_search_span_limited_upper_bound(n: int, config: LocalSearchConfig) -> int:
    total = 0
    if config.enable_swap:
        total += pair_count_with_span(n, config.max_swap_span)
    if config.enable_relocate:
        total += relocate_count_with_span(n, config.max_relocate_span)
    if config.enable_two_opt:
        total += pair_count_with_span(n, config.max_two_opt_span)
    return total


def local_search_evaluated_per_pass(n: int, config: LocalSearchConfig) -> int:
    span_limited = local_search_span_limited_upper_bound(n, config)
    if config.max_neighbors_per_iteration is None:
        return span_limited
    return min(span_limited, config.max_neighbors_per_iteration)


def pct_reduction(original: float, retained: float) -> float:
    if original <= 0:
        return 0.0
    return 100.0 * (1.0 - retained / original)


def pct_share(part: float, whole: float) -> float:
    if whole <= 0:
        return 0.0
    return 100.0 * part / whole


def make_row(
    *,
    size: int,
    repeat: int,
    scenario: str,
    seed: int,
) -> SearchTruncationRow:
    tool = ToolConfig(
        trim_margin=5,
        tool_diameter=6,
        centerline_boundary_margin=3,
        allow_safe_lift_over_released_parts=True,
        allow_low_clearance_detour=True,
        start_point=Point(8.0, 8.0),
    )
    layout = generate_clustered_channel_layout(
        size,
        tool,
        ClusteredLayoutConfig(seed=seed + repeat),
    )
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    process_model = build_process_model_from_args(layout, _Args())
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    selected_units = select_coverage_units(units, repeat_cut_policy="hard")

    beam_config = compact_beam_search_config(size)
    if not isinstance(beam_config, BeamSearchConfig):
        raise TypeError("compact_beam_search_config did not return BeamSearchConfig")
    beam_result = process_aware_beam_search_order(
        selected_units,
        panel,
        tool,
        process_model=process_model,
        config=beam_config,
    )

    diagnostics = beam_result.diagnostics
    beam_upper = beam_directed_expansion_upper_bound(
        diagnostics,
        len(selected_units),
    )
    beam_raw = sum(diag.raw_expansion_count for diag in diagnostics)
    beam_evaluated = sum(diag.evaluated_node_count for diag in diagnostics)
    beam_layer_pruned = sum(diag.layer_pruned_count for diag in diagnostics)
    beam_duplicate_pruned = sum(diag.duplicate_pruned_count for diag in diagnostics)
    beam_diversity_pruned = sum(diag.diversity_pruned_count for diag in diagnostics)

    local_config = compact_local_search_config(
        size,
        process_aware_initial_order=True,
    )
    local_unrestricted = local_search_unrestricted_upper_bound(
        len(selected_units),
        local_config,
    )
    local_span = local_search_span_limited_upper_bound(
        len(selected_units),
        local_config,
    )
    local_evaluated = local_search_evaluated_per_pass(
        len(selected_units),
        local_config,
    )

    return SearchTruncationRow(
        scenario=scenario,
        size=size,
        repeat=repeat,
        candidate_unit_count=len(units),
        selected_unit_count=len(selected_units),
        beam_width=beam_config.beam_width,
        beam_candidate_pool_size=beam_config.candidate_pool_size or 0,
        beam_max_expansions_per_node=beam_config.max_expansions_per_node or 0,
        beam_max_layer_expansions=beam_config.max_layer_expansions or 0,
        beam_directed_expansion_upper_bound=beam_upper,
        beam_raw_expansion_count=beam_raw,
        beam_evaluated_node_count=beam_evaluated,
        beam_candidate_pool_reduction_pct=pct_reduction(beam_upper, beam_raw),
        beam_final_evaluated_share_pct=pct_share(beam_evaluated, beam_upper),
        beam_layer_pruned_count=beam_layer_pruned,
        beam_layer_pruned_pct_of_raw=pct_share(beam_layer_pruned, beam_raw),
        beam_duplicate_pruned_count=beam_duplicate_pruned,
        beam_diversity_pruned_count=beam_diversity_pruned,
        local_search_unrestricted_upper_bound=local_unrestricted,
        local_search_span_limited_upper_bound=local_span,
        local_search_evaluated_per_pass=local_evaluated,
        local_search_reduction_pct_vs_unrestricted=pct_reduction(
            local_unrestricted,
            local_evaluated,
        ),
        local_search_final_share_pct=pct_share(local_evaluated, local_unrestricted),
    )


def summarize(rows: tuple[SearchTruncationRow, ...]) -> tuple[SearchTruncationSummaryRow, ...]:
    grouped: dict[tuple[str, int], list[SearchTruncationRow]] = {}
    for row in rows:
        grouped.setdefault((row.scenario, row.size), []).append(row)
    summary = []
    for (scenario, size), items in sorted(grouped.items()):
        summary.append(
            SearchTruncationSummaryRow(
                scenario=scenario,
                size=size,
                repeats=len(items),
                selected_unit_count_mean=mean(
                    item.selected_unit_count for item in items
                ),
                beam_directed_expansion_upper_bound_mean=mean(
                    item.beam_directed_expansion_upper_bound for item in items
                ),
                beam_raw_expansion_count_mean=mean(
                    item.beam_raw_expansion_count for item in items
                ),
                beam_evaluated_node_count_mean=mean(
                    item.beam_evaluated_node_count for item in items
                ),
                beam_candidate_pool_reduction_pct_mean=mean(
                    item.beam_candidate_pool_reduction_pct for item in items
                ),
                beam_final_evaluated_share_pct_mean=mean(
                    item.beam_final_evaluated_share_pct for item in items
                ),
                beam_layer_pruned_pct_of_raw_mean=mean(
                    item.beam_layer_pruned_pct_of_raw for item in items
                ),
                local_search_unrestricted_upper_bound_mean=mean(
                    item.local_search_unrestricted_upper_bound for item in items
                ),
                local_search_span_limited_upper_bound_mean=mean(
                    item.local_search_span_limited_upper_bound for item in items
                ),
                local_search_evaluated_per_pass_mean=mean(
                    item.local_search_evaluated_per_pass for item in items
                ),
                local_search_reduction_pct_vs_unrestricted_mean=mean(
                    item.local_search_reduction_pct_vs_unrestricted
                    for item in items
                ),
                local_search_final_share_pct_mean=mean(
                    item.local_search_final_share_pct for item in items
                ),
            )
        )
    return tuple(summary)


def write_csv(path: Path, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError("no rows to write")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def fmt_count(value: float) -> str:
    if abs(value) >= 1000000:
        return f"{value / 1000000:.2f}M"
    if abs(value) >= 1000:
        return f"{value / 1000:.1f}k"
    return f"{value:.0f}"


def write_tex_table(path: Path, rows: tuple[SearchTruncationSummaryRow, ...]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Search-truncation diagnostics on clustered synthetic scalability layouts. The beam upper bound counts all directed expansions from retained prefixes to all remaining selected units; evaluated beam nodes are the expansions actually passed through the incremental evaluator after candidate-pool, per-node, and layer caps. The local-search upper bound counts unrestricted swap, relocate, and direction-constrained 2-opt-style neighbors per pass; evaluated neighbors include the span and per-iteration caps used in the scalability configuration.}",
        r"\label{tab:search-truncation-diagnostics}",
        r"\scriptsize",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}rrrrrrr@{}}",
        r"\toprule",
        r"Size & Runs & \shortstack{Selected\\units} & \shortstack{Beam upper\\expansions} & \shortstack{Beam eval.\\share (\%)} & \shortstack{LS upper\\neighbors} & \shortstack{LS eval.\\share (\%)} \\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(
            f"{row.size} & {row.repeats} & "
            f"{row.selected_unit_count_mean:.1f} & "
            f"{fmt_count(row.beam_directed_expansion_upper_bound_mean)} & "
            f"{row.beam_final_evaluated_share_pct_mean:.3f} & "
            f"{fmt_count(row.local_search_unrestricted_upper_bound_mean)} & "
            f"{row.local_search_final_share_pct_mean:.4f} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular*}",
            r"\end{table}",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", default="100,200,500")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20260502)
    parser.add_argument("--scenario", default="clustered")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results" / "paper_artifacts" / "search_truncation_diagnostics.csv",
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=ROOT
        / "results"
        / "paper_artifacts"
        / "search_truncation_diagnostics_summary.csv",
    )
    parser.add_argument(
        "--tex-output",
        type=Path,
        default=ROOT
        / "paper_sci_cutting_cie"
        / "table_search_truncation_diagnostics.tex",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.scenario != "clustered":
        raise ValueError("only clustered scenario is supported by this diagnostic script")
    sizes = tuple(int(item) for item in args.sizes.split(",") if item.strip())
    rows = []
    for size in sizes:
        for repeat in range(args.repeats):
            print(f"diagnose: scenario={args.scenario} size={size} repeat={repeat}")
            rows.append(
                make_row(
                    size=size,
                    repeat=repeat,
                    scenario=args.scenario,
                    seed=args.seed,
                )
            )
    row_tuple = tuple(rows)
    summary_rows = summarize(row_tuple)
    write_csv(args.output, row_tuple)
    write_csv(args.summary_output, summary_rows)
    write_tex_table(args.tex_output, summary_rows)
    print(f"wrote {args.output}")
    print(f"wrote {args.summary_output}")
    print(f"wrote {args.tex_output}")


if __name__ == "__main__":
    main()
