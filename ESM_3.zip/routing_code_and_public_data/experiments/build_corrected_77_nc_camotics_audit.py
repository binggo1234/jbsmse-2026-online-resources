from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.export_gcode_from_diagnostics import NcTemplate, export_route


PROPOSED_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_METRICS = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "full_experiments"
    / "formal_span_coverage_audit"
    / "chapter3_formal_hard_gate25_main_span_audit_metrics.csv"
)
DEFAULT_COVERAGE = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "full_experiments"
    / "formal_span_coverage_audit"
    / "geometric_coverage_audit"
    / "geometric_coverage_route_summary.csv"
)
DEFAULT_OUTPUT = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "auxiliary_nc_camotics_77_proposed"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Regenerate all 77 corrected proposed routes as generic NC/CAMotics "
            "auxiliary exportability artifacts."
        )
    )
    parser.add_argument("--metrics", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--coverage-summary", type=Path, default=DEFAULT_COVERAGE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty CSV: {path}")
        return list(reader)


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"no rows to write: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def coverage_by_diagnostics(path: Path) -> dict[str, dict[str, str]]:
    return {row["diagnostics_file"]: row for row in read_rows(path)}


def load_proposed_rows(path: Path) -> list[dict[str, str]]:
    rows = [row for row in read_rows(path) if row["method"] == PROPOSED_METHOD]
    rows.sort(
        key=lambda row: (
            row["archive"],
            row["placements_member"],
            int(float(row["board_id"])),
            row["diagnostics_file"],
        )
    )
    if len(rows) != 77:
        raise ValueError(f"expected 77 proposed rows, found {len(rows)} in {path}")
    diagnostics = [row["diagnostics_file"] for row in rows]
    if len(set(diagnostics)) != len(diagnostics):
        raise ValueError("proposed diagnostics are not unique")
    return rows


def coverage_gate(
    case_id: str,
    metrics_row: dict[str, str],
    coverage_rows: dict[str, dict[str, str]],
) -> dict[str, object]:
    diagnostics_file = metrics_row["diagnostics_file"]
    coverage = coverage_rows.get(diagnostics_file)
    if coverage is None:
        raise KeyError(f"missing coverage summary for {diagnostics_file}")
    ok = (
        coverage["issue_flag"] == "0"
        and coverage["geometry_coverage_ratio"] == "1.0"
        and coverage["geometry_partial_segment_count"] == "0"
        and coverage["geometry_missing_segment_count"] == "0"
    )
    return {
        "case_id": case_id,
        "method": metrics_row["method"],
        "board_id": metrics_row["board_id"],
        "rectangle_count": metrics_row["rectangle_count"],
        "primitive_segment_count": coverage["primitive_segment_count"],
        "geometry_full_segment_count": coverage["geometry_full_segment_count"],
        "geometry_partial_segment_count": coverage["geometry_partial_segment_count"],
        "geometry_missing_segment_count": coverage["geometry_missing_segment_count"],
        "geometry_coverage_ratio": coverage["geometry_coverage_ratio"],
        "issue_flag": coverage["issue_flag"],
        "coverage_gate_pass": ok,
        "diagnostics_file": diagnostics_file,
    }


def rewrite_camotics_project(path: Path, nc_name: str) -> None:
    project = json.loads(path.read_text(encoding="utf-8"))
    project["files"] = [nc_name]
    path.write_text(json.dumps(project, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def build_readme(output_dir: Path, template: NcTemplate) -> None:
    text = f"""# Corrected 77-Route NC/CAMotics Exportability Audit

This directory contains regenerated generic NC/CAMotics artifacts for all 77
corrected proposed routes in the formal production-derived record set.

## Evidence Role

This is auxiliary exportability evidence. The formal manuscript evidence remains
the corrected span-level geometric coverage audit. These NC/CAMotics artifacts
show that the corrected proposed routes can be exported and parsed/simulated
under one fixed generic 3-axis template.

## Source

- Metrics: `{DEFAULT_METRICS.relative_to(ROOT)}`
- Coverage audit: `{DEFAULT_COVERAGE.relative_to(ROOT)}`
- Method: `{PROPOSED_METHOD}`

## Locked NC Template

- Units: millimetres (`G21`)
- Coordinate mode: absolute (`G90`)
- Stock: {template.stock_width_mm:g} x {template.stock_height_mm:g} x {template.stock_thickness_mm:g} mm
- Tool diameter: {template.tool_diameter_mm:g} mm
- Safe Z: {template.z_safe_mm:g} mm
- Step-down: {template.step_down_mm:g} mm
- Final cutting depth: -{template.stock_thickness_mm:g} mm
- Spindle: {template.spindle_rpm:g} rpm
- Cut feed: {template.feed_cut_mm_min:g} mm/min
- Plunge feed: {template.feed_plunge_mm_min:g} mm/min
- Rapid feed used for parser estimates: {template.feed_rapid_mm_min:g} mm/min

## Files

- `nc_camotics/case_*.nc`: regenerated generic NC programs.
- `nc_camotics/case_*.camotics`: CAMotics projects referencing the matching NC.
- `nc_camotics/camsim_batch_summary.csv`: CAMotics CLI simulation result after running `experiments/run_camotics_batch_simulation.py`.
- `case_index.csv`: provenance and artifact map for all 77 routes.
- `coverage_gate_summary.csv`: corrected span-level coverage gate per route.
- `route_summary.csv`: generic NC parser/export metrics.
- `manifest.json`: machine-readable package summary.

Do not report these files as measured machine cycle-time evidence, controller
verification, or commercial-CAM superiority evidence.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def build_checklist(path: Path) -> None:
    text = """# Manual Inspection Checklist

The batch audit should first be judged by `camsim_batch_summary.csv`. Optional
manual GUI checks can then be done on representative cases.

- [ ] Open selected `.camotics` files without parse errors.
- [ ] Confirm stock is `2440 x 1220 x 18 mm`.
- [ ] Confirm tool diameter is `6 mm`.
- [ ] Confirm routes remain inside the stock envelope.
- [ ] Confirm full-depth fixed-template simulation.
- [ ] Confirm the visible path follows the corrected primitive-edge network.

This checklist supports auxiliary exportability only.
"""
    path.write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    metrics_path = args.metrics.resolve()
    coverage_path = args.coverage_summary.resolve()
    output_dir = args.output_dir.resolve()
    nc_dir = output_dir / "nc_camotics"
    diagnostics_dir = output_dir / "diagnostics"
    template = NcTemplate()

    proposed_rows = load_proposed_rows(metrics_path)
    coverage_rows = coverage_by_diagnostics(coverage_path)

    if output_dir.exists():
        shutil.rmtree(output_dir)
    nc_dir.mkdir(parents=True, exist_ok=True)
    diagnostics_dir.mkdir(parents=True, exist_ok=True)

    case_rows: list[dict[str, object]] = []
    route_rows: list[dict[str, object]] = []
    coverage_gate_rows: list[dict[str, object]] = []

    for index, metrics_row in enumerate(proposed_rows, start=1):
        case_id = f"case_{index:03d}_board{metrics_row['board_id']}"
        source = ROOT / metrics_row["diagnostics_file"]
        if not source.exists():
            raise FileNotFoundError(source)

        gate = coverage_gate(case_id, metrics_row, coverage_rows)
        coverage_gate_rows.append(gate)

        diagnostic_copy = diagnostics_dir / f"{case_id}_{PROPOSED_METHOD}_diagnostics.csv"
        shutil.copy2(source, diagnostic_copy)

        metric = export_route(source, nc_dir, template)
        generated_nc = Path(metric.gcode_file)
        generated_camotics = generated_nc.with_suffix(".camotics")
        target_nc = nc_dir / f"{case_id}_proposed.nc"
        target_camotics = nc_dir / f"{case_id}_proposed.camotics"
        generated_nc.rename(target_nc)
        generated_camotics.rename(target_camotics)
        rewrite_camotics_project(target_camotics, target_nc.name)

        route = asdict(metric)
        route.update(
            {
                "case_id": case_id,
                "board_id": metrics_row["board_id"],
                "rectangle_count": metrics_row["rectangle_count"],
                "archive": metrics_row["archive"],
                "placements_member": metrics_row["placements_member"],
                "seed": metrics_row["seed"],
                "placement_method": metrics_row["placement_method"],
                "diagnostics_copy": str(diagnostic_copy.relative_to(output_dir)),
                "gcode_file": str(target_nc.relative_to(output_dir)),
                "camotics_file": str(target_camotics.relative_to(output_dir)),
            }
        )
        route_rows.append(route)
        case_rows.append(
            {
                "case_id": case_id,
                "board_id": metrics_row["board_id"],
                "rectangle_count": metrics_row["rectangle_count"],
                "archive": metrics_row["archive"],
                "placements_member": metrics_row["placements_member"],
                "seed": metrics_row["seed"],
                "placement_method": metrics_row["placement_method"],
                "diagnostics": str(diagnostic_copy.relative_to(output_dir)),
                "nc": str(target_nc.relative_to(output_dir)),
                "camotics": str(target_camotics.relative_to(output_dir)),
                "primitive_segment_count": gate["primitive_segment_count"],
                "coverage_gate_pass": gate["coverage_gate_pass"],
            }
        )

    write_rows(output_dir / "case_index.csv", case_rows)
    write_rows(output_dir / "route_summary.csv", route_rows)
    write_rows(output_dir / "coverage_gate_summary.csv", coverage_gate_rows)
    build_readme(output_dir, template)
    build_checklist(output_dir / "MANUAL_INSPECTION_CHECKLIST.md")

    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "boundary": "auxiliary NC/CAMotics exportability evidence only",
        "formal_metrics": str(metrics_path.relative_to(ROOT)),
        "coverage_summary": str(coverage_path.relative_to(ROOT)),
        "output_dir": str(output_dir.relative_to(ROOT)),
        "method": PROPOSED_METHOD,
        "case_count": len(case_rows),
        "route_count": len(route_rows),
        "all_coverage_gates_pass": all(
            bool(row["coverage_gate_pass"]) for row in coverage_gate_rows
        ),
        "all_nc_bounds_pass": all(
            int(row["out_of_bounds_action_count"]) == 0 for row in route_rows
        ),
        "all_hard_penalties_zero": all(
            float(row["hard_penalty_sum"]) == 0.0 for row in route_rows
        ),
        "all_support_penalties_zero": all(
            float(row["support_rule_penalty_sum"]) == 0.0 for row in route_rows
        ),
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    zip_path = shutil.make_archive(str(output_dir), "zip", output_dir)
    print(f"wrote {output_dir.relative_to(ROOT)}")
    print(f"wrote {Path(zip_path).relative_to(ROOT)}")
    print(f"cases: {len(case_rows)}")
    print(f"coverage gates pass: {manifest['all_coverage_gates_pass']}")
    print(f"NC bounds pass: {manifest['all_nc_bounds_pass']}")
    print(f"hard penalties zero: {manifest['all_hard_penalties_zero']}")
    print(f"support penalties zero: {manifest['all_support_penalties_zero']}")


if __name__ == "__main__":
    main()
