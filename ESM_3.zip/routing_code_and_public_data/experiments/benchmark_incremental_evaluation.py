from __future__ import annotations

import argparse
import csv
import json
import platform
import subprocess
import sys
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from statistics import mean, median
from time import perf_counter
from types import SimpleNamespace

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.io import (
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.local_search import (
    build_prefix_states,
    evaluate_directed_units,
    evaluate_neighbor_move_metrics,
    local_neighbor_moves,
    process_aware_beam_search_order,
)
from cnc_cutting.models import Panel, PathMetrics
from cnc_cutting.optimizer import select_coverage_units
from cnc_cutting.travel import clear_detour_cache
from process_options import build_process_model_from_args
from run_chapter2_batch import (
    DEFAULT_ARCHIVES,
    board_counts_from_zip,
    compact_beam_search_config,
    compact_local_search_config,
    parse_member_metadata,
    sample_placement_members,
    select_board_ids,
)


ROOT = Path(__file__).resolve().parents[1]
METRIC_FIELDS = (
    "air_move_distance",
    "cutting_length",
    "pierce_count",
    "lift_count",
    "turn_penalty",
    "collision_penalty",
    "boundary_penalty",
    "stability_penalty",
    "repeated_cut_segment_count",
    "repeated_cut_length",
    "redundant_cut_action_count",
    "continuity_reward",
    "safe_lift_count",
    "safe_lift_distance",
    "detour_count",
    "detour_distance",
    "travel_mode_cost",
)


@dataclass(frozen=True)
class IncrementalBenchmarkRow:
    archive: str
    case_name: str
    placement_method: str
    seed: str
    placements_member: str
    board_id: str
    rectangle_count: int
    candidate_unit_count: int
    selected_unit_count: int
    directed_unit_count: int
    move_count: int
    repetitions: int
    prefix_build_ms: float
    incremental_total_ms: float
    full_total_ms: float
    incremental_ms_per_move: float
    full_ms_per_move: float
    speedup: float
    max_abs_metric_error: float
    mismatch_count: int


@dataclass(frozen=True)
class IncrementalBenchmarkSummaryRow:
    cases: int
    total_moves: int
    repetitions: int
    mean_incremental_ms_per_move: float
    median_incremental_ms_per_move: float
    mean_full_ms_per_move: float
    median_full_ms_per_move: float
    mean_speedup: float
    median_speedup: float
    max_abs_metric_error: float
    total_mismatch_count: int


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unknown"


def git_dirty() -> bool:
    try:
        output = subprocess.check_output(
            ["git", "status", "--porcelain"],
            cwd=ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return bool(output.strip())
    except Exception:
        return True


def write_rows(rows: tuple, output: Path) -> None:
    if not rows:
        raise ValueError(f"no rows to write: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def paper_main_process_args() -> SimpleNamespace:
    return SimpleNamespace(
        support_policy="all_edges",
        min_support_count=1,
        min_support_ratio=0.75,
        min_area_normalized_support=0.0,
        adjacency_support_weight=1.0,
    )


def benchmark_cases(
    archives: tuple[Path, ...],
    *,
    max_members_per_archive: int,
    boards_per_member: int,
    min_rectangles: int,
    max_rectangles: int,
    max_cases: int,
) -> tuple[tuple[Path, str, str], ...]:
    cases: list[tuple[Path, str, str]] = []
    for archive in archives:
        for member in sample_placement_members(archive, max_members_per_archive):
            counts = board_counts_from_zip(archive, member)
            for board_id in select_board_ids(
                counts,
                boards_per_member=boards_per_member,
                min_rectangles=min_rectangles,
                max_rectangles=max_rectangles,
            ):
                cases.append((archive, member, board_id))
                if len(cases) >= max_cases:
                    return tuple(cases)
    return tuple(cases)


def metric_error(left: PathMetrics, right: PathMetrics) -> float:
    return max(
        abs(float(getattr(left, field)) - float(getattr(right, field)))
        for field in METRIC_FIELDS
    )


def benchmark_one_case(
    archive: Path,
    placements_member: str,
    board_id: str,
    *,
    max_moves: int,
    repetitions: int,
    tolerance: float,
) -> IncrementalBenchmarkRow:
    cfg = load_chapter2_config_from_zip(archive, placements_member=placements_member)
    tool = tool_config_from_chapter2_config(cfg)
    layout = load_chapter2_layouts_from_zip(
        archive,
        placements_member=placements_member,
        board_ids=(board_id,),
    )[0]
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    process_model = build_process_model_from_args(layout, paper_main_process_args())
    size = len(layout.rectangles)
    selected_units = select_coverage_units(units, repeat_cut_policy="hard")
    beam_result = process_aware_beam_search_order(
        selected_units,
        panel=panel,
        tool=tool,
        process_model=process_model,
        config=compact_beam_search_config(size, repeat_cut_policy="hard"),
    )
    directed_units = beam_result.directed_units
    if not directed_units:
        raise ValueError(f"empty directed route for {archive.name}:{placements_member}:{board_id}")

    local_config = replace(
        compact_local_search_config(size, True, repeat_cut_policy="hard"),
        max_neighbors_per_iteration=max_moves,
    )
    moves = local_neighbor_moves(directed_units, local_config)[:max_moves]
    if not moves:
        raise ValueError(f"no local moves for {archive.name}:{placements_member}:{board_id}")

    clear_detour_cache()
    prefix_start = perf_counter()
    prefix_states = build_prefix_states(
        directed_units,
        panel,
        tool,
        process_model=process_model,
    )
    prefix_build_ms = (perf_counter() - prefix_start) * 1000.0
    current_metrics = beam_result.metrics

    # Warm both paths once so the benchmark compares the evaluator logic rather
    # than first-use detour cache construction.
    warm_errors = []
    for move in moves:
        incremental_metrics = evaluate_neighbor_move_metrics(
            move,
            prefix_states,
            current_metrics,
            panel,
            tool,
            process_model=process_model,
        )
        _, full_metrics = evaluate_directed_units(
            move.directed_units,
            panel,
            tool,
            process_model=process_model,
        )
        warm_errors.append(metric_error(incremental_metrics, full_metrics))
    max_error = max(warm_errors)
    mismatch_count = sum(1 for error in warm_errors if error > tolerance)

    incremental_start = perf_counter()
    for _ in range(repetitions):
        for move in moves:
            evaluate_neighbor_move_metrics(
                move,
                prefix_states,
                current_metrics,
                panel,
                tool,
                process_model=process_model,
            )
    incremental_total_ms = (perf_counter() - incremental_start) * 1000.0

    full_start = perf_counter()
    for _ in range(repetitions):
        for move in moves:
            evaluate_directed_units(
                move.directed_units,
                panel,
                tool,
                process_model=process_model,
            )
    full_total_ms = (perf_counter() - full_start) * 1000.0

    denominator = max(1, len(moves) * repetitions)
    case_name, placement_method, seed = parse_member_metadata(placements_member)
    incremental_per_move = incremental_total_ms / denominator
    full_per_move = full_total_ms / denominator
    return IncrementalBenchmarkRow(
        archive=archive.name,
        case_name=case_name,
        placement_method=placement_method,
        seed=seed,
        placements_member=placements_member,
        board_id=board_id,
        rectangle_count=size,
        candidate_unit_count=len(units),
        selected_unit_count=len(selected_units),
        directed_unit_count=len(directed_units),
        move_count=len(moves),
        repetitions=repetitions,
        prefix_build_ms=prefix_build_ms,
        incremental_total_ms=incremental_total_ms,
        full_total_ms=full_total_ms,
        incremental_ms_per_move=incremental_per_move,
        full_ms_per_move=full_per_move,
        speedup=full_per_move / incremental_per_move if incremental_per_move > 0.0 else 0.0,
        max_abs_metric_error=max_error,
        mismatch_count=mismatch_count,
    )


def summarize(
    rows: tuple[IncrementalBenchmarkRow, ...],
) -> IncrementalBenchmarkSummaryRow:
    return IncrementalBenchmarkSummaryRow(
        cases=len(rows),
        total_moves=sum(row.move_count for row in rows),
        repetitions=max(row.repetitions for row in rows),
        mean_incremental_ms_per_move=mean(row.incremental_ms_per_move for row in rows),
        median_incremental_ms_per_move=median(row.incremental_ms_per_move for row in rows),
        mean_full_ms_per_move=mean(row.full_ms_per_move for row in rows),
        median_full_ms_per_move=median(row.full_ms_per_move for row in rows),
        mean_speedup=mean(row.speedup for row in rows),
        median_speedup=median(row.speedup for row in rows),
        max_abs_metric_error=max(row.max_abs_metric_error for row in rows),
        total_mismatch_count=sum(row.mismatch_count for row in rows),
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Benchmark incremental neighbor evaluation against full route "
            "recomputation on production-derived Chapter 3 layouts."
        )
    )
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=55)
    parser.add_argument("--boards-per-member", type=int, default=1)
    parser.add_argument("--min-rectangles", type=int, default=20)
    parser.add_argument("--max-rectangles", type=int, default=50)
    parser.add_argument("--max-cases", type=int, default=20)
    parser.add_argument("--max-moves-per-case", type=int, default=80)
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--tolerance", type=float, default=1e-6)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "results"
        / "formal"
        / "chapter3_formal_hard_gate25_incremental_evaluation_benchmark.csv",
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=ROOT
        / "results"
        / "formal"
        / "chapter3_formal_hard_gate25_incremental_evaluation_benchmark_summary.csv",
    )
    parser.add_argument(
        "--manifest-output",
        type=Path,
        default=ROOT
        / "results"
        / "formal"
        / "chapter3_formal_hard_gate25_incremental_evaluation_benchmark_manifest.json",
    )
    parser.add_argument("--progress-every", type=int, default=5)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    archives = tuple(args.zip_paths or DEFAULT_ARCHIVES)
    cases = benchmark_cases(
        archives,
        max_members_per_archive=args.max_members_per_archive,
        boards_per_member=args.boards_per_member,
        min_rectangles=args.min_rectangles,
        max_rectangles=args.max_rectangles,
        max_cases=args.max_cases,
    )
    if not cases:
        raise ValueError("no benchmark cases produced")

    rows: list[IncrementalBenchmarkRow] = []
    start_all = perf_counter()
    for index, (archive, member, board_id) in enumerate(cases, start=1):
        rows.append(
            benchmark_one_case(
                archive,
                member,
                board_id,
                max_moves=args.max_moves_per_case,
                repetitions=args.repetitions,
                tolerance=args.tolerance,
            )
        )
        if index % args.progress_every == 0 or index == len(cases):
            elapsed = perf_counter() - start_all
            print(f"completed={index}/{len(cases)} elapsed={elapsed:.1f}s", flush=True)

    result_rows = tuple(rows)
    summary_row = summarize(result_rows)
    if summary_row.total_mismatch_count:
        raise AssertionError(
            f"incremental/full recomputation mismatch count: "
            f"{summary_row.total_mismatch_count}"
        )

    write_rows(result_rows, args.output)
    write_rows((summary_row,), args.summary_output)
    args.manifest_output.parent.mkdir(parents=True, exist_ok=True)
    args.manifest_output.write_text(
        json.dumps(
            {
                "command": sys.argv,
                "python": sys.version,
                "platform": platform.platform(),
                "git_commit": git_commit(),
                "dirty": git_dirty(),
                "archives": [str(path) for path in archives],
                "cases": len(cases),
                "max_moves_per_case": args.max_moves_per_case,
                "repetitions": args.repetitions,
                "tolerance": args.tolerance,
                "output": str(args.output),
                "summary_output": str(args.summary_output),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"wrote: {args.output}")
    print(f"wrote: {args.summary_output}")
    print(f"wrote: {args.manifest_output}")


if __name__ == "__main__":
    main()
