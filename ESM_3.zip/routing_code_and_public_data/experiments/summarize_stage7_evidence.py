from __future__ import annotations

import csv
import json
from pathlib import Path
from statistics import mean, median


ROOT = Path(__file__).resolve().parents[1]
STAGE7 = ROOT / "results" / "corrected_model_stage7_kerf"
FORMAL = STAGE7 / "formal"
PROPOSED = "process_aware_beam_adaptive_polished"


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def record_key(row: dict[str, str]) -> tuple[str, str]:
    return row["placements_member"], row["board_id"]


def planning_cost(row: dict[str, str]) -> float:
    return float(row["cutting_length"]) + float(row["travel_mode_cost"])


def fully_feasible(row: dict[str, str]) -> bool:
    return (
        float(row["hard_penalty"]) == 0.0
        and float(row["stability_penalty"]) == 0.0
        and int(row["coverage_missing_segment_count"]) == 0
        and int(row["process_repeated_span_count"]) == 0
    )


def paired_summary(
    baseline_rows: list[dict[str, str]],
    proposed_rows: list[dict[str, str]],
    label: str,
) -> dict[str, object]:
    baseline = {record_key(row): row for row in baseline_rows}
    proposed = {record_key(row): row for row in proposed_rows}
    keys = sorted(set(baseline) & set(proposed))
    reductions = [
        100.0
        * (planning_cost(baseline[key]) - planning_cost(proposed[key]))
        / planning_cost(baseline[key])
        for key in keys
    ]
    return {
        "comparison": label,
        "n": len(keys),
        "baseline_feasible_records": sum(fully_feasible(baseline[key]) for key in keys),
        "proposed_feasible_records": sum(fully_feasible(proposed[key]) for key in keys),
        "paired_cplan_reduction_mean_pct": f"{mean(reductions):.6f}",
        "paired_cplan_reduction_median_pct": f"{median(reductions):.6f}",
        "proposed_wins": sum(value > 1e-9 for value in reductions),
        "ties": sum(abs(value) <= 1e-9 for value in reductions),
        "baseline_wins": sum(value < -1e-9 for value in reductions),
    }


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def exact_match_count(
    first_rows: list[dict[str, str]],
    second_rows: list[dict[str, str]],
) -> int:
    first = {record_key(row): row for row in first_rows}
    second = {record_key(row): row for row in second_rows}
    return sum(
        planning_cost(first[key]) == planning_cost(second[key])
        and int(first[key]["process_repeated_span_count"])
        == int(second[key]["process_repeated_span_count"])
        for key in set(first) & set(second)
    )


def main() -> None:
    main_rows = read_rows(FORMAL / "chapter3_stage7_main.csv")
    external_rows = read_rows(FORMAL / "chapter3_stage7_external_baselines.csv")
    mcts_rows = read_rows(FORMAL / "chapter3_stage7_prefix_mcts.csv")
    proposed = [row for row in main_rows if row["method"] == PROPOSED]
    comparisons: list[dict[str, object]] = []
    for method in (
        "topology_process_aware",
        "process_local_search_multistart",
        "process_aware_beam",
    ):
        comparisons.append(
            paired_summary(
                [row for row in main_rows if row["method"] == method],
                proposed,
                f"{PROPOSED} vs {method}",
            )
        )
    for method in sorted({row["method"] for row in external_rows}):
        comparisons.append(
            paired_summary(
                [row for row in external_rows if row["method"] == method],
                proposed,
                f"{PROPOSED} vs {method}",
            )
        )
    mcts_proposed = [row for row in mcts_rows if row["method"] == PROPOSED]
    mcts_baseline = [
        row for row in mcts_rows if row["method"] == "process_aware_prefix_beam_mcts"
    ]
    comparisons.append(
        paired_summary(
            mcts_baseline,
            mcts_proposed,
            f"{PROPOSED} vs process_aware_prefix_beam_mcts",
        )
    )
    write_rows(FORMAL / "chapter3_stage7_paired_comparisons.csv", comparisons)

    main_by_method = {
        method: [row for row in main_rows if row["method"] == method]
        for method in {row["method"] for row in main_rows}
    }
    ablation_matches = {
        "beam_polished_vs_beam": exact_match_count(
            read_rows(FORMAL / "chapter3_stage7_ablation_beam_polished.csv"),
            main_by_method["process_aware_beam"],
        ),
        "gate_off_vs_gate25": exact_match_count(
            read_rows(FORMAL / "chapter3_stage7_ablation_gate_off.csv"),
            proposed,
        ),
        "conservative_gate_vs_gate25": exact_match_count(
            read_rows(FORMAL / "chapter3_stage7_ablation_gate_conservative.csv"),
            proposed,
        ),
        "repeat_soft_vs_hard": exact_match_count(
            read_rows(FORMAL / "chapter3_stage7_ablation_repeat_soft.csv"),
            proposed,
        ),
        "repeat_off_vs_hard": exact_match_count(
            read_rows(FORMAL / "chapter3_stage7_ablation_repeat_off.csv"),
            proposed,
        ),
    }
    nc_manifest = json.loads(
        (STAGE7 / "auxiliary_nc_cam_fusion_5case" / "manifest.json").read_text()
    )
    fusion_rows = read_rows(
        STAGE7
        / "auxiliary_nc_cam_fusion_5case"
        / "fusion"
        / "api_batch"
        / "fusion_api_nc_audit.csv"
    )
    public_rows = read_rows(
        STAGE7
        / "public_benchmark"
        / "chapter3_stage7_public_2dpacklib30_summary.csv"
    )
    support_rows = read_rows(
        STAGE7
        / "support_sensitivity"
        / "chapter3_stage7_support_policy_sensitivity_summary.csv"
    )
    cross_support_rows = read_rows(
        STAGE7
        / "cross_method_support_sensitivity"
        / "stage7_cross_method_support_method_summary.csv"
    )
    budget_summary = json.loads(
        (
            STAGE7
            / "budget_matched_search"
            / "stage7_budget_matched_paired_summary.json"
        ).read_text()
    )
    inventory_rows = read_rows(
        STAGE7
        / "inventory_clustered_statistics"
        / "stage7_inventory_summary.csv"
    )
    main_process_rows = {
        row["baseline_method"]: row
        for row in read_rows(FORMAL / "chapter3_stage7_main_statistical.csv")
        if row["metric"] == "process_key"
    }
    mcts_process_row = next(
        row
        for row in read_rows(FORMAL / "chapter3_stage7_prefix_mcts_statistical.csv")
        if row["metric"] == "process_key"
    )
    scalability_rows = read_rows(
        STAGE7
        / "scalability"
        / "chapter3_stage7_scalability_clustered.csv"
    )
    proposed_500 = [
        row
        for row in scalability_rows
        if row["method"] == PROPOSED and int(row["size"]) == 500
    ]
    proposed_500_runtime = [float(row["runtime_ms"]) / 1000.0 for row in proposed_500]
    selected = {
        row["comparison"]: row
        for row in comparisons
    }
    topology = selected[f"{PROPOSED} vs topology_process_aware"]
    beam = selected[f"{PROPOSED} vs process_aware_beam"]
    mcts = selected[f"{PROPOSED} vs process_aware_prefix_beam_mcts"]
    endpoint = selected[f"{PROPOSED} vs endpoint_aware_gtsp"]
    inventory_cplan = {
        row["baseline_method"]: row
        for row in inventory_rows
        if row["metric"] == "cplan"
    }
    topology_inventory = inventory_cplan["topology_process_aware"]
    beam_inventory = inventory_cplan["process_aware_beam"]
    mcts_inventory = inventory_cplan["process_aware_prefix_beam_mcts"]
    cross_gtsp = sorted(
        (row for row in cross_support_rows if row["method"] == "endpoint_aware_gtsp"),
        key=lambda row: float(row["min_support_ratio"]),
    )
    gtsp_violation_counts = ", ".join(
        f"{row['positive_support_penalty_layouts']}/77" for row in cross_gtsp
    )
    gtsp_penalty_means = ", ".join(
        f"{float(row['support_penalty_layout_mean']):.3f}" for row in cross_gtsp
    )
    text = f"""# Stage 7 Corrected Evidence Status

## Geometry and Modeled-Policy Gates

- The legacy 77-record cohort is dimensionally infeasible for a 6 mm cutter: 77/77 records contain zero-gap nominal-part contacts.
- The regenerated cohort contains 77 geometry-only-unique layouts with 20--35 parts per selected board, algorithmically repacked from four distinct production inventories with multiplicities 31, 25, 18, and 3.
- All 77 regenerated layouts pass packing-envelope overlap, stock-boundary, finished-dimension, and swept-disk no-gouge audits.
- All formal proposed routes have zero missing spans, zero repeated spans, zero hard penalties, and zero support-rule penalties.

## Formal Comparisons

- The following W/T/L counts and paired means are layout-level descriptive results, not independent-sample inference.
- Against topology/process-aware routing, the span-aware process-key W/T/L is {main_process_rows['topology_process_aware']['wins']}/{main_process_rows['topology_process_aware']['ties']}/{main_process_rows['topology_process_aware']['losses']}, and the layout-weighted mean paired $C_{{plan}}$ reduction is {float(topology['paired_cplan_reduction_mean_pct']):.2f}%.
- Against fixed process-aware beam search, the span-aware process-key W/T/L is {main_process_rows['process_aware_beam']['wins']}/{main_process_rows['process_aware_beam']['ties']}/{main_process_rows['process_aware_beam']['losses']}, and the layout-weighted mean paired $C_{{plan}}$ reduction is {float(beam['paired_cplan_reduction_mean_pct']):.2f}%.
- Against Prefix Beam MCTS, the span-aware process-key W/T/L is {mcts_process_row['wins']}/{mcts_process_row['ties']}/{mcts_process_row['losses']}, and the layout-weighted mean paired $C_{{plan}}$ reduction is {float(mcts['paired_cplan_reduction_mean_pct']):.2f}%.
- Under the locked strict ratio $\\rho=0.75$, endpoint-aware GTSP violates the modeled support policy on 77/77 layouts. Its scalar planning cost is lower on average; the proposed-vs-GTSP layout-weighted reduction is {float(endpoint['paired_cplan_reduction_mean_pct']):.2f}%. This is a policy-dependent tradeoff, not a cost win or a machine-level infeasibility result.

## Inventory-Clustered Inference

- The inventory hash is the independent unit. Layout reductions are averaged within each inventory before the four inventories are weighted equally.
- Against topology/process-aware routing, the inventory-equal $C_{{plan}}$ reduction is {float(topology_inventory['inventory_equal_mean_reduction_pct']):.2f}% (cluster-bootstrap 95% CI {float(topology_inventory['cluster_bootstrap_ci95_low']):.2f}% to {float(topology_inventory['cluster_bootstrap_ci95_high']):.2f}%; inventory W/T/L {topology_inventory['inventory_wins']}/{topology_inventory['inventory_ties']}/{topology_inventory['inventory_losses']}).
- Against fixed process-aware beam search, the inventory-equal reduction is {float(beam_inventory['inventory_equal_mean_reduction_pct']):.2f}% (95% CI {float(beam_inventory['cluster_bootstrap_ci95_low']):.2f}% to {float(beam_inventory['cluster_bootstrap_ci95_high']):.2f}%).
- Against Prefix Beam MCTS, the inventory-equal reduction is {float(mcts_inventory['inventory_equal_mean_reduction_pct']):.2f}% (95% CI {float(mcts_inventory['cluster_bootstrap_ci95_low']):.2f}% to {float(mcts_inventory['cluster_bootstrap_ci95_high']):.2f}%).
- All listed comparisons have inventory W/T/L 4/0/0, but the exact two-sided sign test is $p=0.125$. This is directional consistency, not conventional statistical significance.

## Ablation Interpretation

- Beam+LS equals fixed Beam on {ablation_matches['beam_polished_vs_beam']}/77 layouts.
- Gate-off and conservative-gate variants equal gate-25 on {ablation_matches['gate_off_vs_gate25']}/77 and {ablation_matches['conservative_gate_vs_gate25']}/77 layouts.
- Soft and disabled repeat policies equal hard repeat protection on {ablation_matches['repeat_soft_vs_hard']}/77 and {ablation_matches['repeat_off_vs_hard']}/77 layouts; every variant still has zero repeated spans.
- The measurable gain therefore comes from the adaptive candidate portfolio, while Event Gate and repeat protection act as safeguards on this cohort.

## Quality--Runtime Check

- Ordinary-beam scales from 1.0x to 3.0x were all evaluated on the 77 layouts under the same evaluator and hardware; the runtime-nearest row was selected without using route quality.
- The 2.5x ordinary beam uses {float(budget_summary['baseline_runtime_ms_mean']):.1f} ms on average versus {float(budget_summary['target_runtime_ms_mean']):.1f} ms for the adaptive portfolio (runtime ratio {float(budget_summary['baseline_to_target_runtime_ratio']):.3f}).
- Relative to this runtime-nearest beam, the portfolio's layout-level paired $C_{{plan}}$ reduction is {float(budget_summary['layout_mean_reduction_pct']):.2f}% with W/T/L {budget_summary['layout_wins']}/{budget_summary['layout_ties']}/{budget_summary['layout_losses']}.
- The inventory-equal reduction is {float(budget_summary['inventory_equal_reduction_pct']):.2f}%, inventory W/T/L is {budget_summary['inventory_wins']}/{budget_summary['inventory_ties']}/{budget_summary['inventory_losses']}, and the exact sign test is $p={float(budget_summary['inventory_sign_test_p']):.3f}$.
- No clear portfolio quality advantage is demonstrated at similar wall-clock scale. The 5.03% topology comparison is a portfolio quality gain; the 1.78% narrow-beam comparison is not an equal-budget dominance result.

## Support-Policy Sensitivity

- The Stage 7 sensitivity varies $\\rho$ over 0.60, 0.75, and 0.90 and adjacency credit $\\alpha$ over 0.50, 1.00, and 1.50, changing one parameter at a time.
- Every alternative setting changes the proposed route on 77/77 layouts, but the paired planning-cost reduction relative to process-aware topology remains between {min(float(row['paired_cplan_reduction_mean_pct']) for row in support_rows):.2f}% and {max(float(row['paired_cplan_reduction_mean_pct']) for row in support_rows):.2f}%.
- All five settings retain zero proposed losses, zero missing spans, and zero hard and support-policy penalties. This is comparative robustness under the modeled policy, not physical calibration of the thresholds.
- The cross-method sweep reports every prespecified ratio 0, 0.25, 0.50, 0.75, and 0.90. GTSP positive-penalty layout counts are {gtsp_violation_counts}, and its mean modeled penalties are {gtsp_penalty_means}, respectively.
- Both process-aware methods retain zero modeled support-policy penalty throughout. The result is a threshold-dependent cost--policy tradeoff; $\\rho=0.75$ is not a physically calibrated fixture boundary.

## NC and Fusion

- The regenerated five-case package contains {nc_manifest['route_count']} NC routes; all route gates and NC stock-bound checks pass.
- Every generated NC program declares `G40` because XY coordinates are already geometrically kerf-compensated.
- Five proposed DXFs were processed through the Fusion API workflow; {sum(row['passed'] == 'True' for row in fusion_rows)}/5 parser-back audits pass the three-depth, segment-retention, bounds, and G40 checks.
- Fusion remains auxiliary geometric exportability evidence, not a route-order or commercial-CAM performance comparator.

## Public Geometry

- The Stage 7 public benchmark contains {sum(int(row['n']) for row in public_rows) // len(public_rows)} kerf-corrected 2DPackLib-derived layouts and four methods.
- All rows have zero hard penalty and zero missing spans. Endpoint-aware GTSP has the lowest scalar planning cost but a nonzero modeled support-policy penalty; Adaptive Beam+LS has the lowest mean planning cost among zero-penalty methods.

## Scalability and Exact Certification

- The Stage 7 kerf-aware clustered-layout stress test completed {len(scalability_rows)}/45 planned runs with zero hard and support-policy penalties.
- At 500 rectangles, Adaptive Beam+LS has a median runtime of {median(proposed_500_runtime):.2f} s and an observed maximum of {max(proposed_500_runtime):.2f} s; the process high-water RSS is {max(float(row['peak_rss_mb']) for row in scalability_rows):.0f} MiB.
- The former 8--12-rectangle exact-gap values are excluded. After adding 6 mm channels and residual-span coverage, the 8-rectangle smoke case did not close within a 120 s certificate budget.
"""
    (STAGE7 / "STAGE7_EVIDENCE_STATUS.md").write_text(text, encoding="utf-8")
    print(f"comparisons={len(comparisons)}")
    print(f"output={STAGE7 / 'STAGE7_EVIDENCE_STATUS.md'}")


if __name__ == "__main__":
    main()
