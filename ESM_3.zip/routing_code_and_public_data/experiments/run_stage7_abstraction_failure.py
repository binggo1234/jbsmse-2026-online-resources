from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
import subprocess
import time
from collections import defaultdict
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from cnc_cutting.io import (
    PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)

from experiments.abstraction_failure import (
    AbstractionVariant,
    audit_layout_abstraction,
)


ROOT = Path(__file__).resolve().parents[1]
STAGE7 = ROOT / "results" / "corrected_model_stage7_kerf"
DEFAULT_OUTPUT = ROOT / "results" / "abstraction_failure_experiment"
OVERALL_FAILURE_THRESHOLD = 0.20
INVENTORY_FAILURE_THRESHOLD = 0.10
MIN_AFFECTED_INVENTORIES = 3


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen Stage 7 abstraction-failure experiment."
    )
    parser.add_argument(
        "--archive",
        type=Path,
        default=STAGE7 / "kerf_layouts" / "stage7_kerf_layouts.zip",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=STAGE7 / "kerf_layouts" / "stage7_kerf_layout_manifest.csv",
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Run the first N records for a non-decisional implementation pilot.",
    )
    return parser.parse_args()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git_value(*args: str) -> str:
    result = subprocess.run(
        ("git", *args),
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def summarize(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[str(row["variant"])].append(row)
    summaries: list[dict[str, object]] = []
    for variant in AbstractionVariant:
        variant_rows = grouped[variant.value]
        count = len(variant_rows)
        missing_counts = [
            int(row["missing_atomic_span_count"]) for row in variant_rows
        ]
        missing_rates = [
            int(row["missing_atomic_span_count"]) / int(row["atomic_span_count"])
            for row in variant_rows
        ]
        summaries.append(
            {
                "variant": variant.value,
                "layout_count": count,
                "claimed_complete_count": sum(
                    bool(row["claimed_complete"]) for row in variant_rows
                ),
                "false_completion_count": sum(
                    bool(row["false_completion"]) for row in variant_rows
                ),
                "false_completion_rate": (
                    sum(bool(row["false_completion"]) for row in variant_rows) / count
                    if count
                    else 0.0
                ),
                "passed_all_audits_count": sum(
                    bool(row["passed_all_audits"]) for row in variant_rows
                ),
                "missing_atomic_span_count": sum(
                    missing_counts
                ),
                "mean_missing_atomic_span_count": (
                    statistics.mean(missing_counts) if missing_counts else 0.0
                ),
                "median_missing_atomic_span_count": (
                    statistics.median(missing_counts) if missing_counts else 0.0
                ),
                "mean_missing_atomic_span_rate": (
                    statistics.mean(missing_rates) if missing_rates else 0.0
                ),
                "median_missing_atomic_span_rate": (
                    statistics.median(missing_rates) if missing_rates else 0.0
                ),
                "partial_primitive_segment_count": sum(
                    int(row["partial_primitive_segment_count"]) for row in variant_rows
                ),
                "finished_dimension_violation_count": sum(
                    int(row["finished_dimension_violation_count"])
                    for row in variant_rows
                ),
                "swept_disk_gouge_count": sum(
                    int(row["swept_disk_gouge_count"]) for row in variant_rows
                ),
            }
        )
    return summaries


def summarize_inventories(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[(str(row["inventory_sha256"]), str(row["variant"]))].append(row)
    output: list[dict[str, object]] = []
    for (inventory, variant), group in sorted(grouped.items()):
        count = len(group)
        false_count = sum(bool(row["false_completion"]) for row in group)
        output.append(
            {
                "inventory_sha256": inventory,
                "variant": variant,
                "layout_count": count,
                "false_completion_count": false_count,
                "false_completion_rate": false_count / count if count else 0.0,
                "passed_all_audits_count": sum(
                    bool(row["passed_all_audits"]) for row in group
                ),
            }
        )
    return output


def decision(
    summaries: list[dict[str, object]],
    inventory_summaries: list[dict[str, object]],
    *,
    decisive_run: bool,
) -> dict[str, object]:
    by_variant = {str(row["variant"]): row for row in summaries}
    corrected = by_variant[AbstractionVariant.COMPENSATED_ATOMIC_SPAN.value]
    coarse = by_variant[AbstractionVariant.COMPENSATED_WHOLE_SEGMENT.value]
    corrected_all_pass = (
        int(corrected["layout_count"]) > 0
        and int(corrected["passed_all_audits_count"]) == int(corrected["layout_count"])
    )
    affected_inventories = sum(
        str(row["variant"])
        == AbstractionVariant.COMPENSATED_WHOLE_SEGMENT.value
        and float(row["false_completion_rate"]) >= INVENTORY_FAILURE_THRESHOLD
        for row in inventory_summaries
    )
    coarse_rate_pass = float(coarse["false_completion_rate"]) >= OVERALL_FAILURE_THRESHOLD
    inventory_spread_pass = affected_inventories >= MIN_AFFECTED_INVENTORIES
    passed = decisive_run and corrected_all_pass and coarse_rate_pass and inventory_spread_pass
    return {
        "decisive_run": decisive_run,
        "corrected_all_pass": corrected_all_pass,
        "compensated_whole_segment_false_completion_rate": coarse[
            "false_completion_rate"
        ],
        "overall_failure_threshold": OVERALL_FAILURE_THRESHOLD,
        "affected_inventory_count": affected_inventories,
        "inventory_failure_threshold": INVENTORY_FAILURE_THRESHOLD,
        "minimum_affected_inventory_count": MIN_AFFECTED_INVENTORIES,
        "representation_necessity_signal": (
            "PASS" if passed else "NO_GO" if decisive_run else "PILOT_ONLY"
        ),
    }


def write_readme(
    path: Path,
    summaries: list[dict[str, object]],
    inventory_summaries: list[dict[str, object]],
    verdict: dict[str, object],
) -> None:
    lines = [
        "# Stage 7 Abstraction-Failure Experiment",
        "",
        f"Verdict: **{verdict['representation_necessity_signal']}**",
        "",
        "This is a representation audit, not a search-performance or cycle-time experiment.",
        "The nominal-centerline group is a positive control and does not count toward novelty.",
        "",
        "## Variant summary",
        "",
        "| Variant | Layouts | Claimed complete | False complete | Pass all audits | Missing spans, mean (rate) | Dimension violations | Gouges |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summaries:
        lines.append(
            f"| `{row['variant']}` | {row['layout_count']} | "
            f"{row['claimed_complete_count']} | {row['false_completion_count']} "
            f"({float(row['false_completion_rate']):.1%}) | "
            f"{row['passed_all_audits_count']} | "
            f"{float(row['mean_missing_atomic_span_count']):.1f} "
            f"({float(row['mean_missing_atomic_span_rate']):.1%}) | "
            f"{row['finished_dimension_violation_count']} | {row['swept_disk_gouge_count']} |"
        )
    lines.extend(
        [
            "",
            "## Frozen decision rule",
            "",
            f"- Corrected model passes all layouts: `{verdict['corrected_all_pass']}`",
            "- Compensated whole-segment false-completion rate: "
            f"`{float(verdict['compensated_whole_segment_false_completion_rate']):.1%}` "
            f"(threshold `{float(verdict['overall_failure_threshold']):.0%}`)",
            f"- Inventories above the 10% failure threshold: `{verdict['affected_inventory_count']}` "
            f"(required `{verdict['minimum_affected_inventory_count']}`)",
            "",
            "## Inventory-blocked results",
            "",
            "| Inventory | Variant | Layouts | False complete | Rate | Pass all audits |",
            "|---|---|---:|---:|---:|---:|",
        ]
    )
    for row in inventory_summaries:
        lines.append(
            f"| `{str(row['inventory_sha256'])[:12]}` | `{row['variant']}` | "
            f"{row['layout_count']} | {row['false_completion_count']} | "
            f"{float(row['false_completion_rate']):.1%} | {row['passed_all_audits_count']} |"
        )
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    args = parse_args()
    started = time.monotonic()
    manifest_rows = read_rows(args.manifest)
    decisive_run = args.limit is None
    if args.limit is not None:
        manifest_rows = manifest_rows[: args.limit]
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    rows: list[dict[str, object]] = []
    for index, record in enumerate(manifest_rows, start=1):
        config = load_chapter2_config_from_zip(
            args.archive,
            placements_member=record["placements_member"],
            config_member=record["config_member"],
        )
        tool = tool_config_from_chapter2_config(config)
        layout = load_chapter2_layouts_from_zip(
            args.archive,
            placements_member=record["placements_member"],
            config_member=record["config_member"],
            board_ids=(record["selected_board_id"],),
            placement_geometry_mode=PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
            tool_diameter=tool.tool_diameter,
        )[0]
        for variant in AbstractionVariant:
            audit = audit_layout_abstraction(layout, tool, variant)
            rows.append(
                {
                    "record_id": record["record_id"],
                    "inventory_sha256": record["inventory_sha256"],
                    "selected_layout_sha256": record["selected_layout_sha256"],
                    "board_id": record["selected_board_id"],
                    **asdict(audit),
                }
            )
        print(f"[{index}/{len(manifest_rows)}] {record['record_id']}", flush=True)

    summaries = summarize(rows)
    inventory_summaries = summarize_inventories(rows)
    verdict = decision(
        summaries,
        inventory_summaries,
        decisive_run=decisive_run,
    )
    write_rows(output_dir / "stage7_abstraction_failure_rows.csv", rows)
    write_rows(output_dir / "stage7_abstraction_failure_summary.csv", summaries)
    write_rows(
        output_dir / "stage7_abstraction_failure_inventory_summary.csv",
        inventory_summaries,
    )
    write_readme(output_dir / "README.md", summaries, inventory_summaries, verdict)
    provenance = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.monotonic() - started,
        "command": " ".join(("python3", *(__import__("sys").argv))),
        "git_commit": git_value("rev-parse", "HEAD"),
        "git_dirty": bool(git_value("status", "--porcelain")),
        "archive": str(args.archive.resolve()),
        "archive_sha256": sha256(args.archive),
        "source_manifest": str(args.manifest.resolve()),
        "source_manifest_sha256": sha256(args.manifest),
        "record_count": len(manifest_rows),
        "unique_inventory_count": len(
            {row["inventory_sha256"] for row in manifest_rows}
        ),
        "frozen_spec": str(
            (ROOT / "docs" / "abstraction_failure_experiment_frozen_spec.md").resolve()
        ),
        "decision": verdict,
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(provenance, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(verdict, indent=2))
    print(f"output={output_dir}")


if __name__ == "__main__":
    main()
