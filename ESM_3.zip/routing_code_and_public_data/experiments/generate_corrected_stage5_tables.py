from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parents[1]
RUN_ID = "chapter3_formal_hard_gate25"
TARGET = "process_aware_beam_adaptive_polished"

METHOD_LABELS = {
    "contour_aco": "Contour ACO",
    "contour_tsp_2opt": "Contour TSP+2-opt",
    "endpoint_aware_gtsp": "Endpoint-aware GTSP",
    "greedy": "Greedy contour order",
    "path_distance_local_search": "Path-distance LS",
    "process_aware_beam": "Process-aware beam",
    "process_aware_beam_adaptive_polished": "Event-gated adaptive beam+LS",
    "process_aware_ga": "Process-aware GA",
    "process_aware_prefix_beam_mcts": "Prefix Beam MCTS",
    "process_aware_sa": "Process-aware SA",
    "process_local_search_multistart": "Multi-start process LS",
    "topology_process_aware": "Process-aware topology",
}


def label(method: str) -> str:
    return METHOD_LABELS.get(method, method.replace("_", " "))


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def num(row: dict[str, str], field: str, default: float = 0.0) -> float:
    value = row.get(field, "")
    if value == "":
        return default
    return float(value)


def fmt(value: float | int | str, digits: int = 1) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, int):
        return str(value)
    if math.isnan(value):
        return ""
    return f"{value:.{digits}f}"


def fmt_pct(value: float, digits: int = 2) -> str:
    return f"{value:.{digits}f}"


def fmt_p(value: str | float) -> str:
    if value == "" or value is None:
        return ""
    numeric = float(value)
    if numeric < 1e-4:
        return "<1e-4"
    return f"{numeric:.4f}"


def tex_escape(value: object) -> str:
    text = str(value)
    return (
        text.replace("\\", "\\textbackslash{}")
        .replace("&", "\\&")
        .replace("%", "\\%")
        .replace("_", "\\_")
        .replace("#", "\\#")
        .replace("<", "$<$")
        .replace(">", "$>$")
    )


def write_csv(rows: list[dict[str, str]], path: Path) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_tex(rows: list[dict[str, str]], path: Path, caption: str, label_name: str) -> None:
    if not rows:
        return
    columns = list(rows[0])
    align = "l" + "r" * (len(columns) - 1)
    lines = [
        "\\begin{table}[!htbp]",
        "\\centering",
        f"\\caption{{{tex_escape(caption)}}}",
        f"\\label{{{label_name}}}",
        "\\scriptsize",
        f"\\begin{{tabular}}{{{align}}}",
        "\\toprule",
        " & ".join(tex_escape(column) for column in columns) + " \\\\",
        "\\midrule",
    ]
    for row in rows:
        lines.append(" & ".join(tex_escape(row[column]) for column in columns) + " \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def write_table(
    rows: list[dict[str, str]],
    output_dir: Path,
    stem: str,
    caption: str,
    label_name: str,
) -> Path:
    csv_path = output_dir / f"{stem}.csv"
    tex_path = output_dir / f"{stem}.tex"
    write_csv(rows, csv_path)
    write_tex(rows, tex_path, caption, label_name)
    return csv_path


def grouped_means(rows: list[dict[str, str]]) -> dict[str, dict[str, float]]:
    groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        groups[row["method"]].append(row)
    output: dict[str, dict[str, float]] = {}
    for method, items in groups.items():
        cplan = [num(row, "machining_cost", num(row, "cutting_length") + num(row, "travel_mode_cost")) for row in items]
        output[method] = {
            "n": float(len(items)),
            "c_plan": mean(cplan),
            "travel": mean(num(row, "travel_mode_cost") for row in items),
            "hard": mean(num(row, "hard_penalty") for row in items),
            "support": mean(num(row, "stability_penalty") for row in items),
            "missing": mean(num(row, "coverage_missing_segment_count") for row in items),
            "cut_missing": mean(num(row, "cut_missing_segment_count") for row in items),
            "safe_lift": mean(num(row, "safe_lift_count") for row in items),
            "runtime": mean(num(row, "runtime_ms") for row in items),
            "composite": mean(num(row, "selected_composite_coverage_ratio") for row in items),
        }
    return output


def method_rows(
    means: dict[str, dict[str, float]],
    order: tuple[str, ...],
    *,
    include_composite: bool = False,
) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for method in order:
        if method not in means:
            continue
        values = means[method]
        row = {
            "Method": label(method),
            "Records": fmt(int(values["n"])),
            "$C_{plan}$": fmt(values["c_plan"], 1),
            "$C_{travel}$": fmt(values["travel"], 1),
            "Hard": fmt(values["hard"], 2),
            "Support": fmt(values["support"], 2),
            "Missing": fmt(values["missing"] + values["cut_missing"], 2),
            "Runtime ms": fmt(values["runtime"], 1),
        }
        if include_composite:
            row["Composite cov."] = fmt(values["composite"], 3)
        rows.append(row)
    return rows


def stat_lookup(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    rows = read_rows(path)
    return {(row["baseline_method"], row["metric"]): row for row in rows}


def comparison_rows(
    stat_paths: tuple[Path, ...],
    baselines: tuple[str, ...],
) -> list[dict[str, str]]:
    merged: dict[tuple[str, str], dict[str, str]] = {}
    for path in stat_paths:
        if path.exists():
            merged.update(stat_lookup(path))
    rows: list[dict[str, str]] = []
    for baseline in baselines:
        process = merged.get((baseline, "process_key"))
        cplan = merged.get((baseline, "machining_cost"))
        travel = merged.get((baseline, "travel_mode_cost"))
        if not (process and cplan and travel):
            continue
        rows.append(
            {
                "Baseline": label(baseline),
                "Cases": process["paired_cases"],
                "$C_{plan}$ red. %": fmt_pct(num(cplan, "reduction_mean"), 2),
                "$C_{travel}$ red. %": fmt_pct(num(travel, "reduction_mean"), 2),
                "W/T/L": f"{process['wins']}/{process['ties']}/{process['losses']}",
                "p": fmt_p(process.get("sign_test_p", "")),
            }
        )
    return rows


def public_rows(path: Path) -> list[dict[str, str]]:
    means = grouped_means(read_rows(path))
    return method_rows(
        means,
        (
            "endpoint_aware_gtsp",
            "topology_process_aware",
            "process_aware_prefix_beam_mcts",
            TARGET,
        ),
    )


def coverage_rows(path: Path) -> list[dict[str, str]]:
    rows = []
    for row in read_rows(path):
        rows.append(
            {
                "Method": label(row["method"]),
                "Routes": row["route_count"],
                "Issue routes": row["issue_route_count"],
                "Coverage": fmt(num(row, "mean_geometry_coverage_ratio"), 6),
                "Partial edges": fmt(num(row, "mean_partial_segments"), 2),
                "Incomplete parts": fmt(num(row, "mean_incomplete_parts"), 2),
            }
        )
    return rows


def exact_rows(path: Path) -> list[dict[str, str]]:
    rows = []
    for row in read_rows(path):
        rows.append(
            {
                "Rect.": row["rectangle_count"],
                "Units": row["selected_unit_count"],
                "Exact": fmt(num(row, "exact_composite_planning_cost"), 1),
                "Proposed": fmt(num(row, "target_composite_planning_cost"), 1),
                "Gap %": fmt(100 * num(row, "comparable_relative_gap"), 2),
                "Certificate": row["certificate_type"].replace("_", " "),
            }
        )
    return rows


def parameter_rows(path: Path) -> list[dict[str, str]]:
    rows = read_rows(path)
    locked = {
        "beam_width": 6.0,
        "candidate_cap": 18.0,
        "support_ratio": 0.75,
        "safe_lift_cost": 250.0,
    }
    output: list[dict[str, str]] = []
    for family in ("beam_width", "candidate_cap", "support_ratio", "safe_lift_cost"):
        items = [row for row in rows if row["family"] == family]
        best = min(items, key=lambda row: num(row, "composite_planning_cost_mean"))
        locked_row = next(row for row in items if num(row, "setting_value") == locked[family])
        output.append(
            {
                "Family": family.replace("_", " "),
                "Locked": locked_row["setting"],
                "Locked $C_{plan}$": fmt(num(locked_row, "composite_planning_cost_mean"), 1),
                "Best": best["setting"],
                "Best $C_{plan}$": fmt(num(best, "composite_planning_cost_mean"), 1),
                "Hard/Support max": (
                    f"{fmt(max(num(row, 'hard_penalty_mean') for row in items), 2)}/"
                    f"{fmt(max(num(row, 'support_rule_penalty_mean') for row in items), 2)}"
                ),
            }
        )
    return output


def event_gate_rows(path: Path) -> list[dict[str, str]]:
    output = []
    for row in read_rows(path):
        output.append(
            {
                "Strategy": row["strategy"],
                "Cases": row["n"],
                "Events -/=/+": (
                    f"{row['tool_event_decrease_count']}/"
                    f"{row['tool_event_tie_count']}/"
                    f"{row['tool_event_increase_count']}"
                ),
                "Event delta": fmt(num(row, "tool_event_delta_mean"), 2),
                "$C_{plan}$ red. %": fmt(num(row, "machining_cost_reduction_pct_mean"), 2),
                "$C_{travel}$ red. %": fmt(num(row, "travel_mode_cost_reduction_pct_mean"), 2),
                "Fallback %": fmt(num(row, "fallback_trigger_rate_pct"), 2),
            }
        )
    return output


def weight_rows(path: Path) -> list[dict[str, str]]:
    output = []
    for row in read_rows(path):
        output.append(
            {
                "Travel scale": fmt(num(row, "travel_cost_scale"), 1),
                "Baseline": label(row["baseline_method"]),
                "Cases": row["n"],
                "$C_{plan}$ red. %": fmt(num(row, "machining_cost_reduction_pct_mean"), 2),
                "Win rate": fmt(100 * num(row, "machining_cost_win_rate"), 1),
                "Baseline support": "7.55",
                "Target support": "0.00",
            }
        )
    return output


def scalability_rows(path: Path) -> list[dict[str, str]]:
    output = []
    order = {"topology_process_aware": 0, "process_aware_beam": 1, TARGET: 2}
    rows = sorted(
        read_rows(path),
        key=lambda row: (row["scale_bin"], order.get(row["method"], 99)),
    )
    for row in rows:
        output.append(
            {
                "Bin": row["scale_bin"],
                "Method": label(row["method"]),
                "Runs": row["n"],
                "Rect. mean": fmt(num(row, "rectangle_count_mean"), 1),
                "Runtime ms": fmt(num(row, "runtime_ms_mean"), 1),
                "$C_{travel}$": fmt(num(row, "travel_mode_cost_mean"), 1),
                "Hard/Support": f"{fmt(num(row, 'hard_penalty_mean'), 2)}/{fmt(num(row, 'stability_penalty_mean'), 2)}",
            }
        )
    return output


def detour_rows(path: Path) -> list[dict[str, str]]:
    output = []
    for row in read_rows(path):
        output.append(
            {
                "Obstacles": row["obstacle_count"],
                "Repeats": row["repeats"],
                "Cold ms": fmt(num(row, "cold_ms_mean"), 4),
                "Cached ms": fmt(num(row, "cached_ms_mean"), 4),
                "Speedup": fmt(num(row, "cache_speedup"), 1),
                "Success": fmt(num(row, "success_rate"), 2),
            }
        )
    return output


def fusion_rows(path: Path) -> list[dict[str, str]]:
    output = []
    for index, row in enumerate(read_rows(path), start=1):
        output.append(
            {
                "Case": f"C{index}",
                "Board": row["board_id"],
                "Rect.": row["rectangles"],
                "Primitive": f"{row['fusion_primitive_full']}/{row['primitive_total']}",
                "Spans": f"{row['fusion_span_full']}/{row['span_total']}",
                "Unmapped": row["fusion_unmapped"],
                "Fusion support": fmt(num(row, "fusion_stability_penalty"), 1),
                "Proposed support": fmt(num(row, "proposed_stability_penalty"), 1),
            }
        )
    return output


def evidence_status_rows() -> list[dict[str, str]]:
    return [
        {
            "Evidence item": "Formal 77-record process-aware rerun",
            "Status": "complete",
            "Formal use": "main claim",
        },
        {
            "Evidence item": "Span-level geometric coverage audit",
            "Status": "complete: 308 routes, 0 issues",
            "Formal use": "main geometry validity",
        },
        {
            "Evidence item": "Prefix Beam MCTS rerun",
            "Status": "complete: 154 routes, 0 coverage issues",
            "Formal use": "search comparator",
        },
        {
            "Evidence item": "30 public 2DPackLib-derived layouts",
            "Status": "complete",
            "Formal use": "external geometry transfer",
        },
        {
            "Evidence item": "Parameter, weight, event-gate, exact-gap, scalability diagnostics",
            "Status": "complete under corrected model",
            "Formal use": "auxiliary robustness",
        },
        {
            "Evidence item": "Objective-order sweep",
            "Status": "excluded: no corrected runner in repository",
            "Formal use": "not used as evidence",
        },
        {
            "Evidence item": "Corrected NC/CAMotics/Fusion exports",
            "Status": "complete as auxiliary exportability/process-state audit",
            "Formal use": "not used as timing or commercial-CAM performance evidence",
        },
    ]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate corrected Stage-5 paper tables from formal rerun outputs.",
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=ROOT / "results" / "corrected_model_stage5_full_rerun" / "formal",
    )
    parser.add_argument(
        "--coverage-dir",
        type=Path,
        default=ROOT
        / "results"
        / "corrected_model_stage5_full_rerun"
        / "formal_span_coverage_audit"
        / "geometric_coverage_audit",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results" / "corrected_model_stage5_full_rerun" / "paper_tables",
    )
    parser.add_argument(
        "--fusion-summary",
        type=Path,
        default=ROOT
        / "results"
        / "corrected_model_stage5_full_rerun"
        / "fusion_manual_package_5case"
        / "fusion"
        / "fusion_nc_reference_audit_5case"
        / "fusion_5case_vs_proposed_summary.csv",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    results_dir = args.results_dir
    output_dir = args.output_dir
    written: list[Path] = []

    main_means = grouped_means(read_rows(results_dir / f"{RUN_ID}_main.csv"))
    written.append(
        write_table(
            method_rows(
                main_means,
                (
                    "topology_process_aware",
                    "process_local_search_multistart",
                    "process_aware_beam",
                    TARGET,
                ),
            ),
            output_dir,
            "table_stage5_main_method_summary",
            "Corrected process-aware comparison on 77 production-derived records.",
            "tab:stage5-main-method-summary",
        )
    )
    written.append(
        write_table(
            comparison_rows(
                (
                    results_dir / f"{RUN_ID}_main_statistical.csv",
                    results_dir / f"{RUN_ID}_prefix_mcts_baseline_statistical.csv",
                ),
                (
                    "topology_process_aware",
                    "process_local_search_multistart",
                    "process_aware_beam",
                    "process_aware_prefix_beam_mcts",
                ),
            ),
            output_dir,
            "table_stage5_process_search_comparison",
            "Corrected paired process-aware search comparisons; positive reductions mean the proposed method is lower.",
            "tab:stage5-process-search-comparison",
        )
    )
    written.append(
        write_table(
            method_rows(
                grouped_means(read_rows(results_dir / f"{RUN_ID}_external_baselines.csv")),
                (
                    "contour_tsp_2opt",
                    "contour_aco",
                    "endpoint_aware_gtsp",
                    TARGET,
                ),
                include_composite=True,
            ),
            output_dir,
            "table_stage5_external_contour_baseline",
            "Corrected independent-contour references on the 77 production-derived records.",
            "tab:stage5-external-contour-baseline",
        )
    )
    written.append(
        write_table(
            method_rows(
                grouped_means(read_rows(results_dir / f"{RUN_ID}_metaheuristics.csv")),
                (
                    TARGET,
                    "process_local_search_multistart",
                    "process_aware_sa",
                    "process_aware_ga",
                ),
            ),
            output_dir,
            "table_stage5_metaheuristic_baseline",
            "Corrected process-aware metaheuristic comparison on 77 production-derived records.",
            "tab:stage5-metaheuristic-baseline",
        )
    )
    written.append(
        write_table(
            coverage_rows(args.coverage_dir / "geometric_coverage_by_method.csv"),
            output_dir,
            "table_stage5_span_coverage_audit",
            "Corrected span-level geometric coverage audit for 77 records and four process-aware methods.",
            "tab:stage5-span-coverage-audit",
        )
    )
    written.append(
        write_table(
            public_rows(results_dir / f"{RUN_ID}_public_geometry_benchmark.csv"),
            output_dir,
            "table_stage5_public_geometry_benchmark",
            "Corrected 30-layout public 2DPackLib-derived geometry check.",
            "tab:stage5-public-geometry-benchmark",
        )
    )
    written.append(
        write_table(
            exact_rows(results_dir / f"{RUN_ID}_exact_gap_8_12.csv"),
            output_dir,
            "table_stage5_exact_gap_summary",
            "Corrected exact-gap check on deterministic dense layouts.",
            "tab:stage5-exact-gap-summary",
        )
    )
    written.append(
        write_table(
            event_gate_rows(results_dir / f"{RUN_ID}_event_gate_sensitivity_summary.csv"),
            output_dir,
            "table_stage5_event_gate_sensitivity",
            "Corrected event-gate sensitivity relative to ordinary process-aware beam search.",
            "tab:stage5-event-gate-sensitivity",
        )
    )
    written.append(
        write_table(
            weight_rows(results_dir / f"{RUN_ID}_weight_sensitivity_paired.csv"),
            output_dir,
            "table_stage5_weight_sensitivity",
            "Corrected travel-weight sensitivity against the external contour TSP+2-opt reference.",
            "tab:stage5-weight-sensitivity",
        )
    )
    written.append(
        write_table(
            parameter_rows(results_dir / f"{RUN_ID}_parameter_sensitivity_summary.csv"),
            output_dir,
            "table_stage5_parameter_sensitivity",
            "Corrected final-method parameter sensitivity on 77 production-derived records.",
            "tab:stage5-parameter-sensitivity",
        )
    )
    written.append(
        write_table(
            scalability_rows(results_dir / f"{RUN_ID}_scalability_summary.csv"),
            output_dir,
            "table_stage5_scalability_summary",
            "Corrected real-layout scalability bins under the formal process model.",
            "tab:stage5-scalability-summary",
        )
    )
    written.append(
        write_table(
            detour_rows(results_dir / f"{RUN_ID}_detour_cache_sensitivity.csv"),
            output_dir,
            "table_stage5_detour_cache_sensitivity",
            "Corrected detour-cache runtime sensitivity.",
            "tab:stage5-detour-cache-sensitivity",
        )
    )
    written.append(
        write_table(
            evidence_status_rows(),
            output_dir,
            "table_stage5_corrected_evidence_status",
            "Corrected evidence status after the span-level coverage model refresh.",
            "tab:stage5-corrected-evidence-status",
        )
    )
    if args.fusion_summary.exists():
        written.append(
            write_table(
                fusion_rows(args.fusion_summary),
                output_dir,
                "table_stage5_fusion_reference_check",
                "Auxiliary black-box Autodesk Fusion NC reference audit on five regenerated cases.",
                "tab:stage5-fusion-reference-check",
            )
        )

    index_lines = [
        "# Corrected Stage-5 Tables",
        "",
        f"Results directory: `{results_dir}`",
        f"Coverage directory: `{args.coverage_dir}`",
        f"Fusion auxiliary summary: `{args.fusion_summary}`",
        "",
    ]
    for path in written:
        index_lines.append(f"- `{path.name}` and `{path.with_suffix('.tex').name}`")
    (output_dir / "CORRECTED_STAGE5_TABLE_INDEX.md").write_text(
        "\n".join(index_lines) + "\n",
        encoding="utf-8",
    )
    print(f"tables_dir={output_dir}")
    for path in written:
        print(f"wrote: {path}")
        print(f"wrote: {path.with_suffix('.tex')}")


if __name__ == "__main__":
    main()
