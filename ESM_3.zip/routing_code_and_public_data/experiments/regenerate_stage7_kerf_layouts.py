from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import zipfile

from cnc_cutting.io import (
    PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
    load_chapter2_config_from_zip,
)
from cnc_cutting.kerf_packing import (
    KerfPackingPart,
    PackedBoard,
    pack_kerf_envelopes,
    select_formal_board,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA_ROOT = Path("<LOCAL_HOME>/Desktop/codex_handoff_20260502/data")
DEFAULT_METRICS = (
    ROOT
    / "results"
    / "corrected_model_stage6_process_key_rerun"
    / "formal"
    / "chapter3_formal_hard_gate25_main.csv"
)
DEFAULT_OUTPUT_DIR = ROOT / "results" / "corrected_model_stage7_kerf" / "kerf_layouts"
TARGET_METHOD = "process_aware_beam_adaptive_polished"
PACKING_ORDER_TOP_K = 3
MAX_PACKING_ATTEMPTS = 20


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Regenerate the formal fixed-layout cohort with tool-width packing envelopes."
    )
    parser.add_argument("--metrics", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--method", default=TARGET_METHOD)
    parser.add_argument("--minimum-parts", type=int, default=20)
    parser.add_argument("--maximum-parts", type=int, default=50)
    return parser.parse_args()


def _read_formal_records(path: Path, method: str) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        rows = [row for row in csv.DictReader(handle) if row.get("method") == method]
    unique: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in rows:
        key = (row["archive"], row["placements_member"], row["board_id"])
        unique[key] = row
    return [unique[key] for key in sorted(unique)]


def _read_all_placement_rows(
    archive_path: Path,
    placements_member: str,
) -> list[dict[str, str]]:
    with zipfile.ZipFile(archive_path) as archive:
        with archive.open(placements_member) as binary_handle:
            text_handle = io.TextIOWrapper(
                binary_handle,
                encoding="utf-8-sig",
                newline="",
            )
            return list(csv.DictReader(text_handle))


def _inventory(
    rows: list[dict[str, str]],
    tool_diameter: float,
) -> tuple[KerfPackingPart, ...]:
    parts: list[KerfPackingPart] = []
    seen_ids: set[str] = set()
    for index, row in enumerate(rows):
        part_id = str(row.get("uid") or row.get("pid_raw") or index + 1).strip()
        if part_id in seen_ids:
            raise ValueError(f"duplicate source part id: {part_id}")
        seen_ids.add(part_id)
        nominal_width = float(row["w0"])
        nominal_height = float(row["h0"])
        parts.append(
            KerfPackingPart(
                part_id=part_id,
                raw_part_id=str(row.get("pid_raw") or part_id),
                nominal_width=nominal_width,
                nominal_height=nominal_height,
                envelope_width=nominal_width + tool_diameter,
                envelope_height=nominal_height + tool_diameter,
            )
        )
    return tuple(parts)


def _placement_csv(boards: tuple[PackedBoard, ...]) -> str:
    handle = io.StringIO(newline="")
    writer = csv.writer(handle, lineterminator="\n")
    writer.writerow(
        ("board", "uid", "pid_raw", "x", "y", "w", "h", "w0", "h0", "rotated")
    )
    for board in boards:
        for packed in board.placed:
            writer.writerow(
                (
                    board.board_id,
                    packed.part.part_id,
                    packed.part.raw_part_id,
                    f"{packed.envelope.x:.9f}",
                    f"{packed.envelope.y:.9f}",
                    f"{packed.envelope.width:.9f}",
                    f"{packed.envelope.height:.9f}",
                    f"{packed.part.nominal_width:.9f}",
                    f"{packed.part.nominal_height:.9f}",
                    int(packed.rotated),
                )
            )
    return handle.getvalue()


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _inventory_sha256(parts: tuple[KerfPackingPart, ...]) -> str:
    payload = "\n".join(
        f"{part.part_id},{part.raw_part_id},{part.nominal_width:.9f},{part.nominal_height:.9f}"
        for part in sorted(parts, key=lambda item: item.part_id)
    )
    return _sha256(payload)


def _packing_order_seed(record: dict[str, str]) -> int:
    provenance = "|".join(
        (
            record["archive"],
            record["placements_member"],
            record["board_id"],
        )
    )
    return int(hashlib.sha256(provenance.encode("utf-8")).hexdigest()[:16], 16)


def _selected_layout_sha256(board: PackedBoard) -> str:
    payload = "\n".join(
        sorted(
            f"{packed.envelope.x:.9f},{packed.envelope.y:.9f},"
            f"{packed.envelope.width:.9f},{packed.envelope.height:.9f},{int(packed.rotated)}"
            for packed in board.placed
        )
    )
    return _sha256(payload)


def _write_manifest(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _write_summary(path: Path, manifest: list[dict[str, object]]) -> None:
    selected_counts = [int(row["selected_part_count"]) for row in manifest]
    source_counts = [int(row["source_part_count"]) for row in manifest]
    generated_board_counts = [int(row["generated_board_count"]) for row in manifest]
    path.write_text(
        "\n".join(
            (
                "# Stage 7 Kerf-Aware Layout Regeneration",
                "",
                "The source inventories are reconstructed from every placement member, then repacked with `BINARY_SPACING=False`, `GAP=6`, and a 6 mm tool-width envelope. Stored `w/h` values are packing envelopes; rotated `w0/h0` values remain the nominal finished dimensions.",
                "",
                "## Cohort",
                "",
                f"- Formal records: {len(manifest)}",
                f"- Source parts per record: {min(source_counts)}--{max(source_counts)}",
                f"- Generated boards per record: {min(generated_board_counts)}--{max(generated_board_counts)}",
                f"- Selected parts per record: {min(selected_counts)}--{max(selected_counts)}",
                f"- Total source parts retained: {sum(source_counts)}",
                f"- Total packed parts written: {sum(int(row['packed_part_count']) for row in manifest)}",
                "- Dropped source parts: 0",
                "",
                "Each record stores all regenerated boards in the archive. The manifest freezes one 20--50-part board using part count, nominal area, and board ID as deterministic selection keys.",
                "",
            )
        ),
        encoding="utf-8",
    )


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    archive_path = args.output_dir / "stage7_kerf_layouts.zip"
    records = _read_formal_records(args.metrics, args.method)
    if len(records) != 77:
        raise ValueError(f"expected 77 formal records, found {len(records)}")

    manifest: list[dict[str, object]] = []
    selected_layout_hashes: set[str] = set()
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as output:
        for index, record in enumerate(records, start=1):
            record_id = f"record_{index:03d}"
            source_archive = args.data_root / record["archive"]
            source_member = record["placements_member"]
            config = load_chapter2_config_from_zip(
                source_archive,
                placements_member=source_member,
            )
            tool_diameter = float(config.get("TOOL_D", 6.0))
            source_rows = _read_all_placement_rows(source_archive, source_member)
            parts = _inventory(source_rows, tool_diameter)
            base_packing_seed = _packing_order_seed(record)
            selected = None
            boards = None
            selected_layout_hash = ""
            packing_attempt = -1
            for attempt in range(MAX_PACKING_ATTEMPTS):
                candidate_boards = pack_kerf_envelopes(
                    parts,
                    panel_width=float(config["BOARD_W"]),
                    panel_height=float(config["BOARD_H"]),
                    trim=float(config.get("TRIM", 5.0)),
                    allow_rotation=True,
                    order_seed=base_packing_seed + attempt,
                    order_top_k=PACKING_ORDER_TOP_K,
                )
                try:
                    candidate_selected = select_formal_board(
                        candidate_boards,
                        minimum_parts=args.minimum_parts,
                        maximum_parts=args.maximum_parts,
                    )
                except ValueError:
                    continue
                candidate_hash = _selected_layout_sha256(candidate_selected)
                if candidate_hash in selected_layout_hashes:
                    continue
                boards = candidate_boards
                selected = candidate_selected
                selected_layout_hash = candidate_hash
                packing_attempt = attempt
                selected_layout_hashes.add(candidate_hash)
                break
            if boards is None or selected is None:
                raise ValueError(
                    f"failed to generate a unique formal layout for {record_id} "
                    f"within {MAX_PACKING_ATTEMPTS} deterministic attempts"
                )
            placement_text = _placement_csv(boards)
            member_prefix = f"stage7/{record_id}"
            placement_member = f"{member_prefix}/placements.csv"
            config_member = f"{member_prefix}/config_dump.json"
            corrected_config = {
                "cfg": {
                    "BOARD_W": float(config["BOARD_W"]),
                    "BOARD_H": float(config["BOARD_H"]),
                    "TRIM": float(config.get("TRIM", 5.0)),
                    "TOOL_D": tool_diameter,
                    "GAP": tool_diameter,
                    "SAFE_GAP": tool_diameter,
                    "BINARY_SPACING": False,
                    "ALLOW_ROT": True,
                    "PACKING_METHOD": "deterministic_maxrects_baf_bounded_size_rank_shuffle",
                    "PACKING_ORDER_SEED": base_packing_seed + packing_attempt,
                    "PACKING_ORDER_TOP_K": PACKING_ORDER_TOP_K,
                    "PACKING_ATTEMPT": packing_attempt,
                    "PLACEMENT_GEOMETRY_MODE": PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
                    "GEOMETRIC_KERF_COMPENSATION": True,
                },
                "provenance": {
                    "source_archive": record["archive"],
                    "source_placements_member": source_member,
                    "source_formal_board_id": record["board_id"],
                    "source_inventory_sha256": _inventory_sha256(parts),
                },
            }
            output.writestr(placement_member, placement_text)
            output.writestr(config_member, json.dumps(corrected_config, indent=2))
            packed_part_count = sum(len(board.placed) for board in boards)
            if packed_part_count != len(parts):
                raise AssertionError("kerf repacking dropped source parts")
            manifest.append(
                {
                    "record_id": record_id,
                    "source_archive": record["archive"],
                    "source_placements_member": source_member,
                    "source_formal_board_id": record["board_id"],
                    "source_part_count": len(parts),
                    "generated_board_count": len(boards),
                    "packed_part_count": packed_part_count,
                    "selected_board_id": selected.board_id,
                    "selected_part_count": len(selected.placed),
                    "selected_nominal_area_mm2": f"{sum(p.part.nominal_width * p.part.nominal_height for p in selected.placed):.6f}",
                    "packing_order_seed": base_packing_seed + packing_attempt,
                    "packing_order_top_k": PACKING_ORDER_TOP_K,
                    "packing_attempt": packing_attempt,
                    "selected_layout_sha256": selected_layout_hash,
                    "placements_member": placement_member,
                    "config_member": config_member,
                    "inventory_sha256": _inventory_sha256(parts),
                    "placements_sha256": _sha256(placement_text),
                }
            )

    unique_layout_count = len(
        {str(row["selected_layout_sha256"]) for row in manifest}
    )
    if unique_layout_count != len(manifest):
        raise AssertionError(
            f"selected layout signatures collapsed: {unique_layout_count}/{len(manifest)}"
        )

    manifest_path = args.output_dir / "stage7_kerf_layout_manifest.csv"
    _write_manifest(manifest_path, manifest)
    _write_summary(args.output_dir / "README.md", manifest)
    print(f"records={len(manifest)}")
    print(f"archive={archive_path}")
    print(f"manifest={manifest_path}")
    print(f"selected_parts={min(int(row['selected_part_count']) for row in manifest)}--{max(int(row['selected_part_count']) for row in manifest)}")
    print(f"unique_selected_layouts={unique_layout_count}")


if __name__ == "__main__":
    main()
