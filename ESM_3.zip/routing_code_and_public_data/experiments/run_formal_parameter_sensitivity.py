from __future__ import annotations

import argparse
import csv
import json
import platform
import subprocess
import sys
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from statistics import mean
from time import perf_counter
from types import SimpleNamespace

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.io import load_chapter2_config_from_zip, load_chapter2_layouts_from_zip
from cnc_cutting.io import tool_config_from_chapter2_config
from cnc_cutting.local_search import BeamSearchConfig
from cnc_cutting.models import Panel
from cnc_cutting.optimizer import (
    ToolEventGateConfig,
    plan_process_aware_beam_adaptive_polished_route,
    wider_beam_search_config,
)
from process_options import build_process_model_from_args
from run_chapter2_batch import (
    board_counts_from_zip,
    compact_beam_search_config,
    compact_local_search_config,
    parse_member_metadata,
    sample_placement_members,
    select_board_ids,
    topology_pool_size,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BEAM_WIDTHS = (3, 6, 9, 12)
DEFAULT_CANDIDATE_CAPS = (8, 18, 32, 48)
DEFAULT_SUPPORT_RATIOS = (0.50, 0.65, 0.75, 0.85)
DEFAULT_SAFE_LIFT_COSTS = (100.0, 250.0, 500.0, 1000.0)


@dataclass(frozen=True)
class ParameterSensitivityRow:
    family: str
    setting: str
    setting_value: float
    archive: str
    case_name: str
    placement_method: str
    seed: str
    placements_member: str
    board_id: str
    rectangle_count: int
    support_policy: str
    min_support_count: int
    min_support_ratio: float
    min_area_normalized_support: float
    adjacency_support_weight: float
    safe_lift_fixed_cost: float
    beam_width: int
    beam_candidate_pool_size: int | None
    beam_max_expansions_per_node: int | None
    beam_max_layer_expansions: int | None
    runtime_ms: float
    candidate_unit_count: int
    selected_unit_count: int
    action_count: int
    composite_planning_cost: float
    cutting_length: float
    travel_mode_cost: float
    air_move_distance: float
    hard_penalty: float
    support_rule_penalty: float
    repeated_segments: int
    repeated_length: float
    redundant_actions: int
    tool_events: int
    safe_lift_count: int
    detour_count: int


@dataclass(frozen=True)
class ParameterSensitivitySummaryRow:
    family: str
    setting: str
    setting_value: float
    n: int
    composite_planning_cost_mean: float
    travel_mode_cost_mean: float
    hard_penalty_mean: float
    support_rule_penalty_mean: float
    repeated_segments_mean: float
    repeated_length_mean: float
    tool_events_mean: float
    safe_lift_count_mean: float
    detour_count_mean: float
    runtime_ms_mean: float


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unknown"


def git_dirty() -> bool:
    try:
        output = subprocess.check_output(
            ["git", "status", "--porcelain"],
            cwd=ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return bool(output.strip())
    except Exception:
        return True


def write_dataclass_rows(rows: tuple, output_path: Path) -> None:
    if not rows:
        raise ValueError(f"no rows to write: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def support_args(
    *,
    min_support_ratio: float,
) -> SimpleNamespace:
    return SimpleNamespace(
        support_policy="all_edges",
        min_support_count=1,
        min_support_ratio=min_support_ratio,
        min_area_normalized_support=0.0,
        adjacency_support_weight=1.0,
    )


def sensitivity_cases(
    archives: tuple[Path, ...],
    *,
    max_members_per_archive: int,
    boards_per_member: int,
    min_rectangles: int,
    max_rectangles: int,
) -> tuple[tuple[Path, str, str], ...]:
    cases: list[tuple[Path, str, str]] = []
    for archive in archives:
        for member in sample_placement_members(archive, max_members_per_archive):
            counts = board_counts_from_zip(archive, member)
            for board_id in select_board_ids(
                counts,
                boards_per_member=boards_per_member,
                min_rectangles=min_rectangles,
                max_rectangles=max_rectangles,
            ):
                cases.append((archive, member, board_id))
    return tuple(cases)


def beam_config_for(
    *,
    size: int,
    beam_width: int | None = None,
    candidate_pool_size: int | None = None,
) -> BeamSearchConfig:
    base = compact_beam_search_config(size, repeat_cut_policy="hard")
    width = base.beam_width if beam_width is None else beam_width
    cap = base.candidate_pool_size if candidate_pool_size is None else candidate_pool_size
    layer_ratio = (
        base.max_layer_expansions / base.beam_width
        if base.max_layer_expansions is not None and base.beam_width > 0
        else 7.0
    )
    per_node_ratio = (
        base.max_expansions_per_node / base.candidate_pool_size
        if base.max_expansions_per_node is not None
        and base.candidate_pool_size is not None
        and base.candidate_pool_size > 0
        else 2.0
    )
    return replace(
        base,
        beam_width=width,
        candidate_pool_size=cap,
        max_layer_expansions=max(width, int(round(width * layer_ratio))),
        max_expansions_per_node=(
            None if cap is None else max(cap, int(round(cap * per_node_ratio)))
        ),
    )


def run_variant(
    *,
    family: str,
    setting: str,
    setting_value: float,
    archive: Path,
    placements_member: str,
    board_id: str,
    layout,
    panel: Panel,
    base_tool,
    units,
    support_ratio: float,
    safe_lift_fixed_cost: float,
    beam_width: int | None,
    candidate_pool_size: int | None,
) -> ParameterSensitivityRow:
    size = len(layout.rectangles)
    tool = replace(base_tool, safe_lift_fixed_cost=safe_lift_fixed_cost)
    process_args = support_args(min_support_ratio=support_ratio)
    process_model = build_process_model_from_args(layout, process_args)
    beam_config = beam_config_for(
        size=size,
        beam_width=beam_width,
        candidate_pool_size=candidate_pool_size,
    )
    fallback_config = wider_beam_search_config(beam_config)
    polish_config = compact_local_search_config(size, True, repeat_cut_policy="hard")
    gate = ToolEventGateConfig(
        enabled=True,
        min_travel_saving_per_extra_event=25.0,
        min_travel_saving_ratio_per_extra_event=0.0,
        min_machining_saving=1e-9,
    )

    start = perf_counter()
    plan = plan_process_aware_beam_adaptive_polished_route(
        units,
        panel,
        tool,
        beam_config=beam_config,
        fallback_beam_config=fallback_config,
        polish_config=polish_config,
        topology_candidate_pool_size=topology_pool_size(size),
        process_model=process_model,
        tool_event_gate=gate,
        repeat_cut_policy="hard",
    )
    runtime_ms = (perf_counter() - start) * 1000.0
    case_name, placement_method, seed = parse_member_metadata(placements_member)
    metrics = plan.metrics
    return ParameterSensitivityRow(
        family=family,
        setting=setting,
        setting_value=setting_value,
        archive=archive.name,
        case_name=case_name,
        placement_method=placement_method,
        seed=seed,
        placements_member=placements_member,
        board_id=board_id,
        rectangle_count=size,
        support_policy=process_args.support_policy,
        min_support_count=process_args.min_support_count,
        min_support_ratio=process_args.min_support_ratio,
        min_area_normalized_support=process_args.min_area_normalized_support,
        adjacency_support_weight=process_args.adjacency_support_weight,
        safe_lift_fixed_cost=tool.safe_lift_fixed_cost,
        beam_width=beam_config.beam_width,
        beam_candidate_pool_size=beam_config.candidate_pool_size,
        beam_max_expansions_per_node=beam_config.max_expansions_per_node,
        beam_max_layer_expansions=beam_config.max_layer_expansions,
        runtime_ms=runtime_ms,
        candidate_unit_count=len(units),
        selected_unit_count=len(plan.selected_units),
        action_count=len(plan.actions),
        composite_planning_cost=metrics.cutting_length + metrics.travel_mode_cost,
        cutting_length=metrics.cutting_length,
        travel_mode_cost=metrics.travel_mode_cost,
        air_move_distance=metrics.air_move_distance,
        hard_penalty=metrics.hard_penalty,
        support_rule_penalty=metrics.stability_penalty,
        repeated_segments=metrics.repeated_cut_segment_count,
        repeated_length=metrics.repeated_cut_length,
        redundant_actions=metrics.redundant_cut_action_count,
        tool_events=metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
        safe_lift_count=metrics.safe_lift_count,
        detour_count=metrics.detour_count,
    )


def summarize(rows: tuple[ParameterSensitivityRow, ...]) -> tuple[ParameterSensitivitySummaryRow, ...]:
    groups: dict[tuple[str, str, float], list[ParameterSensitivityRow]] = {}
    for row in rows:
        groups.setdefault((row.family, row.setting, row.setting_value), []).append(row)
    summary: list[ParameterSensitivitySummaryRow] = []
    family_order = {"beam_width": 0, "candidate_cap": 1, "support_ratio": 2, "safe_lift_cost": 3}
    for (family, setting, value), items in sorted(
        groups.items(), key=lambda item: (family_order.get(item[0][0], 99), item[0][2])
    ):
        summary.append(
            ParameterSensitivitySummaryRow(
                family=family,
                setting=setting,
                setting_value=value,
                n=len(items),
                composite_planning_cost_mean=mean(row.composite_planning_cost for row in items),
                travel_mode_cost_mean=mean(row.travel_mode_cost for row in items),
                hard_penalty_mean=mean(row.hard_penalty for row in items),
                support_rule_penalty_mean=mean(row.support_rule_penalty for row in items),
                repeated_segments_mean=mean(row.repeated_segments for row in items),
                repeated_length_mean=mean(row.repeated_length for row in items),
                tool_events_mean=mean(row.tool_events for row in items),
                safe_lift_count_mean=mean(row.safe_lift_count for row in items),
                detour_count_mean=mean(row.detour_count for row in items),
                runtime_ms_mean=mean(row.runtime_ms for row in items),
            )
        )
    return tuple(summary)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=55)
    parser.add_argument("--boards-per-member", type=int, default=1)
    parser.add_argument("--min-rectangles", type=int, default=20)
    parser.add_argument("--max-rectangles", type=int, default=50)
    parser.add_argument("--beam-widths", nargs="+", type=int, default=list(DEFAULT_BEAM_WIDTHS))
    parser.add_argument(
        "--candidate-caps",
        nargs="+",
        type=int,
        default=list(DEFAULT_CANDIDATE_CAPS),
    )
    parser.add_argument(
        "--support-ratios",
        nargs="+",
        type=float,
        default=list(DEFAULT_SUPPORT_RATIOS),
    )
    parser.add_argument(
        "--safe-lift-costs",
        nargs="+",
        type=float,
        default=list(DEFAULT_SAFE_LIFT_COSTS),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results" / "formal" / "chapter3_formal_hard_gate25_parameter_sensitivity.csv",
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=ROOT
        / "results"
        / "formal"
        / "chapter3_formal_hard_gate25_parameter_sensitivity_summary.csv",
    )
    parser.add_argument(
        "--manifest-output",
        type=Path,
        default=ROOT
        / "results"
        / "formal"
        / "chapter3_formal_hard_gate25_parameter_sensitivity_manifest.json",
    )
    parser.add_argument("--progress-every", type=int, default=25)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    archives = tuple(args.zip_paths or ())
    if not archives:
        raise ValueError("at least one --zip-path is required")
    cases = sensitivity_cases(
        archives,
        max_members_per_archive=args.max_members_per_archive,
        boards_per_member=args.boards_per_member,
        min_rectangles=args.min_rectangles,
        max_rectangles=args.max_rectangles,
    )
    if not cases:
        raise ValueError("no sensitivity cases produced; relax filters")

    variants: list[tuple[str, str, float, float, float, int | None, int | None]] = []
    for value in args.beam_widths:
        variants.append(("beam_width", f"beam={value}", float(value), 0.75, 250.0, value, None))
    for value in args.candidate_caps:
        variants.append(("candidate_cap", f"cap={value}", float(value), 0.75, 250.0, None, value))
    for value in args.support_ratios:
        variants.append(("support_ratio", f"rho={value:g}", float(value), value, 250.0, None, None))
    for value in args.safe_lift_costs:
        variants.append(("safe_lift_cost", f"lift={value:g}", float(value), 0.75, value, None, None))

    total_runs = len(cases) * len(variants)
    print(f"cases={len(cases)} variants={len(variants)} total_runs={total_runs}", flush=True)
    rows: list[ParameterSensitivityRow] = []
    completed = 0
    start_all = perf_counter()
    for archive, member, board_id in cases:
        cfg = load_chapter2_config_from_zip(archive, placements_member=member)
        base_tool = tool_config_from_chapter2_config(cfg)
        layout = load_chapter2_layouts_from_zip(
            archive,
            placements_member=member,
            board_ids=(board_id,),
        )[0]
        panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
        units = build_candidate_cutting_units(
            layout,
            base_tool,
            max_collinear_gap=base_tool.min_channel_width,
        )
        for family, setting, value, support_ratio, safe_lift, beam_width, cap in variants:
            rows.append(
                run_variant(
                    family=family,
                    setting=setting,
                    setting_value=value,
                    archive=archive,
                    placements_member=member,
                    board_id=board_id,
                    layout=layout,
                    panel=panel,
                    base_tool=base_tool,
                    units=units,
                    support_ratio=support_ratio,
                    safe_lift_fixed_cost=safe_lift,
                    beam_width=beam_width,
                    candidate_pool_size=cap,
                )
            )
            completed += 1
            if completed % args.progress_every == 0 or completed == total_runs:
                elapsed = perf_counter() - start_all
                print(
                    f"completed={completed}/{total_runs} elapsed={elapsed:.1f}s",
                    flush=True,
                )

    result_rows = tuple(rows)
    summary_rows = summarize(result_rows)
    write_dataclass_rows(result_rows, args.output)
    write_dataclass_rows(summary_rows, args.summary_output)
    args.manifest_output.parent.mkdir(parents=True, exist_ok=True)
    args.manifest_output.write_text(
        json.dumps(
            {
                "command": sys.argv,
                "python": sys.version,
                "platform": platform.platform(),
                "git_commit": git_commit(),
                "dirty": git_dirty(),
                "archives": [str(path) for path in archives],
                "cases": len(cases),
                "variants": len(variants),
                "output": str(args.output),
                "summary_output": str(args.summary_output),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"wrote: {args.output}")
    print(f"wrote: {args.summary_output}")
    print(f"wrote: {args.manifest_output}")


if __name__ == "__main__":
    main()
