from __future__ import annotations

import argparse
import csv
from pathlib import Path
from statistics import mean

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
FORMAL = ROOT / "results" / "corrected_model_stage7_kerf" / "formal"
BLUE = "#0072B2"
ORANGE = "#E69F00"
GREEN = "#009E73"


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def record_key(row: dict[str, str]) -> tuple[str, str]:
    return row["placements_member"], row["board_id"]


def planning_cost(row: dict[str, str]) -> float:
    return float(row["cutting_length"]) + float(row["travel_mode_cost"])


def method_rows(rows: list[dict[str, str]], method: str) -> list[dict[str, str]]:
    return [row for row in rows if row["method"] == method]


def paired_reduction(
    reference: list[dict[str, str]],
    candidate: list[dict[str, str]],
    field,
) -> float:
    first = {record_key(row): row for row in reference}
    second = {record_key(row): row for row in candidate}
    values = []
    for key in sorted(set(first) & set(second)):
        baseline = field(first[key])
        value = field(second[key])
        values.append(100.0 * (baseline - value) / baseline)
    return mean(values)


def changed_routes(
    reference: list[dict[str, str]], candidate: list[dict[str, str]]
) -> int:
    first = {record_key(row): row for row in reference}
    second = {record_key(row): row for row in candidate}
    return sum(
        abs(planning_cost(first[key]) - planning_cost(second[key])) > 1e-9
        or first[key]["process_repeated_span_count"]
        != second[key]["process_repeated_span_count"]
        for key in set(first) & set(second)
    )


def build_rows(args: argparse.Namespace) -> list[dict[str, object]]:
    main = read_rows(args.main_input)
    topology = method_rows(main, "topology_process_aware")
    beam = method_rows(main, "process_aware_beam")
    proposed = method_rows(main, "process_aware_beam_adaptive_polished")
    polished = read_rows(args.beam_polished_input)

    rows: list[dict[str, object]] = []
    for label, values in (
        ("Topology", topology),
        ("Beam", beam),
        ("Beam+LS", polished),
        ("Adaptive", proposed),
    ):
        rows.append(
            {
                "panel": "search",
                "setting": label,
                "cplan_reduction_pct": paired_reduction(
                    topology, values, planning_cost
                ),
                "travel_reduction_pct": paired_reduction(
                    topology, values, lambda row: float(row["travel_mode_cost"])
                ),
            }
        )

    for label, path in (
        ("Disabled", args.gate_off_input),
        ("Current 25", args.main_input),
        ("Conservative", args.gate_conservative_input),
    ):
        values = read_rows(path)
        values = method_rows(values, "process_aware_beam_adaptive_polished")
        rows.append(
            {
                "panel": "gate",
                "setting": label,
                "cplan_reduction_pct": paired_reduction(
                    beam, values, planning_cost
                ),
                "travel_reduction_pct": paired_reduction(
                    beam, values, lambda row: float(row["travel_mode_cost"])
                ),
                "routes_changed_vs_current": changed_routes(proposed, values),
            }
        )

    for label, path in (
        ("Hard", args.main_input),
        ("Soft", args.repeat_soft_input),
        ("Off", args.repeat_off_input),
    ):
        values = method_rows(
            read_rows(path), "process_aware_beam_adaptive_polished"
        )
        rows.append(
            {
                "panel": "repeat",
                "setting": label,
                "repeated_spans_mean": mean(
                    float(row["process_repeated_span_count"]) for row in values
                ),
                "cplan_mean": mean(planning_cost(row) for row in values),
                "routes_changed_vs_hard": changed_routes(proposed, values),
            }
        )
    return rows


def write_rows(rows: list[dict[str, object]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({field for row in rows for field in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def label_bars(ax, bars, digits: int = 2) -> None:
    for bar in bars:
        value = bar.get_height()
        ax.annotate(
            f"{value:.{digits}f}",
            (bar.get_x() + bar.get_width() / 2.0, value),
            xytext=(0, 3),
            textcoords="offset points",
            ha="center",
            fontsize=6.5,
        )


def plot(rows: list[dict[str, object]], path: Path) -> None:
    plt.rcParams.update({"font.family": "serif", "font.size": 8})
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.45), dpi=300)
    width = 0.36

    search = [row for row in rows if row["panel"] == "search"]
    x = list(range(len(search)))
    bars_a = axes[0].bar(
        [value - width / 2 for value in x],
        [float(row["cplan_reduction_pct"]) for row in search],
        width,
        color=BLUE,
        label=r"$C_{plan}$",
    )
    bars_b = axes[0].bar(
        [value + width / 2 for value in x],
        [float(row["travel_reduction_pct"]) for row in search],
        width,
        color=ORANGE,
        label="Travel",
    )
    label_bars(axes[0], bars_a)
    label_bars(axes[0], bars_b)
    axes[0].set_xticks(x, [str(row["setting"]) for row in search], rotation=20)
    axes[0].set_ylabel("Paired reduction vs topology (%)")
    axes[0].set_ylim(0, 16)
    axes[0].set_title("A  Search allocation", loc="left", fontweight="bold")
    axes[0].legend(frameon=False, loc="upper left")

    gates = [row for row in rows if row["panel"] == "gate"]
    x = list(range(len(gates)))
    bars_a = axes[1].bar(
        [value - width / 2 for value in x],
        [float(row["cplan_reduction_pct"]) for row in gates],
        width,
        color=BLUE,
    )
    bars_b = axes[1].bar(
        [value + width / 2 for value in x],
        [float(row["travel_reduction_pct"]) for row in gates],
        width,
        color=ORANGE,
    )
    label_bars(axes[1], bars_a)
    label_bars(axes[1], bars_b)
    axes[1].set_xticks(x, [str(row["setting"]) for row in gates], rotation=15)
    axes[1].set_ylabel("Paired reduction vs beam (%)")
    axes[1].set_ylim(0, 6.5)
    axes[1].set_title("B  Gate safeguard", loc="left", fontweight="bold")

    repeat = [row for row in rows if row["panel"] == "repeat"]
    x = list(range(len(repeat)))
    bars = axes[2].bar(
        x,
        [float(row["repeated_spans_mean"]) for row in repeat],
        0.55,
        color=GREEN,
    )
    label_bars(axes[2], bars, digits=1)
    axes[2].set_xticks(x, [str(row["setting"]) for row in repeat])
    axes[2].set_ylabel("Repeated spans (mean)")
    axes[2].set_ylim(0, 1.0)
    axes[2].set_title("C  Repeat policy", loc="left", fontweight="bold")

    for ax in axes:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", color="#D1D5DB", linewidth=0.5, alpha=0.6)
        ax.set_axisbelow(True)
    fig.tight_layout(w_pad=1.1)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight")
    fig.savefig(path.with_suffix(".png"), bbox_inches="tight")
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--main-input", type=Path, default=FORMAL / "chapter3_stage7_main.csv")
    parser.add_argument("--beam-polished-input", type=Path, default=FORMAL / "chapter3_stage7_ablation_beam_polished.csv")
    parser.add_argument("--gate-off-input", type=Path, default=FORMAL / "chapter3_stage7_ablation_gate_off.csv")
    parser.add_argument("--gate-conservative-input", type=Path, default=FORMAL / "chapter3_stage7_ablation_gate_conservative.csv")
    parser.add_argument("--repeat-soft-input", type=Path, default=FORMAL / "chapter3_stage7_ablation_repeat_soft.csv")
    parser.add_argument("--repeat-off-input", type=Path, default=FORMAL / "chapter3_stage7_ablation_repeat_off.csv")
    parser.add_argument("--figure-output", type=Path, default=ROOT / "figures" / "corrected_model_stage7_kerf" / "fig_ablation_effects.pdf")
    parser.add_argument("--summary-output", type=Path, default=ROOT / "results" / "corrected_model_stage7_kerf" / "paper_tables" / "stage7_ablation_figure_metrics.csv")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = build_rows(args)
    write_rows(rows, args.summary_output)
    plot(rows, args.figure_output)
    print(f"summary: {args.summary_output}")
    print(f"figure: {args.figure_output}")


if __name__ == "__main__":
    main()
