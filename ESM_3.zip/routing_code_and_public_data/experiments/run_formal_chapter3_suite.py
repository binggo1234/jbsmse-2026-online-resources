from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from chapter3_formal_config import (
    FORMAL_EXTERNAL_METHODS,
    FORMAL_MAIN_METHODS,
    FORMAL_METAHEURISTIC_METHODS,
    FORMAL_OUTPUT_STEMS,
    FORMAL_RANDOM_SEED,
    FORMAL_RUN_ID,
    FORMAL_SCALABILITY_METHODS,
    FORMAL_TARGET_METHOD,
    FORMAL_TIMEOUTS_SECONDS,
    FormalSuiteConfig,
    archive_args,
    formal_layout_args,
    formal_process_args,
)
from experiment_manifest import write_experiment_manifest


ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class FormalCommand:
    name: str
    command: tuple[str, ...]
    expected_outputs: tuple[Path, ...]
    notes: str = ""


def python_command(script_name: str, *args: str) -> tuple[str, ...]:
    return (sys.executable, str(ROOT / "experiments" / script_name), *args)


def common_batch_args(
    config: FormalSuiteConfig,
    timeout_key: str,
    *,
    output_stem: str,
    methods: Iterable[str],
) -> tuple[str, ...]:
    return (
        "--results-dir",
        str(config.results_dir),
        "--output-stem",
        output_stem,
        *archive_args(config.archives),
        *formal_layout_args(config),
        "--task-timeout-seconds",
        f"{FORMAL_TIMEOUTS_SECONDS[timeout_key]:g}",
        *formal_process_args(),
        "--methods",
        *tuple(methods),
        "--target-method",
        FORMAL_TARGET_METHOD,
        "--bootstrap-samples",
        str(config.bootstrap_samples),
        "--bootstrap-seed",
        str(config.bootstrap_seed),
    )


def csv_outputs(config: FormalSuiteConfig, stem: str) -> tuple[Path, ...]:
    base = config.results_dir / stem
    return (
        base.with_suffix(".csv"),
        base.with_name(f"{base.name}_summary.csv"),
        base.with_name(f"{base.name}_manifest.json"),
    )


def default_suite_manifest_path(config: FormalSuiteConfig) -> Path:
    return config.results_dir / f"{config.run_id}_suite_manifest.json"


def build_formal_commands(
    config: FormalSuiteConfig,
    *,
    fresh: bool = False,
) -> tuple[FormalCommand, ...]:
    commands: list[FormalCommand] = []
    fresh_arg = ("--fresh",) if fresh else ()
    resume_arg = () if fresh else ("--resume",)

    main_stem = FORMAL_OUTPUT_STEMS["main"]
    commands.append(
        FormalCommand(
            "main",
            python_command(
                "run_final_chapter3_main.py",
                *common_batch_args(
                    config,
                    "main",
                    output_stem=main_stem,
                    methods=FORMAL_MAIN_METHODS,
                ),
                *fresh_arg,
            ),
            csv_outputs(config, main_stem),
            "Main process-aware comparison.",
        )
    )

    external_stem = FORMAL_OUTPUT_STEMS["external"]
    commands.append(
        FormalCommand(
            "external",
            python_command(
                "run_final_chapter3_external_baselines.py",
                *common_batch_args(
                    config,
                    "external",
                    output_stem=external_stem,
                    methods=FORMAL_EXTERNAL_METHODS,
                ),
                "--no-progress-bar",
                *resume_arg,
            ),
            csv_outputs(config, external_stem),
            "Classical contour-centroid and process-aware external baselines.",
        )
    )

    meta_stem = FORMAL_OUTPUT_STEMS["metaheuristic"]
    commands.append(
        FormalCommand(
            "metaheuristic",
            python_command(
                "run_meta_heuristic_sa.py",
                *common_batch_args(
                    config,
                    "metaheuristic",
                    output_stem=meta_stem,
                    methods=FORMAL_METAHEURISTIC_METHODS,
                ),
                "--no-progress-bar",
                *resume_arg,
            ),
            csv_outputs(config, meta_stem),
            "Apples-to-apples process-aware SA/GA/LS baselines.",
        )
    )

    ablation_prefix = FORMAL_OUTPUT_STEMS["ablation"]
    commands.append(
        FormalCommand(
            "ablation",
            python_command(
                "run_final_chapter3_ablations.py",
                "--results-dir",
                str(config.results_dir),
                "--output-prefix",
                ablation_prefix,
                *archive_args(config.archives),
                *formal_layout_args(config),
                "--task-timeout-seconds",
                f"{FORMAL_TIMEOUTS_SECONDS['ablation']:g}",
                "--bootstrap-samples",
                str(config.bootstrap_samples),
                "--bootstrap-seed",
                str(config.bootstrap_seed),
                *fresh_arg,
            ),
            (config.results_dir / f"{ablation_prefix}_search_components_hard_gate25.csv",),
            "Repeat-cut, event-gate, and search-component ablations.",
        )
    )

    weight_stem = FORMAL_OUTPUT_STEMS["weight"]
    commands.append(
        FormalCommand(
            "weight",
            python_command(
                "run_weight_sensitivity.py",
                *archive_args(config.archives),
                *formal_layout_args(config),
                "--task-timeout-seconds",
                f"{FORMAL_TIMEOUTS_SECONDS['weight']:g}",
                "--travel-cost-scales",
                "0.5",
                "1",
                "2",
                "--safe-lift-fixed-costs",
                "250",
                "--output",
                str(config.results_dir / f"{weight_stem}.csv"),
                "--summary-output",
                str(config.results_dir / f"{weight_stem}_summary.csv"),
                "--paired-output",
                str(config.results_dir / f"{weight_stem}_paired.csv"),
                "--manifest-output",
                str(config.results_dir / f"{weight_stem}_manifest.json"),
                "--progress-output",
                str(config.results_dir / f"{weight_stem}_progress.csv"),
                *formal_process_args(),
                "--no-progress-bar",
                *resume_arg,
            ),
            (
                config.results_dir / f"{weight_stem}.csv",
                config.results_dir / f"{weight_stem}_summary.csv",
                config.results_dir / f"{weight_stem}_manifest.json",
            ),
            "Weight sensitivity under the same paper-main process model.",
        )
    )

    event_stem = FORMAL_OUTPUT_STEMS["event_gate"]
    commands.append(
        FormalCommand(
            "event_gate",
            python_command(
                "run_tool_event_gate_sensitivity.py",
                *archive_args(config.archives),
                *formal_layout_args(config),
                "--task-timeout-seconds",
                f"{FORMAL_TIMEOUTS_SECONDS['event_gate']:g}",
                "--output",
                str(config.results_dir / f"{event_stem}.csv"),
                "--summary-output",
                str(config.results_dir / f"{event_stem}_summary.csv"),
                "--increase-output",
                str(config.results_dir / f"{event_stem}_increase_cases.csv"),
                "--decision-output",
                str(config.results_dir / f"{event_stem}_decisions.csv"),
                "--figure-dir",
                str(config.figure_dir / event_stem),
                "--progress-output",
                str(config.results_dir / f"{event_stem}_progress.csv"),
                "--experiment-preset",
                "paper-main",
                "--no-progress-bar",
                *resume_arg,
            ),
            (
                config.results_dir / f"{event_stem}.csv",
                config.results_dir / f"{event_stem}_summary.csv",
                config.results_dir / f"{event_stem}_decisions.csv",
            ),
            "Event-gate decision-boundary and candidate acceptance analysis.",
        )
    )

    exact_stem = FORMAL_OUTPUT_STEMS["exact_gap"]
    commands.append(
        FormalCommand(
            "exact_gap",
            python_command(
                "run_certified_exact_gap.py",
                "--instance-source",
                "structured",
                "--min-rectangles",
                "8",
                "--max-rectangles",
                "12",
                "--timeout-seconds",
                "30",
                "--static-lower-bound-timeout-seconds",
                "60",
                "--output",
                str(config.results_dir / f"{exact_stem}.csv"),
                "--summary-output",
                str(config.results_dir / f"{exact_stem}_summary.csv"),
                "--manifest-output",
                str(config.results_dir / f"{exact_stem}_manifest.json"),
                *formal_process_args(),
            ),
            (
                config.results_dir / f"{exact_stem}.csv",
                config.results_dir / f"{exact_stem}_summary.csv",
                config.results_dir / f"{exact_stem}_manifest.json",
            ),
            "Certified 8-12 rectangle exact-gap analysis.",
        )
    )

    scalability_stem = FORMAL_OUTPUT_STEMS["scalability"]
    commands.append(
        FormalCommand(
            "scalability",
            python_command(
                "run_final_chapter3_scalability.py",
                "--results-dir",
                str(config.results_dir),
                "--output-stem",
                scalability_stem,
                *archive_args(config.archives),
                "--max-members-per-archive",
                str(config.max_members_per_archive),
                "--max-boards-per-bin",
                "20",
                "--methods",
                *FORMAL_SCALABILITY_METHODS,
                "--task-timeout-seconds",
                f"{FORMAL_TIMEOUTS_SECONDS['scalability']:g}",
                *formal_process_args(),
                *fresh_arg,
            ),
            csv_outputs(config, scalability_stem),
            "Real-layout scalability bins.",
        )
    )

    detour_stem = FORMAL_OUTPUT_STEMS["detour_cache"]
    commands.append(
        FormalCommand(
            "detour_cache",
            python_command(
                "run_detour_cache_sensitivity.py",
                "--output-csv",
                str(config.results_dir / f"{detour_stem}.csv"),
                "--repeats",
                "5",
                "--obstacle-counts",
                "1",
                "4",
                "9",
                "16",
                "25",
                "36",
                "49",
                "64",
            ),
            (config.results_dir / f"{detour_stem}.csv",),
            "Synthetic detour/cache runtime sensitivity.",
        )
    )

    return tuple(commands)


def command_env() -> dict[str, str]:
    env = os.environ.copy()
    src_path = str(ROOT / "src")
    experiments_path = str(ROOT / "experiments")
    existing = env.get("PYTHONPATH", "")
    prefix = os.pathsep.join((src_path, experiments_path))
    env["PYTHONPATH"] = prefix if not existing else f"{prefix}{os.pathsep}{existing}"
    return env


def run_command(command: FormalCommand, *, dry_run: bool) -> None:
    print(f"\n[{command.name}] {command.notes}")
    print(shlex.join(command.command), flush=True)
    if dry_run:
        return
    subprocess.run(command.command, cwd=ROOT, env=command_env(), check=True)


def repository_is_dirty() -> bool:
    result = subprocess.run(
        ("git", "status", "--porcelain"),
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    return bool(result.stdout.strip())


def write_suite_manifest(
    path: Path,
    *,
    config: FormalSuiteConfig,
    args: argparse.Namespace,
    commands: tuple[FormalCommand, ...],
) -> None:
    expected_outputs = tuple(
        output for command in commands for output in command.expected_outputs
    )
    write_experiment_manifest(
        path,
        experiment_name="chapter3_formal_suite",
        args=args,
        archives=config.archives,
        outputs=expected_outputs,
        root=ROOT,
        extra={
            "formal_run_id": config.run_id,
            "command_count": len(commands),
            "commands": [
                {
                    "name": command.name,
                    "notes": command.notes,
                    "command": list(command.command),
                    "expected_outputs": [str(path) for path in command.expected_outputs],
                }
                for command in commands
            ],
        },
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run or dry-run the frozen Chapter 3 formal experiment suite.",
    )
    parser.add_argument(
        "--suite",
        nargs="+",
        choices=(
            "all",
            "main",
            "external",
            "metaheuristic",
            "ablation",
            "weight",
            "event_gate",
            "exact_gap",
            "scalability",
            "detour",
            "detour_cache",
        ),
        default=("all",),
    )
    parser.add_argument(
        "--tasks",
        nargs="+",
        choices=(
            "all",
            "main",
            "external",
            "metaheuristic",
            "ablation",
            "weight",
            "event_gate",
            "exact_gap",
            "scalability",
            "detour",
            "detour_cache",
        ),
        help="Alias for --suite; provided for the formal optimization plan wording.",
    )
    parser.add_argument("--results-dir", type=Path, default=None)
    parser.add_argument("--figure-dir", type=Path, default=None)
    parser.add_argument("--suite-manifest-output", type=Path, default=None)
    parser.add_argument("--fresh", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--skip-suite-manifest", action="store_true")
    parser.add_argument(
        "--require-clean",
        action="store_true",
        help="Abort before execution if the git worktree is dirty.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    default_config = FormalSuiteConfig()
    config = FormalSuiteConfig(
        results_dir=args.results_dir or default_config.results_dir,
        figure_dir=args.figure_dir or default_config.figure_dir,
    )
    selected = set(args.tasks or args.suite)
    if "detour" in selected:
        selected.remove("detour")
        selected.add("detour_cache")
    commands = build_formal_commands(config, fresh=args.fresh)
    if "all" not in selected:
        commands = tuple(command for command in commands if command.name in selected)
    if args.require_clean and not args.dry_run and repository_is_dirty():
        raise SystemExit(
            "git worktree is dirty; commit or stash changes before a formal rerun"
        )
    suite_manifest = args.suite_manifest_output or default_suite_manifest_path(config)
    if args.dry_run:
        print(f"\nsuite_manifest={suite_manifest} (not written during dry-run)")
    elif not args.skip_suite_manifest:
        write_suite_manifest(
            suite_manifest,
            config=config,
            args=args,
            commands=commands,
        )
        print(f"\nsuite_manifest={suite_manifest}")
    for command in commands:
        run_command(command, dry_run=args.dry_run)
    print(f"\nformal_run_id={FORMAL_RUN_ID}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
