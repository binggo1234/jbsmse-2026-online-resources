from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "results" / "corrected_model_stage7_kerf" / "kerf_layouts" / "stage7_kerf_layouts.zip"
RECORD_MANIFEST = ROOT / "results" / "corrected_model_stage7_kerf" / "kerf_layouts" / "stage7_kerf_layout_manifest.csv"
DEFAULT_OUTPUT_DIR = ROOT / "results" / "corrected_model_stage7_kerf" / "formal"


@dataclass(frozen=True)
class SuiteTask:
    name: str
    methods: tuple[str, ...]
    repeat_policy: str = "hard"
    timeout_seconds: int = 30
    extra_args: tuple[str, ...] = ()
    diagnostics: bool = False


TASKS = (
    SuiteTask(
        "main",
        (
            "topology_process_aware",
            "process_local_search_multistart",
            "process_aware_beam",
            "process_aware_beam_adaptive_polished",
        ),
        diagnostics=True,
    ),
    SuiteTask(
        "external_baselines",
        (
            "greedy",
            "contour_tsp_2opt",
            "contour_aco",
            "endpoint_aware_gtsp",
            "path_distance_local_search",
            "topology",
            "process_aware_sa",
            "process_aware_ga",
        ),
        timeout_seconds=60,
    ),
    SuiteTask(
        "prefix_mcts",
        (
            "process_aware_prefix_beam_mcts",
            "process_aware_beam_adaptive_polished",
        ),
        timeout_seconds=120,
        extra_args=("--algorithm-seed", "20260502"),
        diagnostics=True,
    ),
    SuiteTask("ablation_beam_polished", ("process_aware_beam_polished",)),
    SuiteTask(
        "ablation_gate_off",
        ("process_aware_beam_adaptive_polished",),
        extra_args=("--disable-tool-event-gate",),
    ),
    SuiteTask(
        "ablation_gate_conservative",
        ("process_aware_beam_adaptive_polished",),
        extra_args=(
            "--tool-event-min-travel-saving",
            "100",
            "--tool-event-min-travel-saving-ratio",
            "0.02",
        ),
    ),
    SuiteTask(
        "ablation_repeat_soft",
        ("process_aware_beam_adaptive_polished",),
        repeat_policy="soft",
    ),
    SuiteTask(
        "ablation_repeat_off",
        ("process_aware_beam_adaptive_polished",),
        repeat_policy="off",
    ),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the complete Stage 7 formal suite.")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument(
        "--tasks",
        nargs="+",
        choices=[task.name for task in TASKS],
        default=[task.name for task in TASKS],
    )
    return parser.parse_args()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_task(task: SuiteTask, output_dir: Path) -> dict[str, object]:
    output = output_dir / f"chapter3_stage7_{task.name}.csv"
    summary = output_dir / f"chapter3_stage7_{task.name}_summary.csv"
    bin_summary = output_dir / f"chapter3_stage7_{task.name}_bin_summary.csv"
    manifest = output_dir / f"chapter3_stage7_{task.name}_manifest.json"
    progress = output_dir / f"chapter3_stage7_{task.name}_progress.csv"
    command = [
        sys.executable,
        str(ROOT / "experiments" / "run_chapter2_batch.py"),
        "--zip-path",
        str(ARCHIVE),
        "--record-manifest",
        str(RECORD_MANIFEST),
        "--experiment-preset",
        "paper-main",
        "--repeat-cut-policy",
        task.repeat_policy,
        "--tool-event-min-travel-saving",
        "25",
        "--tool-event-min-travel-saving-ratio",
        "0",
        "--tool-event-min-machining-saving",
        "1e-09",
        "--methods",
        *task.methods,
        "--task-timeout-seconds",
        str(task.timeout_seconds),
        "--output",
        str(output),
        "--summary-output",
        str(summary),
        "--bin-summary-output",
        str(bin_summary),
        "--manifest-output",
        str(manifest),
        "--progress-output",
        str(progress),
        "--no-progress-bar",
        *task.extra_args,
    ]
    if task.diagnostics:
        command.extend(
            ("--diagnostics-dir", str(output_dir / f"{task.name}_diagnostics"))
        )
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join(
        (str(ROOT / "src"), str(ROOT / "experiments"))
    )
    print(f"[stage7] start {task.name}", flush=True)
    subprocess.run(command, cwd=ROOT, env=environment, check=True)
    with output.open(newline="", encoding="utf-8-sig") as handle:
        row_count = sum(1 for _ in csv.DictReader(handle))
    expected_rows = 77 * len(task.methods)
    if row_count != expected_rows:
        raise ValueError(
            f"{task.name} produced {row_count} rows; expected {expected_rows}"
        )
    print(f"[stage7] complete {task.name}: rows={row_count}", flush=True)
    return {
        "task": task.name,
        "methods": task.methods,
        "repeat_policy": task.repeat_policy,
        "row_count": row_count,
        "output": str(output.relative_to(ROOT)),
        "output_sha256": _sha256(output),
        "manifest": str(manifest.relative_to(ROOT)),
    }


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    requested = set(args.tasks)
    records = [
        run_task(task, output_dir) for task in TASKS if task.name in requested
    ]
    suite_manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "archive": str(ARCHIVE.relative_to(ROOT)),
        "archive_sha256": _sha256(ARCHIVE),
        "record_manifest": str(RECORD_MANIFEST.relative_to(ROOT)),
        "record_manifest_sha256": _sha256(RECORD_MANIFEST),
        "tasks": records,
    }
    path = output_dir / "chapter3_stage7_suite_manifest.json"
    path.write_text(json.dumps(suite_manifest, indent=2) + "\n", encoding="utf-8")
    print(f"[stage7] suite manifest: {path}")


if __name__ == "__main__":
    main()
