from __future__ import annotations

import argparse
import csv
import json
import math
import re
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FUSION_DIR = (
    ROOT
    / "results"
    / "corrected_model_stage7_kerf"
    / "auxiliary_nc_cam_fusion_5case"
    / "fusion"
)
CUT_LAYERS = {
    "SINGLE_EDGE",
    "SHARED_EDGE",
    "NEAR_SHARED_CHANNEL",
    "COLLINEAR_CHAIN",
    "CUT_LINE",
}
TARGET_DEPTHS = (-6.0, -12.0, -18.0)
TOLERANCE = 1e-3


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit Stage 7 Fusion API DXF-to-NC auxiliary evidence."
    )
    parser.add_argument("--fusion-dir", type=Path, default=DEFAULT_FUSION_DIR)
    return parser.parse_args()


def read_dxf_segments(path: Path) -> list[tuple[float, float, float, float]]:
    raw = path.read_text(encoding="ascii").splitlines()
    if len(raw) % 2:
        raise ValueError(f"odd DXF group-code line count: {path}")
    pairs = [(int(raw[i].strip()), raw[i + 1].strip()) for i in range(0, len(raw), 2)]
    segments: list[tuple[float, float, float, float]] = []
    current: dict[int, str] | None = None
    for code, value in pairs:
        if code == 0:
            if current is not None:
                append_dxf_segment(current, segments)
            current = {} if value == "LINE" else None
        elif current is not None:
            current[code] = value
    if current is not None:
        append_dxf_segment(current, segments)
    return segments


def append_dxf_segment(
    current: dict[int, str], segments: list[tuple[float, float, float, float]]
) -> None:
    if current.get(8) not in CUT_LAYERS:
        return
    if not all(key in current for key in (10, 20, 11, 21)):
        return
    segments.append(
        tuple(float(current[key]) for key in (10, 20, 11, 21))  # type: ignore[arg-type]
    )


def parse_nc(path: Path) -> dict[str, object]:
    position = {"X": 0.0, "Y": 0.0, "Z": 0.0}
    motion = None
    feed = None
    cut_segments: dict[float, list[tuple[float, float, float, float]]] = defaultdict(list)
    xy_values = [0.0]
    yy_values = [0.0]
    z_values = [0.0]
    text = path.read_text(encoding="ascii", errors="strict")
    for raw_line in text.splitlines():
        line = raw_line.split("(", 1)[0]
        motion_match = re.search(r"\bG([01])\b", line)
        if motion_match:
            motion = int(motion_match.group(1))
        feed_match = re.search(r"\bF(-?\d+(?:\.\d+)?)", line)
        if feed_match:
            feed = float(feed_match.group(1))
        next_position = position.copy()
        for axis in "XYZ":
            match = re.search(rf"\b{axis}(-?\d+(?:\.\d+)?)", line)
            if match:
                next_position[axis] = float(match.group(1))
        xy_values.append(next_position["X"])
        yy_values.append(next_position["Y"])
        z_values.append(next_position["Z"])
        if (
            motion == 1
            and feed == 3600.0
            and (
                next_position["X"] != position["X"]
                or next_position["Y"] != position["Y"]
            )
        ):
            depth = round(next_position["Z"], 3)
            cut_segments[depth].append(
                (
                    position["X"],
                    position["Y"],
                    next_position["X"],
                    next_position["Y"],
                )
            )
        position = next_position
    return {
        "text": text,
        "cut_segments": dict(cut_segments),
        "x_min": min(xy_values),
        "x_max": max(xy_values),
        "y_min": min(yy_values),
        "y_max": max(yy_values),
        "z_min": min(z_values),
        "z_max": max(z_values),
    }


def segment_length(segment: tuple[float, float, float, float]) -> float:
    return math.hypot(segment[2] - segment[0], segment[3] - segment[1])


def axis_interval(
    segment: tuple[float, float, float, float]
) -> tuple[str, float, float, float]:
    x1, y1, x2, y2 = segment
    if abs(y2 - y1) <= TOLERANCE:
        return "H", round((y1 + y2) / 2.0, 3), min(x1, x2), max(x1, x2)
    if abs(x2 - x1) <= TOLERANCE:
        return "V", round((x1 + x2) / 2.0, 3), min(y1, y2), max(y1, y2)
    raise ValueError(f"non-axis-aligned segment in Fusion auxiliary evidence: {segment}")


def interval_index(
    segments: list[tuple[float, float, float, float]]
) -> dict[tuple[str, float], list[tuple[float, float]]]:
    index: dict[tuple[str, float], list[tuple[float, float]]] = defaultdict(list)
    for segment in segments:
        orientation, coordinate, low, high = axis_interval(segment)
        index[(orientation, coordinate)].append((low, high))
    for key, intervals in index.items():
        intervals.sort()
        merged: list[tuple[float, float]] = []
        for low, high in intervals:
            if not merged or low > merged[-1][1] + TOLERANCE:
                merged.append((low, high))
            else:
                merged[-1] = (merged[-1][0], max(merged[-1][1], high))
        index[key] = merged
    return index


def segment_is_covered(
    segment: tuple[float, float, float, float],
    index: dict[tuple[str, float], list[tuple[float, float]]],
) -> bool:
    orientation, coordinate, low, high = axis_interval(segment)
    return any(
        interval_low <= low + TOLERANCE and interval_high >= high - TOLERANCE
        for interval_low, interval_high in index.get((orientation, coordinate), [])
    )


def audit_case(dxf_path: Path, nc_path: Path, api_row: dict[str, object]) -> dict[str, object]:
    desired = read_dxf_segments(dxf_path)
    parsed = parse_nc(nc_path)
    cut_segments = parsed["cut_segments"]
    assert isinstance(cut_segments, dict)
    desired_length = sum(segment_length(segment) for segment in desired)
    depth_rows = {}
    missing_total = 0
    length_match = True
    for depth in TARGET_DEPTHS:
        actual = cut_segments.get(depth, [])
        actual_length = sum(segment_length(segment) for segment in actual)
        missing = sum(
            not segment_is_covered(segment, interval_index(actual)) for segment in desired
        )
        missing_total += missing
        length_match = length_match and abs(actual_length - desired_length) <= TOLERANCE
        depth_rows[str(depth)] = {
            "nc_xy_cut_length_mm": actual_length,
            "missing_dxf_segment_count": missing,
        }
    observed_cut_depths = sorted(cut_segments)
    text = str(parsed["text"])
    depth_pass = observed_cut_depths == sorted(TARGET_DEPTHS)
    bounds_pass = (
        float(parsed["x_min"]) >= -TOLERANCE
        and float(parsed["x_max"]) <= 2440.0 + TOLERANCE
        and float(parsed["y_min"]) >= -TOLERANCE
        and float(parsed["y_max"]) <= 1220.0 + TOLERANCE
        and float(parsed["z_min"]) >= -18.0 - TOLERANCE
    )
    compensation_pass = not re.search(r"\bG4[12]\b", text)
    selection_pass = (
        int(api_row["input_cut_line_count"])
        == int(api_row["fusion_sketch_curve_count"])
        == int(api_row["fusion_chain_selection_count"])
        == len(desired)
    )
    passed = all(
        (
            api_row["status"] == "passed",
            selection_pass,
            depth_pass,
            length_match,
            missing_total == 0,
            bounds_pass,
            compensation_pass,
        )
    )
    return {
        "case_id": api_row["case_id"],
        "passed": passed,
        "dxf_segment_count": len(desired),
        "selection_count_pass": selection_pass,
        "dxf_cut_length_mm": desired_length,
        "observed_cut_depths_mm": observed_cut_depths,
        "three_depth_pass": depth_pass,
        "per_depth_length_pass": length_match,
        "missing_dxf_segment_count": missing_total,
        "bounds_pass": bounds_pass,
        "controller_compensation_off_pass": compensation_pass,
        "x_min": parsed["x_min"],
        "x_max": parsed["x_max"],
        "y_min": parsed["y_min"],
        "y_max": parsed["y_max"],
        "z_min": parsed["z_min"],
        "z_max": parsed["z_max"],
        "fusion_machining_time_s": api_row["fusion_machining_time_s"],
        "fusion_feed_distance_mm": api_row["fusion_feed_distance_mm"],
        "fusion_rapid_distance_mm": api_row["fusion_rapid_distance_mm"],
        "depth_audit": depth_rows,
    }


def main() -> None:
    args = parse_args()
    fusion_dir = args.fusion_dir.resolve()
    api_dir = fusion_dir / "api_batch"
    api_rows = json.loads((api_dir / "fusion_api_results.json").read_text(encoding="utf-8"))
    results = []
    for api_row in api_rows:
        case_id = str(api_row["case_id"])
        results.append(
            audit_case(
                fusion_dir / "dxf" / f"{case_id}.dxf",
                api_dir / "nc" / f"{case_id}.nc",
                api_row,
            )
        )
    summary = {
        "case_count": len(results),
        "passed_case_count": sum(bool(row["passed"]) for row in results),
        "all_pass": all(bool(row["passed"]) for row in results),
        "cases": results,
    }
    (api_dir / "fusion_api_nc_audit.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=True), encoding="utf-8"
    )
    csv_fields = [
        "case_id",
        "passed",
        "dxf_segment_count",
        "selection_count_pass",
        "dxf_cut_length_mm",
        "observed_cut_depths_mm",
        "three_depth_pass",
        "per_depth_length_pass",
        "missing_dxf_segment_count",
        "bounds_pass",
        "controller_compensation_off_pass",
        "fusion_machining_time_s",
        "fusion_feed_distance_mm",
        "fusion_rapid_distance_mm",
    ]
    with (api_dir / "fusion_api_nc_audit.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=csv_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)
    print(json.dumps({key: summary[key] for key in ("case_count", "passed_case_count", "all_pass")}))
    if not summary["all_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
