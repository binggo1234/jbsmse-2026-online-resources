from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean, median
from time import perf_counter

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.exact_dp import (
    ExactBranchAndBoundConfig,
    exact_process_branch_and_bound_order,
)
from cnc_cutting.exact_lower_bound import exact_static_routing_lower_bound
from cnc_cutting.geometry import euclidean_distance
from cnc_cutting.io import (
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.local_search import evaluate_directed_units, process_metric_key
from cnc_cutting.models import Layout, Panel, PathMetrics, PlacedRectangle, Point, ToolConfig
from cnc_cutting.optimizer import select_coverage_units
from cnc_cutting.topology_operators import (
    DirectedUnitCandidate,
    directed_unit_candidates,
)
from process_options import (
    add_experiment_preset_arg,
    add_repeat_cut_policy_args,
    add_stability_model_args,
    add_tool_event_gate_args,
    apply_experiment_preset,
    build_process_model_from_args,
    build_tool_event_gate_from_args,
    repeat_cut_policy_from_args,
)
from run_chapter2_batch import (
    DEFAULT_ARCHIVES,
    board_counts_from_zip,
    build_planners,
    parse_member_metadata,
    sample_placement_members,
    select_board_ids,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "results" / "chapter3_certified_exact_gap_8_12.csv"
DEFAULT_SUMMARY_OUTPUT = (
    ROOT / "results" / "chapter3_certified_exact_gap_8_12_summary.csv"
)
DEFAULT_MANIFEST_OUTPUT = (
    ROOT / "results" / "chapter3_certified_exact_gap_8_12_manifest.json"
)
DEFAULT_TARGET_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_INCUMBENT_METHODS = (
    "process_local_search_multistart",
    "process_aware_beam",
    "process_aware_beam_polished",
    "process_aware_beam_adaptive",
    DEFAULT_TARGET_METHOD,
)


@dataclass(frozen=True)
class CertifiedGapRow:
    archive: str
    case_name: str
    placement_method: str
    seed: str
    placements_member: str
    board_id: str
    rectangle_count: int
    candidate_unit_count: int
    selected_unit_count: int
    target_method: str
    exact_objective_scope: str
    certificate_type: str
    static_lower_bound_proven: bool
    static_travel_distance_lower_bound: float
    static_composite_cost_lower_bound: float
    static_lower_bound_runtime_seconds: float
    optimality_proven: bool
    termination_reason: str
    exact_runtime_seconds: float
    exact_expanded_nodes: int
    exact_pruned_by_bound: int
    exact_pruned_by_dominance: int
    exact_retained_states: int
    exact_hard_penalty: float
    exact_support_rule_penalty: float
    exact_repeated_cut_segment_count: int
    exact_composite_planning_cost: float
    exact_travel_mode_cost: float
    target_runtime_ms: float
    target_hard_penalty: float
    target_support_rule_penalty: float
    target_repeated_cut_segment_count: int
    target_composite_planning_cost: float
    target_travel_mode_cost: float
    process_key_gap: str
    comparable_cost_gap: float | None
    comparable_relative_gap: float | None


@dataclass(frozen=True)
class CertifiedGapSummary:
    certified_case_count: int
    attempted_case_count: int
    rectangle_count_min: int | None
    rectangle_count_max: int | None
    selected_unit_count_min: int | None
    selected_unit_count_max: int | None
    exact_runtime_seconds_mean: float | None
    exact_runtime_seconds_median: float | None
    exact_runtime_seconds_max: float | None
    relative_gap_mean: float | None
    relative_gap_median: float | None
    relative_gap_max: float | None
    relative_gap_ci95_low: float | None
    relative_gap_ci95_high: float | None
    target_tie_count: int
    target_loss_count: int


def metrics_are_cost_comparable(first: PathMetrics, second: PathMetrics) -> bool:
    return (
        abs(first.hard_penalty - second.hard_penalty) <= 1e-9
        and abs(first.stability_penalty - second.stability_penalty) <= 1e-9
        and first.repeated_cut_segment_count == second.repeated_cut_segment_count
        and abs(first.repeated_cut_length - second.repeated_cut_length) <= 1e-9
        and first.redundant_cut_action_count == second.redundant_cut_action_count
    )


def feasibility_cost_key(metrics: PathMetrics) -> tuple:
    return (
        metrics.hard_penalty,
        metrics.stability_penalty,
        metrics.repeated_cut_segment_count,
        metrics.repeated_cut_length,
        metrics.redundant_cut_action_count,
        metrics.machining_cost,
    )


def bootstrap_mean_ci(
    values: list[float],
    *,
    samples: int,
    seed: int,
) -> tuple[float | None, float | None]:
    if not values:
        return None, None
    if len(values) == 1:
        return values[0], values[0]
    rng = random.Random(seed)
    bootstrap_means = sorted(
        mean(rng.choice(values) for _ in values) for _ in range(samples)
    )
    low_index = int(0.025 * (samples - 1))
    high_index = int(0.975 * (samples - 1))
    return bootstrap_means[low_index], bootstrap_means[high_index]


def target_plan(
    *,
    method: str,
    units,
    panel: Panel,
    tool,
    process_model,
    tool_event_gate,
    rectangle_count: int,
    repeat_cut_policy: str,
):
    planner = build_planners(
        (method,),
        units,
        panel,
        tool,
        process_model,
        tool_event_gate,
        rectangle_count,
        repeat_cut_policy,
    )[0]
    start = perf_counter()
    plan = planner.planner()
    return plan, (perf_counter() - start) * 1000.0


def directed_units_from_plan(
    plan,
    selected_units,
) -> tuple[DirectedUnitCandidate, ...] | None:
    candidates_by_id = {
        unit.unit_id: directed_unit_candidates(unit) for unit in selected_units
    }
    directed: list[DirectedUnitCandidate] = []
    seen: set[str] = set()
    for action in plan.actions:
        unit_id = action.cutting_unit_id
        if unit_id is None or unit_id in seen or unit_id not in candidates_by_id:
            continue
        matching = [
            candidate
            for candidate in candidates_by_id[unit_id]
            if candidate.start == action.start and candidate.end == action.end
        ]
        if len(matching) != 1:
            return None
        directed.append(matching[0])
        seen.add(unit_id)
    if len(directed) != len(selected_units):
        return None
    return tuple(directed)


def solve_layout(
    *,
    archive_name: str,
    case_name: str,
    placement_method: str,
    seed: str,
    placements_member: str,
    board_id: str,
    layout: Layout,
    tool: ToolConfig,
    args: argparse.Namespace,
) -> CertifiedGapRow:
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    process_model = build_process_model_from_args(layout, args)
    tool_event_gate = build_tool_event_gate_from_args(args)
    repeat_cut_policy = repeat_cut_policy_from_args(args)
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    selected_units = select_coverage_units(
        units,
        repeat_cut_policy=repeat_cut_policy,
    )
    plan, target_runtime_ms = target_plan(
        method=args.target_method,
        units=units,
        panel=panel,
        tool=tool,
        process_model=process_model,
        tool_event_gate=tool_event_gate,
        rectangle_count=len(layout.rectangles),
        repeat_cut_policy=repeat_cut_policy,
    )
    incumbent_plans = [(args.target_method, plan)]
    for method in args.incumbent_methods:
        if method == args.target_method:
            continue
        incumbent_plan, _ = target_plan(
            method=method,
            units=units,
            panel=panel,
            tool=tool,
            process_model=process_model,
            tool_event_gate=tool_event_gate,
            rectangle_count=len(layout.rectangles),
            repeat_cut_policy=repeat_cut_policy,
        )
        incumbent_plans.append((method, incumbent_plan))
    _, best_incumbent_plan = min(
        incumbent_plans,
        key=lambda item: (
            feasibility_cost_key(item[1].metrics),
            item[0],
        ),
    )
    incumbent_directed_units = directed_units_from_plan(
        best_incumbent_plan,
        selected_units,
    )
    incumbent_metrics = best_incumbent_plan.metrics
    static_lower_bound = exact_static_routing_lower_bound(
        selected_units,
        tool.start_point,
        timeout_seconds=args.static_lower_bound_timeout_seconds,
        distance_scale=args.distance_scale,
    )
    if static_lower_bound.optimality_proven:
        _, static_route_metrics = evaluate_directed_units(
            static_lower_bound.directed_units,
            panel,
            tool,
            process_model=process_model,
        )
        if feasibility_cost_key(static_route_metrics) < feasibility_cost_key(
            incumbent_metrics
        ):
            incumbent_directed_units = static_lower_bound.directed_units
            incumbent_metrics = static_route_metrics
    minimum_travel_weight = min(
        tool.low_clearance_travel_weight,
        tool.detour_travel_weight,
        tool.safe_lift_travel_weight,
    )
    fixed_cutting_length = sum(
        euclidean_distance(unit.start, unit.end) for unit in selected_units
    )
    static_composite_cost_lower_bound = (
        fixed_cutting_length
        + static_lower_bound.travel_distance_lower_bound * minimum_travel_weight
    )
    incumbent_reaches_static_bound = (
        static_lower_bound.optimality_proven
        and incumbent_metrics.hard_penalty == 0.0
        and incumbent_metrics.stability_penalty == 0.0
        and incumbent_metrics.repeated_cut_segment_count == 0
        and incumbent_metrics.repeated_cut_length == 0.0
        and incumbent_metrics.redundant_cut_action_count == 0
        and abs(
            incumbent_metrics.machining_cost - static_composite_cost_lower_bound
        )
        <= args.certificate_tolerance
    )
    if incumbent_reaches_static_bound:
        exact_metrics = incumbent_metrics
        exact_optimality_proven = True
        exact_termination_reason = "static_relaxation_bound"
        exact_runtime_seconds = static_lower_bound.runtime_seconds
        exact_expanded_nodes = 0
        exact_pruned_by_bound = 0
        exact_pruned_by_dominance = 0
        exact_retained_states = 0
        certificate_type = "static_relaxation_bound"
    else:
        exact = exact_process_branch_and_bound_order(
            selected_units,
            panel,
            tool,
            process_model=process_model,
            config=ExactBranchAndBoundConfig(
                timeout_seconds=args.timeout_seconds,
                max_expanded_nodes=args.max_expanded_nodes,
                repeat_cut_policy=repeat_cut_policy,
                objective_scope="feasibility_cost",
            ),
            incumbent_directed_units=incumbent_directed_units,
        )
        exact_metrics = exact.metrics
        search_reaches_static_bound = (
            static_lower_bound.optimality_proven
            and exact.metrics.hard_penalty == 0.0
            and exact.metrics.stability_penalty == 0.0
            and exact.metrics.repeated_cut_segment_count == 0
            and exact.metrics.repeated_cut_length == 0.0
            and exact.metrics.redundant_cut_action_count == 0
            and abs(
                exact.metrics.machining_cost - static_composite_cost_lower_bound
            )
            <= args.certificate_tolerance
        )
        exact_optimality_proven = (
            exact.optimality_proven or search_reaches_static_bound
        )
        exact_termination_reason = (
            "static_relaxation_bound_after_search"
            if search_reaches_static_bound
            else exact.termination_reason
        )
        exact_runtime_seconds = (
            static_lower_bound.runtime_seconds + exact.runtime_seconds
        )
        exact_expanded_nodes = exact.expanded_nodes
        exact_pruned_by_bound = exact.pruned_by_bound
        exact_pruned_by_dominance = exact.pruned_by_dominance
        exact_retained_states = exact.retained_states
        certificate_type = (
            "static_relaxation_bound_after_search"
            if search_reaches_static_bound
            else (
                "dynamic_branch_and_bound"
                if exact.optimality_proven
                else "uncertified"
            )
        )

    target_key = process_metric_key(
        plan.metrics,
        repeat_cut_policy=repeat_cut_policy,
    )
    exact_key = process_metric_key(
        exact_metrics,
        repeat_cut_policy=repeat_cut_policy,
    )
    if target_key == exact_key:
        process_key_gap = "tie"
    elif target_key > exact_key:
        process_key_gap = "target_worse"
    else:
        process_key_gap = "target_better_uncertified_reference"

    comparable = exact_optimality_proven and metrics_are_cost_comparable(
        plan.metrics,
        exact_metrics,
    )
    cost_gap = (
        plan.metrics.machining_cost - exact_metrics.machining_cost
        if comparable
        else None
    )
    relative_gap = (
        cost_gap / exact_metrics.machining_cost
        if comparable and exact_metrics.machining_cost > 1e-9 and cost_gap is not None
        else None
    )
    return CertifiedGapRow(
        archive=archive_name,
        case_name=case_name,
        placement_method=placement_method,
        seed=seed,
        placements_member=placements_member,
        board_id=board_id,
        rectangle_count=len(layout.rectangles),
        candidate_unit_count=len(units),
        selected_unit_count=len(selected_units),
        target_method=args.target_method,
        exact_objective_scope="feasibility_cost",
        certificate_type=certificate_type,
        static_lower_bound_proven=static_lower_bound.optimality_proven,
        static_travel_distance_lower_bound=(
            static_lower_bound.travel_distance_lower_bound
        ),
        static_composite_cost_lower_bound=static_composite_cost_lower_bound,
        static_lower_bound_runtime_seconds=static_lower_bound.runtime_seconds,
        optimality_proven=exact_optimality_proven,
        termination_reason=exact_termination_reason,
        exact_runtime_seconds=exact_runtime_seconds,
        exact_expanded_nodes=exact_expanded_nodes,
        exact_pruned_by_bound=exact_pruned_by_bound,
        exact_pruned_by_dominance=exact_pruned_by_dominance,
        exact_retained_states=exact_retained_states,
        exact_hard_penalty=exact_metrics.hard_penalty,
        exact_support_rule_penalty=exact_metrics.stability_penalty,
        exact_repeated_cut_segment_count=exact_metrics.repeated_cut_segment_count,
        exact_composite_planning_cost=exact_metrics.machining_cost,
        exact_travel_mode_cost=exact_metrics.travel_mode_cost,
        target_runtime_ms=target_runtime_ms,
        target_hard_penalty=plan.metrics.hard_penalty,
        target_support_rule_penalty=plan.metrics.stability_penalty,
        target_repeated_cut_segment_count=plan.metrics.repeated_cut_segment_count,
        target_composite_planning_cost=plan.metrics.machining_cost,
        target_travel_mode_cost=plan.metrics.travel_mode_cost,
        process_key_gap=process_key_gap,
        comparable_cost_gap=cost_gap,
        comparable_relative_gap=relative_gap,
    )


def run_case(
    archive: Path,
    placements_member: str,
    board_id: str,
    args: argparse.Namespace,
) -> CertifiedGapRow:
    cfg = load_chapter2_config_from_zip(archive, placements_member=placements_member)
    tool = tool_config_from_chapter2_config(cfg)
    layout: Layout = load_chapter2_layouts_from_zip(
        archive,
        placements_member=placements_member,
        board_ids=(board_id,),
    )[0]
    case_name, placement_method, seed = parse_member_metadata(placements_member)
    return solve_layout(
        archive_name=archive.name,
        case_name=case_name,
        placement_method=placement_method,
        seed=seed,
        placements_member=placements_member,
        board_id=board_id,
        layout=layout,
        tool=tool,
        args=args,
    )


def structured_grid_layout(rectangle_count: int) -> tuple[Layout, ToolConfig]:
    columns_by_count = {
        1: 1,
        2: 2,
        3: 3,
        4: 2,
        5: 5,
        6: 3,
        7: 7,
        8: 4,
        9: 3,
        10: 5,
        11: 11,
        12: 6,
    }
    columns = columns_by_count[rectangle_count]
    width = 100.0
    height = 100.0
    inset = 20.0
    tool_diameter = 6.0
    pitch_x = width + tool_diameter
    pitch_y = height + tool_diameter
    rectangles = tuple(
        PlacedRectangle(
            part_id=f"R{index + 1}",
            x=inset + (index % columns) * pitch_x,
            y=inset + (index // columns) * pitch_y,
            width=width,
            height=height,
        )
        for index in range(rectangle_count)
    )
    rows = (rectangle_count + columns - 1) // columns
    layout = Layout(
        panel_id=f"structured_grid_{rectangle_count}",
        panel_width=2 * inset + columns * width + max(columns - 1, 0) * tool_diameter,
        panel_height=2 * inset + rows * height + max(rows - 1, 0) * tool_diameter,
        rectangles=rectangles,
    )
    tool = ToolConfig(
        trim_margin=5.0,
        tool_diameter=tool_diameter,
        start_point=Point(inset, inset),
        geometric_kerf_compensation=True,
    )
    return layout, tool


def run_structured_case(
    rectangle_count: int,
    args: argparse.Namespace,
) -> CertifiedGapRow:
    layout, tool = structured_grid_layout(rectangle_count)
    return solve_layout(
        archive_name="synthetic_generator",
        case_name=f"structured_grid_{rectangle_count}",
        placement_method="deterministic_dense_grid",
        seed="deterministic",
        placements_member="generated",
        board_id=layout.panel_id,
        layout=layout,
        tool=tool,
        args=args,
    )


def summarize(
    rows: list[CertifiedGapRow],
    *,
    bootstrap_samples: int,
    bootstrap_seed: int,
) -> CertifiedGapSummary:
    certified = [row for row in rows if row.optimality_proven]
    comparable_gaps = [
        row.comparable_relative_gap
        for row in certified
        if row.comparable_relative_gap is not None
    ]
    ci_low, ci_high = bootstrap_mean_ci(
        comparable_gaps,
        samples=bootstrap_samples,
        seed=bootstrap_seed,
    )
    return CertifiedGapSummary(
        certified_case_count=len(certified),
        attempted_case_count=len(rows),
        rectangle_count_min=min((row.rectangle_count for row in certified), default=None),
        rectangle_count_max=max((row.rectangle_count for row in certified), default=None),
        selected_unit_count_min=min(
            (row.selected_unit_count for row in certified),
            default=None,
        ),
        selected_unit_count_max=max(
            (row.selected_unit_count for row in certified),
            default=None,
        ),
        exact_runtime_seconds_mean=(
            mean(row.exact_runtime_seconds for row in certified)
            if certified
            else None
        ),
        exact_runtime_seconds_median=(
            median(row.exact_runtime_seconds for row in certified)
            if certified
            else None
        ),
        exact_runtime_seconds_max=(
            max(row.exact_runtime_seconds for row in certified)
            if certified
            else None
        ),
        relative_gap_mean=mean(comparable_gaps) if comparable_gaps else None,
        relative_gap_median=median(comparable_gaps) if comparable_gaps else None,
        relative_gap_max=max(comparable_gaps) if comparable_gaps else None,
        relative_gap_ci95_low=ci_low,
        relative_gap_ci95_high=ci_high,
        target_tie_count=sum(row.process_key_gap == "tie" for row in certified),
        target_loss_count=sum(
            row.process_key_gap == "target_worse" for row in certified
        ),
    )


def write_csv_rows(rows: list[CertifiedGapRow], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git_metadata() -> dict[str, object]:
    commit = subprocess.run(
        ("git", "rev-parse", "HEAD"),
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    status = subprocess.run(
        ("git", "status", "--porcelain"),
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    return {"commit": commit, "dirty": bool(status.strip())}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run certified branch-and-bound optimality-gap experiments on "
            "1-12 rectangle layouts. Unfinished searches are retained as "
            "diagnostics but excluded from certified summaries."
        )
    )
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=2)
    parser.add_argument("--boards-per-member", type=int, default=2)
    parser.add_argument("--min-rectangles", type=int, default=8)
    parser.add_argument("--max-rectangles", type=int, default=12)
    parser.add_argument("--max-cases", type=int, default=12)
    parser.add_argument(
        "--instance-source",
        choices=("structured", "production", "both"),
        default="structured",
    )
    parser.add_argument("--timeout-seconds", type=float, default=600.0)
    parser.add_argument(
        "--static-lower-bound-timeout-seconds",
        type=float,
        default=120.0,
    )
    parser.add_argument("--distance-scale", type=int, default=1_000_000)
    parser.add_argument("--certificate-tolerance", type=float, default=1e-6)
    parser.add_argument("--max-expanded-nodes", type=int)
    parser.add_argument("--target-method", default=DEFAULT_TARGET_METHOD)
    parser.add_argument(
        "--incumbent-methods",
        nargs="+",
        default=list(DEFAULT_INCUMBENT_METHODS),
        help="Process-aware methods used only to warm-start the exact solver.",
    )
    parser.add_argument("--bootstrap-samples", type=int, default=5000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260502)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--summary-output", type=Path, default=DEFAULT_SUMMARY_OUTPUT)
    parser.add_argument("--manifest-output", type=Path, default=DEFAULT_MANIFEST_OUTPUT)
    add_experiment_preset_arg(parser)
    add_stability_model_args(parser)
    add_tool_event_gate_args(parser)
    add_repeat_cut_policy_args(parser)
    return apply_experiment_preset(parser.parse_args())


def main() -> None:
    args = parse_args()
    archives = tuple(args.zip_paths) if args.zip_paths else DEFAULT_ARCHIVES
    rows: list[CertifiedGapRow] = []
    if args.instance_source in {"structured", "both"}:
        for rectangle_count in range(args.min_rectangles, args.max_rectangles + 1):
            if rectangle_count not in set(range(1, 13)):
                continue
            print(f"case: structured rectangles={rectangle_count}", flush=True)
            row = run_structured_case(rectangle_count, args)
            rows.append(row)
            print(
                f"  units={row.selected_unit_count} proven={row.optimality_proven} "
                f"reason={row.termination_reason} "
                f"runtime={row.exact_runtime_seconds:.3f}s "
                f"expanded={row.exact_expanded_nodes}",
                flush=True,
            )

    if args.instance_source in {"production", "both"}:
        case_specs: list[tuple[Path, str, str, int]] = []
        for archive in archives:
            members = sample_placement_members(archive, args.max_members_per_archive)
            for member in members:
                counts = board_counts_from_zip(archive, member)
                board_ids = select_board_ids(
                    counts,
                    boards_per_member=args.boards_per_member,
                    min_rectangles=args.min_rectangles,
                    max_rectangles=args.max_rectangles,
                )
                case_specs.extend(
                    (archive, member, board_id, counts[board_id])
                    for board_id in board_ids
                )
        case_specs.sort(key=lambda item: (item[3], item[0].name, item[1], item[2]))
        remaining_case_count = max(args.max_cases - len(rows), 0)
        for archive, member, board_id, rectangle_count in case_specs[
            :remaining_case_count
        ]:
            print(
                f"case: archive={archive.name} board={board_id} "
                f"rectangles={rectangle_count}",
                flush=True,
            )
            row = run_case(archive, member, board_id, args)
            rows.append(row)
            print(
                f"  units={row.selected_unit_count} proven={row.optimality_proven} "
                f"reason={row.termination_reason} "
                f"runtime={row.exact_runtime_seconds:.3f}s "
                f"expanded={row.exact_expanded_nodes}",
                flush=True,
            )

    if not rows:
        raise ValueError("no 1-12 rectangle cases were selected")

    summary = summarize(
        rows,
        bootstrap_samples=args.bootstrap_samples,
        bootstrap_seed=args.bootstrap_seed,
    )
    write_csv_rows(rows, args.output)
    args.summary_output.parent.mkdir(parents=True, exist_ok=True)
    with args.summary_output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(summary).keys()))
        writer.writeheader()
        writer.writerow(asdict(summary))

    manifest = {
        "arguments": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in vars(args).items()
        },
        "git": git_metadata(),
        "outputs": {
            "rows": {
                "path": str(args.output),
                "sha256": sha256(args.output),
            },
            "summary": {
                "path": str(args.summary_output),
                "sha256": sha256(args.summary_output),
            },
        },
        "summary": asdict(summary),
    }
    args.manifest_output.parent.mkdir(parents=True, exist_ok=True)
    args.manifest_output.write_text(
        json.dumps(manifest, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    print(f"wrote: {args.output}")
    print(f"wrote: {args.summary_output}")
    print(f"wrote: {args.manifest_output}")


if __name__ == "__main__":
    main()
