from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from math import comb
from pathlib import Path
from statistics import mean, median


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT_DIR = (
    ROOT / "results" / "corrected_model_stage7_kerf" / "budget_matched_search"
)


def _compare(value: float, tolerance: float = 1e-9) -> str:
    if value > tolerance:
        return "win"
    if value < -tolerance:
        return "loss"
    return "tie"


def _sign_test_p(wins: int, losses: int) -> float:
    trials = wins + losses
    if trials == 0:
        return 1.0
    observed = min(wins, losses)
    lower = sum(comb(trials, k) for k in range(observed + 1)) / (2**trials)
    return min(1.0, 2.0 * lower)


def summarize_matched_pair(
    rows: list[dict[str, str]],
    *,
    target_variant: str,
    baseline_variant: str,
) -> dict[str, object]:
    by_record: dict[str, dict[str, dict[str, str]]] = defaultdict(dict)
    for row in rows:
        by_record[row["record_id"]][row["variant"]] = row

    reductions: list[float] = []
    inventory_reductions: dict[str, list[float]] = defaultdict(list)
    outcomes = {"win": 0, "tie": 0, "loss": 0}
    target_runtimes: list[float] = []
    baseline_runtimes: list[float] = []
    for record_id, variants in by_record.items():
        if target_variant not in variants or baseline_variant not in variants:
            raise ValueError(f"missing matched variant for {record_id}")
        target = variants[target_variant]
        baseline = variants[baseline_variant]
        baseline_cost = float(baseline["cplan"])
        target_cost = float(target["cplan"])
        reduction = 100.0 * (baseline_cost - target_cost) / baseline_cost
        reductions.append(reduction)
        inventory_reductions[target["inventory_sha256"]].append(reduction)
        outcomes[_compare(baseline_cost - target_cost)] += 1
        target_runtimes.append(float(target["runtime_ms"]))
        baseline_runtimes.append(float(baseline["runtime_ms"]))

    inventory_means = {
        inventory: mean(values)
        for inventory, values in inventory_reductions.items()
    }
    inventory_outcomes = {"win": 0, "tie": 0, "loss": 0}
    for value in inventory_means.values():
        inventory_outcomes[_compare(value)] += 1

    return {
        "target_variant": target_variant,
        "baseline_variant": baseline_variant,
        "layout_instances": len(reductions),
        "inventory_clusters": len(inventory_means),
        "layout_mean_reduction_pct": mean(reductions),
        "layout_median_reduction_pct": median(reductions),
        "layout_wins": outcomes["win"],
        "layout_ties": outcomes["tie"],
        "layout_losses": outcomes["loss"],
        "inventory_equal_reduction_pct": mean(inventory_means.values()),
        "inventory_wins": inventory_outcomes["win"],
        "inventory_ties": inventory_outcomes["tie"],
        "inventory_losses": inventory_outcomes["loss"],
        "inventory_sign_test_p": _sign_test_p(
            inventory_outcomes["win"], inventory_outcomes["loss"]
        ),
        "target_runtime_ms_mean": mean(target_runtimes),
        "baseline_runtime_ms_mean": mean(baseline_runtimes),
        "baseline_to_target_runtime_ratio": (
            mean(baseline_runtimes) / mean(target_runtimes)
        ),
        "inventory_mean_reductions_pct": inventory_means,
    }


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def _write_inventory_rows(path: Path, summary: dict[str, object]) -> None:
    values = summary["inventory_mean_reductions_pct"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=("inventory_sha256", "mean_reduction_pct")
        )
        writer.writeheader()
        for inventory, reduction in sorted(values.items()):
            writer.writerow(
                {
                    "inventory_sha256": inventory,
                    "mean_reduction_pct": reduction,
                }
            )


def _write_latex(
    path: Path,
    quality_runtime_rows: list[dict[str, str]],
    matched_variant: str,
) -> None:
    portfolio_runtime = float(
        next(
            row["runtime_ms_mean"]
            for row in quality_runtime_rows
            if row["variant"] == "adaptive_portfolio"
        )
    )
    ordered = sorted(
        quality_runtime_rows,
        key=lambda row: (row["variant"] != "adaptive_portfolio", float(row["scale"])),
    )
    lines = [
        r"\begin{table}[htbp]",
        r"\centering",
        r"\caption{Stage~7 quality--runtime comparison under the same evaluator and hardware. Ordinary-beam configurations were fixed after a 10-layout range pilot and all are reported. The runtime-matched row is selected only by proximity to the adaptive portfolio's mean wall-clock time; route quality is not used for selection.}",
        r"\label{tab:budget-matched-search}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{4pt}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lrrrrr@{}}",
        r"\toprule",
        r"Configuration & Scale & Beam width & Runtime (ms) & Runtime ratio & $C_{\mathrm{plan}}$ \\",
        r"\midrule",
    ]
    for row in ordered:
        label = (
            "Adaptive portfolio"
            if row["variant"] == "adaptive_portfolio"
            else f"Ordinary beam {float(row['scale']):g}$\\times$"
        )
        if row["variant"] == matched_variant:
            label += " (matched)"
        scale = "--" if row["variant"] == "adaptive_portfolio" else f"{float(row['scale']):.1f}"
        lines.append(
            f"{label} & {scale} & {float(row['beam_width_mean']):.1f} & "
            f"{float(row['runtime_ms_mean']):.1f} & "
            f"{float(row['runtime_ms_mean']) / portfolio_runtime:.3f} & "
            f"{float(row['cplan_mean']):.1f} \\\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular*}", r"\end{table}", ""))
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze the Stage 7 budget-matched search experiment."
    )
    parser.add_argument("--input-dir", type=Path, default=DEFAULT_INPUT_DIR)
    parser.add_argument("--latex-output", type=Path, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    routes = _read_csv(args.input_dir / "stage7_budget_matched_routes.csv")
    quality_runtime = _read_csv(
        args.input_dir / "stage7_budget_matched_summary.csv"
    )
    selection = json.loads(
        (args.input_dir / "stage7_runtime_matched_selection.json").read_text()
    )
    matched_variant = selection["runtime_matched_ordinary_beam"]["variant"]
    summary = summarize_matched_pair(
        routes,
        target_variant="adaptive_portfolio",
        baseline_variant=matched_variant,
    )
    (args.input_dir / "stage7_budget_matched_paired_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    _write_inventory_rows(
        args.input_dir / "stage7_budget_matched_inventory_rows.csv", summary
    )
    latex_output = args.latex_output or (
        args.input_dir / "table_budget_matched_search.tex"
    )
    _write_latex(latex_output, quality_runtime, matched_variant)
    print(json.dumps({key: value for key, value in summary.items() if key != "inventory_mean_reductions_pct"}, indent=2))
    print(f"latex={latex_output}")


if __name__ == "__main__":
    main()
