from __future__ import annotations

import argparse
import csv
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from urllib.request import urlopen

from cnc_cutting.models import Layout, PlacedRectangle, Point, ToolConfig


NGCUT_URL = (
    "https://site.unibo.it/operations-research/en/research/2dpacklib/"
    "ngcut.zip/@@download/file/NGCUT.zip"
)


@dataclass(frozen=True)
class PublicItem:
    item_id: str
    width: float
    height: float
    copies: int = 1


@dataclass(frozen=True)
class PublicInstance:
    name: str
    source: str
    bin_width: float
    bin_height: float
    items: tuple[PublicItem, ...]


def _tokens(line: str) -> list[str]:
    return line.replace(",", " ").split()


def _clean_lines(text: str) -> list[str]:
    return [
        line.strip()
        for line in text.splitlines()
        if line.strip() and not line.lstrip().startswith(("#", "%", "//"))
    ]


def _copies_from_fields(
    demand: float,
    upper_bound: float,
    policy: str,
    max_copies_per_type: int,
) -> int:
    if policy == "demand":
        copies = int(demand) if demand > 0 else 1
    elif policy == "upper_bound":
        copies = int(upper_bound) if upper_bound > 0 else 1
    else:
        copies = 1
    return max(1, min(max_copies_per_type, copies))


def parse_ins2d(
    text: str,
    *,
    name: str,
    source: str,
    copies_policy: str,
    max_copies_per_type: int,
) -> PublicInstance:
    lines = _clean_lines(text)
    if len(lines) < 2:
        raise ValueError(f"{name}: expected at least two header lines")
    item_count = int(float(_tokens(lines[0])[0]))
    stock_tokens = _tokens(lines[1])
    if len(stock_tokens) < 2:
        raise ValueError(f"{name}: missing stock width/height line")
    bin_width = float(stock_tokens[0])
    bin_height = float(stock_tokens[1])
    items: list[PublicItem] = []
    for index, line in enumerate(lines[2 : 2 + item_count], start=1):
        tokens = _tokens(line)
        if len(tokens) < 3:
            raise ValueError(f"{name}: malformed item line {index}: {line}")
        item_id = tokens[0]
        width = float(tokens[1])
        height = float(tokens[2])
        demand = float(tokens[3]) if len(tokens) > 3 else 1.0
        upper_bound = float(tokens[4]) if len(tokens) > 4 else 1.0
        items.append(
            PublicItem(
                item_id=item_id,
                width=width,
                height=height,
                copies=_copies_from_fields(
                    demand,
                    upper_bound,
                    copies_policy,
                    max_copies_per_type,
                ),
            )
        )
    return PublicInstance(
        name=name,
        source=source,
        bin_width=bin_width,
        bin_height=bin_height,
        items=tuple(items),
    )


def parse_csv_instances(
    path: Path,
    *,
    copies_policy: str,
    max_copies_per_type: int,
) -> tuple[PublicInstance, ...]:
    grouped: dict[str, list[dict[str, str]]] = {}
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        required = {"instance", "item_id", "width", "height"}
        missing = required - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"{path}: missing required CSV columns: {sorted(missing)}")
        for row in reader:
            grouped.setdefault(row["instance"], []).append(row)

    instances: list[PublicInstance] = []
    for instance_name, rows in grouped.items():
        first = rows[0]
        bin_width = float(first.get("bin_width") or 0.0)
        bin_height = float(first.get("bin_height") or 0.0)
        items: list[PublicItem] = []
        for row in rows:
            demand = float(row.get("demand") or row.get("copies") or 1.0)
            upper_bound = float(row.get("upper_bound") or demand)
            items.append(
                PublicItem(
                    item_id=row["item_id"],
                    width=float(row["width"]),
                    height=float(row["height"]),
                    copies=_copies_from_fields(
                        demand,
                        upper_bound,
                        copies_policy,
                        max_copies_per_type,
                    ),
                )
            )
        instances.append(
            PublicInstance(
                name=instance_name,
                source=str(path),
                bin_width=bin_width,
                bin_height=bin_height,
                items=tuple(items),
            )
        )
    return tuple(instances)


def iter_public_instances(
    input_paths: tuple[Path, ...],
    *,
    copies_policy: str,
    max_copies_per_type: int,
) -> tuple[PublicInstance, ...]:
    instances: list[PublicInstance] = []
    for path in input_paths:
        if path.suffix.lower() == ".zip":
            with zipfile.ZipFile(path) as archive:
                for name in sorted(archive.namelist()):
                    if not name.lower().endswith(".ins2d"):
                        continue
                    text = archive.read(name).decode("utf-8-sig", errors="ignore")
                    instances.append(
                        parse_ins2d(
                            text,
                            name=Path(name).stem,
                            source=f"{path.name}:{name}",
                            copies_policy=copies_policy,
                            max_copies_per_type=max_copies_per_type,
                        )
                    )
        elif path.is_dir():
            instances.extend(
                iter_public_instances(
                    tuple(sorted(path.rglob("*.ins2D"))),
                    copies_policy=copies_policy,
                    max_copies_per_type=max_copies_per_type,
                )
            )
            instances.extend(
                iter_public_instances(
                    tuple(sorted(path.rglob("*.csv"))),
                    copies_policy=copies_policy,
                    max_copies_per_type=max_copies_per_type,
                )
            )
        elif path.suffix.lower() == ".csv":
            instances.extend(
                parse_csv_instances(
                    path,
                    copies_policy=copies_policy,
                    max_copies_per_type=max_copies_per_type,
                )
            )
        else:
            text = path.read_text(encoding="utf-8-sig")
            instances.append(
                parse_ins2d(
                    text,
                    name=path.stem,
                    source=str(path),
                    copies_policy=copies_policy,
                    max_copies_per_type=max_copies_per_type,
                )
            )
    return tuple(instances)


def pack_public_instance(
    instance: PublicInstance,
    *,
    scale: float,
    tool: ToolConfig,
    gap: float | None,
) -> Layout:
    if scale <= 0:
        raise ValueError("scale must be positive")
    row_gap = tool.min_channel_width if gap is None else gap
    # Place nominal geometry inside a tool-radius-inflated packing envelope.
    # The compensated outer centerline then returns to the configured trim.
    margin = tool.trim_margin + tool.tool_radius
    source_width = instance.bin_width if instance.bin_width > 0 else 0.0
    target_inner_width = max(
        source_width * scale,
        max((item.width * scale for item in instance.items), default=0.0),
    )
    panel_width = 2.0 * margin + target_inner_width
    x = margin
    y = margin
    row_height = 0.0
    max_x = margin
    rectangles: list[PlacedRectangle] = []
    part_index = 0

    for item in instance.items:
        width = item.width * scale
        height = item.height * scale
        for copy_index in range(item.copies):
            if x > margin and x + width > margin + target_inner_width + 1e-9:
                y += row_height + row_gap
                x = margin
                row_height = 0.0
            part_index += 1
            rectangles.append(
                PlacedRectangle(
                    part_id=f"{item.item_id}_{copy_index + 1}",
                    x=x,
                    y=y,
                    width=width,
                    height=height,
                )
            )
            max_x = max(max_x, x + width)
            x += width + row_gap
            row_height = max(row_height, height)

    generated_height = y + row_height + margin
    public_bin_height = instance.bin_height * scale if instance.bin_height > 0 else 0.0
    panel_height = max(public_bin_height + 2.0 * margin, generated_height)
    panel_width = max(panel_width, max_x + margin)
    return Layout(
        panel_id=f"public_{instance.name}",
        panel_width=panel_width,
        panel_height=panel_height,
        rectangles=tuple(rectangles),
    )


def write_layout(layout: Layout, path: Path) -> None:
    payload = {
        "panel_id": layout.panel_id,
        "panel_width": layout.panel_width,
        "panel_height": layout.panel_height,
        "rectangles": [
            {
                "part_id": rectangle.part_id,
                "x": rectangle.x,
                "y": rectangle.y,
                "width": rectangle.width,
                "height": rectangle.height,
            }
            for rectangle in layout.rectangles
        ],
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def download_ngcut(output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / "NGCUT.zip"
    if not target.exists():
        target.write_bytes(urlopen(NGCUT_URL, timeout=30).read())
    return target


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Convert 2DPackLib-style rectangular instances into fixed-layout JSON "
            "records for planning-level CNC routing benchmarks."
        )
    )
    parser.add_argument("--input", action="append", type=Path, default=[])
    parser.add_argument("--download-ngcut", action="store_true")
    parser.add_argument("--raw-dir", type=Path, default=Path("data/public_benchmarks/raw"))
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data/public_benchmarks/layouts"),
    )
    parser.add_argument("--scale", type=float, default=25.0)
    parser.add_argument("--trim-margin", type=float, default=5.0)
    parser.add_argument("--tool-diameter", type=float, default=6.0)
    parser.add_argument("--safe-clearance", type=float, default=0.0)
    parser.add_argument("--gap", type=float, default=None)
    parser.add_argument(
        "--copies-policy",
        choices=("one", "demand", "upper_bound"),
        default="one",
    )
    parser.add_argument("--max-copies-per-type", type=int, default=3)
    parser.add_argument("--limit", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_paths = list(args.input)
    if args.download_ngcut:
        input_paths.append(download_ngcut(args.raw_dir))
    if not input_paths:
        raise SystemExit("provide --input or --download-ngcut")

    tool = ToolConfig(
        trim_margin=args.trim_margin,
        tool_diameter=args.tool_diameter,
        safe_clearance=args.safe_clearance,
        centerline_boundary_margin=args.tool_diameter / 2.0,
        allow_safe_lift_over_released_parts=True,
        allow_low_clearance_detour=True,
        start_point=Point(args.trim_margin, args.trim_margin),
    )
    instances = iter_public_instances(
        tuple(input_paths),
        copies_policy=args.copies_policy,
        max_copies_per_type=args.max_copies_per_type,
    )
    if args.limit is not None:
        instances = instances[: args.limit]

    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest_rows: list[dict[str, str | int | float]] = []
    for instance in instances:
        layout = pack_public_instance(
            instance,
            scale=args.scale,
            tool=tool,
            gap=args.gap,
        )
        output_path = args.output_dir / f"{layout.panel_id}.json"
        write_layout(layout, output_path)
        manifest_rows.append(
            {
                "layout_file": str(output_path),
                "instance": instance.name,
                "source": instance.source,
                "source_bin_width": instance.bin_width,
                "source_bin_height": instance.bin_height,
                "item_type_count": len(instance.items),
                "rectangle_count": len(layout.rectangles),
                "panel_width": layout.panel_width,
                "panel_height": layout.panel_height,
                "scale": args.scale,
                "gap": tool.min_channel_width if args.gap is None else args.gap,
                "copies_policy": args.copies_policy,
            }
        )

    manifest_path = args.output_dir / "manifest.csv"
    with manifest_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(manifest_rows[0]))
        writer.writeheader()
        writer.writerows(manifest_rows)
    print(f"wrote {len(manifest_rows)} layouts to {args.output_dir}")
    print(f"wrote {manifest_path}")


if __name__ == "__main__":
    main()
