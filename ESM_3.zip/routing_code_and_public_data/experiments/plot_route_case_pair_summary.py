from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.io import (
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.models import Panel
from process_options import add_stability_model_args, add_tool_event_gate_args
from process_options import build_process_model_from_args, build_tool_event_gate_from_args
from visualize_route_comparison import (
    ROOT,
    METHOD_LABELS,
    RouteRun,
    compute_focus_box,
    plot_single_route,
    route_metrics_row,
    run_method,
    write_route_metrics,
)


PRIVATE_DATA_ROOT_ENV = "CHAPTER3_PRIVATE_DATA_DIR"
DEFAULT_PRIVATE_DATA_ROOT = Path(
    os.environ.get(PRIVATE_DATA_ROOT_ENV, ROOT / "data" / "private_archives")
)


@dataclass(frozen=True)
class RouteCaseSpec:
    case_label: str
    archive_name: str
    placements_member: str
    board_id: str
    baseline_method: str = "process_aware_beam"
    final_method: str = "process_aware_beam_adaptive_polished"

    def zip_path(self, data_root: Path) -> Path:
        return data_root / self.archive_name


CASE_SPECS = (
    RouteCaseSpec(
        case_label="Board 340",
        archive_name="review_overnight_20260422.zip",
        placements_member=(
            r"review_overnight_20260422\review_t1_ind_a_5seed_300s"
            r"\review_t1_ind_a_5seed_300s__data1\rh_mcts_prefix_beam"
            r"\seed_1000\placements.csv"
        ),
        board_id="340",
    ),
    RouteCaseSpec(
        case_label="Board 1",
        archive_name="paper_extended_suite_20260321_continuous_run_only_20260324_0001.zip",
        placements_member=(
            "paper_extended_suite_20260321/exp_robust_ind_5seed_1200s/"
            "exp_robust_ind_5seed_1200s__data6/rh_mcts_ref/"
            "seed_1001/placements.csv"
        ),
        board_id="1",
    ),
)


def load_case_runs(
    spec: RouteCaseSpec,
    args: argparse.Namespace,
) -> tuple[object, tuple[RouteRun, RouteRun]]:
    zip_path = spec.zip_path(args.data_root)
    cfg = load_chapter2_config_from_zip(
        zip_path,
        placements_member=spec.placements_member,
    )
    tool = tool_config_from_chapter2_config(cfg)
    layout = load_chapter2_layouts_from_zip(
        zip_path,
        placements_member=spec.placements_member,
        board_ids=(spec.board_id,),
    )[0]
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    process_model = build_process_model_from_args(
        layout,
        args,
        tool=tool,
        max_collinear_gap=tool.min_channel_width,
    )
    tool_event_gate = build_tool_event_gate_from_args(args)
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    runs = tuple(
        run_method(
            method,
            units,
            panel,
            tool,
            process_model,
            tool_event_gate,
            len(layout.rectangles),
        )
        for method in (spec.baseline_method, spec.final_method)
    )
    return layout, runs  # type: ignore[return-value]


def add_compact_route_legend(fig: plt.Figure) -> None:
    handles = [
        plt.Line2D([0], [0], color="#111827", linewidth=0.8, alpha=0.55, label="layout outline"),
        plt.Line2D([0], [0], color="#0072B2", linewidth=1.4, label="shared-edge cut"),
        plt.Line2D([0], [0], color="#009E73", linewidth=1.4, label="near-shared cut"),
        plt.Line2D([0], [0], color="#E69F00", linewidth=1.4, label="collinear chain"),
        plt.Line2D([0], [0], color="#6B7280", linewidth=1.4, label="single-edge cut"),
        plt.Line2D([0], [0], color="#F59E0B", linestyle="--", label="travel"),
        plt.Line2D([0], [0], color="#0891B2", linestyle="--", label="detour"),
        plt.Line2D([0], [0], color="#7C3AED", linestyle="--", label="safe lift"),
    ]
    fig.legend(
        handles=handles,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.025),
        ncol=4,
        frameon=False,
        fontsize=7.2,
        handlelength=2.2,
        columnspacing=1.0,
    )


def plot_case_pair_summary(
    case_data: tuple[tuple[RouteCaseSpec, object, tuple[RouteRun, RouteRun]], ...],
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.05), dpi=300, squeeze=False)
    panel_letters = "ABCD"
    for row_index, (spec, layout, runs) in enumerate(case_data):
        focus_box = compute_focus_box(layout, runs)  # type: ignore[arg-type]
        for col_index, run in enumerate(runs):
            panel_index = row_index * 2 + col_index
            method_label = METHOD_LABELS.get(run.method, run.method)
            title = f"{spec.case_label}: {method_label}"
            plot_single_route(
                axes[row_index][col_index],
                layout,  # type: ignore[arg-type]
                run,
                label_parts=False,
                label_actions=False,
                action_label_stride=20,
                zoom_box=focus_box,
                panel_label=panel_letters[panel_index],
                title=title,
                show_metrics=True,
            )
            if row_index == 0:
                axes[row_index][col_index].set_xlabel("")
                axes[row_index][col_index].tick_params(labelbottom=False)
            if col_index == 1:
                axes[row_index][col_index].set_ylabel("")
                axes[row_index][col_index].tick_params(labelleft=False)

    add_compact_route_legend(fig)
    fig.tight_layout(rect=(0.0, 0.095, 1.0, 1.0), h_pad=0.9, w_pad=0.75)
    fig.savefig(output_path)
    fig.savefig(output_path.with_suffix(".pdf"))
    fig.savefig(output_path.with_suffix(".png"))
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data-root",
        type=Path,
        default=DEFAULT_PRIVATE_DATA_ROOT,
        help=(
            "Directory containing the private production-derived route-case "
            f"archives. Defaults to ${PRIVATE_DATA_ROOT_ENV} or "
            "data/private_archives."
        ),
    )
    parser.add_argument(
        "--figure-output",
        type=Path,
        default=ROOT / "figures" / "paper_artifacts" / "fig_route_case_pair_summary.pdf",
    )
    parser.add_argument(
        "--metrics-output",
        type=Path,
        default=ROOT / "results" / "paper_artifacts" / "route_case_pair_summary_metrics.csv",
    )
    add_stability_model_args(parser)
    add_tool_event_gate_args(parser)
    parser.set_defaults(
        support_policy="all_edges",
        min_support_count=1,
        min_support_ratio=0.75,
        min_area_normalized_support=0.0,
        adjacency_support_weight=1.0,
        tool_event_min_travel_saving=25.0,
        tool_event_min_travel_saving_ratio=0.0,
        tool_event_min_machining_saving=1e-9,
    )
    return parser.parse_args()


def require_archives(case_specs: tuple[RouteCaseSpec, ...], data_root: Path) -> None:
    missing = [
        spec.zip_path(data_root)
        for spec in case_specs
        if not spec.zip_path(data_root).is_file()
    ]
    if not missing:
        return
    paths = "\n".join(f"  - {path}" for path in missing)
    raise SystemExit(
        "Missing private route-case archive(s):\n"
        f"{paths}\n"
        f"Set --data-root or {PRIVATE_DATA_ROOT_ENV} to the directory that "
        "contains these archives."
    )


def main() -> None:
    args = parse_args()
    require_archives(CASE_SPECS, args.data_root)
    case_data = tuple((spec, *load_case_runs(spec, args)) for spec in CASE_SPECS)
    rows = tuple(
        route_metrics_row(
            spec.zip_path(args.data_root),
            spec.placements_member,
            spec.board_id,
            layout,
            run,
        )
        for spec, layout, runs in case_data
        for run in runs
    )
    write_route_metrics(rows, args.metrics_output)
    plot_case_pair_summary(case_data, args.figure_output)
    print(f"metrics: {args.metrics_output}")
    print(f"figure: {args.figure_output}")


if __name__ == "__main__":
    main()
