from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

DEFAULT_OUTPUT_STEM = "chapter3_main_hard_gate25_real_77_20_50"
DEFAULT_TARGET_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_METHODS = (
    "topology_process_aware",
    "process_local_search_multistart",
    "process_aware_beam",
    DEFAULT_TARGET_METHOD,
)
DEFAULT_STAT_METRICS = (
    "process_key",
    "machining_cost",
    "travel_mode_cost",
    "air_move_distance",
    "runtime_ms",
    "process_repeated_span_count",
    "stability_penalty",
    "hard_penalty",
    "detour_count",
)


@dataclass(frozen=True)
class FinalExperimentPaths:
    route_csv: Path
    summary_csv: Path
    bin_summary_csv: Path
    manifest_json: Path
    progress_csv: Path
    statistical_csv: Path
    statistical_md: Path


def final_experiment_paths(
    results_dir: Path,
    output_stem: str | Path,
) -> FinalExperimentPaths:
    base = Path(output_stem)
    if base.parent == Path("."):
        base = results_dir / base.name
    return FinalExperimentPaths(
        route_csv=base.with_suffix(".csv"),
        summary_csv=base.with_name(f"{base.name}_summary.csv"),
        bin_summary_csv=base.with_name(f"{base.name}_bin_summary.csv"),
        manifest_json=base.with_name(f"{base.name}_manifest.json"),
        progress_csv=base.with_name(f"{base.name}_progress.csv"),
        statistical_csv=base.with_name(f"{base.name}_statistical.csv"),
        statistical_md=base.with_name(f"{base.name}_statistical.md"),
    )


def build_batch_command(
    paths: FinalExperimentPaths,
    *,
    python_executable: str,
    zip_paths: tuple[Path, ...],
    methods: tuple[str, ...],
    experiment_preset: str = "paper-main",
    repeat_cut_policy: str = "hard",
    tool_event_gate_enabled: bool = True,
    tool_event_min_travel_saving: float = 25.0,
    tool_event_min_travel_saving_ratio: float = 0.0,
    tool_event_min_machining_saving: float = 1e-9,
    max_members_per_archive: int,
    boards_per_member: int,
    min_rectangles: int,
    max_rectangles: int,
    task_timeout_seconds: float,
    fresh: bool,
    progress_bar: bool,
    algorithm_seed: int | None = None,
) -> list[str]:
    command = [
        python_executable,
        str(ROOT / "experiments" / "run_chapter2_batch.py"),
        "--experiment-preset",
        experiment_preset,
        "--repeat-cut-policy",
        repeat_cut_policy,
        "--tool-event-min-travel-saving",
        f"{tool_event_min_travel_saving:g}",
        "--tool-event-min-travel-saving-ratio",
        f"{tool_event_min_travel_saving_ratio:g}",
        "--tool-event-min-machining-saving",
        f"{tool_event_min_machining_saving:g}",
        "--max-members-per-archive",
        str(max_members_per_archive),
        "--boards-per-member",
        str(boards_per_member),
        "--min-rectangles",
        str(min_rectangles),
        "--max-rectangles",
        str(max_rectangles),
        "--methods",
        *methods,
        "--task-timeout-seconds",
        f"{task_timeout_seconds:g}",
        "--output",
        str(paths.route_csv),
        "--summary-output",
        str(paths.summary_csv),
        "--bin-summary-output",
        str(paths.bin_summary_csv),
        "--manifest-output",
        str(paths.manifest_json),
        "--progress-output",
        str(paths.progress_csv),
    ]
    if algorithm_seed is not None:
        command.extend(("--algorithm-seed", str(algorithm_seed)))
    for zip_path in zip_paths:
        command.extend(("--zip-path", str(zip_path)))
    if not tool_event_gate_enabled:
        command.append("--disable-tool-event-gate")
    if not fresh:
        command.append("--resume")
    if not progress_bar:
        command.append("--no-progress-bar")
    return command


def build_statistical_command(
    paths: FinalExperimentPaths,
    *,
    python_executable: str,
    target_method: str,
    baseline_methods: tuple[str, ...],
    metrics: tuple[str, ...],
    bootstrap_samples: int,
    bootstrap_seed: int,
) -> list[str]:
    return [
        python_executable,
        str(ROOT / "experiments" / "analyze_statistical_robustness.py"),
        "--input",
        str(paths.route_csv),
        "--target-method",
        target_method,
        "--baseline-methods",
        *baseline_methods,
        "--metrics",
        *metrics,
        "--bootstrap-samples",
        str(bootstrap_samples),
        "--bootstrap-seed",
        str(bootstrap_seed),
        "--output",
        str(paths.statistical_csv),
        "--markdown-output",
        str(paths.statistical_md),
    ]


def command_env() -> dict[str, str]:
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH", "")
    src_path = str(ROOT / "src")
    env["PYTHONPATH"] = (
        src_path if not existing_pythonpath else f"{src_path}{os.pathsep}{existing_pythonpath}"
    )
    return env


def run_command(command: list[str], *, dry_run: bool) -> None:
    print(shlex.join(command), flush=True)
    if not dry_run:
        subprocess.run(command, cwd=ROOT, env=command_env(), check=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the fixed Chapter 3 main CNC cutting experiment.",
    )
    parser.add_argument("--results-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--output-stem", default=DEFAULT_OUTPUT_STEM)
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=55)
    parser.add_argument("--boards-per-member", type=int, default=1)
    parser.add_argument("--min-rectangles", type=int, default=20)
    parser.add_argument("--max-rectangles", type=int, default=50)
    parser.add_argument("--task-timeout-seconds", type=float, default=30.0)
    parser.add_argument("--methods", nargs="+", default=list(DEFAULT_METHODS))
    parser.add_argument("--target-method", default=DEFAULT_TARGET_METHOD)
    parser.add_argument(
        "--experiment-preset",
        choices=("paper-main",),
        default="paper-main",
    )
    parser.add_argument(
        "--repeat-cut-policy",
        choices=("hard", "soft", "off"),
        default="hard",
    )
    parser.add_argument("--disable-tool-event-gate", action="store_true")
    parser.add_argument("--tool-event-min-travel-saving", type=float, default=25.0)
    parser.add_argument("--tool-event-min-travel-saving-ratio", type=float, default=0.0)
    parser.add_argument("--tool-event-min-machining-saving", type=float, default=1e-9)
    parser.add_argument("--bootstrap-samples", type=int, default=2000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260522)
    parser.add_argument("--fresh", action="store_true", help="Overwrite existing CSVs.")
    parser.add_argument("--progress-bar", action="store_true")
    parser.add_argument("--skip-batch", action="store_true")
    parser.add_argument("--skip-statistics", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    methods = tuple(args.methods)
    if args.target_method not in methods:
        raise ValueError("--target-method must be included in --methods")
    baseline_methods = tuple(method for method in methods if method != args.target_method)
    if not baseline_methods:
        raise ValueError("at least one baseline method is required")

    paths = final_experiment_paths(args.results_dir, args.output_stem)
    paths.route_csv.parent.mkdir(parents=True, exist_ok=True)
    python_executable = sys.executable

    if not args.skip_batch:
        run_command(
            build_batch_command(
                paths,
                python_executable=python_executable,
                zip_paths=tuple(args.zip_paths or ()),
                methods=methods,
                experiment_preset=args.experiment_preset,
                repeat_cut_policy=args.repeat_cut_policy,
                tool_event_gate_enabled=not args.disable_tool_event_gate,
                tool_event_min_travel_saving=args.tool_event_min_travel_saving,
                tool_event_min_travel_saving_ratio=(
                    args.tool_event_min_travel_saving_ratio
                ),
                tool_event_min_machining_saving=args.tool_event_min_machining_saving,
                max_members_per_archive=args.max_members_per_archive,
                boards_per_member=args.boards_per_member,
                min_rectangles=args.min_rectangles,
                max_rectangles=args.max_rectangles,
                task_timeout_seconds=args.task_timeout_seconds,
                fresh=args.fresh,
                progress_bar=args.progress_bar,
            ),
            dry_run=args.dry_run,
        )
    if not args.skip_statistics:
        run_command(
            build_statistical_command(
                paths,
                python_executable=python_executable,
                target_method=args.target_method,
                baseline_methods=baseline_methods,
                metrics=DEFAULT_STAT_METRICS,
                bootstrap_samples=args.bootstrap_samples,
                bootstrap_seed=args.bootstrap_seed,
            ),
            dry_run=args.dry_run,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
