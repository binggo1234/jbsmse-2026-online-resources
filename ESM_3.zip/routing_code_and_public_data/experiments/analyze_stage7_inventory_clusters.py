from __future__ import annotations

import argparse
import csv
import random
import re
from collections import defaultdict
from dataclasses import asdict, dataclass
from math import comb
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_STAGE7 = ROOT / "results" / "corrected_model_stage7_kerf"
TARGET_METHOD = "process_aware_beam_adaptive_polished"
COMPARISONS = (
    ("topology_process_aware", "Process-aware topology"),
    ("process_local_search_multistart", "Multi-start process LS"),
    ("process_aware_beam", "Ordinary process-aware beam"),
    ("process_aware_sa", "Process-aware SA"),
    ("process_aware_ga", "Process-aware GA"),
    ("process_aware_prefix_beam_mcts", "Prefix Beam MCTS"),
)
METRICS = (
    ("cplan", r"$C_{\mathrm{plan}}$"),
    ("travel_mode_cost", r"$C_{\mathrm{travel}}$"),
)


@dataclass(frozen=True)
class InventoryRow:
    baseline_method: str
    baseline_label: str
    target_method: str
    metric: str
    inventory_sha256: str
    layout_instances: int
    baseline_mean: float
    target_mean: float
    mean_paired_reduction_pct: float
    layout_wins: int
    layout_ties: int
    layout_losses: int


@dataclass(frozen=True)
class SummaryRow:
    baseline_method: str
    baseline_label: str
    target_method: str
    metric: str
    inventory_clusters: int
    layout_instances: int
    layout_weighted_mean_reduction_pct: float
    inventory_equal_mean_reduction_pct: float
    cluster_bootstrap_ci95_low: float
    cluster_bootstrap_ci95_high: float
    inventory_wins: int
    inventory_ties: int
    inventory_losses: int
    inventory_sign_test_p: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Inventory-clustered inference for the Stage 7 layout cohort."
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=DEFAULT_STAGE7 / "kerf_layouts" / "stage7_kerf_layout_manifest.csv",
    )
    parser.add_argument(
        "--main",
        type=Path,
        default=DEFAULT_STAGE7 / "formal" / "chapter3_stage7_main.csv",
    )
    parser.add_argument(
        "--external",
        type=Path,
        default=DEFAULT_STAGE7
        / "formal"
        / "chapter3_stage7_external_baselines.csv",
    )
    parser.add_argument(
        "--mcts",
        type=Path,
        default=DEFAULT_STAGE7 / "formal" / "chapter3_stage7_prefix_mcts.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_STAGE7 / "inventory_clustered_statistics",
    )
    parser.add_argument("--bootstrap-samples", type=int, default=20000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260711)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def record_id(row: dict[str, str]) -> str:
    match = re.search(r"(record_\d+)", row["placements_member"])
    if match is None:
        raise ValueError(f"cannot infer Stage 7 record from {row['placements_member']}")
    return match.group(1)


def metric_value(row: dict[str, str], metric: str) -> float:
    if metric == "cplan":
        return float(row["cutting_length"]) + float(row["travel_mode_cost"])
    return float(row[metric])


def reduction_pct(baseline: float, target: float) -> float:
    if abs(baseline) <= 1e-12:
        return 0.0 if abs(target) <= 1e-12 else -100.0
    return 100.0 * (baseline - target) / abs(baseline)


def compare(delta: float, tolerance: float = 1e-9) -> str:
    if delta > tolerance:
        return "win"
    if delta < -tolerance:
        return "loss"
    return "tie"


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def cluster_bootstrap_ci(
    cluster_values: list[float],
    *,
    samples: int,
    seed: int,
) -> tuple[float, float]:
    generator = random.Random(seed)
    size = len(cluster_values)
    bootstrapped = [
        mean(cluster_values[generator.randrange(size)] for _ in range(size))
        for _ in range(samples)
    ]
    return percentile(bootstrapped, 0.025), percentile(bootstrapped, 0.975)


def exact_sign_test_p(wins: int, losses: int) -> float:
    trials = wins + losses
    if trials == 0:
        return 1.0
    observed = min(wins, losses)
    lower_tail = sum(comb(trials, k) for k in range(observed + 1)) / (2**trials)
    return min(1.0, 2.0 * lower_tail)


def write_csv(path: Path, rows: list[object]) -> None:
    payload = [asdict(row) for row in rows]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(payload[0]))
        writer.writeheader()
        writer.writerows(payload)


def write_latex(path: Path, rows: list[SummaryRow]) -> None:
    cplan_rows = [row for row in rows if row.metric == "cplan"]
    lines = [
        r"\begin{table}[htbp]",
        r"\centering",
        r"\caption{Inventory-clustered robustness of the Stage~7 comparisons. The 77 layouts are descriptive instances algorithmically repacked from four distinct production part inventories. Means weight the four inventories equally; confidence intervals resample inventory-level mean reductions. W/T/L and the two-sided sign test also use the inventory as the independent unit.}",
        r"\label{tab:inventory-clustered-robustness}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3.0pt}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lrrrrr@{}}",
        r"\toprule",
        r"Comparator & Layouts & Inventories & $\Delta C_{\mathrm{plan}}$ (95\% CI) & Inventory W/T/L & $p$ \\",
        r"\midrule",
    ]
    for row in cplan_rows:
        lines.append(
            f"{row.baseline_label} & {row.layout_instances} & "
            f"{row.inventory_clusters} & "
            f"{row.inventory_equal_mean_reduction_pct:.2f}\\% "
            f"({row.cluster_bootstrap_ci95_low:.2f}, "
            f"{row.cluster_bootstrap_ci95_high:.2f}) & "
            f"{row.inventory_wins}/{row.inventory_ties}/{row.inventory_losses} & "
            f"{row.inventory_sign_test_p:.3f} \\\\"
        )
    lines.extend(
        (
            r"\bottomrule",
            r"\end{tabular*}",
            r"\end{table}",
            "",
        )
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    manifest = read_csv(args.manifest)
    inventory_by_record = {
        row["record_id"]: row["inventory_sha256"] for row in manifest
    }
    if len(set(inventory_by_record.values())) != 4:
        raise ValueError("expected four distinct Stage 7 inventory hashes")

    method_rows: dict[str, dict[str, dict[str, str]]] = defaultdict(dict)
    for path in (args.main, args.external, args.mcts):
        for row in read_csv(path):
            method_rows[row["method"]][record_id(row)] = row

    inventory_rows: list[InventoryRow] = []
    summary_rows: list[SummaryRow] = []
    for comparison_index, (baseline_method, baseline_label) in enumerate(COMPARISONS):
        baseline_by_record = method_rows[baseline_method]
        target_by_record = method_rows[TARGET_METHOD]
        common_records = sorted(set(baseline_by_record) & set(target_by_record))
        if len(common_records) != 77:
            raise ValueError(
                f"{baseline_method} has {len(common_records)} paired Stage 7 records"
            )
        for metric_index, (metric, _metric_label) in enumerate(METRICS):
            grouped: dict[str, list[tuple[float, float, float]]] = defaultdict(list)
            layout_reductions: list[float] = []
            for current_record in common_records:
                baseline = metric_value(baseline_by_record[current_record], metric)
                target = metric_value(target_by_record[current_record], metric)
                reduction = reduction_pct(baseline, target)
                grouped[inventory_by_record[current_record]].append(
                    (baseline, target, reduction)
                )
                layout_reductions.append(reduction)

            current_inventory_rows: list[InventoryRow] = []
            for inventory_sha256, values in sorted(grouped.items()):
                outcomes = [compare(baseline - target) for baseline, target, _ in values]
                current_inventory_rows.append(
                    InventoryRow(
                        baseline_method=baseline_method,
                        baseline_label=baseline_label,
                        target_method=TARGET_METHOD,
                        metric=metric,
                        inventory_sha256=inventory_sha256,
                        layout_instances=len(values),
                        baseline_mean=mean(value[0] for value in values),
                        target_mean=mean(value[1] for value in values),
                        mean_paired_reduction_pct=mean(value[2] for value in values),
                        layout_wins=outcomes.count("win"),
                        layout_ties=outcomes.count("tie"),
                        layout_losses=outcomes.count("loss"),
                    )
                )
            inventory_rows.extend(current_inventory_rows)

            cluster_reductions = [
                row.mean_paired_reduction_pct for row in current_inventory_rows
            ]
            cluster_outcomes = [compare(value) for value in cluster_reductions]
            ci_low, ci_high = cluster_bootstrap_ci(
                cluster_reductions,
                samples=args.bootstrap_samples,
                seed=args.bootstrap_seed + 101 * comparison_index + metric_index,
            )
            wins = cluster_outcomes.count("win")
            losses = cluster_outcomes.count("loss")
            summary_rows.append(
                SummaryRow(
                    baseline_method=baseline_method,
                    baseline_label=baseline_label,
                    target_method=TARGET_METHOD,
                    metric=metric,
                    inventory_clusters=len(current_inventory_rows),
                    layout_instances=len(common_records),
                    layout_weighted_mean_reduction_pct=mean(layout_reductions),
                    inventory_equal_mean_reduction_pct=mean(cluster_reductions),
                    cluster_bootstrap_ci95_low=ci_low,
                    cluster_bootstrap_ci95_high=ci_high,
                    inventory_wins=wins,
                    inventory_ties=cluster_outcomes.count("tie"),
                    inventory_losses=losses,
                    inventory_sign_test_p=exact_sign_test_p(wins, losses),
                )
            )

    write_csv(args.output_dir / "stage7_inventory_rows.csv", inventory_rows)
    write_csv(args.output_dir / "stage7_inventory_summary.csv", summary_rows)
    write_latex(
        args.output_dir / "table_inventory_clustered_robustness.tex",
        summary_rows,
    )
    print(f"inventory_clusters={len(set(inventory_by_record.values()))}")
    print(f"summary={args.output_dir / 'stage7_inventory_summary.csv'}")


if __name__ == "__main__":
    main()
