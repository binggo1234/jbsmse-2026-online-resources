from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean, pstdev
from time import perf_counter

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.exact_dp import ExactDPConfig, exact_process_dp_order
from cnc_cutting.io import (
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.local_search import process_metric_key
from cnc_cutting.models import Layout, Panel, PathMetrics
from cnc_cutting.optimizer import RoutePlan, select_coverage_units
from process_options import (
    add_experiment_preset_arg,
    add_repeat_cut_policy_args,
    add_stability_model_args,
    add_tool_event_gate_args,
    apply_experiment_preset,
    build_process_model_from_args,
    build_tool_event_gate_from_args,
    repeat_cut_policy_from_args,
)
from run_chapter2_batch import (
    DEFAULT_ARCHIVES,
    DEFAULT_METHODS as CHAPTER2_METHODS,
    build_planners,
    board_counts_from_zip,
    parse_member_metadata,
    sample_placement_members,
    select_board_ids,
)


ROOT = Path(__file__).resolve().parents[1]

DEFAULT_OUTPUT = ROOT / "results" / "chapter3_optimality_gap_small_real_8_12.csv"
DEFAULT_SUMMARY_OUTPUT = (
    ROOT / "results" / "chapter3_optimality_gap_small_real_8_12_summary.csv"
)
DEFAULT_TARGET_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_METHODS = (
    "greedy",
    "path_distance_local_search",
    "topology",
    "topology_process_aware",
    "process_local_search_multistart",
    "process_aware_beam",
    DEFAULT_TARGET_METHOD,
)
DEFAULT_REFERENCE_METHODS = (
    "process_local_search_multistart",
    "process_aware_beam",
    "process_aware_beam_polished",
    "process_aware_beam_adaptive",
    DEFAULT_TARGET_METHOD,
)
REFERENCE_EXACT = "exact_dp"
REFERENCE_PORTFOLIO = "portfolio_upper_bound"


@dataclass(frozen=True)
class TimedPlan:
    method: str
    plan: RoutePlan
    runtime_ms: float


@dataclass(frozen=True)
class ReferencePlan:
    kind: str
    method: str
    metrics: PathMetrics
    action_count: int | None
    runtime_ms: float
    exact_expanded_nodes: int | None
    exact_retained_states: int | None


@dataclass(frozen=True)
class OptimalityGapRow:
    archive: str
    case_name: str
    placement_method: str
    seed: str
    placements_member: str
    board_id: str
    method: str
    reference_kind: str
    reference_method: str
    reference_is_exact: bool
    rectangle_count: int
    candidate_unit_count: int
    selected_unit_count: int
    action_count: int
    runtime_ms: float
    reference_runtime_ms: float
    exact_expanded_nodes: int | None
    exact_retained_states: int | None
    hard_penalty: float
    stability_penalty: float
    repeated_cut_segment_count: int
    repeated_cut_length: float
    redundant_cut_action_count: int
    travel_mode_cost: float
    machining_cost: float
    air_move_distance: float
    tool_event_count: int
    reference_hard_penalty: float
    reference_stability_penalty: float
    reference_repeated_cut_segment_count: int
    reference_repeated_cut_length: float
    reference_redundant_cut_action_count: int
    reference_travel_mode_cost: float
    reference_machining_cost: float
    travel_mode_cost_gap: float
    machining_cost_gap: float
    travel_mode_cost_gap_ratio: float
    travel_gap_comparable: bool
    comparable_travel_mode_cost_gap: float | None
    comparable_travel_mode_cost_gap_ratio: float | None
    process_key_winner: str


@dataclass(frozen=True)
class OptimalityGapSummaryRow:
    reference_kind: str
    method: str
    n: int
    rectangle_count_mean: float
    selected_unit_count_mean: float
    runtime_ms_mean: float
    runtime_ms_std: float
    travel_mode_cost_mean: float
    travel_mode_cost_gap_mean: float
    travel_mode_cost_gap_ratio_mean: float
    comparable_case_count: int
    comparable_travel_mode_cost_gap_mean: float | None
    comparable_travel_mode_cost_gap_ratio_mean: float | None
    machining_cost_gap_mean: float
    hard_penalty_mean: float
    stability_penalty_mean: float
    process_key_tie_count: int
    process_key_loss_count: int


def tool_event_count(metrics: PathMetrics) -> int:
    return metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count


def process_key_winner(
    metrics: PathMetrics,
    reference_metrics: PathMetrics,
    repeat_cut_policy: str,
) -> str:
    key = process_metric_key(metrics, repeat_cut_policy=repeat_cut_policy)
    reference_key = process_metric_key(
        reference_metrics,
        repeat_cut_policy=repeat_cut_policy,
    )
    if key < reference_key:
        return "method"
    if key > reference_key:
        return "reference"
    return "tie"


def travel_gap_comparable(
    metrics: PathMetrics,
    reference_metrics: PathMetrics,
) -> bool:
    return (
        abs(metrics.hard_penalty - reference_metrics.hard_penalty) < 1e-9
        and abs(metrics.stability_penalty - reference_metrics.stability_penalty) < 1e-9
        and metrics.repeated_cut_segment_count
        == reference_metrics.repeated_cut_segment_count
        and abs(metrics.repeated_cut_length - reference_metrics.repeated_cut_length)
        < 1e-9
        and metrics.redundant_cut_action_count
        == reference_metrics.redundant_cut_action_count
    )


def timed_plan(
    method: str,
    units,
    panel: Panel,
    tool,
    process_model,
    tool_event_gate,
    size: int,
    repeat_cut_policy: str,
) -> TimedPlan:
    planner = build_planners(
        (method,),
        units,
        panel,
        tool,
        process_model,
        tool_event_gate,
        size,
        repeat_cut_policy,
    )[0]
    start = perf_counter()
    plan = planner.planner()
    runtime_ms = (perf_counter() - start) * 1000.0
    return TimedPlan(method=method, plan=plan, runtime_ms=runtime_ms)


def reference_kind_for_unit_count(
    selected_unit_count: int,
    max_exact_units: int,
    allow_portfolio_reference: bool,
) -> str | None:
    if selected_unit_count <= max_exact_units:
        return REFERENCE_EXACT
    if allow_portfolio_reference:
        return REFERENCE_PORTFOLIO
    return None


def build_reference_plan(
    *,
    selected_units,
    units,
    panel: Panel,
    tool,
    process_model,
    tool_event_gate,
    layout: Layout,
    args: argparse.Namespace,
    plan_cache: dict[str, TimedPlan],
) -> ReferencePlan | None:
    repeat_cut_policy = repeat_cut_policy_from_args(args)
    reference_kind = reference_kind_for_unit_count(
        len(selected_units),
        args.max_exact_units,
        args.allow_portfolio_reference,
    )
    if reference_kind is None:
        return None

    if reference_kind == REFERENCE_EXACT:
        start = perf_counter()
        exact = exact_process_dp_order(
            selected_units,
            panel,
            tool,
            process_model=process_model,
            config=ExactDPConfig(
                max_units=args.max_exact_units,
                repeat_cut_policy=repeat_cut_policy,
            ),
        )
        runtime_ms = (perf_counter() - start) * 1000.0
        return ReferencePlan(
            kind=REFERENCE_EXACT,
            method="exact_process_dp",
            metrics=exact.metrics,
            action_count=len(exact.actions),
            runtime_ms=runtime_ms,
            exact_expanded_nodes=exact.expanded_nodes,
            exact_retained_states=exact.retained_states,
        )

    reference_methods = tuple(args.reference_methods)
    for method in reference_methods:
        if method not in plan_cache:
            plan_cache[method] = timed_plan(
                method,
                units,
                panel,
                tool,
                process_model,
                tool_event_gate,
                len(layout.rectangles),
                repeat_cut_policy,
            )

    best = min(
        (plan_cache[method] for method in reference_methods),
        key=lambda item: process_metric_key(
            item.plan.metrics,
            repeat_cut_policy=repeat_cut_policy,
        ),
    )
    return ReferencePlan(
        kind=REFERENCE_PORTFOLIO,
        method=best.method,
        metrics=best.plan.metrics,
        action_count=len(best.plan.actions),
        runtime_ms=sum(plan_cache[method].runtime_ms for method in reference_methods),
        exact_expanded_nodes=None,
        exact_retained_states=None,
    )


def row_from_metrics(
    *,
    archive: Path,
    placements_member: str,
    board_id: str,
    method: str,
    layout: Layout,
    candidate_unit_count: int,
    selected_unit_count: int,
    action_count: int,
    runtime_ms: float,
    metrics: PathMetrics,
    reference: ReferencePlan,
    repeat_cut_policy: str,
) -> OptimalityGapRow:
    case_name, placement_method, seed = parse_member_metadata(placements_member)
    travel_gap = metrics.travel_mode_cost - reference.metrics.travel_mode_cost
    machining_gap = metrics.machining_cost - reference.metrics.machining_cost
    travel_gap_ratio = (
        travel_gap / reference.metrics.travel_mode_cost
        if reference.metrics.travel_mode_cost > 1e-9
        else 0.0
    )
    comparable = travel_gap_comparable(metrics, reference.metrics)
    return OptimalityGapRow(
        archive=archive.name,
        case_name=case_name,
        placement_method=placement_method,
        seed=seed,
        placements_member=placements_member,
        board_id=board_id,
        method=method,
        reference_kind=reference.kind,
        reference_method=reference.method,
        reference_is_exact=reference.kind == REFERENCE_EXACT,
        rectangle_count=len(layout.rectangles),
        candidate_unit_count=candidate_unit_count,
        selected_unit_count=selected_unit_count,
        action_count=action_count,
        runtime_ms=runtime_ms,
        reference_runtime_ms=reference.runtime_ms,
        exact_expanded_nodes=reference.exact_expanded_nodes,
        exact_retained_states=reference.exact_retained_states,
        hard_penalty=metrics.hard_penalty,
        stability_penalty=metrics.stability_penalty,
        repeated_cut_segment_count=metrics.repeated_cut_segment_count,
        repeated_cut_length=metrics.repeated_cut_length,
        redundant_cut_action_count=metrics.redundant_cut_action_count,
        travel_mode_cost=metrics.travel_mode_cost,
        machining_cost=metrics.machining_cost,
        air_move_distance=metrics.air_move_distance,
        tool_event_count=tool_event_count(metrics),
        reference_hard_penalty=reference.metrics.hard_penalty,
        reference_stability_penalty=reference.metrics.stability_penalty,
        reference_repeated_cut_segment_count=(
            reference.metrics.repeated_cut_segment_count
        ),
        reference_repeated_cut_length=reference.metrics.repeated_cut_length,
        reference_redundant_cut_action_count=(
            reference.metrics.redundant_cut_action_count
        ),
        reference_travel_mode_cost=reference.metrics.travel_mode_cost,
        reference_machining_cost=reference.metrics.machining_cost,
        travel_mode_cost_gap=travel_gap,
        machining_cost_gap=machining_gap,
        travel_mode_cost_gap_ratio=travel_gap_ratio,
        travel_gap_comparable=comparable,
        comparable_travel_mode_cost_gap=travel_gap if comparable else None,
        comparable_travel_mode_cost_gap_ratio=(
            travel_gap_ratio if comparable else None
        ),
        process_key_winner=process_key_winner(
            metrics,
            reference.metrics,
            repeat_cut_policy=repeat_cut_policy,
        ),
    )


def run_case(
    archive: Path,
    placements_member: str,
    board_id: str,
    methods: tuple[str, ...],
    args: argparse.Namespace,
) -> tuple[OptimalityGapRow, ...]:
    cfg = load_chapter2_config_from_zip(archive, placements_member=placements_member)
    tool = tool_config_from_chapter2_config(cfg)
    layout = load_chapter2_layouts_from_zip(
        archive,
        placements_member=placements_member,
        board_ids=(board_id,),
    )[0]
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    process_model = build_process_model_from_args(layout, args)
    tool_event_gate = build_tool_event_gate_from_args(args)
    repeat_cut_policy = repeat_cut_policy_from_args(args)
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    selected_units = select_coverage_units(
        units,
        repeat_cut_policy=repeat_cut_policy,
    )
    plan_cache: dict[str, TimedPlan] = {}
    reference = build_reference_plan(
        selected_units=selected_units,
        units=units,
        panel=panel,
        tool=tool,
        process_model=process_model,
        tool_event_gate=tool_event_gate,
        layout=layout,
        args=args,
        plan_cache=plan_cache,
    )
    if reference is None:
        print(
            f"    skip reference: board={board_id} rectangles={len(layout.rectangles)} "
            f"selected_units={len(selected_units)} max_exact_units={args.max_exact_units}"
        )
        return ()

    rows: list[OptimalityGapRow] = []
    if reference.kind == REFERENCE_EXACT:
        rows.append(
            row_from_metrics(
                archive=archive,
                placements_member=placements_member,
                board_id=board_id,
                method="exact_process_dp",
                layout=layout,
                candidate_unit_count=len(units),
                selected_unit_count=len(selected_units),
                action_count=reference.action_count or 0,
                runtime_ms=reference.runtime_ms,
                metrics=reference.metrics,
                reference=reference,
                repeat_cut_policy=repeat_cut_policy,
            )
        )

    for method in methods:
        if method == "exact_process_dp":
            continue
        if method not in plan_cache:
            plan_cache[method] = timed_plan(
                method,
                units,
                panel,
                tool,
                process_model,
                tool_event_gate,
                len(layout.rectangles),
                repeat_cut_policy,
            )
        timed = plan_cache[method]
        rows.append(
            row_from_metrics(
                archive=archive,
                placements_member=placements_member,
                board_id=board_id,
                method=method,
                layout=layout,
                candidate_unit_count=len(units),
                selected_unit_count=len(timed.plan.selected_units),
                action_count=len(timed.plan.actions),
                runtime_ms=timed.runtime_ms,
                metrics=timed.plan.metrics,
                reference=reference,
                repeat_cut_policy=repeat_cut_policy,
            )
        )
    return tuple(rows)


def write_rows(rows: tuple[OptimalityGapRow, ...], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def summarize_rows(
    rows: tuple[OptimalityGapRow, ...],
) -> tuple[OptimalityGapSummaryRow, ...]:
    grouped: dict[tuple[str, str], list[OptimalityGapRow]] = {}
    for row in rows:
        grouped.setdefault((row.reference_kind, row.method), []).append(row)

    summary: list[OptimalityGapSummaryRow] = []
    for (reference_kind, method), items in sorted(grouped.items()):
        comparable_items = [row for row in items if row.travel_gap_comparable]
        summary.append(
            OptimalityGapSummaryRow(
                reference_kind=reference_kind,
                method=method,
                n=len(items),
                rectangle_count_mean=mean(row.rectangle_count for row in items),
                selected_unit_count_mean=mean(row.selected_unit_count for row in items),
                runtime_ms_mean=mean(row.runtime_ms for row in items),
                runtime_ms_std=(
                    pstdev(row.runtime_ms for row in items)
                    if len(items) > 1
                    else 0.0
                ),
                travel_mode_cost_mean=mean(row.travel_mode_cost for row in items),
                travel_mode_cost_gap_mean=mean(
                    row.travel_mode_cost_gap for row in items
                ),
                travel_mode_cost_gap_ratio_mean=mean(
                    row.travel_mode_cost_gap_ratio for row in items
                ),
                comparable_case_count=len(comparable_items),
                comparable_travel_mode_cost_gap_mean=(
                    mean(
                        row.comparable_travel_mode_cost_gap
                        for row in comparable_items
                        if row.comparable_travel_mode_cost_gap is not None
                    )
                    if comparable_items
                    else None
                ),
                comparable_travel_mode_cost_gap_ratio_mean=(
                    mean(
                        row.comparable_travel_mode_cost_gap_ratio
                        for row in comparable_items
                        if row.comparable_travel_mode_cost_gap_ratio is not None
                    )
                    if comparable_items
                    else None
                ),
                machining_cost_gap_mean=mean(row.machining_cost_gap for row in items),
                hard_penalty_mean=mean(row.hard_penalty for row in items),
                stability_penalty_mean=mean(row.stability_penalty for row in items),
                process_key_tie_count=sum(
                    1 for row in items if row.process_key_winner == "tie"
                ),
                process_key_loss_count=sum(
                    1 for row in items if row.process_key_winner == "reference"
                ),
            )
        )
    return tuple(summary)


def write_summary(
    rows: tuple[OptimalityGapSummaryRow, ...],
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run small-scale optimality-gap cases against exact DP when possible "
            "and a strong portfolio reference otherwise."
        )
    )
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=2)
    parser.add_argument("--boards-per-member", type=int, default=2)
    parser.add_argument("--min-rectangles", type=int, default=8)
    parser.add_argument("--max-rectangles", type=int, default=12)
    parser.add_argument("--max-exact-units", type=int, default=12)
    parser.add_argument(
        "--allow-portfolio-reference",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Use the best route found by reference methods when the selected "
            "cutting-unit count exceeds the exact-DP cap."
        ),
    )
    parser.add_argument(
        "--methods",
        nargs="+",
        choices=("exact_process_dp", *CHAPTER2_METHODS),
        default=list(DEFAULT_METHODS),
    )
    parser.add_argument(
        "--reference-methods",
        nargs="+",
        choices=CHAPTER2_METHODS,
        default=list(DEFAULT_REFERENCE_METHODS),
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--summary-output", type=Path, default=DEFAULT_SUMMARY_OUTPUT)
    add_experiment_preset_arg(parser)
    add_stability_model_args(parser)
    add_tool_event_gate_args(parser)
    add_repeat_cut_policy_args(parser)
    return apply_experiment_preset(parser.parse_args())


def main() -> None:
    args = parse_args()
    archives = tuple(args.zip_paths) if args.zip_paths else DEFAULT_ARCHIVES
    methods = tuple(args.methods)
    rows: list[OptimalityGapRow] = []

    for archive in archives:
        members = sample_placement_members(archive, args.max_members_per_archive)
        print(f"archive: {archive.name}, sampled_members={len(members)}")
        for member in members:
            counts = board_counts_from_zip(archive, member)
            board_ids = select_board_ids(
                counts,
                boards_per_member=args.boards_per_member,
                min_rectangles=args.min_rectangles,
                max_rectangles=args.max_rectangles,
            )
            print(
                f"  member: {member} boards={','.join(board_ids) if board_ids else 'none'}"
            )
            for board_id in board_ids:
                case_rows = run_case(archive, member, board_id, methods, args)
                rows.extend(case_rows)
                for row in case_rows:
                    print(
                        f"    {row.method:<36} board={board_id} "
                        f"ref={row.reference_kind}:{row.reference_method:<36} "
                        f"runtime={row.runtime_ms:>8.3f} ms "
                        f"gap={row.travel_mode_cost_gap:>9.3f}"
                    )

    if not rows:
        raise ValueError("no optimality-gap rows produced; relax filters")

    output_rows = tuple(rows)
    summary_rows = summarize_rows(output_rows)
    write_rows(output_rows, args.output)
    write_summary(summary_rows, args.summary_output)
    print(f"wrote: {args.output}")
    print(f"wrote: {args.summary_output}")


if __name__ == "__main__":
    main()
