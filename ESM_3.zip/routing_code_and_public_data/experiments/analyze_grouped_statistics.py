from __future__ import annotations

import argparse
import csv
import random
from collections import defaultdict
from dataclasses import dataclass
from math import comb
from pathlib import Path
from statistics import mean, median, pstdev
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RESULTS = (
    ROOT
    / "results"
    / "chapter3_main_hard_gate25_real_77_20_50_protected_portfolio_v2.csv"
)
DEFAULT_AUDIT = ROOT / "results" / "chapter3_layout_independence_audit.csv"
DEFAULT_UNIT_OUTPUT = ROOT / "results" / "chapter3_grouped_statistics_units.csv"
DEFAULT_METHOD_OUTPUT = ROOT / "results" / "chapter3_grouped_statistics_method_summary.csv"
DEFAULT_COMPARISON_OUTPUT = ROOT / "results" / "chapter3_grouped_statistics_comparison.csv"
DEFAULT_MARKDOWN_OUTPUT = ROOT / "docs" / "chapter3_grouped_statistics_summary.md"

TARGET_METHOD = "process_aware_beam_adaptive_polished"
BASELINE_METHODS = (
    "topology_process_aware",
    "process_local_search_multistart",
    "process_aware_beam",
)
GROUPING_UNITS = ("record", "geometry", "board_group", "source_case")
SUMMARY_METRICS = (
    "machining_cost",
    "travel_mode_cost",
    "air_move_distance",
    "tool_event_count",
    "detour_count",
    "runtime_ms",
    "hard_penalty",
    "stability_penalty",
)
COMPARISON_METRICS = (
    "process_key",
    "machining_cost",
    "travel_mode_cost",
    "air_move_distance",
    "tool_event_count",
    "detour_count",
    "runtime_ms",
    "hard_penalty",
    "stability_penalty",
)
HARD_PROCESS_KEY_FIELDS = (
    "hard_penalty",
    "stability_penalty",
    "process_repeated_span_count",
    "process_repeated_span_length",
    "process_redundant_action_count",
    "machining_cost",
    "process_tool_event_count",
    "travel_mode_cost",
    "air_move_distance",
    "process_turn_penalty",
    "process_negative_continuity_reward",
)


@dataclass(frozen=True)
class ResultRow:
    values: dict[str, str]
    case_id: str
    method: str

    def number(self, field: str, default: float = 0.0) -> float:
        if field == "machining_cost":
            return self.number("cutting_length", default) + self.number(
                "travel_mode_cost",
                default,
            )
        if field == "tool_event_count":
            return (
                self.number("pierce_count", default)
                + self.number("lift_count", default)
                + self.number("safe_lift_count", default)
            )
        if field == "negative_continuity_reward":
            return -self.number("continuity_reward", default)
        value = self.values.get(field, "")
        if value == "":
            return default
        try:
            return float(value)
        except ValueError:
            return default


@dataclass(frozen=True)
class AuditRecord:
    case_id: str
    geometry_signature: str
    board_group: str
    source_case: str


@dataclass(frozen=True)
class UnitMethodRow:
    grouping_unit: str
    unit_id: str
    source_case_count: int
    board_group_count: int
    geometry_count: int
    record_count: int
    method: str
    values: dict[str, float]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compute record-level, geometry-deduplicated, board-grouped, and "
            "source-case grouped statistics for the Chapter 3 main experiment."
        )
    )
    parser.add_argument("--results", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--audit", type=Path, default=DEFAULT_AUDIT)
    parser.add_argument("--target-method", default=TARGET_METHOD)
    parser.add_argument(
        "--baseline-methods",
        nargs="+",
        default=BASELINE_METHODS,
    )
    parser.add_argument(
        "--summary-metrics",
        nargs="+",
        default=SUMMARY_METRICS,
    )
    parser.add_argument(
        "--comparison-metrics",
        nargs="+",
        default=COMPARISON_METRICS,
    )
    parser.add_argument("--bootstrap-samples", type=int, default=4000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260608)
    parser.add_argument("--unit-output", type=Path, default=DEFAULT_UNIT_OUTPUT)
    parser.add_argument("--method-output", type=Path, default=DEFAULT_METHOD_OUTPUT)
    parser.add_argument(
        "--comparison-output",
        type=Path,
        default=DEFAULT_COMPARISON_OUTPUT,
    )
    parser.add_argument(
        "--markdown-output",
        type=Path,
        default=DEFAULT_MARKDOWN_OUTPUT,
    )
    return parser.parse_args()


def build_case_id(row: dict[str, str]) -> str:
    return "|".join(
        row.get(field, "")
        for field in ("archive", "placements_member", "board_id")
    )


def read_results(path: Path) -> tuple[ResultRow, ...]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty result CSV: {path}")
        required = {"archive", "placements_member", "board_id", "method"}
        missing = required.difference(reader.fieldnames)
        if missing:
            raise ValueError(f"{path} is missing required fields: {sorted(missing)}")
        rows = [
            ResultRow(row, build_case_id(row), row["method"])
            for row in reader
            if row.get("method", "")
        ]
    if not rows:
        raise ValueError(f"no method rows found in {path}")
    return tuple(rows)


def read_audit(path: Path) -> dict[str, AuditRecord]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty audit CSV: {path}")
        required = {
            "case_id",
            "geometry_signature",
            "board_group",
            "case_name",
        }
        missing = required.difference(reader.fieldnames)
        if missing:
            raise ValueError(f"{path} is missing required fields: {sorted(missing)}")
        records = {
            row["case_id"]: AuditRecord(
                case_id=row["case_id"],
                geometry_signature=row["geometry_signature"],
                board_group=row["board_group"],
                source_case=row["case_name"],
            )
            for row in reader
        }
    if not records:
        raise ValueError(f"no audit rows found in {path}")
    return records


def grouping_key(unit: str, row: ResultRow, audit: AuditRecord) -> str:
    if unit == "record":
        return row.case_id
    if unit == "geometry":
        return audit.geometry_signature
    if unit == "board_group":
        return audit.board_group
    if unit == "source_case":
        return audit.source_case
    raise ValueError(f"unsupported grouping unit: {unit}")


def all_metrics(
    summary_metrics: Iterable[str],
    comparison_metrics: Iterable[str],
) -> tuple[str, ...]:
    fields = []
    for metric in tuple(summary_metrics) + tuple(comparison_metrics):
        if metric == "process_key":
            continue
        if metric not in fields:
            fields.append(metric)
    for field in HARD_PROCESS_KEY_FIELDS:
        if field not in fields and field != "machining_cost":
            fields.append(field)
    return tuple(fields)


def process_key(values: dict[str, float]) -> tuple[float, ...]:
    missing = [field for field in HARD_PROCESS_KEY_FIELDS if field not in values]
    if missing:
        raise ValueError(
            "process_key requires corrected span-aware fields; "
            f"missing {missing}"
        )
    return tuple(values[field] for field in HARD_PROCESS_KEY_FIELDS)


def scalar_metric(values: dict[str, float], metric: str) -> float:
    if metric == "process_key":
        return values.get("machining_cost", 0.0)
    return values.get(metric, 0.0)


def compare_metric(
    target_values: dict[str, float],
    baseline_values: dict[str, float],
    metric: str,
) -> str:
    if metric == "process_key":
        target_key = process_key(target_values)
        baseline_key = process_key(baseline_values)
        if target_key < baseline_key:
            return "target"
        if target_key > baseline_key:
            return "baseline"
        return "tie"
    target = scalar_metric(target_values, metric)
    baseline = scalar_metric(baseline_values, metric)
    if target < baseline:
        return "target"
    if target > baseline:
        return "baseline"
    return "tie"


def relative_reduction_pct(baseline: float, target: float) -> float:
    if abs(baseline) < 1e-12:
        if abs(target) < 1e-12:
            return 0.0
        return -100.0 if target > baseline else 100.0
    return 100.0 * (baseline - target) / abs(baseline)


def exact_sign_test_p_value(wins: int, losses: int) -> float | None:
    trials = wins + losses
    if trials == 0:
        return None
    observed = min(wins, losses)
    lower_tail = sum(comb(trials, k) for k in range(observed + 1)) / (2**trials)
    return min(1.0, 2.0 * lower_tail)


def percentile(sorted_values: list[float], pct: float) -> float:
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return sorted_values[0]
    position = (len(sorted_values) - 1) * pct
    lower = int(position)
    upper = min(lower + 1, len(sorted_values) - 1)
    weight = position - lower
    return sorted_values[lower] * (1.0 - weight) + sorted_values[upper] * weight


def bootstrap_mean_ci(
    values: list[float],
    *,
    samples: int,
    seed: int,
) -> tuple[float, float]:
    if not values:
        return 0.0, 0.0
    if len(values) == 1 or samples <= 0:
        return values[0], values[0]
    rng = random.Random(seed)
    size = len(values)
    means = [
        mean(values[rng.randrange(size)] for _ in range(size))
        for _ in range(samples)
    ]
    means.sort()
    return percentile(means, 0.025), percentile(means, 0.975)


def cohen_d(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    std = pstdev(values)
    if std < 1e-12:
        return 0.0
    return mean(values) / std


def aggregate_units(
    rows: tuple[ResultRow, ...],
    audit_records: dict[str, AuditRecord],
    *,
    units: tuple[str, ...],
    metrics: tuple[str, ...],
) -> tuple[UnitMethodRow, ...]:
    grouped: dict[tuple[str, str, str], list[ResultRow]] = defaultdict(list)
    unit_members: dict[tuple[str, str], set[str]] = defaultdict(set)
    unit_sources: dict[tuple[str, str], set[str]] = defaultdict(set)
    unit_boards: dict[tuple[str, str], set[str]] = defaultdict(set)
    unit_geometries: dict[tuple[str, str], set[str]] = defaultdict(set)

    for row in rows:
        audit = audit_records.get(row.case_id)
        if audit is None:
            raise KeyError(f"missing audit record for case_id={row.case_id}")
        for unit in units:
            unit_id = grouping_key(unit, row, audit)
            grouped[(unit, unit_id, row.method)].append(row)
            unit_key = (unit, unit_id)
            unit_members[unit_key].add(row.case_id)
            unit_sources[unit_key].add(audit.source_case)
            unit_boards[unit_key].add(audit.board_group)
            unit_geometries[unit_key].add(audit.geometry_signature)

    output: list[UnitMethodRow] = []
    for (unit, unit_id, method), items in sorted(grouped.items()):
        unit_key = (unit, unit_id)
        values = {
            metric: mean(row.number(metric) for row in items)
            for metric in metrics
        }
        output.append(
            UnitMethodRow(
                grouping_unit=unit,
                unit_id=unit_id,
                source_case_count=len(unit_sources[unit_key]),
                board_group_count=len(unit_boards[unit_key]),
                geometry_count=len(unit_geometries[unit_key]),
                record_count=len(unit_members[unit_key]),
                method=method,
                values=values,
            )
        )
    return tuple(output)


def group_unit_rows(
    rows: tuple[UnitMethodRow, ...],
) -> dict[str, dict[str, dict[str, UnitMethodRow]]]:
    grouped: dict[str, dict[str, dict[str, UnitMethodRow]]] = defaultdict(
        lambda: defaultdict(dict)
    )
    for row in rows:
        grouped[row.grouping_unit][row.unit_id][row.method] = row
    return grouped


def format_float(value: float | None) -> str:
    if value is None:
        return ""
    return f"{value:.6f}"


def format_pvalue(value: float | None) -> str:
    if value is None:
        return ""
    return f"{value:.12g}"


def write_unit_rows(path: Path, rows: tuple[UnitMethodRow, ...], metrics: tuple[str, ...]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = (
        "grouping_unit",
        "unit_id",
        "source_case_count",
        "board_group_count",
        "geometry_count",
        "record_count",
        "method",
        *metrics,
    )
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "grouping_unit": row.grouping_unit,
                    "unit_id": row.unit_id,
                    "source_case_count": row.source_case_count,
                    "board_group_count": row.board_group_count,
                    "geometry_count": row.geometry_count,
                    "record_count": row.record_count,
                    "method": row.method,
                    **{metric: format_float(row.values[metric]) for metric in metrics},
                }
            )


def method_summary_rows(
    unit_rows: tuple[UnitMethodRow, ...],
    metrics: tuple[str, ...],
) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    by_unit_method: dict[tuple[str, str], list[UnitMethodRow]] = defaultdict(list)
    for row in unit_rows:
        by_unit_method[(row.grouping_unit, row.method)].append(row)
    for (unit, method), rows in sorted(by_unit_method.items()):
        out: dict[str, str] = {
            "grouping_unit": unit,
            "method": method,
            "n_units": str(len(rows)),
            "mean_records_per_unit": format_float(
                mean(row.record_count for row in rows)
            ),
        }
        for metric in metrics:
            values = [row.values[metric] for row in rows]
            out[f"{metric}_mean"] = format_float(mean(values))
            out[f"{metric}_median"] = format_float(median(values))
            out[f"{metric}_std"] = format_float(pstdev(values) if len(values) > 1 else 0.0)
        output.append(out)
    return output


def write_dict_rows(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    for row in rows:
        for field in row:
            if field not in fieldnames:
                fieldnames.append(field)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def comparison_rows(
    unit_rows: tuple[UnitMethodRow, ...],
    *,
    target_method: str,
    baseline_methods: tuple[str, ...],
    metrics: tuple[str, ...],
    bootstrap_samples: int,
    bootstrap_seed: int,
) -> list[dict[str, str]]:
    grouped = group_unit_rows(unit_rows)
    output: list[dict[str, str]] = []
    seed_offset = 0
    for grouping_unit in GROUPING_UNITS:
        unit_map = grouped.get(grouping_unit, {})
        for baseline_method in baseline_methods:
            pairs = [
                (methods[baseline_method], methods[target_method])
                for methods in unit_map.values()
                if baseline_method in methods and target_method in methods
            ]
            if not pairs:
                continue
            for metric in metrics:
                baseline_values = [
                    scalar_metric(baseline.values, metric) for baseline, _ in pairs
                ]
                target_values = [
                    scalar_metric(target.values, metric) for _, target in pairs
                ]
                reductions = [
                    relative_reduction_pct(baseline, target)
                    for baseline, target in zip(baseline_values, target_values)
                ]
                deltas = [
                    target - baseline
                    for baseline, target in zip(baseline_values, target_values)
                ]
                wins = sum(
                    1
                    for baseline, target in pairs
                    if compare_metric(target.values, baseline.values, metric) == "target"
                )
                ties = sum(
                    1
                    for baseline, target in pairs
                    if compare_metric(target.values, baseline.values, metric) == "tie"
                )
                losses = sum(
                    1
                    for baseline, target in pairs
                    if compare_metric(target.values, baseline.values, metric)
                    == "baseline"
                )
                ci_low, ci_high = bootstrap_mean_ci(
                    reductions,
                    samples=bootstrap_samples,
                    seed=bootstrap_seed + seed_offset,
                )
                seed_offset += 1
                baseline_mean = mean(baseline_values)
                target_mean = mean(target_values)
                output.append(
                    {
                        "grouping_unit": grouping_unit,
                        "baseline_method": baseline_method,
                        "target_method": target_method,
                        "metric": metric,
                        "paired_units": str(len(pairs)),
                        "baseline_mean": format_float(baseline_mean),
                        "baseline_median": format_float(median(baseline_values)),
                        "target_mean": format_float(target_mean),
                        "target_median": format_float(median(target_values)),
                        "reduction_mean": format_float(mean(reductions)),
                        "reduction_median": format_float(median(reductions)),
                        "reduction_of_means": format_float(
                            relative_reduction_pct(baseline_mean, target_mean)
                        ),
                        "reduction_ci95_low": format_float(ci_low),
                        "reduction_ci95_high": format_float(ci_high),
                        "absolute_delta_mean": format_float(mean(deltas)),
                        "absolute_delta_median": format_float(median(deltas)),
                        "wins": str(wins),
                        "ties": str(ties),
                        "losses": str(losses),
                        "win_rate": format_float(wins / len(pairs)),
                        "paired_sign_test_p": format_pvalue(
                            exact_sign_test_p_value(wins, losses)
                        ),
                        "effect_size_reduction": format_float(cohen_d(reductions)),
                    }
                )
    return output


def p_value_label(value: str) -> str:
    if not value:
        return ""
    number = float(value)
    return "<1e-4" if number < 1e-4 else f"{number:.4f}"


def write_markdown(
    path: Path,
    *,
    results_path: Path,
    audit_path: Path,
    unit_rows: tuple[UnitMethodRow, ...],
    comparison: list[dict[str, str]],
    target_method: str,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    unit_counts = {
        unit: len({row.unit_id for row in unit_rows if row.grouping_unit == unit})
        for unit in GROUPING_UNITS
    }
    lines = [
        "# Chapter 3 Grouped Statistical Analysis",
        "",
        f"Result input: `{results_path}`",
        f"Layout-audit input: `{audit_path}`",
        "",
        "Positive reductions mean the target method has a lower value than the baseline.",
        "`process_key` wins use the lexicographic process key; its mean columns use",
        "the composite planning-level machining cost as the scalar companion.",
        "",
        "## Statistical units",
        "",
        "| unit | paired units | interpretation |",
        "|---|---:|---|",
        f"| record | {unit_counts.get('record', 0)} | original layout records |",
        f"| geometry | {unit_counts.get('geometry', 0)} | deduplicated geometry signatures |",
        f"| board_group | {unit_counts.get('board_group', 0)} | grouped by `case_name + board_id` |",
        f"| source_case | {unit_counts.get('source_case', 0)} | grouped by source case |",
        "",
        "## Main paired comparison",
        "",
        f"Target method: `{target_method}`.",
        "",
        "| unit | baseline | metric | n | reduction mean | 95% CI | win/tie/loss | sign-test p |",
        "|---|---|---|---:|---:|---:|---:|---:|",
    ]
    key_metrics = {"process_key", "machining_cost", "travel_mode_cost", "runtime_ms"}
    for row in comparison:
        if row["metric"] not in key_metrics:
            continue
        lines.append(
            "| "
            + " | ".join(
                (
                    row["grouping_unit"],
                    row["baseline_method"],
                    row["metric"],
                    row["paired_units"],
                    f"{float(row['reduction_mean']):.2f}%",
                    (
                        f"[{float(row['reduction_ci95_low']):.2f}, "
                        f"{float(row['reduction_ci95_high']):.2f}]"
                    ),
                    f"{row['wins']}/{row['ties']}/{row['losses']}",
                    p_value_label(row["paired_sign_test_p"]),
                )
            )
            + " |"
        )
    lines.extend(
        [
            "",
            "## Manuscript implication",
            "",
            "The 77 rows should be described as production-derived layout records,",
            "not as 77 independent industrial boards. Confirmatory claims should",
            "quote the geometry-, board-group-, or source-case grouped analyses",
            "when reporting statistical significance.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    rows = read_results(args.results)
    audit = read_audit(args.audit)
    metrics = all_metrics(args.summary_metrics, args.comparison_metrics)
    unit_rows = aggregate_units(
        rows,
        audit,
        units=GROUPING_UNITS,
        metrics=metrics,
    )
    comparison = comparison_rows(
        unit_rows,
        target_method=args.target_method,
        baseline_methods=tuple(args.baseline_methods),
        metrics=tuple(args.comparison_metrics),
        bootstrap_samples=args.bootstrap_samples,
        bootstrap_seed=args.bootstrap_seed,
    )
    method_summary = method_summary_rows(unit_rows, tuple(args.summary_metrics))

    write_unit_rows(args.unit_output, unit_rows, metrics)
    write_dict_rows(args.method_output, method_summary)
    write_dict_rows(args.comparison_output, comparison)
    write_markdown(
        args.markdown_output,
        results_path=args.results,
        audit_path=args.audit,
        unit_rows=unit_rows,
        comparison=comparison,
        target_method=args.target_method,
    )
    print(f"wrote: {args.unit_output}")
    print(f"wrote: {args.method_output}")
    print(f"wrote: {args.comparison_output}")
    print(f"wrote: {args.markdown_output}")


if __name__ == "__main__":
    main()
