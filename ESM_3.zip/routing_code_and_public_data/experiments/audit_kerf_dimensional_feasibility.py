from __future__ import annotations

import argparse
import csv
import io
import math
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from cnc_cutting.io import load_chapter2_config_from_zip


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA_ROOT = Path("<LOCAL_HOME>/Desktop/codex_handoff_20260502/data")
DEFAULT_METRICS = (
    ROOT
    / "results"
    / "corrected_model_stage6_process_key_rerun"
    / "formal"
    / "chapter3_formal_hard_gate25_main.csv"
)
DEFAULT_OUTPUT_DIR = (
    ROOT / "results" / "corrected_model_stage7_kerf" / "audit_existing_77"
)
TARGET_METHOD = "process_aware_beam_adaptive_polished"
TOLERANCE = 1e-6


@dataclass(frozen=True)
class NominalRectangle:
    part_id: str
    x: float
    y: float
    width: float
    height: float
    stored_width: float
    stored_height: float
    rotated: bool

    @property
    def max_x(self) -> float:
        return self.x + self.width

    @property
    def max_y(self) -> float:
        return self.y + self.height


@dataclass(frozen=True)
class PairConflict:
    archive: str
    placements_member: str
    board_id: str
    first_part_id: str
    second_part_id: str
    conflict_type: str
    x_gap_mm: float
    y_gap_mm: float
    euclidean_gap_mm: float
    tool_diameter_mm: float


@dataclass(frozen=True)
class RecordAudit:
    archive: str
    placements_member: str
    board_id: str
    rectangle_count: int
    tool_diameter_mm: float
    tool_radius_mm: float
    binary_spacing: bool
    configured_gap_mm: float
    configured_safe_gap_mm: float
    stored_nominal_dimension_count: int
    stored_tool_inflated_dimension_count: int
    unexpected_dimension_count: int
    zero_gap_edge_contact_count: int
    subtool_positive_gap_count: int
    boundary_radius_violation_count: int
    selected_true_shared_unit_count: int
    kerf_dimensionally_feasible: bool


def _boolean(value: str) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def nominal_dimensions(row: dict[str, str]) -> tuple[float, float]:
    rotated = _boolean(row.get("rotated", "0"))
    width0 = float(row["w0"])
    height0 = float(row["h0"])
    return (height0, width0) if rotated else (width0, height0)


def nominal_rectangle(row: dict[str, str]) -> NominalRectangle:
    width, height = nominal_dimensions(row)
    return NominalRectangle(
        part_id=str(row.get("uid") or row.get("pid_raw") or ""),
        x=float(row["x"]),
        y=float(row["y"]),
        width=width,
        height=height,
        stored_width=float(row["w"]),
        stored_height=float(row["h"]),
        rotated=_boolean(row.get("rotated", "0")),
    )


def axis_gap(first_min: float, first_max: float, second_min: float, second_max: float) -> float:
    if first_max < second_min:
        return second_min - first_max
    if second_max < first_min:
        return first_min - second_max
    return 0.0


def axis_overlap(
    first_min: float,
    first_max: float,
    second_min: float,
    second_max: float,
) -> float:
    return max(0.0, min(first_max, second_max) - max(first_min, second_min))


def classify_pair_conflict(
    first: NominalRectangle,
    second: NominalRectangle,
    tool_diameter: float,
    tolerance: float = TOLERANCE,
) -> tuple[str, float, float, float] | None:
    x_gap = axis_gap(first.x, first.max_x, second.x, second.max_x)
    y_gap = axis_gap(first.y, first.max_y, second.y, second.max_y)
    x_overlap = axis_overlap(first.x, first.max_x, second.x, second.max_x)
    y_overlap = axis_overlap(first.y, first.max_y, second.y, second.max_y)
    distance = math.hypot(x_gap, y_gap)

    vertical_edge_touch = (
        abs(first.max_x - second.x) <= tolerance
        or abs(second.max_x - first.x) <= tolerance
    ) and y_overlap > tolerance
    horizontal_edge_touch = (
        abs(first.max_y - second.y) <= tolerance
        or abs(second.max_y - first.y) <= tolerance
    ) and x_overlap > tolerance
    edge_touch = vertical_edge_touch or horizontal_edge_touch
    if edge_touch:
        return "zero_gap_edge_contact", x_gap, y_gap, distance
    if distance > tolerance and distance < tool_diameter - tolerance:
        return "positive_gap_below_tool_diameter", x_gap, y_gap, distance
    return None


def dimension_semantics(
    rectangle: NominalRectangle,
    tool_diameter: float,
    tolerance: float = TOLERANCE,
) -> str:
    width_inflation = rectangle.stored_width - rectangle.width
    height_inflation = rectangle.stored_height - rectangle.height
    if abs(width_inflation) <= tolerance and abs(height_inflation) <= tolerance:
        return "nominal"
    if (
        abs(width_inflation - tool_diameter) <= tolerance
        and abs(height_inflation - tool_diameter) <= tolerance
    ):
        return "tool_inflated"
    return "unexpected"


def boundary_radius_violation_count(
    rectangles: Iterable[NominalRectangle],
    panel_width: float,
    panel_height: float,
    tool_radius: float,
    tolerance: float = TOLERANCE,
) -> int:
    return sum(
        rectangle.x < tool_radius - tolerance
        or rectangle.y < tool_radius - tolerance
        or rectangle.max_x > panel_width - tool_radius + tolerance
        or rectangle.max_y > panel_height - tool_radius + tolerance
        for rectangle in rectangles
    )


def _canonical_board_id(value: str) -> str:
    text = str(value).strip()
    try:
        number = float(text)
    except ValueError:
        return text
    return str(int(number)) if number.is_integer() else text


def load_board_rows(
    archive_path: Path,
    placements_member: str,
    board_id: str,
) -> list[dict[str, str]]:
    with zipfile.ZipFile(archive_path) as archive:
        with archive.open(placements_member) as binary_handle:
            text_handle = io.TextIOWrapper(binary_handle, encoding="utf-8-sig", newline="")
            return [
                row
                for row in csv.DictReader(text_handle)
                if _canonical_board_id(row["board"]) == _canonical_board_id(board_id)
            ]


def read_record_rows(metrics_path: Path, method: str) -> list[dict[str, str]]:
    with metrics_path.open(newline="", encoding="utf-8-sig") as handle:
        rows = [row for row in csv.DictReader(handle) if row.get("method") == method]
    unique: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in rows:
        key = (row["archive"], row["placements_member"], row["board_id"])
        unique[key] = row
    return [unique[key] for key in sorted(unique)]


def audit_record(
    metric_row: dict[str, str],
    data_root: Path,
) -> tuple[RecordAudit, list[PairConflict]]:
    archive_name = metric_row["archive"]
    placements_member = metric_row["placements_member"]
    board_id = metric_row["board_id"]
    archive_path = data_root / archive_name
    if not archive_path.exists():
        raise FileNotFoundError(archive_path)

    config = load_chapter2_config_from_zip(
        archive_path,
        placements_member=placements_member,
    )
    tool_diameter = float(config.get("TOOL_D", 6.0))
    tool_radius = tool_diameter / 2.0
    panel_width = float(config["BOARD_W"])
    panel_height = float(config["BOARD_H"])
    board_rows = load_board_rows(archive_path, placements_member, board_id)
    rectangles = [nominal_rectangle(row) for row in board_rows]

    semantics = [dimension_semantics(rectangle, tool_diameter) for rectangle in rectangles]
    conflicts: list[PairConflict] = []
    for first_index, first in enumerate(rectangles):
        for second in rectangles[first_index + 1 :]:
            conflict = classify_pair_conflict(first, second, tool_diameter)
            if conflict is None:
                continue
            conflict_type, x_gap, y_gap, distance = conflict
            conflicts.append(
                PairConflict(
                    archive=archive_name,
                    placements_member=placements_member,
                    board_id=board_id,
                    first_part_id=first.part_id,
                    second_part_id=second.part_id,
                    conflict_type=conflict_type,
                    x_gap_mm=x_gap,
                    y_gap_mm=y_gap,
                    euclidean_gap_mm=distance,
                    tool_diameter_mm=tool_diameter,
                )
            )

    zero_gap_count = sum(
        conflict.conflict_type == "zero_gap_edge_contact" for conflict in conflicts
    )
    subtool_count = sum(
        conflict.conflict_type == "positive_gap_below_tool_diameter" for conflict in conflicts
    )
    boundary_count = boundary_radius_violation_count(
        rectangles,
        panel_width,
        panel_height,
        tool_radius,
    )
    audit = RecordAudit(
        archive=archive_name,
        placements_member=placements_member,
        board_id=board_id,
        rectangle_count=len(rectangles),
        tool_diameter_mm=tool_diameter,
        tool_radius_mm=tool_radius,
        binary_spacing=bool(config.get("BINARY_SPACING", False)),
        configured_gap_mm=float(config.get("GAP", 0.0)),
        configured_safe_gap_mm=float(config.get("SAFE_GAP", tool_diameter)),
        stored_nominal_dimension_count=semantics.count("nominal"),
        stored_tool_inflated_dimension_count=semantics.count("tool_inflated"),
        unexpected_dimension_count=semantics.count("unexpected"),
        zero_gap_edge_contact_count=zero_gap_count,
        subtool_positive_gap_count=subtool_count,
        boundary_radius_violation_count=boundary_count,
        selected_true_shared_unit_count=int(
            float(metric_row.get("selected_shared_edge_count", "0") or 0)
        ),
        kerf_dimensionally_feasible=(
            len(rectangles) > 0
            and semantics.count("unexpected") == 0
            and zero_gap_count == 0
            and subtool_count == 0
            and boundary_count == 0
        ),
    )
    return audit, conflicts


def write_csv(path: Path, rows: Iterable[object], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def write_summary(path: Path, audits: list[RecordAudit], conflicts: list[PairConflict]) -> None:
    infeasible = [row for row in audits if not row.kerf_dimensionally_feasible]
    zero_gap_records = [row for row in audits if row.zero_gap_edge_contact_count > 0]
    lines = [
        "# Kerf and Finished-Dimension Feasibility Audit",
        "",
        f"Generated: {datetime.now(timezone.utc).isoformat()}",
        "",
        "This audit reconstructs nominal rectangle dimensions from `w0/h0` and the "
        "rotation flag. It then checks whether the stored fixed layouts admit a "
        "finite-diameter cutter without changing nominal finished dimensions.",
        "",
        "## Verdict",
        "",
        f"- Audited records: {len(audits)}",
        f"- Kerf-dimensionally infeasible records: {len(infeasible)}",
        f"- Records with zero-gap edge contacts: {len(zero_gap_records)}",
        f"- Zero-gap edge-contact pairs: {sum(row.zero_gap_edge_contact_count for row in audits)}",
        f"- Positive sub-tool-diameter gap pairs: {sum(row.subtool_positive_gap_count for row in audits)}",
        f"- Selected true-shared units in audited proposed routes: {sum(row.selected_true_shared_unit_count for row in audits)}",
        f"- Detailed pair conflicts: {len(conflicts)}",
        "",
        "A zero-gap contact between nominal rectangles cannot preserve both finished "
        "part boundaries when the cutter has positive radius. Such a layout requires "
        "regeneration with tool-diameter packing envelopes or an explicit machining "
        "allowance supplied upstream.",
        "",
        "## Record Summary",
        "",
        "| Archive | Board | Parts | Zero-gap pairs | Sub-tool gaps | Boundary violations | True-shared units | Feasible |",
        "|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in audits:
        lines.append(
            f"| `{row.archive}` | {row.board_id} | {row.rectangle_count} | "
            f"{row.zero_gap_edge_contact_count} | {row.subtool_positive_gap_count} | "
            f"{row.boundary_radius_violation_count} | {row.selected_true_shared_unit_count} | "
            f"{'yes' if row.kerf_dimensionally_feasible else 'no'} |"
        )
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit finite-tool kerf and finished-dimension feasibility.",
    )
    parser.add_argument("--metrics", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--method", default=TARGET_METHOD)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    metric_rows = read_record_rows(args.metrics, args.method)
    audits: list[RecordAudit] = []
    conflicts: list[PairConflict] = []
    for metric_row in metric_rows:
        audit, record_conflicts = audit_record(metric_row, args.data_root)
        audits.append(audit)
        conflicts.extend(record_conflicts)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(
        args.output_dir / "dimensional_feasibility_record_summary.csv",
        audits,
        list(RecordAudit.__dataclass_fields__),
    )
    write_csv(
        args.output_dir / "dimensional_feasibility_pair_conflicts.csv",
        conflicts,
        list(PairConflict.__dataclass_fields__),
    )
    write_summary(
        args.output_dir / "dimensional_feasibility_audit_summary.md",
        audits,
        conflicts,
    )
    print(f"audited_records={len(audits)}")
    print(f"infeasible_records={sum(not row.kerf_dimensionally_feasible for row in audits)}")
    print(f"zero_gap_records={sum(row.zero_gap_edge_contact_count > 0 for row in audits)}")
    print(f"pair_conflicts={len(conflicts)}")
    print(f"output_dir={args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
