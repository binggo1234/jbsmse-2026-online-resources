from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import mean, median, pstdev


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = (
    ROOT
    / "results"
    / "formal"
    / "chapter3_formal_hard_gate25_stochastic_multiseed.csv"
)
DEFAULT_OUTPUT = (
    ROOT
    / "results"
    / "formal"
    / "chapter3_stochastic_multiseed_variability_summary.csv"
)
DEFAULT_MARKDOWN = ROOT / "docs" / "chapter3_stochastic_multiseed_summary.md"
METRICS = (
    "composite_planning_cost",
    "travel_mode_cost",
    "air_move_distance",
    "tool_event_count",
    "runtime_ms",
)


@dataclass(frozen=True)
class SeedRow:
    case_id: str
    method: str
    algorithm_seed: str
    values: dict[str, float]
    hard_penalty: float
    support_rule_penalty: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Summarize within-layout variability across stochastic algorithm seeds "
            "without treating repeated seeds as independent layout records."
        )
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--markdown-output", type=Path, default=DEFAULT_MARKDOWN)
    return parser.parse_args()


def case_id(row: dict[str, str]) -> str:
    return "|".join(
        row.get(field, "")
        for field in ("archive", "placements_member", "board_id")
    )


def number(row: dict[str, str], field: str) -> float:
    return float(row.get(field, "0") or 0.0)


def metric_values(row: dict[str, str]) -> dict[str, float]:
    return {
        "composite_planning_cost": (
            number(row, "cutting_length") + number(row, "travel_mode_cost")
        ),
        "travel_mode_cost": number(row, "travel_mode_cost"),
        "air_move_distance": number(row, "air_move_distance"),
        "tool_event_count": (
            number(row, "pierce_count")
            + number(row, "lift_count")
            + number(row, "safe_lift_count")
        ),
        "runtime_ms": number(row, "runtime_ms"),
    }


def read_rows(path: Path) -> tuple[SeedRow, ...]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty result CSV: {path}")
        required = {"method", "algorithm_seed", "archive", "placements_member", "board_id"}
        missing = required.difference(reader.fieldnames)
        if missing:
            raise ValueError(f"{path} is missing fields: {sorted(missing)}")
        rows = tuple(
            SeedRow(
                case_id=case_id(row),
                method=row["method"],
                algorithm_seed=row["algorithm_seed"],
                values=metric_values(row),
                hard_penalty=number(row, "hard_penalty"),
                support_rule_penalty=number(row, "stability_penalty"),
            )
            for row in reader
        )
    if not rows:
        raise ValueError(f"no stochastic rows found: {path}")
    return rows


def summarize(rows: tuple[SeedRow, ...]) -> list[dict[str, str]]:
    grouped: dict[tuple[str, str], list[SeedRow]] = defaultdict(list)
    for row in rows:
        grouped[(row.method, row.case_id)].append(row)

    methods = sorted({row.method for row in rows})
    output: list[dict[str, str]] = []
    for method in methods:
        layout_groups = [
            items
            for (group_method, _), items in grouped.items()
            if group_method == method
        ]
        seed_counts = {len({row.algorithm_seed for row in items}) for items in layout_groups}
        if len(seed_counts) != 1:
            raise ValueError(f"inconsistent seed counts for method {method}: {seed_counts}")

        summary: dict[str, str] = {
            "method": method,
            "layout_records": str(len(layout_groups)),
            "algorithm_seeds": str(next(iter(seed_counts))),
            "hard_violation_runs": str(
                sum(row.hard_penalty > 0.0 for items in layout_groups for row in items)
            ),
            "support_rule_violation_runs": str(
                sum(
                    row.support_rule_penalty > 0.0
                    for items in layout_groups
                    for row in items
                )
            ),
        }
        for metric in METRICS:
            layout_means = [
                mean(row.values[metric] for row in items)
                for items in layout_groups
            ]
            layout_stds = [
                pstdev(row.values[metric] for row in items)
                if len(items) > 1
                else 0.0
                for items in layout_groups
            ]
            layout_ranges = [
                max(row.values[metric] for row in items)
                - min(row.values[metric] for row in items)
                for items in layout_groups
            ]
            summary[f"{metric}_mean"] = f"{mean(layout_means):.6f}"
            summary[f"{metric}_median"] = f"{median(layout_means):.6f}"
            summary[f"{metric}_within_layout_std_mean"] = (
                f"{mean(layout_stds):.6f}"
            )
            summary[f"{metric}_within_layout_std_max"] = f"{max(layout_stds):.6f}"
            summary[f"{metric}_within_layout_range_max"] = (
                f"{max(layout_ranges):.6f}"
            )
        output.append(summary)
    return output


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(rows[0]),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path: Path, input_path: Path, rows: list[dict[str, str]]) -> None:
    lines = [
        "# Stochastic Baseline Multi-Seed Summary",
        "",
        f"Input: `{input_path}`",
        "",
        (
            "Each layout record is first aggregated across algorithm seeds. "
            "The reported variability is therefore within-layout seed variability, "
            "not pseudo-replication across repeated runs."
        ),
        "",
        "| method | layouts | seeds | composite cost | within-layout std | travel cost | within-layout std | hard violations | support-rule violations |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {method} | {layout_records} | {algorithm_seeds} | "
            "{composite_planning_cost_mean:.1f} | "
            "{composite_planning_cost_within_layout_std_mean:.2f} | "
            "{travel_mode_cost_mean:.1f} | "
            "{travel_mode_cost_within_layout_std_mean:.2f} | "
            "{hard_violation_runs} | {support_rule_violation_runs} |".format(
                **{
                    key: (
                        float(value)
                        if key.endswith(("_mean", "_std_mean"))
                        else value
                    )
                    for key, value in row.items()
                }
            )
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    rows = summarize(read_rows(args.input))
    write_csv(args.output, rows)
    write_markdown(args.markdown_output, args.input, rows)
    print(f"wrote: {args.output}")
    print(f"wrote: {args.markdown_output}")


if __name__ == "__main__":
    main()
