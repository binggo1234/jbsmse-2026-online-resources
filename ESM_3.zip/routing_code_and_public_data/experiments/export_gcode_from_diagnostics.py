from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path


DEFAULT_ROUTE_CASE_DIRS = (
    Path("results/chapter3_route_cases/case_large_board340"),
    Path("results/chapter3_route_cases/case_large_guard_board341"),
    Path("results/chapter3_route_cases/case_mid_board262"),
    Path("results/chapter3_route_cases/case_small_board4"),
    Path("results/paper_artifacts_final_selector/route_case_large_gain_diagnostics"),
    Path("results/paper_artifacts_final_selector/route_case_medium_diagnostics"),
    Path("results/paper_artifacts_final_selector/route_case_small_diagnostics"),
    Path("results/representative_route_cases_after_runtime_opt/main_adaptive_gain_diagnostics"),
)

DEFAULT_DIAGNOSTICS = tuple(
    path
    for case_dir in DEFAULT_ROUTE_CASE_DIRS
    for path in (
        case_dir / "process_aware_beam_diagnostics.csv",
        case_dir / "process_aware_beam_adaptive_polished_diagnostics.csv",
    )
)


@dataclass(frozen=True)
class NcTemplate:
    stock_width_mm: float = 2440.0
    stock_height_mm: float = 1220.0
    stock_thickness_mm: float = 18.0
    tool_diameter_mm: float = 6.0
    z_safe_mm: float = 5.0
    step_down_mm: float = 6.0
    spindle_rpm: int = 18000
    feed_cut_mm_min: float = 3600.0
    feed_plunge_mm_min: float = 800.0
    feed_rapid_mm_min: float = 8000.0
    coordinate_tolerance_mm: float = 1e-6

    @property
    def depths(self) -> tuple[float, ...]:
        depth = 0.0
        values: list[float] = []
        while depth < self.stock_thickness_mm - 1e-9:
            depth = min(depth + self.step_down_mm, self.stock_thickness_mm)
            values.append(-depth)
        return tuple(values)


@dataclass(frozen=True)
class RouteNcMetrics:
    case_name: str
    method: str
    diagnostics_csv: str
    gcode_file: str
    stock_width_mm: float
    stock_height_mm: float
    stock_thickness_mm: float
    tool_diameter_mm: float
    cut_action_count: int
    travel_action_count: int
    planar_cut_length_mm: float
    nc_cut_length_mm: float
    rapid_xy_length_mm: float
    implicit_reposition_mm: float
    z_feed_count: int
    lift_count: int
    estimated_cut_time_s: float
    estimated_rapid_xy_time_s: float
    estimated_plunge_time_s: float
    estimated_retract_time_s: float
    estimated_total_time_s: float
    out_of_bounds_action_count: int
    hard_penalty_sum: float
    support_rule_penalty_sum: float
    safe_lift_event_count: int
    detour_event_count: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Export NC-level G-code programs from route diagnostic CSV files. "
            "The output is a reproducible simulation layer for NC Viewer, "
            "CAMotics, or similar 3-axis G-code viewers; it is not a "
            "machine-specific post-processor."
        )
    )
    parser.add_argument(
        "--diagnostics",
        type=Path,
        nargs="*",
        default=DEFAULT_DIAGNOSTICS,
        help="Route diagnostic CSV files. Defaults to eight unique representative route pairs.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/nc_simulation_mvp"),
        help="Directory for generated .nc files and summary tables.",
    )
    parser.add_argument("--stock-width-mm", type=float, default=2440.0)
    parser.add_argument("--stock-height-mm", type=float, default=1220.0)
    parser.add_argument("--stock-thickness-mm", type=float, default=18.0)
    parser.add_argument("--tool-diameter-mm", type=float, default=6.0)
    parser.add_argument("--z-safe-mm", type=float, default=5.0)
    parser.add_argument("--step-down-mm", type=float, default=6.0)
    parser.add_argument("--spindle-rpm", type=int, default=18000)
    parser.add_argument("--feed-cut-mm-min", type=float, default=3600.0)
    parser.add_argument("--feed-plunge-mm-min", type=float, default=800.0)
    parser.add_argument("--feed-rapid-mm-min", type=float, default=8000.0)
    return parser.parse_args()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty diagnostic CSV: {path}")
        return list(reader)


def number(row: dict[str, str], field: str, default: float = 0.0) -> float:
    value = row.get(field, "")
    if value == "":
        return default
    return float(value)


def point(row: dict[str, str], prefix: str) -> tuple[float, float]:
    return number(row, f"{prefix}_x"), number(row, f"{prefix}_y")


def distance(first: tuple[float, float], second: tuple[float, float]) -> float:
    return math.hypot(second[0] - first[0], second[1] - first[1])


def same_point(
    first: tuple[float, float],
    second: tuple[float, float],
    tolerance: float,
) -> bool:
    return distance(first, second) <= tolerance


def safe_slug(value: str) -> str:
    slug = "".join(ch if ch.isalnum() else "_" for ch in value).strip("_")
    return slug or "route"


def infer_case_and_method(path: Path) -> tuple[str, str]:
    case_name = path.parent.name
    method = path.stem
    suffix = "_diagnostics"
    if method.endswith(suffix):
        method = method[: -len(suffix)]
    return case_name, method


def is_out_of_bounds(
    start: tuple[float, float],
    end: tuple[float, float],
    template: NcTemplate,
) -> bool:
    for x, y in (start, end):
        if x < -1e-9 or y < -1e-9:
            return True
        if x > template.stock_width_mm + 1e-9:
            return True
        if y > template.stock_height_mm + 1e-9:
            return True
    return False


def emit_header(lines: list[str], source: Path, template: NcTemplate) -> None:
    lines.extend(
        [
            "(NC-level simulation export from planning diagnostics)",
            f"(Source: {source})",
            "(Boundary: generic 3-axis G-code, not a machine-specific post-processor)",
            f"(Stock: {template.stock_width_mm:.3f} x {template.stock_height_mm:.3f} x "
            f"{template.stock_thickness_mm:.3f} mm)",
            f"(Tool diameter: {template.tool_diameter_mm:.3f} mm)",
            "(XY coordinates are geometrically kerf-compensated; controller compensation disabled)",
            "G21",
            "G90",
            "G17",
            "G40",
            f"G0 Z{template.z_safe_mm:.3f}",
            "T1 M6",
            f"M3 S{template.spindle_rpm}",
        ]
    )


def emit_footer(lines: list[str], template: NcTemplate) -> None:
    lines.extend(
        [
            f"G0 Z{template.z_safe_mm:.3f}",
            "M5",
            "M30",
        ]
    )


def write_camotics_project(gcode_path: Path, template: NcTemplate) -> Path:
    project_path = gcode_path.with_suffix(".camotics")
    project = {
        "units": "metric",
        "resolution-mode": "medium",
        "resolution": 2.0,
        "tools": {
            "1": {
                "units": "metric",
                "shape": "cylindrical",
                "length": 30.0,
                "diameter": template.tool_diameter_mm,
                "description": "Generic CNC router bit",
            }
        },
        "workpiece": {
            "automatic": False,
            "margin": 0,
            "bounds": {
                "min": [0, 0, -template.stock_thickness_mm],
                "max": [template.stock_width_mm, template.stock_height_mm, 0],
            },
        },
        "files": [gcode_path.name],
    }
    project_path.write_text(
        json.dumps(project, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return project_path


def emit_rapid(
    lines: list[str],
    x: float,
    y: float,
    template: NcTemplate,
    comment: str | None = None,
) -> None:
    if comment:
        lines.append(f"({comment})")
    lines.append(f"G0 Z{template.z_safe_mm:.3f}")
    lines.append(f"G0 X{x:.3f} Y{y:.3f}")


def emit_cut_segment(
    lines: list[str],
    start: tuple[float, float],
    end: tuple[float, float],
    template: NcTemplate,
    action_index: int,
    unit_id: str,
) -> None:
    lines.append(f"(Action {action_index}: cut {unit_id})")
    emit_rapid(lines, start[0], start[1], template)
    forward = True
    for depth in template.depths:
        target = end if forward else start
        lines.append(f"G1 Z{depth:.3f} F{template.feed_plunge_mm_min:.1f}")
        lines.append(
            f"G1 X{target[0]:.3f} Y{target[1]:.3f} F{template.feed_cut_mm_min:.1f}"
        )
        forward = not forward
    lines.append(f"G0 Z{template.z_safe_mm:.3f}")


def export_route(
    diagnostics_path: Path,
    output_dir: Path,
    template: NcTemplate,
) -> RouteNcMetrics:
    rows = read_rows(diagnostics_path)
    case_name, method = infer_case_and_method(diagnostics_path)
    gcode_name = f"{safe_slug(case_name)}__{safe_slug(method)}.nc"
    gcode_path = output_dir / gcode_name

    lines: list[str] = []
    emit_header(lines, diagnostics_path, template)

    current_xy = (0.0, 0.0)
    cut_action_count = 0
    travel_action_count = 0
    planar_cut_length = 0.0
    rapid_xy_length = 0.0
    implicit_reposition = 0.0
    out_of_bounds = 0
    hard_penalty_sum = 0.0
    support_rule_penalty_sum = 0.0
    safe_lift_event_count = 0
    detour_event_count = 0

    for row in rows:
        action_index = int(row["action_index"])
        action_type = row["action_type"]
        travel_mode = row.get("travel_mode", "")
        start = point(row, "start")
        end = point(row, "end")
        length = number(row, "length", distance(start, end))
        out_of_bounds += int(is_out_of_bounds(start, end, template))
        hard_penalty_sum += number(row, "collision_penalty") + number(
            row,
            "boundary_penalty",
        )
        support_rule_penalty_sum += number(row, "stability_penalty_delta")
        safe_lift_event_count += int(number(row, "safe_lift_count"))
        detour_event_count += int(number(row, "detour_count"))

        if not same_point(current_xy, start, template.coordinate_tolerance_mm):
            gap = distance(current_xy, start)
            implicit_reposition += gap
            rapid_xy_length += gap
            emit_rapid(
                lines,
                start[0],
                start[1],
                template,
                comment=(
                    f"Implicit reposition before action {action_index}; "
                    f"diagnostic gap {gap:.3f} mm"
                ),
            )
            current_xy = start

        if action_type == "travel":
            travel_action_count += 1
            rapid_xy_length += length
            lines.append(f"(Action {action_index}: travel mode={travel_mode})")
            emit_rapid(lines, end[0], end[1], template)
            current_xy = end
        elif action_type == "cut":
            cut_action_count += 1
            planar_cut_length += length
            emit_cut_segment(
                lines,
                start,
                end,
                template,
                action_index=action_index,
                unit_id=row.get("cutting_unit_id", "") or row.get("segment_id", ""),
            )
            current_xy = end
        else:
            raise ValueError(f"unsupported action_type={action_type!r} in {diagnostics_path}")

    emit_footer(lines, template)
    output_dir.mkdir(parents=True, exist_ok=True)
    gcode_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_camotics_project(gcode_path, template)

    layers = len(template.depths)
    nc_cut_length = planar_cut_length * layers
    z_feed_count = cut_action_count * layers
    lift_count = cut_action_count
    estimated_cut_time = nc_cut_length / template.feed_cut_mm_min * 60.0
    estimated_rapid_xy_time = rapid_xy_length / template.feed_rapid_mm_min * 60.0
    estimated_plunge_time = (
        cut_action_count * template.stock_thickness_mm / template.feed_plunge_mm_min * 60.0
    )
    estimated_retract_time = (
        cut_action_count
        * (template.stock_thickness_mm + template.z_safe_mm)
        / template.feed_rapid_mm_min
        * 60.0
    )
    estimated_total_time = (
        estimated_cut_time
        + estimated_rapid_xy_time
        + estimated_plunge_time
        + estimated_retract_time
    )

    return RouteNcMetrics(
        case_name=case_name,
        method=method,
        diagnostics_csv=str(diagnostics_path),
        gcode_file=str(gcode_path),
        stock_width_mm=template.stock_width_mm,
        stock_height_mm=template.stock_height_mm,
        stock_thickness_mm=template.stock_thickness_mm,
        tool_diameter_mm=template.tool_diameter_mm,
        cut_action_count=cut_action_count,
        travel_action_count=travel_action_count,
        planar_cut_length_mm=planar_cut_length,
        nc_cut_length_mm=nc_cut_length,
        rapid_xy_length_mm=rapid_xy_length,
        implicit_reposition_mm=implicit_reposition,
        z_feed_count=z_feed_count,
        lift_count=lift_count,
        estimated_cut_time_s=estimated_cut_time,
        estimated_rapid_xy_time_s=estimated_rapid_xy_time,
        estimated_plunge_time_s=estimated_plunge_time,
        estimated_retract_time_s=estimated_retract_time,
        estimated_total_time_s=estimated_total_time,
        out_of_bounds_action_count=out_of_bounds,
        hard_penalty_sum=hard_penalty_sum,
        support_rule_penalty_sum=support_rule_penalty_sum,
        safe_lift_event_count=safe_lift_event_count,
        detour_event_count=detour_event_count,
    )


def write_summary(rows: list[RouteNcMetrics], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        fieldnames = list(asdict(rows[0]).keys())
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def write_pair_summary(rows: list[RouteNcMetrics], output_path: Path) -> None:
    by_case_method = {(row.case_name, row.method): row for row in rows}
    pairs: list[dict[str, str]] = []
    for case_name in sorted({row.case_name for row in rows}):
        baseline = by_case_method.get((case_name, "process_aware_beam"))
        target = by_case_method.get(
            (case_name, "process_aware_beam_adaptive_polished")
        )
        if baseline is None or target is None:
            continue
        time_delta = baseline.estimated_total_time_s - target.estimated_total_time_s
        travel_delta = baseline.rapid_xy_length_mm - target.rapid_xy_length_mm
        rows_common = {
            "case_name": case_name,
            "baseline_method": baseline.method,
            "target_method": target.method,
            "baseline_estimated_total_time_s": f"{baseline.estimated_total_time_s:.6f}",
            "target_estimated_total_time_s": f"{target.estimated_total_time_s:.6f}",
            "estimated_time_delta_s": f"{time_delta:.6f}",
            "estimated_time_reduction_pct": (
                f"{100.0 * time_delta / baseline.estimated_total_time_s:.6f}"
                if baseline.estimated_total_time_s
                else ""
            ),
            "baseline_rapid_xy_length_mm": f"{baseline.rapid_xy_length_mm:.6f}",
            "target_rapid_xy_length_mm": f"{target.rapid_xy_length_mm:.6f}",
            "rapid_xy_delta_mm": f"{travel_delta:.6f}",
            "rapid_xy_reduction_pct": (
                f"{100.0 * travel_delta / baseline.rapid_xy_length_mm:.6f}"
                if baseline.rapid_xy_length_mm
                else ""
            ),
            "baseline_planar_cut_length_mm": f"{baseline.planar_cut_length_mm:.6f}",
            "target_planar_cut_length_mm": f"{target.planar_cut_length_mm:.6f}",
            "baseline_out_of_bounds": str(baseline.out_of_bounds_action_count),
            "target_out_of_bounds": str(target.out_of_bounds_action_count),
            "baseline_hard_penalty": f"{baseline.hard_penalty_sum:.6f}",
            "target_hard_penalty": f"{target.hard_penalty_sum:.6f}",
        }
        pairs.append(rows_common)
    if not pairs:
        return
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(pairs[0].keys()),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(pairs)


def write_readme(output_dir: Path, template: NcTemplate) -> None:
    text = f"""# NC-Level Simulation Export

This directory contains generic 3-axis G-code programs exported from route
diagnostic CSV files. The files are intended for NC Viewer, CAMotics, or similar
G-code viewers. They are not machine-specific post-processor outputs and should
not be interpreted as controller-verified production programs.

The default export contains eight unique representative route pairs, i.e.,
sixteen NC programs. The paired metrics are reported in
`nc_simulation_pair_summary.csv`; manual CAMotics screenshots are retained as a
spot-check subset rather than as commercial CAM validation.

## Template

- Units: millimetres (`G21`)
- Coordinate mode: absolute (`G90`)
- Stock: {template.stock_width_mm:g} x {template.stock_height_mm:g} x {template.stock_thickness_mm:g} mm
- Tool diameter: {template.tool_diameter_mm:g} mm
- Safe Z: {template.z_safe_mm:g} mm
- Step-down: {template.step_down_mm:g} mm
- Spindle: {template.spindle_rpm:g} rpm
- Cut feed: {template.feed_cut_mm_min:g} mm/min
- Plunge feed: {template.feed_plunge_mm_min:g} mm/min
- Rapid feed used for time estimation: {template.feed_rapid_mm_min:g} mm/min

## Verification Workflow

1. Open each `.nc` file in NC Viewer for a quick XY toolpath check.
2. Open the corresponding `.camotics` project file in CAMotics.
3. Confirm that the project stock and tool match the template above.
4. Confirm that the route is readable, remains within the stock, and removes
   material along the expected primitive-edge segments.
5. Use `nc_simulation_summary.csv` for the route-level metrics and estimated
   kinematic time under the fixed template.

All compared routes use the same depth, tool, feed, and retract/plunge template,
so differences come from XY route order and event structure rather than CAM
operation settings.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    template = NcTemplate(
        stock_width_mm=args.stock_width_mm,
        stock_height_mm=args.stock_height_mm,
        stock_thickness_mm=args.stock_thickness_mm,
        tool_diameter_mm=args.tool_diameter_mm,
        z_safe_mm=args.z_safe_mm,
        step_down_mm=args.step_down_mm,
        spindle_rpm=args.spindle_rpm,
        feed_cut_mm_min=args.feed_cut_mm_min,
        feed_plunge_mm_min=args.feed_plunge_mm_min,
        feed_rapid_mm_min=args.feed_rapid_mm_min,
    )
    rows = [
        export_route(path, args.output_dir, template)
        for path in args.diagnostics
    ]
    if not rows:
        raise ValueError("no diagnostics files supplied")
    write_summary(rows, args.output_dir / "nc_simulation_summary.csv")
    write_pair_summary(rows, args.output_dir / "nc_simulation_pair_summary.csv")
    write_readme(args.output_dir, template)
    print(f"wrote {len(rows)} NC programs to {args.output_dir}")
    print(f"summary: {args.output_dir / 'nc_simulation_summary.csv'}")


if __name__ == "__main__":
    main()
