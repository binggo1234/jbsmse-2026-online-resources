from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.io import (
    PLACEMENT_GEOMETRY_STORED,
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.models import CuttingUnit, CuttingUnitType


ROOT = Path(__file__).resolve().parents[1]
STAGE7 = ROOT / "results" / "corrected_model_stage7_kerf"


@dataclass(frozen=True)
class RouteSpanAudit:
    placements_member: str
    board_id: str
    method: str
    atomic_span_count: int
    covered_atomic_span_count: int
    missing_atomic_span_count: int
    repeated_atomic_span_count: int
    unknown_cutting_unit_count: int
    coverage_ratio: float
    passed: bool


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit Stage 7 route completeness over corrected atomic spans."
    )
    parser.add_argument(
        "--archive",
        type=Path,
        default=STAGE7 / "kerf_layouts" / "stage7_kerf_layouts.zip",
    )
    parser.add_argument(
        "--record-manifest",
        type=Path,
        default=STAGE7 / "kerf_layouts" / "stage7_kerf_layout_manifest.csv",
    )
    parser.add_argument(
        "--metrics",
        type=Path,
        default=STAGE7 / "formal" / "chapter3_stage7_main.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=STAGE7 / "layout_audit" / "route_spans",
    )
    return parser.parse_args()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_rows(path: Path, rows: list[RouteSpanAudit]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(RouteSpanAudit.__dataclass_fields__))
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def audit_span_ids(
    all_span_ids: set[str],
    cut_unit_ids: list[str],
    unit_span_ids: dict[str, tuple[str, ...]],
) -> tuple[int, int, int, float]:
    counts: Counter[str] = Counter()
    unknown = 0
    for unit_id in cut_unit_ids:
        span_ids = unit_span_ids.get(unit_id)
        if span_ids is None:
            unknown += 1
            continue
        counts.update(span_ids)
    covered = all_span_ids & set(counts)
    missing = all_span_ids - covered
    repeated = sum(count > 1 for span_id, count in counts.items() if span_id in all_span_ids)
    ratio = len(covered) / len(all_span_ids) if all_span_ids else 1.0
    return len(missing), repeated, unknown, ratio


def unit_span_index(units: tuple[CuttingUnit, ...]) -> tuple[set[str], dict[str, tuple[str, ...]]]:
    all_span_ids = {
        span.span_id
        for unit in units
        if unit.unit_type == CuttingUnitType.SINGLE_EDGE
        for span in unit.covered_spans
    }
    by_unit = {
        unit.unit_id: tuple(span.span_id for span in unit.covered_spans)
        for unit in units
    }
    return all_span_ids, by_unit


def resolve_diagnostics(path_value: str) -> Path:
    path = Path(path_value)
    return path if path.is_absolute() else ROOT / path


def main() -> None:
    args = parse_args()
    record_rows = read_rows(args.record_manifest)
    config_by_member = {
        row["placements_member"]: row.get("config_member", "") for row in record_rows
    }
    metrics_rows = read_rows(args.metrics)
    case_cache: dict[tuple[str, str], tuple[set[str], dict[str, tuple[str, ...]]]] = {}
    audits: list[RouteSpanAudit] = []

    for metric in metrics_rows:
        member = metric["placements_member"]
        board_id = metric["board_id"]
        case_key = (member, board_id)
        indexed = case_cache.get(case_key)
        if indexed is None:
            config_member = config_by_member.get(member) or None
            config = load_chapter2_config_from_zip(
                args.archive,
                placements_member=member,
                config_member=config_member,
            )
            tool = tool_config_from_chapter2_config(config)
            geometry_mode = str(
                config.get("PLACEMENT_GEOMETRY_MODE", PLACEMENT_GEOMETRY_STORED)
            )
            layout = load_chapter2_layouts_from_zip(
                args.archive,
                placements_member=member,
                config_member=config_member,
                board_ids=(board_id,),
                placement_geometry_mode=geometry_mode,
                tool_diameter=tool.tool_diameter,
            )[0]
            units = build_candidate_cutting_units(
                layout,
                tool,
                max_collinear_gap=tool.min_channel_width,
            )
            indexed = unit_span_index(units)
            case_cache[case_key] = indexed

        diagnostics = read_rows(resolve_diagnostics(metric["diagnostics_file"]))
        cut_unit_ids = [
            row["cutting_unit_id"]
            for row in diagnostics
            if row.get("action_type") == "cut" and row.get("cutting_unit_id")
        ]
        all_span_ids, by_unit = indexed
        missing, repeated, unknown, ratio = audit_span_ids(
            all_span_ids, cut_unit_ids, by_unit
        )
        audits.append(
            RouteSpanAudit(
                placements_member=member,
                board_id=board_id,
                method=metric["method"],
                atomic_span_count=len(all_span_ids),
                covered_atomic_span_count=len(all_span_ids) - missing,
                missing_atomic_span_count=missing,
                repeated_atomic_span_count=repeated,
                unknown_cutting_unit_count=unknown,
                coverage_ratio=ratio,
                passed=missing == 0 and repeated == 0 and unknown == 0,
            )
        )

    output_dir = args.output_dir.resolve()
    output_path = output_dir / "stage7_route_span_audit.csv"
    write_rows(output_path, audits)
    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "route_count": len(audits),
        "passed_route_count": sum(row.passed for row in audits),
        "failed_route_count": sum(not row.passed for row in audits),
        "missing_atomic_span_count": sum(row.missing_atomic_span_count for row in audits),
        "repeated_atomic_span_count": sum(row.repeated_atomic_span_count for row in audits),
        "unknown_cutting_unit_count": sum(row.unknown_cutting_unit_count for row in audits),
        "mean_coverage_ratio": (
            sum(row.coverage_ratio for row in audits) / len(audits) if audits else 1.0
        ),
        "archive": str(args.archive),
        "record_manifest": str(args.record_manifest),
        "metrics": str(args.metrics),
        "output": str(output_path),
    }
    summary_path = output_dir / "stage7_route_span_audit_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if summary["failed_route_count"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
