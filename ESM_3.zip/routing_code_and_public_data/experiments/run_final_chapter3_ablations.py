from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import dataclass
from pathlib import Path

from run_final_chapter3_main import (
    DEFAULT_STAT_METRICS,
    DEFAULT_TARGET_METHOD,
    ROOT,
    build_batch_command,
    build_statistical_command,
    final_experiment_paths,
    run_command,
)


DEFAULT_OUTPUT_PREFIX = "chapter3_ablation"
DEFAULT_GROUPS = ("repeat_policy", "tool_event_gate", "search_components")
REPEAT_POLICY_METRICS = (
    "process_key",
    "machining_cost",
    "travel_mode_cost",
    "air_move_distance",
    "process_repeated_span_count",
    "process_repeated_span_length",
    "process_redundant_action_count",
    "stability_penalty",
    "hard_penalty",
    "runtime_ms",
)
SEARCH_COMPONENT_METHODS = (
    "topology_process_aware",
    "process_aware_beam",
    "process_aware_beam_polished",
    DEFAULT_TARGET_METHOD,
)


@dataclass(frozen=True)
class AblationVariant:
    group: str
    name: str
    output_stem: str
    methods: tuple[str, ...]
    repeat_cut_policy: str = "hard"
    tool_event_gate_enabled: bool = True
    tool_event_min_travel_saving: float = 25.0
    tool_event_min_travel_saving_ratio: float = 0.0


@dataclass(frozen=True)
class AblationGroup:
    name: str
    variants: tuple[AblationVariant, ...]
    comparison_output_stem: str | None = None
    comparison_target: str | None = None
    comparison_metrics: tuple[str, ...] = DEFAULT_STAT_METRICS
    component_target_method: str | None = None


def default_ablation_groups(output_prefix: str = DEFAULT_OUTPUT_PREFIX) -> dict[str, AblationGroup]:
    target_only = (DEFAULT_TARGET_METHOD,)
    repeat_variants = (
        AblationVariant(
            group="repeat_policy",
            name="repeat_policy_hard",
            output_stem=f"{output_prefix}_repeat_policy_hard",
            methods=target_only,
            repeat_cut_policy="hard",
        ),
        AblationVariant(
            group="repeat_policy",
            name="repeat_policy_soft",
            output_stem=f"{output_prefix}_repeat_policy_soft",
            methods=target_only,
            repeat_cut_policy="soft",
        ),
        AblationVariant(
            group="repeat_policy",
            name="repeat_policy_off",
            output_stem=f"{output_prefix}_repeat_policy_off",
            methods=target_only,
            repeat_cut_policy="off",
        ),
    )
    gate_variants = (
        AblationVariant(
            group="tool_event_gate",
            name="gate25",
            output_stem=f"{output_prefix}_tool_event_gate_gate25",
            methods=target_only,
        ),
        AblationVariant(
            group="tool_event_gate",
            name="gate_off",
            output_stem=f"{output_prefix}_tool_event_gate_off",
            methods=target_only,
            tool_event_gate_enabled=False,
        ),
        AblationVariant(
            group="tool_event_gate",
            name="old_gate100_rel2",
            output_stem=f"{output_prefix}_tool_event_gate_old100_rel2",
            methods=target_only,
            tool_event_min_travel_saving=100.0,
            tool_event_min_travel_saving_ratio=0.02,
        ),
    )
    component_variants = (
        AblationVariant(
            group="search_components",
            name="search_components",
            output_stem=f"{output_prefix}_search_components_hard_gate25",
            methods=SEARCH_COMPONENT_METHODS,
        ),
    )
    return {
        "repeat_policy": AblationGroup(
            name="repeat_policy",
            variants=repeat_variants,
            comparison_output_stem=f"{output_prefix}_repeat_policy_comparison",
            comparison_target="repeat_policy_hard",
            comparison_metrics=REPEAT_POLICY_METRICS,
        ),
        "tool_event_gate": AblationGroup(
            name="tool_event_gate",
            variants=gate_variants,
            comparison_output_stem=f"{output_prefix}_tool_event_gate_comparison",
            comparison_target="gate25",
            comparison_metrics=DEFAULT_STAT_METRICS,
        ),
        "search_components": AblationGroup(
            name="search_components",
            variants=component_variants,
            component_target_method=DEFAULT_TARGET_METHOD,
            comparison_metrics=DEFAULT_STAT_METRICS,
        ),
    }


def build_variant_batch_command(
    variant: AblationVariant,
    *,
    results_dir: Path,
    python_executable: str,
    zip_paths: tuple[Path, ...],
    max_members_per_archive: int,
    boards_per_member: int,
    min_rectangles: int,
    max_rectangles: int,
    task_timeout_seconds: float,
    fresh: bool,
    progress_bar: bool,
) -> list[str]:
    return build_batch_command(
        final_experiment_paths(results_dir, variant.output_stem),
        python_executable=python_executable,
        zip_paths=zip_paths,
        methods=variant.methods,
        repeat_cut_policy=variant.repeat_cut_policy,
        tool_event_gate_enabled=variant.tool_event_gate_enabled,
        tool_event_min_travel_saving=variant.tool_event_min_travel_saving,
        tool_event_min_travel_saving_ratio=variant.tool_event_min_travel_saving_ratio,
        max_members_per_archive=max_members_per_archive,
        boards_per_member=boards_per_member,
        min_rectangles=min_rectangles,
        max_rectangles=max_rectangles,
        task_timeout_seconds=task_timeout_seconds,
        fresh=fresh,
        progress_bar=progress_bar,
    )


def merge_variant_results(
    variants: tuple[AblationVariant, ...],
    *,
    results_dir: Path,
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] | None = None
    merged_rows: list[dict[str, str]] = []
    for variant in variants:
        if len(variant.methods) != 1:
            raise ValueError("variant comparison merging expects exactly one method")
        source_method = variant.methods[0]
        source_path = final_experiment_paths(results_dir, variant.output_stem).route_csv
        with source_path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise ValueError(f"empty CSV: {source_path}")
            current_fieldnames = [
                field for field in reader.fieldnames if field != "repeat_cut_policy"
            ]
            if fieldnames is None:
                fieldnames = ["ablation_variant", *current_fieldnames]
            for row in reader:
                if row.get("method") != source_method:
                    continue
                row = {field: value for field, value in row.items() if field != "repeat_cut_policy"}
                row["method"] = variant.name
                row["ablation_variant"] = variant.name
                merged_rows.append(row)

    if fieldnames is None:
        raise ValueError("no variant rows found")
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(merged_rows)


def run_group(
    group: AblationGroup,
    *,
    args: argparse.Namespace,
    python_executable: str,
) -> None:
    zip_paths = tuple(args.zip_paths or ())
    for variant in group.variants:
        if args.skip_batch:
            continue
        run_command(
            build_variant_batch_command(
                variant,
                results_dir=args.results_dir,
                python_executable=python_executable,
                zip_paths=zip_paths,
                max_members_per_archive=args.max_members_per_archive,
                boards_per_member=args.boards_per_member,
                min_rectangles=args.min_rectangles,
                max_rectangles=args.max_rectangles,
                task_timeout_seconds=args.task_timeout_seconds,
                fresh=args.fresh,
                progress_bar=args.progress_bar,
            ),
            dry_run=args.dry_run,
        )

    if args.skip_statistics:
        return

    if group.comparison_output_stem is not None and group.comparison_target is not None:
        comparison_paths = final_experiment_paths(
            args.results_dir,
            group.comparison_output_stem,
        )
        if args.dry_run:
            print(f"merge variant CSVs -> {comparison_paths.route_csv}", flush=True)
        else:
            merge_variant_results(
                group.variants,
                results_dir=args.results_dir,
                output_path=comparison_paths.route_csv,
            )
        run_command(
            build_statistical_command(
                comparison_paths,
                python_executable=python_executable,
                target_method=group.comparison_target,
                baseline_methods=tuple(
                    variant.name
                    for variant in group.variants
                    if variant.name != group.comparison_target
                ),
                metrics=group.comparison_metrics,
                bootstrap_samples=args.bootstrap_samples,
                bootstrap_seed=args.bootstrap_seed,
            ),
            dry_run=args.dry_run,
        )

    if group.component_target_method is not None:
        if len(group.variants) != 1:
            raise ValueError("component comparison expects one multi-method variant")
        variant = group.variants[0]
        paths = final_experiment_paths(args.results_dir, variant.output_stem)
        run_command(
            build_statistical_command(
                paths,
                python_executable=python_executable,
                target_method=group.component_target_method,
                baseline_methods=tuple(
                    method
                    for method in variant.methods
                    if method != group.component_target_method
                ),
                metrics=group.comparison_metrics,
                bootstrap_samples=args.bootstrap_samples,
                bootstrap_seed=args.bootstrap_seed,
            ),
            dry_run=args.dry_run,
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the fixed Chapter 3 ablation experiment suites.",
    )
    parser.add_argument("--results-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--output-prefix", default=DEFAULT_OUTPUT_PREFIX)
    parser.add_argument("--groups", nargs="+", choices=DEFAULT_GROUPS, default=list(DEFAULT_GROUPS))
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=55)
    parser.add_argument("--boards-per-member", type=int, default=1)
    parser.add_argument("--min-rectangles", type=int, default=20)
    parser.add_argument("--max-rectangles", type=int, default=50)
    parser.add_argument("--task-timeout-seconds", type=float, default=30.0)
    parser.add_argument("--bootstrap-samples", type=int, default=2000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260522)
    parser.add_argument("--fresh", action="store_true", help="Overwrite existing CSVs.")
    parser.add_argument("--progress-bar", action="store_true")
    parser.add_argument("--skip-batch", action="store_true")
    parser.add_argument("--skip-statistics", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    groups = default_ablation_groups(args.output_prefix)
    python_executable = sys.executable
    for group_name in args.groups:
        run_group(groups[group_name], args=args, python_executable=python_executable)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
