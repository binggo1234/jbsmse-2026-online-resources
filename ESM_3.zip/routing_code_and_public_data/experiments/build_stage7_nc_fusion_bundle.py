from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.build_corrected_auxiliary_validation_bundle import (
    collect_cut_segments,
    copy_diagnostics,
    pct_delta,
    rewrite_camotics_project,
    write_dxf,
    write_rows,
)
from experiments.export_gcode_from_diagnostics import NcTemplate, export_route

DEFAULT_METRICS = (
    ROOT
    / "results"
    / "corrected_model_stage7_kerf"
    / "formal"
    / "chapter3_stage7_main.csv"
)
DEFAULT_OUTPUT = (
    ROOT
    / "results"
    / "corrected_model_stage7_kerf"
    / "auxiliary_nc_cam_fusion_5case"
)
BASELINE_METHOD = "process_aware_beam"
PROPOSED_METHOD = "process_aware_beam_adaptive_polished"


@dataclass(frozen=True)
class RoutePair:
    key: tuple[str, str]
    baseline: dict[str, str]
    proposed: dict[str, str]

    @property
    def rectangle_count(self) -> int:
        return int(self.baseline["rectangle_count"])

    @property
    def cplan_reduction_pct(self) -> float:
        baseline_cost = planning_cost(self.baseline)
        return 100.0 * (baseline_cost - planning_cost(self.proposed)) / baseline_cost


@dataclass(frozen=True)
class SelectedCase:
    case_id: str
    role: str
    description: str
    pair: RoutePair


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build the Stage 7 five-case NC/CAMotics/Fusion auxiliary package."
    )
    parser.add_argument("--metrics", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def planning_cost(row: dict[str, str]) -> float:
    return float(row["cutting_length"]) + float(row["travel_mode_cost"])


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def load_pairs(path: Path) -> list[RoutePair]:
    grouped: dict[tuple[str, str], dict[str, dict[str, str]]] = {}
    for row in read_rows(path):
        if row["method"] not in {BASELINE_METHOD, PROPOSED_METHOD}:
            continue
        key = (row["placements_member"], row["board_id"])
        grouped.setdefault(key, {})[row["method"]] = row
    pairs = [
        RoutePair(key, methods[BASELINE_METHOD], methods[PROPOSED_METHOD])
        for key, methods in sorted(grouped.items())
        if BASELINE_METHOD in methods and PROPOSED_METHOD in methods
    ]
    if len(pairs) != 77:
        raise ValueError(f"expected 77 route pairs, found {len(pairs)}")
    return pairs


def choose_cases(pairs: list[RoutePair]) -> list[SelectedCase]:
    selected: list[SelectedCase] = []
    used: set[tuple[str, str]] = set()

    def add(case_id: str, role: str, description: str, ordered: list[RoutePair]) -> None:
        pair = next(pair for pair in ordered if pair.key not in used)
        used.add(pair.key)
        selected.append(SelectedCase(case_id, role, description, pair))

    positive = [pair for pair in pairs if pair.cplan_reduction_pct > 1e-9]
    median_count = sorted(pair.rectangle_count for pair in pairs)[len(pairs) // 2]
    add(
        "case_01_stage7_core",
        "core",
        "First frozen Stage 7 formal record",
        pairs,
    )
    add(
        "case_02_small_layout",
        "small_layout",
        "Small kerf-aware layout with a positive paired improvement",
        sorted(positive, key=lambda pair: (pair.rectangle_count, -pair.cplan_reduction_pct)),
    )
    add(
        "case_03_median_layout",
        "median_layout",
        "Median-size kerf-aware layout",
        sorted(
            positive,
            key=lambda pair: (
                abs(pair.rectangle_count - median_count),
                -pair.cplan_reduction_pct,
            ),
        ),
    )
    add(
        "case_04_high_gain",
        "high_gain",
        "Largest positive paired planning-cost improvement",
        sorted(positive, key=lambda pair: -pair.cplan_reduction_pct),
    )
    add(
        "case_05_low_gain",
        "low_gain",
        "Smallest positive paired planning-cost improvement",
        sorted(positive, key=lambda pair: pair.cplan_reduction_pct),
    )
    return selected


def route_gate_pass(row: dict[str, str]) -> bool:
    return (
        int(row["coverage_missing_segment_count"]) == 0
        and int(row["process_repeated_span_count"]) == 0
        and float(row["hard_penalty"]) == 0.0
        and float(row["stability_penalty"]) == 0.0
    )


def main() -> None:
    args = parse_args()
    metrics_path = args.metrics.resolve()
    output_dir = args.output_dir.resolve()
    selected = choose_cases(load_pairs(metrics_path))
    template = NcTemplate()
    if output_dir.exists():
        shutil.rmtree(output_dir)

    nc_dir = output_dir / "nc_camotics"
    diagnostics_dir = output_dir / "diagnostics"
    fusion_dir = output_dir / "fusion"
    dxf_dir = fusion_dir / "dxf"
    nc_reference_dir = fusion_dir / "nc_reference"
    for directory in (
        nc_dir,
        diagnostics_dir,
        dxf_dir,
        nc_reference_dir,
        fusion_dir / "fusion_exported_nc",
        fusion_dir / "fusion_screenshots",
    ):
        directory.mkdir(parents=True, exist_ok=True)

    route_rows: list[dict[str, object]] = []
    pair_rows: list[dict[str, object]] = []
    case_rows: list[dict[str, object]] = []
    fusion_rows: list[dict[str, object]] = []
    for case in selected:
        exported: dict[str, dict[str, object]] = {}
        for label, source_row in (
            ("baseline", case.pair.baseline),
            ("proposed", case.pair.proposed),
        ):
            if not route_gate_pass(source_row):
                raise ValueError(f"route gate failed for {case.case_id} {label}")
            diagnostics_source = ROOT / source_row["diagnostics_file"]
            diagnostics_copy = (
                diagnostics_dir
                / f"{case.case_id}_{label}_{source_row['method']}_diagnostics.csv"
            )
            copy_diagnostics(diagnostics_source, diagnostics_copy)
            metric = export_route(diagnostics_source, nc_dir, template)
            generated_nc = Path(metric.gcode_file)
            generated_camotics = generated_nc.with_suffix(".camotics")
            target_nc = nc_dir / f"{case.case_id}_{label}.nc"
            target_camotics = nc_dir / f"{case.case_id}_{label}.camotics"
            generated_nc.rename(target_nc)
            generated_camotics.rename(target_camotics)
            rewrite_camotics_project(target_camotics, target_nc.name)
            shutil.copy2(target_nc, nc_reference_dir / target_nc.name)
            row = asdict(metric)
            row.update(
                {
                    "case_id": case.case_id,
                    "case_role": case.role,
                    "method_label": label,
                    "record_member": source_row["placements_member"],
                    "board_id": source_row["board_id"],
                    "rectangle_count": source_row["rectangle_count"],
                    "route_gate_pass": True,
                    "diagnostics_copy": str(diagnostics_copy.relative_to(output_dir)),
                    "gcode_file": str(target_nc.relative_to(output_dir)),
                    "camotics_file": str(target_camotics.relative_to(output_dir)),
                }
            )
            route_rows.append(row)
            exported[label] = row

        dxf_paths: dict[str, Path] = {}
        dxf_segment_counts: dict[str, int] = {}
        for label, source_row in (
            ("baseline", case.pair.baseline),
            ("proposed", case.pair.proposed),
        ):
            diagnostics_source = ROOT / source_row["diagnostics_file"]
            segments = collect_cut_segments(diagnostics_source)
            dxf_path = dxf_dir / f"{case.case_id}_{label}.dxf"
            write_dxf(dxf_path, case, segments, template)
            dxf_paths[label] = dxf_path
            dxf_segment_counts[label] = len(segments)
        baseline = exported["baseline"]
        proposed = exported["proposed"]
        base_time = float(baseline["estimated_total_time_s"])
        prop_time = float(proposed["estimated_total_time_s"])
        base_rapid = float(baseline["rapid_xy_length_mm"])
        prop_rapid = float(proposed["rapid_xy_length_mm"])
        pair_rows.append(
            {
                "case_id": case.case_id,
                "case_role": case.role,
                "record_member": case.pair.key[0],
                "board_id": case.pair.key[1],
                "rectangle_count": case.pair.rectangle_count,
                "cplan_reduction_pct": f"{case.pair.cplan_reduction_pct:.6f}",
                "baseline_estimated_total_time_s": f"{base_time:.6f}",
                "proposed_estimated_total_time_s": f"{prop_time:.6f}",
                "estimated_time_reduction_pct": f"{pct_delta(base_time, prop_time):.6f}",
                "baseline_rapid_xy_length_mm": f"{base_rapid:.6f}",
                "proposed_rapid_xy_length_mm": f"{prop_rapid:.6f}",
                "rapid_xy_reduction_pct": f"{pct_delta(base_rapid, prop_rapid):.6f}",
                "baseline_out_of_bounds": baseline["out_of_bounds_action_count"],
                "proposed_out_of_bounds": proposed["out_of_bounds_action_count"],
            }
        )
        case_rows.append(
            {
                "case_id": case.case_id,
                "case_role": case.role,
                "description": case.description,
                "record_member": case.pair.key[0],
                "board_id": case.pair.key[1],
                "rectangle_count": case.pair.rectangle_count,
                "baseline_diagnostics": exported["baseline"]["diagnostics_copy"],
                "proposed_diagnostics": exported["proposed"]["diagnostics_copy"],
                "baseline_nc": exported["baseline"]["gcode_file"],
                "proposed_nc": exported["proposed"]["gcode_file"],
                "baseline_fusion_dxf": str(dxf_paths["baseline"].relative_to(output_dir)),
                "proposed_fusion_dxf": str(dxf_paths["proposed"].relative_to(output_dir)),
                "baseline_fusion_cut_segment_count": dxf_segment_counts["baseline"],
                "proposed_fusion_cut_segment_count": dxf_segment_counts["proposed"],
            }
        )
        fusion_rows.append(
            {
                "case_id": case.case_id,
                "method_label": "proposed",
                "fusion_dxf_file": str(dxf_paths["proposed"].relative_to(output_dir)),
                "fusion_exported_nc": "",
                "fusion_screenshot": "",
                "simulation_status": "pending_fusion_api_batch",
                "notes": "Black-box exportability check only; controller compensation remains off.",
            }
        )

    write_rows(output_dir / "case_index.csv", case_rows)
    write_rows(output_dir / "route_summary.csv", route_rows)
    write_rows(output_dir / "pair_summary.csv", pair_rows)
    write_rows(fusion_dir / "fusion_result_template.csv", fusion_rows)
    readme = """# Stage 7 Auxiliary NC/CAMotics/Fusion Bundle

This package is regenerated from the kerf-aware Stage 7 formal diagnostics.
All XY cut coordinates are geometric cutter-center offsets for a 6 mm tool;
the NC header uses `G40`, so controller-side radius compensation must remain off.

The generic NC and CAMotics files are automated exportability artifacts. The
five proposed DXFs are the non-duplicated inputs for Autodesk Fusion black-box
validation. Baseline DXFs remain in the package for traceability but are not
rerun because Fusion is not used for paired route-order performance claims.
"""
    (output_dir / "README.md").write_text(readme, encoding="utf-8")
    checklist = """# Fusion Black-Box Auxiliary Checklist

Run only the five `proposed` DXFs. Baseline and proposed contain the same
machining geometry, and Fusion is allowed to reorder it internally.

1. Import the DXF in millimetres. Select only cut-path layers (`SINGLE_EDGE`,
   `SHARED_EDGE`, `NEAR_SHARED_CHANNEL`, `COLLINEAR_CHAIN`, and `CUT_LINE`);
   exclude `STOCK` and `ANNOTATION` from machining geometry.
2. Create fixed stock `2440 x 1220 x 18 mm` with zero XY/Z offsets and the
   work origin at the stock lower-left top surface.
3. Use one 6 mm flat router/end mill at 18000 rpm, 3600 mm/min cutting feed,
   and 800 mm/min plunge feed.
4. Create a 2D Trace operation with center compensation. The imported lines
   are already cutter-center trajectories; the posted program must not apply
   G41/G42.
5. Enable multiple depths with 6 mm step-down to `-18 mm` in three passes.
6. Run `Stage7FusionBatch`, then audit the NC files with
   `experiments/audit_stage7_fusion_api_batch.py`.
7. Require all five cases to pass curve-count equality, three-depth execution,
   span coverage, per-depth length equality, stock bounds, and compensation checks.

Do not compare Fusion's automatically reordered toolpath against the proposed
route order. The formal performance claim remains based on the corrected
evaluator; Fusion is an auxiliary import, generation, and post-processing check.
"""
    (fusion_dir / "FUSION_CHECKLIST.md").write_text(checklist, encoding="utf-8")
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "formal_metrics": str(metrics_path.relative_to(ROOT)),
        "case_count": len(selected),
        "route_count": len(route_rows),
        "fusion_evaluation_case_count": len(fusion_rows),
        "all_route_gates_pass": all(row["route_gate_pass"] for row in route_rows),
        "all_nc_bounds_pass": all(
            int(row["out_of_bounds_action_count"]) == 0 for row in route_rows
        ),
        "controller_compensation": "G40",
        "fusion_status": "pending_fusion_api_batch",
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="utf-8",
    )
    zip_path = shutil.make_archive(str(output_dir), "zip", output_dir)
    print(f"cases={len(selected)}")
    print(f"routes={len(route_rows)}")
    print(f"route_gates_pass={manifest['all_route_gates_pass']}")
    print(f"nc_bounds_pass={manifest['all_nc_bounds_pass']}")
    print(f"output={output_dir}")
    print(f"zip={zip_path}")


if __name__ == "__main__":
    main()
