from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, replace
from enum import Enum

from cnc_cutting.cutting_units import (
    build_candidate_cutting_units,
    primitive_cutting_units,
    relation_cutting_units,
)
from cnc_cutting.geometry import compensated_rectangle_edges, euclidean_distance
from cnc_cutting.manufacturability import audit_cutting_units
from cnc_cutting.models import CuttingUnit, Layout, ToolConfig
from cnc_cutting.optimizer import select_coverage_units
from cnc_cutting.spans import (
    build_segment_spans,
    layout_edges_relations_and_spans,
)


class AbstractionVariant(str, Enum):
    NOMINAL_WHOLE_SEGMENT = "nominal_whole_segment"
    COMPENSATED_WHOLE_SEGMENT = "compensated_whole_segment"
    COMPENSATED_ATOMIC_SPAN = "compensated_atomic_span"


@dataclass(frozen=True)
class AbstractionAudit:
    variant: str
    part_count: int
    primitive_segment_count: int
    atomic_span_count: int
    candidate_unit_count: int
    selected_unit_count: int
    claimed_required_count: int
    claimed_covered_count: int
    claimed_complete: bool
    actual_covered_atomic_span_count: int
    missing_atomic_span_count: int
    repeated_atomic_span_count: int
    partial_primitive_segment_count: int
    fully_missing_primitive_segment_count: int
    finished_dimension_violation_count: int
    swept_disk_gouge_count: int
    selected_cut_length_mm: float
    false_completion: bool
    passed_all_audits: bool


def _whole_segment_primitive_units(
    segments,
    atomic_spans_by_segment,
    trajectory_segments_by_id=None,
) -> tuple[CuttingUnit, ...]:
    full_spans_by_segment = build_segment_spans(segments)
    units = primitive_cutting_units(
        segments,
        spans_by_segment=full_spans_by_segment,
        trajectory_segments_by_id=trajectory_segments_by_id,
    )
    return tuple(
        replace(
            unit,
            covered_spans=atomic_spans_by_segment[unit.covered_segment_ids[0]],
        )
        for unit in units
    )


def _selection_view(unit: CuttingUnit) -> CuttingUnit:
    segment_ids = tuple(
        dict.fromkeys(
            unit.covered_segment_ids
            or tuple(span.segment_id for span in unit.covered_spans)
        )
    )
    return replace(unit, covered_segment_ids=segment_ids, covered_spans=())


def _whole_segment_candidates(
    layout: Layout,
    tool: ToolConfig,
    *,
    compensated: bool,
) -> tuple[tuple[CuttingUnit, ...], tuple[CuttingUnit, ...]]:
    segments, relations, spans_by_segment = layout_edges_relations_and_spans(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    trajectory_segments_by_id = None
    if compensated:
        trajectory_segments_by_id = {
            segment.segment_id: segment
            for rectangle in layout.rectangles
            for segment in compensated_rectangle_edges(rectangle, tool.tool_radius)
        }
    primitive_units = _whole_segment_primitive_units(
        segments,
        spans_by_segment,
        trajectory_segments_by_id=trajectory_segments_by_id,
    )
    relation_units: tuple[CuttingUnit, ...] = ()
    if compensated:
        relation_units = relation_cutting_units(
            relations,
            spans_by_segment=spans_by_segment,
            nominal_segments_by_id={segment.segment_id: segment for segment in segments},
        )
    physical_units = primitive_units + relation_units
    return tuple(_selection_view(unit) for unit in physical_units), physical_units


def _candidate_views(
    layout: Layout,
    tool: ToolConfig,
    variant: AbstractionVariant,
) -> tuple[tuple[CuttingUnit, ...], dict[str, CuttingUnit], bool]:
    if variant == AbstractionVariant.NOMINAL_WHOLE_SEGMENT:
        selection_units, physical_units = _whole_segment_candidates(
            layout,
            tool,
            compensated=False,
        )
        return selection_units, {unit.unit_id: unit for unit in physical_units}, False

    if variant == AbstractionVariant.COMPENSATED_WHOLE_SEGMENT:
        selection_units, physical_units = _whole_segment_candidates(
            layout,
            tool,
            compensated=True,
        )
        return selection_units, {unit.unit_id: unit for unit in physical_units}, False

    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    return units, {unit.unit_id: unit for unit in units}, True


def audit_layout_abstraction(
    layout: Layout,
    tool: ToolConfig,
    variant: AbstractionVariant,
) -> AbstractionAudit:
    if not tool.geometric_kerf_compensation:
        raise ValueError("abstraction audit requires a kerf-compensated Stage 7 tool")

    segments, _, spans_by_segment = layout_edges_relations_and_spans(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    all_segment_ids = {segment.segment_id for segment in segments}
    all_span_ids = {
        span.span_id
        for spans in spans_by_segment.values()
        for span in spans
    }
    selection_units, physical_by_id, atomic_selection = _candidate_views(
        layout,
        tool,
        variant,
    )
    selected = select_coverage_units(selection_units)
    selected_physical = tuple(physical_by_id[unit.unit_id] for unit in selected)

    if atomic_selection:
        claimed_required = all_span_ids
        claimed_counts = Counter(
            span.span_id for unit in selected for span in unit.covered_spans
        )
    else:
        claimed_required = all_segment_ids
        claimed_counts = Counter(
            segment_id for unit in selected for segment_id in unit.covered_segment_ids
        )
    claimed_covered = claimed_required & set(claimed_counts)
    claimed_complete = claimed_covered == claimed_required

    actual_counts = Counter(
        span.span_id for unit in selected_physical for span in unit.covered_spans
    )
    actual_covered = all_span_ids & set(actual_counts)
    missing_span_ids = all_span_ids - actual_covered
    repeated_span_count = sum(
        count > 1
        for span_id, count in actual_counts.items()
        if span_id in all_span_ids
    )
    partial_segment_count = 0
    fully_missing_segment_count = 0
    for segment_id, spans in spans_by_segment.items():
        required = {span.span_id for span in spans}
        covered = required & actual_covered
        if covered and covered != required:
            partial_segment_count += 1
        elif not covered:
            fully_missing_segment_count += 1

    violations = audit_cutting_units(selected_physical, layout, tool.tool_radius)
    finished_dimension_count = sum(
        violation.violation_type
        in {
            "incorrect_centerline_offset",
            "centerline_does_not_cover_nominal_span",
            "non_axis_aligned_cut",
        }
        for violation in violations
    )
    gouge_count = sum(
        violation.violation_type == "swept_disk_gouges_nominal_part"
        for violation in violations
    )
    passed = (
        not missing_span_ids
        and repeated_span_count == 0
        and finished_dimension_count == 0
        and gouge_count == 0
    )
    false_completion = claimed_complete and not passed

    return AbstractionAudit(
        variant=variant.value,
        part_count=len(layout.rectangles),
        primitive_segment_count=len(all_segment_ids),
        atomic_span_count=len(all_span_ids),
        candidate_unit_count=len(selection_units),
        selected_unit_count=len(selected),
        claimed_required_count=len(claimed_required),
        claimed_covered_count=len(claimed_covered),
        claimed_complete=claimed_complete,
        actual_covered_atomic_span_count=len(actual_covered),
        missing_atomic_span_count=len(missing_span_ids),
        repeated_atomic_span_count=repeated_span_count,
        partial_primitive_segment_count=partial_segment_count,
        fully_missing_primitive_segment_count=fully_missing_segment_count,
        finished_dimension_violation_count=finished_dimension_count,
        swept_disk_gouge_count=gouge_count,
        selected_cut_length_mm=sum(
            euclidean_distance(unit.start, unit.end) for unit in selected_physical
        ),
        false_completion=false_completion,
        passed_all_audits=passed,
    )

