from __future__ import annotations

import argparse
import csv
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from experiment_manifest import write_experiment_manifest
from run_chapter2_batch import DEFAULT_ARCHIVES
from run_final_chapter3_main import (
    build_batch_command,
    final_experiment_paths,
    run_command,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_STEM = "chapter3_formal_hard_gate25_stochastic_multiseed"
DEFAULT_METHODS = ("contour_aco", "process_aware_sa", "process_aware_ga")
DEFAULT_SEEDS = tuple(range(20260502, 20260512))
TARGET_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_TARGET_RESULTS = (
    ROOT
    / "results"
    / "formal"
    / "chapter3_formal_hard_gate25_external_baselines.csv"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run stochastic contour ACO, process-aware SA, and process-aware GA "
            "over multiple algorithm seeds on the fixed Chapter 3 layouts."
        )
    )
    parser.add_argument("--results-dir", type=Path, default=ROOT / "results" / "formal")
    parser.add_argument("--output-stem", default=DEFAULT_OUTPUT_STEM)
    parser.add_argument("--target-results", type=Path, default=DEFAULT_TARGET_RESULTS)
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=55)
    parser.add_argument("--boards-per-member", type=int, default=1)
    parser.add_argument("--min-rectangles", type=int, default=20)
    parser.add_argument("--max-rectangles", type=int, default=50)
    parser.add_argument("--task-timeout-seconds", type=float, default=90.0)
    parser.add_argument("--methods", nargs="+", default=DEFAULT_METHODS)
    parser.add_argument("--algorithm-seeds", nargs="+", type=int, default=DEFAULT_SEEDS)
    parser.add_argument(
        "--max-parallel-seeds",
        type=int,
        default=3,
        help="Maximum number of independent algorithm-seed runs executed in parallel.",
    )
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-progress-bar", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def case_id(row: dict[str, str]) -> tuple[str, str, str]:
    return row["archive"], row["placements_member"], row["board_id"]


def read_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty result CSV: {path}")
        return list(reader.fieldnames), list(reader)


def combine_seed_rows(
    seed_results: tuple[tuple[int, list[dict[str, str]]], ...],
    methods: tuple[str, ...],
) -> tuple[list[str], list[dict[str, str]]]:
    if not seed_results:
        raise ValueError("at least one seed result is required")

    expected_cases: set[tuple[str, str, str]] | None = None
    combined: list[dict[str, str]] = []
    fields: list[str] | None = None
    for algorithm_seed, rows in seed_results:
        selected = [row for row in rows if row.get("method") in methods]
        seed_cases = {case_id(row) for row in selected}
        if expected_cases is None:
            expected_cases = seed_cases
        elif seed_cases != expected_cases:
            raise ValueError(f"layout records differ for algorithm seed {algorithm_seed}")

        indexed = {(case_id(row), row["method"]): row for row in selected}
        missing = [
            (record, method)
            for record in sorted(seed_cases)
            for method in methods
            if (record, method) not in indexed
        ]
        if missing:
            raise ValueError(
                f"seed {algorithm_seed} is not fully paired; first missing: {missing[0]}"
            )

        for record in sorted(seed_cases):
            for method in methods:
                output_row = dict(indexed[(record, method)])
                output_row["algorithm_seed"] = str(algorithm_seed)
                combined.append(output_row)
                if fields is None:
                    fields = [*output_row]

    return fields or ["algorithm_seed"], combined


def append_target_rows(
    fieldnames: list[str],
    stochastic_rows: list[dict[str, str]],
    target_rows: list[dict[str, str]],
) -> tuple[list[str], list[dict[str, str]]]:
    target = [row for row in target_rows if row.get("method") == TARGET_METHOD]
    stochastic_cases = {case_id(row) for row in stochastic_rows}
    target_by_case = {case_id(row): row for row in target}
    missing = sorted(stochastic_cases.difference(target_by_case))
    if missing:
        raise ValueError(f"target results miss layout record: {missing[0]}")

    output_fields = list(fieldnames)
    if "algorithm_seed" not in output_fields:
        output_fields.append("algorithm_seed")
    output = list(stochastic_rows)
    for record in sorted(stochastic_cases):
        row = dict(target_by_case[record])
        row["algorithm_seed"] = "deterministic"
        output.append(row)
    return output_fields, output


def write_rows(
    path: Path,
    fieldnames: list[str],
    rows: list[dict[str, str]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            lineterminator="\n",
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    methods = tuple(args.methods)
    seeds = tuple(args.algorithm_seeds)
    archives = tuple(args.zip_paths) if args.zip_paths else DEFAULT_ARCHIVES
    if args.max_parallel_seeds <= 0:
        raise ValueError("--max-parallel-seeds must be positive")

    seed_results: list[tuple[int, list[dict[str, str]]]] = []
    seed_outputs: list[Path] = []
    seed_jobs = []

    for algorithm_seed in seeds:
        seed_stem = f"{args.output_stem}_seed_{algorithm_seed}"
        paths = final_experiment_paths(args.results_dir, seed_stem)
        command = build_batch_command(
            paths,
            python_executable=sys.executable,
            zip_paths=archives,
            methods=methods,
            max_members_per_archive=args.max_members_per_archive,
            boards_per_member=args.boards_per_member,
            min_rectangles=args.min_rectangles,
            max_rectangles=args.max_rectangles,
            task_timeout_seconds=args.task_timeout_seconds,
            fresh=not args.resume,
            progress_bar=not args.no_progress_bar,
            algorithm_seed=algorithm_seed,
        )
        seed_jobs.append((algorithm_seed, paths, command))
        seed_outputs.extend((paths.route_csv, paths.manifest_json))

    if args.dry_run:
        for _, _, command in seed_jobs:
            run_command(command, dry_run=True)
        return

    with ThreadPoolExecutor(max_workers=args.max_parallel_seeds) as executor:
        futures = {
            executor.submit(run_command, command, dry_run=False): (
                algorithm_seed,
                paths,
            )
            for algorithm_seed, paths, command in seed_jobs
        }
        for future in as_completed(futures):
            algorithm_seed, paths = futures[future]
            future.result()
            print(f"completed algorithm seed: {algorithm_seed}")

    for algorithm_seed, paths, _ in seed_jobs:
        _, rows = read_rows(paths.route_csv)
        seed_results.append((algorithm_seed, rows))

    fieldnames, combined = combine_seed_rows(tuple(seed_results), methods)
    combined_path = args.results_dir / f"{args.output_stem}.csv"
    write_rows(combined_path, fieldnames, combined)

    _, target_rows = read_rows(args.target_results)
    comparison_fields, comparison_rows = append_target_rows(
        fieldnames,
        combined,
        target_rows,
    )
    comparison_path = args.results_dir / f"{args.output_stem}_comparison.csv"
    write_rows(comparison_path, comparison_fields, comparison_rows)

    manifest_path = args.results_dir / f"{args.output_stem}_suite_manifest.json"
    write_experiment_manifest(
        manifest_path,
        experiment_name="chapter3_stochastic_multiseed_baselines",
        args=args,
        archives=archives,
        outputs=(
            *seed_outputs,
            combined_path,
            comparison_path,
        ),
        root=ROOT,
        extra={
            "algorithm_seeds": seeds,
            "methods": methods,
            "records_per_method_seed": (
                len(combined) // max(1, len(methods) * len(seeds))
            ),
            "combined_row_count": len(combined),
            "comparison_row_count": len(comparison_rows),
        },
    )
    print(f"wrote: {combined_path}")
    print(f"wrote: {comparison_path}")
    print(f"wrote: {manifest_path}")


if __name__ == "__main__":
    main()
