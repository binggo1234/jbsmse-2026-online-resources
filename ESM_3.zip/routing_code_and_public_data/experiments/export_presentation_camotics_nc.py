from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.geometry import rectangle_corners, rectangle_edges
from cnc_cutting.io import (
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.models import CuttingUnit, EdgeSegment, Layout, PlacedRectangle, Point
from export_gcode_from_diagnostics import NcTemplate
from plot_route_case_pair_summary import (
    CASE_SPECS,
    DEFAULT_PRIVATE_DATA_ROOT,
    ROOT,
    require_archives,
)
from process_options import add_stability_model_args, add_tool_event_gate_args


def emit_header(lines: list[str], template: NcTemplate, source_label: str) -> None:
    lines.extend(
        [
            "(Presentation-only CAMotics visual audit NC)",
            f"(Source route: {source_label})",
            "(Purpose: clear primitive rectangle contour visualization)",
            "(This is not a machine-specific production post-processor)",
            f"(Stock: {template.stock_width_mm:.3f} x {template.stock_height_mm:.3f} x "
            f"{template.stock_thickness_mm:.3f} mm)",
            f"(Tool diameter: {template.tool_diameter_mm:.3f} mm)",
            "G21",
            "G90",
            "G17",
            f"G0 Z{template.z_safe_mm:.3f}",
            "T1 M6",
            f"M3 S{template.spindle_rpm}",
        ]
    )


def emit_footer(lines: list[str], template: NcTemplate) -> None:
    lines.extend([f"G0 Z{template.z_safe_mm:.3f}", "M5", "M30"])


def emit_rectangle_contour(
    lines: list[str],
    rectangle: PlacedRectangle,
    template: NcTemplate,
    index: int,
) -> None:
    lower_left, lower_right, upper_right, upper_left = rectangle_corners(rectangle)
    lines.extend(
        [
            f"(Part {index}: {rectangle.part_id})",
            f"G0 Z{template.z_safe_mm:.3f}",
            f"G0 X{lower_left.x:.3f} Y{lower_left.y:.3f}",
            f"G1 Z{-template.stock_thickness_mm:.3f} F{template.feed_plunge_mm_min:.1f}",
            f"G1 X{lower_right.x:.3f} Y{lower_right.y:.3f} F{template.feed_cut_mm_min:.1f}",
            f"G1 X{upper_right.x:.3f} Y{upper_right.y:.3f} F{template.feed_cut_mm_min:.1f}",
            f"G1 X{upper_left.x:.3f} Y{upper_left.y:.3f} F{template.feed_cut_mm_min:.1f}",
            f"G1 X{lower_left.x:.3f} Y{lower_left.y:.3f} F{template.feed_cut_mm_min:.1f}",
            f"G0 Z{template.z_safe_mm:.3f}",
        ]
    )


def distance(first: Point, second: Point) -> float:
    return ((first.x - second.x) ** 2 + (first.y - second.y) ** 2) ** 0.5


def emit_cut_edge(
    lines: list[str],
    segment: EdgeSegment,
    template: NcTemplate,
    action_index: int,
    current_xy: Point,
    *,
    trace_depth_mm: float,
    include_full_depth_pass: bool,
) -> Point:
    if distance(current_xy, segment.start) <= distance(current_xy, segment.end):
        start, end = segment.start, segment.end
    else:
        start, end = segment.end, segment.start
    trace_depth = -abs(trace_depth_mm)
    lines.extend(
        [
            f"(Expanded action {action_index}: primitive edge {segment.segment_id})",
            f"G0 Z{template.z_safe_mm:.3f}",
            f"G0 X{start.x:.3f} Y{start.y:.3f}",
            "(Visible trace pass for CAMotics top-surface readability)",
            f"G1 Z{trace_depth:.3f} F{template.feed_plunge_mm_min:.1f}",
            f"G1 X{end.x:.3f} Y{end.y:.3f} F{template.feed_cut_mm_min:.1f}",
        ]
    )
    if include_full_depth_pass:
        lines.extend(
            [
                "(Full-depth confirmation pass on the same expanded edge)",
                f"G1 Z{-template.stock_thickness_mm:.3f} F{template.feed_plunge_mm_min:.1f}",
                f"G1 X{start.x:.3f} Y{start.y:.3f} F{template.feed_cut_mm_min:.1f}",
                f"G0 Z{template.z_safe_mm:.3f}",
            ]
        )
        return start
    lines.append(f"G0 Z{template.z_safe_mm:.3f}")
    return end


def write_camotics_project(gcode_path: Path, template: NcTemplate) -> Path:
    project_path = gcode_path.with_suffix(".camotics")
    project = {
        "units": "metric",
        "resolution-mode": "manual",
        "resolution": 0.5,
        "tools": {
            "1": {
                "units": "metric",
                "shape": "cylindrical",
                "length": 30.0,
                "diameter": template.tool_diameter_mm,
                "description": "Generic CNC router bit",
            }
        },
        "workpiece": {
            "automatic": False,
            "margin": 0,
            "bounds": {
                "min": [0, 0, -template.stock_thickness_mm],
                "max": [template.stock_width_mm, template.stock_height_mm, 0],
            },
        },
        "files": [gcode_path.name],
    }
    project_path.write_text(json.dumps(project, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return project_path


def primitive_edge_count(layout: Layout) -> int:
    return sum(len(rectangle_edges(rectangle)) for rectangle in layout.rectangles)


def load_layout_and_units(
    spec,
    data_root: Path,
) -> tuple[Layout, dict[str, CuttingUnit]]:
    zip_path = spec.zip_path(data_root)
    cfg = load_chapter2_config_from_zip(
        zip_path,
        placements_member=spec.placements_member,
    )
    tool = tool_config_from_chapter2_config(cfg)
    layout = load_chapter2_layouts_from_zip(
        zip_path,
        placements_member=spec.placements_member,
        board_ids=(spec.board_id,),
    )[0]
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    return layout, {unit.unit_id: unit for unit in units}


def read_diagnostic_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty diagnostic CSV: {path}")
        return list(reader)


def export_route_expanded_edge_nc(
    layout: Layout,
    unit_by_id: dict[str, CuttingUnit],
    diagnostics_path: Path,
    output_dir: Path,
    output_name: str,
    template: NcTemplate,
    trace_depth_mm: float,
    include_full_depth_pass: bool,
) -> tuple[Path, int, int]:
    output_dir.mkdir(parents=True, exist_ok=True)
    nc_path = output_dir / output_name
    lines: list[str] = []
    emit_header(
        lines,
        template,
        f"{diagnostics_path}; expanded from final route cutting units",
    )
    rows = read_diagnostic_rows(diagnostics_path)
    current_xy = Point(0.0, 0.0)
    covered: set[str] = set()

    for row in rows:
        if row.get("action_type") != "cut":
            continue
        unit_id = row.get("cutting_unit_id", "")
        unit = unit_by_id.get(unit_id)
        if unit is None:
            raise KeyError(f"cutting_unit_id not found in candidate units: {unit_id}")
        # Preserve route-level unit order, but draw the actual primitive part edges
        # covered by the unit so CAMotics shows complete panel boundaries.
        remaining = list(unit.segments)
        while remaining:
            next_index, next_segment = min(
                enumerate(remaining),
                key=lambda item: min(
                    distance(current_xy, item[1].start),
                    distance(current_xy, item[1].end),
                ),
            )
            current_xy = emit_cut_edge(
                lines,
                next_segment,
                template,
                int(row["action_index"]),
                current_xy,
                trace_depth_mm=trace_depth_mm,
                include_full_depth_pass=include_full_depth_pass,
            )
            covered.add(next_segment.segment_id)
            del remaining[next_index]

    emit_footer(lines, template)
    nc_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_camotics_project(nc_path, template)
    return nc_path, len(covered), primitive_edge_count(layout) - len(covered)


def export_visual_contour_nc(
    layout: Layout,
    output_dir: Path,
    output_name: str,
    source_label: str,
    template: NcTemplate,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    nc_path = output_dir / output_name
    lines: list[str] = []
    emit_header(lines, template, source_label)
    for index, rectangle in enumerate(layout.rectangles, start=1):
        emit_rectangle_contour(lines, rectangle, template, index)
    emit_footer(lines, template)
    nc_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_camotics_project(nc_path, template)
    return nc_path


def write_readme(
    output_dir: Path,
    nc_path: Path,
    layout: Layout,
    *,
    include_full_depth_pass: bool,
) -> None:
    pass_description = (
        "Each expanded edge includes a shallow top-surface trace pass for "
        "CAMotics readability, followed by a full-depth confirmation pass on "
        "the same XY edge."
        if include_full_depth_pass
        else "Each expanded edge is emitted as a shallow top-surface trace "
        "pass only, so CAMotics top-view screenshots show the completed "
        "contour network clearly."
    )
    text = f"""# Board 340 Presentation CAMotics NC

This folder contains a visual-audit NC file for presentation screenshots.

- File: `{nc_path.name}`
- Rectangles: {len(layout.rectangles)}
- Primitive rectangle edges: {primitive_edge_count(layout)}
- Purpose: show complete final-route primitive-edge coverage clearly in CAMotics.

This file preserves the final route's cutting-unit order, then expands each
selected cutting unit into the primitive rectangle edges it covers.
{pass_description}
It is easier to read in CAMotics than the raw route-unit NC, where shared-edge,
near-shared, collinear-chain, and centerline-only paths can look visually
incomplete or cluttered.

Use this file for presentation visual inspection, not for route-cost metrics or
machine-specific production cutting.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Export a clean CAMotics NC for presentation contour visualization."
    )
    parser.add_argument("--data-root", type=Path, default=DEFAULT_PRIVATE_DATA_ROOT)
    parser.add_argument("--case-index", type=int, default=0, choices=range(len(CASE_SPECS)))
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results" / "camotics_presentation_board340",
    )
    parser.add_argument(
        "--output-name",
        default="board340_final_route_visible_edges.nc",
    )
    parser.add_argument(
        "--diagnostics",
        type=Path,
        default=ROOT
        / "results"
        / "chapter3_route_cases"
        / "case_large_board340"
        / "process_aware_beam_adaptive_polished_diagnostics.csv",
    )
    parser.add_argument("--stock-width-mm", type=float, default=2440.0)
    parser.add_argument("--stock-height-mm", type=float, default=1220.0)
    parser.add_argument("--stock-thickness-mm", type=float, default=18.0)
    parser.add_argument("--tool-diameter-mm", type=float, default=6.0)
    parser.add_argument("--z-safe-mm", type=float, default=5.0)
    parser.add_argument("--spindle-rpm", type=int, default=18000)
    parser.add_argument("--feed-cut-mm-min", type=float, default=3600.0)
    parser.add_argument("--feed-plunge-mm-min", type=float, default=800.0)
    parser.add_argument(
        "--trace-depth-mm",
        type=float,
        default=1.0,
        help="Shallow top-surface trace depth added before full-depth confirmation.",
    )
    parser.add_argument(
        "--skip-full-depth-pass",
        action="store_true",
        help="Only emit the shallow visible trace pass.",
    )
    add_stability_model_args(parser)
    add_tool_event_gate_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    require_archives(CASE_SPECS, args.data_root)
    spec = CASE_SPECS[args.case_index]
    layout, unit_by_id = load_layout_and_units(spec, args.data_root)
    template = NcTemplate(
        stock_width_mm=args.stock_width_mm,
        stock_height_mm=args.stock_height_mm,
        stock_thickness_mm=args.stock_thickness_mm,
        tool_diameter_mm=args.tool_diameter_mm,
        z_safe_mm=args.z_safe_mm,
        step_down_mm=args.stock_thickness_mm,
        spindle_rpm=args.spindle_rpm,
        feed_cut_mm_min=args.feed_cut_mm_min,
        feed_plunge_mm_min=args.feed_plunge_mm_min,
    )
    nc_path, covered_count, missing_count = export_route_expanded_edge_nc(
        layout,
        unit_by_id,
        args.diagnostics,
        args.output_dir,
        args.output_name,
        template,
        trace_depth_mm=args.trace_depth_mm,
        include_full_depth_pass=not args.skip_full_depth_pass,
    )
    write_readme(
        args.output_dir,
        nc_path,
        layout,
        include_full_depth_pass=not args.skip_full_depth_pass,
    )
    print(f"rectangles: {len(layout.rectangles)}")
    print(f"primitive_edges: {primitive_edge_count(layout)}")
    print(f"expanded_route_covered_edges: {covered_count}")
    print(f"expanded_route_missing_edges: {missing_count}")
    print(f"nc: {nc_path}")
    print(f"camotics: {nc_path.with_suffix('.camotics')}")


if __name__ == "__main__":
    main()
