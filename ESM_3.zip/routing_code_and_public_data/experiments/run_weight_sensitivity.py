from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from dataclasses import asdict, dataclass, fields, replace
from pathlib import Path
from statistics import mean, median, pstdev
from time import perf_counter

from cnc_cutting.coverage_diagnostics import diagnose_route_coverage
from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.io import load_chapter2_config_from_zip, load_chapter2_layouts_from_zip
from cnc_cutting.io import tool_config_from_chapter2_config
from cnc_cutting.models import Panel, ToolConfig
from experiment_manifest import default_manifest_path, write_experiment_manifest
from process_options import (
    add_experiment_preset_arg,
    add_repeat_cut_policy_args,
    add_stability_model_args,
    add_tool_event_gate_args,
    apply_experiment_preset,
    build_process_model_from_args,
    build_tool_event_gate_from_args,
    repeat_cut_policy_from_args,
)
from progress_bar import TerminalProgressBar
from progress_log import default_progress_log_path, prepare_progress_log
from run_chapter2_batch import (
    DEFAULT_ARCHIVES,
    BatchRouteRow,
    board_counts_from_zip,
    build_planners,
    parse_member_metadata,
    sample_placement_members,
    select_board_ids,
)
from task_timeout import TaskTimeoutError, task_timeout


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TARGET_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_BASELINE_METHOD = "contour_tsp_2opt"
DEFAULT_METHODS = (DEFAULT_BASELINE_METHOD, DEFAULT_TARGET_METHOD)
DEFAULT_TRAVEL_COST_SCALES = (0.5, 1.0, 2.0)
DEFAULT_SAFE_LIFT_FIXED_COSTS = (100.0, 250.0, 500.0)


@dataclass(frozen=True)
class WeightProfile:
    profile_name: str
    travel_cost_scale: float
    safe_lift_fixed_cost: float


@dataclass(frozen=True)
class WeightSensitivityRow:
    archive: str
    case_name: str
    placement_method: str
    seed: str
    placements_member: str
    board_id: str
    profile_name: str
    travel_cost_scale: float
    safe_lift_fixed_cost: float
    low_clearance_travel_weight: float
    detour_travel_weight: float
    safe_lift_travel_weight: float
    support_policy: str
    min_support_count: int
    min_support_ratio: float
    min_area_normalized_support: float
    adjacency_support_weight: float
    tool_event_gate_enabled: bool
    tool_event_min_travel_saving: float
    tool_event_min_travel_saving_ratio: float
    tool_event_min_machining_saving: float
    repeat_cut_policy: str
    method: str
    runtime_ms: float
    rectangle_count: int
    candidate_unit_count: int
    selected_unit_count: int
    action_count: int
    selected_composite_coverage_ratio: float
    cut_repeated_segment_count: int
    cut_duplicate_segment_length: float
    redundant_cut_action_count: int
    cutting_length: float
    travel_mode_cost: float
    machining_cost: float
    air_move_distance: float
    pierce_count: int
    lift_count: int
    safe_lift_count: int
    safe_lift_distance: float
    detour_count: int
    detour_distance: float
    hard_penalty: float
    stability_penalty: float


@dataclass(frozen=True)
class WeightSensitivitySummaryRow:
    profile_name: str
    travel_cost_scale: float
    safe_lift_fixed_cost: float
    method: str
    support_policy: str
    min_support_count: int
    min_support_ratio: float
    min_area_normalized_support: float
    adjacency_support_weight: float
    tool_event_gate_enabled: bool
    repeat_cut_policy: str
    n: int
    runtime_ms_mean: float
    runtime_ms_std: float
    cutting_length_mean: float
    travel_mode_cost_mean: float
    machining_cost_mean: float
    air_move_distance_mean: float
    safe_lift_count_mean: float
    detour_count_mean: float
    cut_repeated_segment_count_mean: float
    selected_composite_coverage_ratio_mean: float
    hard_penalty_mean: float
    stability_penalty_mean: float


@dataclass(frozen=True)
class WeightSensitivityPairedRow:
    profile_name: str
    travel_cost_scale: float
    safe_lift_fixed_cost: float
    baseline_method: str
    target_method: str
    n: int
    baseline_machining_cost_mean: float
    target_machining_cost_mean: float
    machining_cost_delta_mean: float
    machining_cost_reduction_pct_mean: float
    machining_cost_reduction_pct_median: float
    machining_cost_win_rate: float
    baseline_travel_mode_cost_mean: float
    target_travel_mode_cost_mean: float
    travel_mode_cost_delta_mean: float
    baseline_cutting_length_mean: float
    target_cutting_length_mean: float
    cutting_length_delta_mean: float
    baseline_runtime_ms_mean: float
    target_runtime_ms_mean: float
    runtime_ms_delta_mean: float


def profile_name(travel_cost_scale: float, safe_lift_fixed_cost: float) -> str:
    return (
        f"travel{travel_cost_scale:g}_lift{safe_lift_fixed_cost:g}"
        .replace(".", "p")
        .replace("-", "m")
    )


def build_weight_profiles(
    travel_cost_scales: tuple[float, ...],
    safe_lift_fixed_costs: tuple[float, ...],
) -> tuple[WeightProfile, ...]:
    profiles: list[WeightProfile] = []
    for travel_cost_scale in travel_cost_scales:
        if travel_cost_scale <= 0.0:
            raise ValueError("travel_cost_scale must be positive")
        for safe_lift_fixed_cost in safe_lift_fixed_costs:
            if safe_lift_fixed_cost < 0.0:
                raise ValueError("safe_lift_fixed_cost must be non-negative")
            profiles.append(
                WeightProfile(
                    profile_name=profile_name(travel_cost_scale, safe_lift_fixed_cost),
                    travel_cost_scale=travel_cost_scale,
                    safe_lift_fixed_cost=safe_lift_fixed_cost,
                )
            )
    return tuple(profiles)


def weighted_tool_config(base_tool: ToolConfig, profile: WeightProfile) -> ToolConfig:
    return replace(
        base_tool,
        low_clearance_travel_weight=(
            base_tool.low_clearance_travel_weight * profile.travel_cost_scale
        ),
        detour_travel_weight=base_tool.detour_travel_weight * profile.travel_cost_scale,
        safe_lift_travel_weight=(
            base_tool.safe_lift_travel_weight * profile.travel_cost_scale
        ),
        safe_lift_fixed_cost=profile.safe_lift_fixed_cost,
    )


def row_key(row: WeightSensitivityRow) -> tuple[str, ...]:
    return (
        row.archive,
        row.placements_member,
        row.board_id,
        row.profile_name,
        row.method,
        row.support_policy,
        str(row.min_support_count),
        f"{row.min_support_ratio:.12g}",
        f"{row.min_area_normalized_support:.12g}",
        f"{row.adjacency_support_weight:.12g}",
        str(row.tool_event_gate_enabled),
        f"{row.tool_event_min_travel_saving:.12g}",
        f"{row.tool_event_min_travel_saving_ratio:.12g}",
        f"{row.tool_event_min_machining_saving:.12g}",
        row.repeat_cut_policy,
    )


def planned_row_key(
    archive_name: str,
    placements_member: str,
    board_id: str,
    profile: WeightProfile,
    method: str,
    args: argparse.Namespace,
) -> tuple[str, ...]:
    return (
        archive_name,
        placements_member,
        board_id,
        profile.profile_name,
        method,
        args.support_policy,
        str(args.min_support_count),
        f"{args.min_support_ratio:.12g}",
        f"{args.min_area_normalized_support:.12g}",
        f"{args.adjacency_support_weight:.12g}",
        str(not getattr(args, "disable_tool_event_gate", False)),
        f"{args.tool_event_min_travel_saving:.12g}",
        f"{args.tool_event_min_travel_saving_ratio:.12g}",
        f"{args.tool_event_min_machining_saving:.12g}",
        repeat_cut_policy_from_args(args),
    )


def batch_row_to_weight_row(
    row: BatchRouteRow,
    profile: WeightProfile,
    tool: ToolConfig,
) -> WeightSensitivityRow:
    return WeightSensitivityRow(
        archive=row.archive,
        case_name=row.case_name,
        placement_method=row.placement_method,
        seed=row.seed,
        placements_member=row.placements_member,
        board_id=row.board_id,
        profile_name=profile.profile_name,
        travel_cost_scale=profile.travel_cost_scale,
        safe_lift_fixed_cost=profile.safe_lift_fixed_cost,
        low_clearance_travel_weight=tool.low_clearance_travel_weight,
        detour_travel_weight=tool.detour_travel_weight,
        safe_lift_travel_weight=tool.safe_lift_travel_weight,
        support_policy=row.support_policy,
        min_support_count=row.min_support_count,
        min_support_ratio=row.min_support_ratio,
        min_area_normalized_support=row.min_area_normalized_support,
        adjacency_support_weight=row.adjacency_support_weight,
        tool_event_gate_enabled=row.tool_event_gate_enabled,
        tool_event_min_travel_saving=row.tool_event_min_travel_saving,
        tool_event_min_travel_saving_ratio=row.tool_event_min_travel_saving_ratio,
        tool_event_min_machining_saving=row.tool_event_min_machining_saving,
        repeat_cut_policy=row.repeat_cut_policy,
        method=row.method,
        runtime_ms=row.runtime_ms,
        rectangle_count=row.rectangle_count,
        candidate_unit_count=row.candidate_unit_count,
        selected_unit_count=row.selected_unit_count,
        action_count=row.action_count,
        selected_composite_coverage_ratio=row.selected_composite_coverage_ratio,
        cut_repeated_segment_count=row.cut_repeated_segment_count,
        cut_duplicate_segment_length=row.cut_duplicate_segment_length,
        redundant_cut_action_count=row.redundant_cut_action_count,
        cutting_length=row.cutting_length,
        travel_mode_cost=row.travel_mode_cost,
        machining_cost=row.cutting_length + row.travel_mode_cost,
        air_move_distance=row.air_move_distance,
        pierce_count=row.pierce_count,
        lift_count=row.lift_count,
        safe_lift_count=row.safe_lift_count,
        safe_lift_distance=row.safe_lift_distance,
        detour_count=row.detour_count,
        detour_distance=row.detour_distance,
        hard_penalty=row.hard_penalty,
        stability_penalty=row.stability_penalty,
    )


def run_weighted_case(
    archive: Path,
    placements_member: str,
    board_id: str,
    profile: WeightProfile,
    methods: tuple[str, ...],
    args: argparse.Namespace,
    completed_keys: set[tuple[str, ...]] | None,
    progress_bar: TerminalProgressBar | None,
) -> tuple[WeightSensitivityRow, ...]:
    cfg = load_chapter2_config_from_zip(archive, placements_member=placements_member)
    tool = weighted_tool_config(tool_config_from_chapter2_config(cfg), profile)
    layout = load_chapter2_layouts_from_zip(
        archive,
        placements_member=placements_member,
        board_ids=(board_id,),
    )[0]
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    process_model = build_process_model_from_args(layout, args)
    tool_event_gate = build_tool_event_gate_from_args(args)
    repeat_cut_policy = repeat_cut_policy_from_args(args)
    candidate_units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    planners = build_planners(
        methods,
        candidate_units,
        panel,
        tool,
        process_model,
        tool_event_gate,
        len(layout.rectangles),
        repeat_cut_policy,
    )
    rows: list[WeightSensitivityRow] = []
    for spec in planners:
        key = planned_row_key(
            archive.name,
            placements_member,
            board_id,
            profile,
            spec.method,
            args,
        )
        if completed_keys is not None and key in completed_keys:
            print(
                f"    skip completed: profile={profile.profile_name} "
                f"board={board_id} method={spec.method}"
            )
            if progress_bar is not None:
                progress_bar.advance("skipped", f"{profile.profile_name} {spec.method}")
            continue

        print(
            f"    run: profile={profile.profile_name} board={board_id} "
            f"method={spec.method} rectangles={len(layout.rectangles)}"
        )
        start = perf_counter()
        try:
            with task_timeout(args.task_timeout_seconds):
                plan = spec.planner()
        except TaskTimeoutError:
            elapsed_ms = (perf_counter() - start) * 1000.0
            print(
                f"    timed out: profile={profile.profile_name} board={board_id} "
                f"method={spec.method} elapsed={elapsed_ms:.3f} ms "
                f"limit={args.task_timeout_seconds:g} s"
            )
            if progress_bar is not None:
                progress_bar.advance("timed_out", f"{profile.profile_name} {spec.method}")
            continue

        runtime_ms = (perf_counter() - start) * 1000.0
        coverage = diagnose_route_coverage(
            candidate_units,
            plan.selected_units,
            plan.actions,
            process_model=process_model,
        )
        case_name, placement_method, seed = parse_member_metadata(placements_member)
        batch_row = BatchRouteRow(
            archive=archive.name,
            case_name=case_name,
            placement_method=placement_method,
            seed=seed,
            placements_member=placements_member,
            board_id=board_id,
            support_policy=args.support_policy,
            min_support_count=args.min_support_count,
            min_support_ratio=args.min_support_ratio,
            min_area_normalized_support=args.min_area_normalized_support,
            adjacency_support_weight=args.adjacency_support_weight,
            tool_event_gate_enabled=tool_event_gate.enabled,
            tool_event_min_travel_saving=(
                tool_event_gate.min_travel_saving_per_extra_event
            ),
            tool_event_min_travel_saving_ratio=(
                tool_event_gate.min_travel_saving_ratio_per_extra_event
            ),
            tool_event_min_machining_saving=tool_event_gate.min_machining_saving,
            repeat_cut_policy=repeat_cut_policy,
            method=spec.method,
            topology_candidate_pool_size=spec.topology_candidate_pool_size,
            beam_width=spec.beam_width,
            beam_candidate_pool_size=spec.beam_candidate_pool_size,
            beam_max_expansions_per_node=spec.beam_max_expansions_per_node,
            beam_max_layer_expansions=spec.beam_max_layer_expansions,
            beam_diversity_bucket_limit=spec.beam_diversity_bucket_limit,
            beam_min_expansions_per_parent=spec.beam_min_expansions_per_parent,
            beam_unstable_min_expansions_per_parent=(
                spec.beam_unstable_min_expansions_per_parent
            ),
            beam_unstable_layer_expansion_multiplier=(
                spec.beam_unstable_layer_expansion_multiplier
            ),
            beam_unstable_layer_expansion_bonus=spec.beam_unstable_layer_expansion_bonus,
            runtime_ms=runtime_ms,
            rectangle_count=len(layout.rectangles),
            rectangle_count_bin="",
            candidate_unit_count=len(candidate_units),
            selected_unit_count=len(plan.selected_units),
            action_count=len(plan.actions),
            coverage_original_segment_count=coverage.original_segment_count,
            coverage_covered_segment_count=coverage.coverage_covered_segment_count,
            coverage_missing_segment_count=coverage.coverage_missing_segment_count,
            coverage_repeated_segment_count=coverage.coverage_repeated_segment_count,
            coverage_duplicate_segment_count=coverage.coverage_duplicate_segment_count,
            coverage_duplicate_segment_length=coverage.coverage_duplicate_segment_length,
            cut_covered_segment_count=coverage.cut_covered_segment_count,
            cut_missing_segment_count=coverage.cut_missing_segment_count,
            cut_repeated_segment_count=coverage.cut_repeated_segment_count,
            cut_duplicate_segment_count=coverage.cut_duplicate_segment_count,
            cut_duplicate_segment_length=coverage.cut_duplicate_segment_length,
            selected_single_edge_count=coverage.selected_single_edge_count,
            selected_shared_edge_count=coverage.selected_shared_edge_count,
            selected_near_shared_channel_count=coverage.selected_near_shared_channel_count,
            selected_collinear_chain_count=coverage.selected_collinear_chain_count,
            selected_composite_unit_count=coverage.selected_composite_unit_count,
            selected_composite_covered_segment_count=(
                coverage.selected_composite_covered_segment_count
            ),
            selected_composite_coverage_ratio=coverage.selected_composite_coverage_ratio,
            partially_overlapping_selected_unit_count=(
                coverage.partially_overlapping_selected_unit_count
            ),
            redundant_selected_unit_count=coverage.redundant_selected_unit_count,
            partial_repeated_cut_action_count=coverage.partial_repeated_cut_action_count,
            redundant_cut_action_count=coverage.redundant_cut_action_count,
            process_repeated_span_count=plan.metrics.repeated_cut_segment_count,
            process_repeated_span_length=plan.metrics.repeated_cut_length,
            process_redundant_action_count=plan.metrics.redundant_cut_action_count,
            process_tool_event_count=(
                plan.metrics.pierce_count
                + plan.metrics.lift_count
                + plan.metrics.safe_lift_count
            ),
            process_turn_penalty=plan.metrics.turn_penalty,
            process_negative_continuity_reward=-plan.metrics.continuity_reward,
            air_move_distance=plan.metrics.air_move_distance,
            cutting_length=plan.metrics.cutting_length,
            pierce_count=plan.metrics.pierce_count,
            lift_count=plan.metrics.lift_count,
            collision_penalty=plan.metrics.collision_penalty,
            boundary_penalty=plan.metrics.boundary_penalty,
            stability_penalty=plan.metrics.stability_penalty,
            safe_lift_count=plan.metrics.safe_lift_count,
            safe_lift_distance=plan.metrics.safe_lift_distance,
            detour_count=plan.metrics.detour_count,
            detour_distance=plan.metrics.detour_distance,
            travel_mode_cost=plan.metrics.travel_mode_cost,
            hard_penalty=plan.metrics.hard_penalty,
        )
        rows.append(batch_row_to_weight_row(batch_row, profile, tool))
        if progress_bar is not None:
            progress_bar.advance("completed", f"{profile.profile_name} {spec.method}")
    return tuple(rows)


def sample_cases(
    archives: tuple[Path, ...],
    max_members_per_archive: int,
    boards_per_member: int,
    min_rectangles: int,
    max_rectangles: int | None,
) -> tuple[tuple[Path, str, str], ...]:
    cases: list[tuple[Path, str, str]] = []
    for archive in archives:
        for member in sample_placement_members(archive, max_members_per_archive):
            board_ids = select_board_ids(
                board_counts_from_zip(archive, member),
                boards_per_member=boards_per_member,
                min_rectangles=min_rectangles,
                max_rectangles=max_rectangles,
            )
            for board_id in board_ids:
                cases.append((archive, member, board_id))
    return tuple(cases)


def summarize_rows(
    rows: tuple[WeightSensitivityRow, ...],
) -> tuple[WeightSensitivitySummaryRow, ...]:
    groups: dict[tuple[str, str], list[WeightSensitivityRow]] = defaultdict(list)
    for row in rows:
        groups[(row.profile_name, row.method)].append(row)

    summary: list[WeightSensitivitySummaryRow] = []
    for profile, method in sorted(groups):
        items = groups[(profile, method)]
        summary.append(
            WeightSensitivitySummaryRow(
                profile_name=profile,
                travel_cost_scale=items[0].travel_cost_scale,
                safe_lift_fixed_cost=items[0].safe_lift_fixed_cost,
                method=method,
                support_policy=items[0].support_policy,
                min_support_count=items[0].min_support_count,
                min_support_ratio=items[0].min_support_ratio,
                min_area_normalized_support=items[0].min_area_normalized_support,
                adjacency_support_weight=items[0].adjacency_support_weight,
                tool_event_gate_enabled=items[0].tool_event_gate_enabled,
                repeat_cut_policy=items[0].repeat_cut_policy,
                n=len(items),
                runtime_ms_mean=mean(row.runtime_ms for row in items),
                runtime_ms_std=pstdev(row.runtime_ms for row in items),
                cutting_length_mean=mean(row.cutting_length for row in items),
                travel_mode_cost_mean=mean(row.travel_mode_cost for row in items),
                machining_cost_mean=mean(row.machining_cost for row in items),
                air_move_distance_mean=mean(row.air_move_distance for row in items),
                safe_lift_count_mean=mean(row.safe_lift_count for row in items),
                detour_count_mean=mean(row.detour_count for row in items),
                cut_repeated_segment_count_mean=mean(
                    row.cut_repeated_segment_count for row in items
                ),
                selected_composite_coverage_ratio_mean=mean(
                    row.selected_composite_coverage_ratio for row in items
                ),
                hard_penalty_mean=mean(row.hard_penalty for row in items),
                stability_penalty_mean=mean(row.stability_penalty for row in items),
            )
        )
    return tuple(summary)


def paired_summary_rows(
    rows: tuple[WeightSensitivityRow, ...],
    target_method: str,
    baseline_methods: tuple[str, ...],
) -> tuple[WeightSensitivityPairedRow, ...]:
    by_case: dict[tuple[str, str, str, str], dict[str, WeightSensitivityRow]] = (
        defaultdict(dict)
    )
    for row in rows:
        key = (row.archive, row.placements_member, row.board_id, row.profile_name)
        by_case[key][row.method] = row

    grouped: dict[tuple[str, str], list[tuple[WeightSensitivityRow, WeightSensitivityRow]]] = (
        defaultdict(list)
    )
    for method_rows in by_case.values():
        target = method_rows.get(target_method)
        if target is None:
            continue
        for baseline_method in baseline_methods:
            baseline = method_rows.get(baseline_method)
            if baseline is not None:
                grouped[(target.profile_name, baseline_method)].append((baseline, target))

    paired_rows: list[WeightSensitivityPairedRow] = []
    for profile, baseline_method in sorted(grouped):
        pairs = grouped[(profile, baseline_method)]
        reductions = [
            reduction_pct(baseline.machining_cost, target.machining_cost)
            for baseline, target in pairs
        ]
        paired_rows.append(
            WeightSensitivityPairedRow(
                profile_name=profile,
                travel_cost_scale=pairs[0][1].travel_cost_scale,
                safe_lift_fixed_cost=pairs[0][1].safe_lift_fixed_cost,
                baseline_method=baseline_method,
                target_method=target_method,
                n=len(pairs),
                baseline_machining_cost_mean=mean(
                    baseline.machining_cost for baseline, _ in pairs
                ),
                target_machining_cost_mean=mean(target.machining_cost for _, target in pairs),
                machining_cost_delta_mean=mean(
                    target.machining_cost - baseline.machining_cost
                    for baseline, target in pairs
                ),
                machining_cost_reduction_pct_mean=mean(reductions),
                machining_cost_reduction_pct_median=median(reductions),
                machining_cost_win_rate=mean(
                    target.machining_cost < baseline.machining_cost
                    for baseline, target in pairs
                ),
                baseline_travel_mode_cost_mean=mean(
                    baseline.travel_mode_cost for baseline, _ in pairs
                ),
                target_travel_mode_cost_mean=mean(
                    target.travel_mode_cost for _, target in pairs
                ),
                travel_mode_cost_delta_mean=mean(
                    target.travel_mode_cost - baseline.travel_mode_cost
                    for baseline, target in pairs
                ),
                baseline_cutting_length_mean=mean(
                    baseline.cutting_length for baseline, _ in pairs
                ),
                target_cutting_length_mean=mean(target.cutting_length for _, target in pairs),
                cutting_length_delta_mean=mean(
                    target.cutting_length - baseline.cutting_length
                    for baseline, target in pairs
                ),
                baseline_runtime_ms_mean=mean(baseline.runtime_ms for baseline, _ in pairs),
                target_runtime_ms_mean=mean(target.runtime_ms for _, target in pairs),
                runtime_ms_delta_mean=mean(
                    target.runtime_ms - baseline.runtime_ms for baseline, target in pairs
                ),
            )
        )
    return tuple(paired_rows)


def reduction_pct(baseline: float, target: float) -> float:
    if baseline == 0.0:
        return 0.0
    return (baseline - target) / baseline * 100.0


def write_dataclass_rows(path: Path, rows: tuple) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def append_dataclass_rows(path: Path, rows: tuple[WeightSensitivityRow, ...]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()))
        if write_header:
            writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def load_existing_rows(path: Path) -> tuple[WeightSensitivityRow, ...]:
    if not path.exists() or path.stat().st_size == 0:
        return ()
    with path.open(newline="", encoding="utf-8") as handle:
        return tuple(row_from_dict(row) for row in csv.DictReader(handle))


def row_from_dict(raw: dict[str, str]) -> WeightSensitivityRow:
    return WeightSensitivityRow(
        **{
            field.name: coerce_value(field.name, raw.get(field.name, ""))
            for field in fields(WeightSensitivityRow)
        }
    )


INT_FIELDS = {
    "min_support_count",
    "rectangle_count",
    "candidate_unit_count",
    "selected_unit_count",
    "action_count",
    "cut_repeated_segment_count",
    "redundant_cut_action_count",
    "pierce_count",
    "lift_count",
    "safe_lift_count",
    "detour_count",
}
FLOAT_FIELDS = {
    "travel_cost_scale",
    "safe_lift_fixed_cost",
    "low_clearance_travel_weight",
    "detour_travel_weight",
    "safe_lift_travel_weight",
    "min_support_ratio",
    "min_area_normalized_support",
    "adjacency_support_weight",
    "tool_event_min_travel_saving",
    "tool_event_min_travel_saving_ratio",
    "tool_event_min_machining_saving",
    "runtime_ms",
    "selected_composite_coverage_ratio",
    "cut_duplicate_segment_length",
    "cutting_length",
    "travel_mode_cost",
    "machining_cost",
    "air_move_distance",
    "safe_lift_distance",
    "detour_distance",
    "hard_penalty",
    "stability_penalty",
}
BOOL_FIELDS = {"tool_event_gate_enabled"}


def coerce_value(name: str, value: str):
    if name in BOOL_FIELDS:
        return value == "True"
    if name in INT_FIELDS:
        return int(value)
    if name in FLOAT_FIELDS:
        return float(value)
    return value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run weight-sensitivity experiments for normalized CNC machining cost."
        )
    )
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=3)
    parser.add_argument("--boards-per-member", type=int, default=1)
    parser.add_argument("--min-rectangles", type=int, default=20)
    parser.add_argument("--max-rectangles", type=int, default=50)
    parser.add_argument(
        "--travel-cost-scales",
        nargs="+",
        type=float,
        default=list(DEFAULT_TRAVEL_COST_SCALES),
        help="Multipliers applied to all distance-based travel-mode weights.",
    )
    parser.add_argument(
        "--safe-lift-fixed-costs",
        nargs="+",
        type=float,
        default=list(DEFAULT_SAFE_LIFT_FIXED_COSTS),
        help="Absolute fixed costs assigned to each safe-lift travel event.",
    )
    parser.add_argument(
        "--methods",
        nargs="+",
        default=list(DEFAULT_METHODS),
    )
    parser.add_argument("--target-method", default=DEFAULT_TARGET_METHOD)
    parser.add_argument(
        "--baseline-methods",
        nargs="+",
        default=[DEFAULT_BASELINE_METHOD],
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results" / "chapter3_weight_sensitivity.csv",
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=ROOT / "results" / "chapter3_weight_sensitivity_summary.csv",
    )
    parser.add_argument(
        "--paired-output",
        type=Path,
        default=ROOT / "results" / "chapter3_weight_sensitivity_paired.csv",
    )
    parser.add_argument("--manifest-output", type=Path, default=None)
    parser.add_argument("--progress-output", type=Path, default=None)
    parser.add_argument("--task-timeout-seconds", type=float, default=30.0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-progress-bar", action="store_true")
    add_experiment_preset_arg(parser)
    add_stability_model_args(parser)
    add_tool_event_gate_args(parser)
    add_repeat_cut_policy_args(parser)
    return apply_experiment_preset(parser.parse_args())


def main() -> None:
    args = parse_args()
    archives = tuple(args.zip_paths) if args.zip_paths else DEFAULT_ARCHIVES
    methods = tuple(args.methods)
    if args.target_method not in methods:
        raise ValueError("--target-method must be included in --methods")
    missing_baselines = set(args.baseline_methods) - set(methods)
    if missing_baselines:
        raise ValueError(f"--baseline-methods must be included in --methods: {missing_baselines}")
    profiles = build_weight_profiles(
        tuple(args.travel_cost_scales),
        tuple(args.safe_lift_fixed_costs),
    )
    cases = sample_cases(
        archives,
        max_members_per_archive=args.max_members_per_archive,
        boards_per_member=args.boards_per_member,
        min_rectangles=args.min_rectangles,
        max_rectangles=args.max_rectangles,
    )
    if not cases:
        raise ValueError("no weight-sensitivity cases produced; relax filters")

    progress_output = args.progress_output or default_progress_log_path(args.output)
    prepare_progress_log(progress_output, resume=args.resume)
    existing_rows = load_existing_rows(args.output) if args.resume else ()
    completed_keys = {row_key(row) for row in existing_rows}
    if not args.resume:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text("", encoding="utf-8")
    rows: list[WeightSensitivityRow] = list(existing_rows)
    if existing_rows:
        print(f"resume: loaded {len(existing_rows)} rows from {args.output}")

    planned_tasks = len(cases) * len(profiles) * len(methods)
    progress_bar = TerminalProgressBar(
        planned_tasks,
        enabled=not args.no_progress_bar,
    )
    progress_bar.start("weight-sensitivity method tasks")
    print(
        f"sampled_cases={len(cases)} profiles={len(profiles)} "
        f"methods={','.join(methods)}"
    )
    for archive, member, board_id in cases:
        print(f"case: {archive.name} board={board_id} member={member}")
        for profile in profiles:
            new_rows = run_weighted_case(
                archive,
                member,
                board_id,
                profile,
                methods,
                args,
                completed_keys,
                progress_bar,
            )
            append_dataclass_rows(args.output, new_rows)
            rows.extend(new_rows)
            completed_keys.update(row_key(row) for row in new_rows)

    if not rows:
        raise ValueError("no weight-sensitivity rows produced")

    row_tuple = tuple(rows)
    summary = summarize_rows(row_tuple)
    paired = paired_summary_rows(
        row_tuple,
        target_method=args.target_method,
        baseline_methods=tuple(args.baseline_methods),
    )
    write_dataclass_rows(args.summary_output, summary)
    write_dataclass_rows(args.paired_output, paired)
    manifest_output = args.manifest_output or default_manifest_path(args.output)
    write_experiment_manifest(
        manifest_output,
        experiment_name="chapter3_weight_sensitivity",
        args=args,
        archives=archives,
        outputs=(args.output, args.summary_output, args.paired_output, progress_output),
        root=ROOT,
        extra={
            "row_count": len(row_tuple),
            "summary_row_count": len(summary),
            "paired_row_count": len(paired),
            "profiles": tuple(asdict(profile) for profile in profiles),
            "methods": methods,
            "target_method": args.target_method,
            "baseline_methods": tuple(args.baseline_methods),
        },
    )

    print(f"wrote: {args.output}")
    print(f"wrote: {args.summary_output}")
    print(f"wrote: {args.paired_output}")
    print(f"wrote: {manifest_output}")
    for row in paired:
        print(
            f"{row.profile_name:<20} {row.baseline_method:<20} "
            f"n={row.n:<3} reduction={row.machining_cost_reduction_pct_mean:>7.2f}% "
            f"win={row.machining_cost_win_rate:>5.2f}"
        )


if __name__ == "__main__":
    main()
