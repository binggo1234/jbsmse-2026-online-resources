from __future__ import annotations

import argparse
import csv
import html
import json
from pathlib import Path


DEFAULT_ROUTE_CASE_DIRS = (
    Path("results/chapter3_route_cases/case_large_board340"),
    Path("results/chapter3_route_cases/case_large_guard_board341"),
    Path("results/chapter3_route_cases/case_mid_board262"),
    Path("results/chapter3_route_cases/case_small_board4"),
    Path("results/paper_artifacts_final_selector/route_case_large_gain_diagnostics"),
    Path("results/paper_artifacts_final_selector/route_case_medium_diagnostics"),
    Path("results/paper_artifacts_final_selector/route_case_small_diagnostics"),
    Path("results/representative_route_cases_after_runtime_opt/main_adaptive_gain_diagnostics"),
)

DEFAULT_DIAGNOSTICS = tuple(
    path
    for case_dir in DEFAULT_ROUTE_CASE_DIRS
    for path in (
        case_dir / "process_aware_beam_diagnostics.csv",
        case_dir / "process_aware_beam_adaptive_polished_diagnostics.csv",
    )
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate an offline HTML route viewer from diagnostic CSV files."
    )
    parser.add_argument("--diagnostics", type=Path, nargs="*", default=DEFAULT_DIAGNOSTICS)
    parser.add_argument(
        "--summary",
        type=Path,
        default=Path("results/nc_simulation_mvp/nc_simulation_summary.csv"),
    )
    parser.add_argument(
        "--pair-summary",
        type=Path,
        default=Path("results/nc_simulation_mvp/nc_simulation_pair_summary.csv"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/nc_simulation_mvp/offline_route_viewer.html"),
    )
    parser.add_argument("--stock-width-mm", type=float, default=2440.0)
    parser.add_argument("--stock-height-mm", type=float, default=1220.0)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        return list(reader)


def num(row: dict[str, str], field: str) -> float:
    value = row.get(field, "")
    return float(value) if value else 0.0


def infer_case_and_method(path: Path) -> tuple[str, str]:
    case_name = path.parent.name
    method = path.stem
    if method.endswith("_diagnostics"):
        method = method[: -len("_diagnostics")]
    return case_name, method


def route_payload(path: Path) -> dict:
    case_name, method = infer_case_and_method(path)
    actions = []
    for row in read_csv(path):
        actions.append(
            {
                "index": int(row["action_index"]),
                "type": row["action_type"],
                "mode": row.get("travel_mode", ""),
                "x1": num(row, "start_x"),
                "y1": num(row, "start_y"),
                "x2": num(row, "end_x"),
                "y2": num(row, "end_y"),
                "unit": row.get("cutting_unit_id", ""),
                "collision": num(row, "collision_penalty") + num(row, "boundary_penalty"),
                "safeLift": num(row, "safe_lift_count"),
                "detour": num(row, "detour_count"),
            }
        )
    return {"case": case_name, "method": method, "actions": actions}


def build_html(payload: dict) -> str:
    data = json.dumps(payload, ensure_ascii=False)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>NC-level route viewer</title>
<style>
body {{
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  color: #111;
  background: #fff;
}}
.wrap {{
  max-width: 1280px;
  margin: 20px auto;
  padding: 0 22px 32px;
}}
h1 {{ font-size: 22px; margin: 0 0 8px; }}
.note {{ color: #444; font-size: 13px; margin-bottom: 16px; line-height: 1.45; }}
.controls {{
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 14px;
}}
select, button {{
  font-size: 14px;
  padding: 6px 9px;
  border: 1px solid #999;
  border-radius: 4px;
  background: #fff;
}}
.grid {{
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 16px;
  align-items: start;
}}
svg {{
  width: 100%;
  height: auto;
  border: 1px solid #111;
  background: #fafafa;
}}
.panel {{
  border: 1px solid #bbb;
  padding: 12px;
  font-size: 13px;
  line-height: 1.5;
}}
.legend span {{
  display: inline-block;
  width: 28px;
  height: 0;
  border-top: 3px solid #000;
  margin-right: 7px;
  vertical-align: middle;
}}
.legend .travel {{ border-top: 2px dashed #777; }}
.legend .detour {{ border-top-color: #0072B2; }}
.legend .safe {{ border-top-color: #7C3AED; }}
.legend .bad {{ border-top-color: #C00000; }}
table {{ border-collapse: collapse; width: 100%; font-size: 12px; margin-top: 12px; }}
td, th {{ border-bottom: 1px solid #ddd; padding: 4px 3px; text-align: right; }}
td:first-child, th:first-child {{ text-align: left; }}
@media (max-width: 900px) {{
  .grid {{ grid-template-columns: 1fr; }}
}}
</style>
</head>
<body>
<div class="wrap">
<h1>Offline NC-level route viewer</h1>
<div class="note">
This page renders route diagnostic CSV files locally in the browser. It is a visual
pre-check before NC Viewer/CAMotics and does not upload production-derived route data
to an external web service.
</div>
<div class="controls">
  <label>Case/method:
    <select id="routeSelect"></select>
  </label>
  <button id="toggleTravel">Toggle travel moves</button>
  <button id="fitRoute">Fit route bounds</button>
</div>
<div class="grid">
  <svg id="canvas" viewBox="0 0 2440 1220" role="img" aria-label="Route drawing"></svg>
  <div class="panel">
    <b id="routeTitle"></b>
    <div id="metrics"></div>
    <div class="legend">
      <p><span></span>cut</p>
      <p><span class="travel"></span>low-clearance travel</p>
      <p><span class="travel detour"></span>detour travel</p>
      <p><span class="travel safe"></span>safe-lift travel</p>
      <p><span class="travel bad"></span>penalty-marked move</p>
    </div>
  </div>
</div>
</div>
<script>
const DATA = {data};
let showTravel = true;
let fitBounds = false;
const svg = document.getElementById('canvas');
const select = document.getElementById('routeSelect');
for (const route of DATA.routes) {{
  const opt = document.createElement('option');
  opt.value = route.case + '||' + route.method;
  opt.textContent = route.case + ' / ' + route.method;
  select.appendChild(opt);
}}
function routeKey(route) {{ return route.case + '||' + route.method; }}
function selectedRoute() {{
  return DATA.routes.find(r => routeKey(r) === select.value) || DATA.routes[0];
}}
function lineColor(action) {{
  if (action.collision > 0) return '#C00000';
  if (action.type === 'cut') return '#111111';
  if (action.mode === 'safe_lift') return '#7C3AED';
  if (action.mode === 'low_clearance_detour') return '#0072B2';
  return '#777777';
}}
function dash(action) {{
  return action.type === 'cut' ? '' : '8 6';
}}
function setViewBox(route) {{
  if (!fitBounds) {{
    svg.setAttribute('viewBox', `0 0 ${{DATA.stock.width}} ${{DATA.stock.height}}`);
    return;
  }}
  const xs = [], ys = [];
  for (const a of route.actions) {{
    xs.push(a.x1, a.x2); ys.push(a.y1, a.y2);
  }}
  const pad = 50;
  const minX = Math.max(0, Math.min(...xs) - pad);
  const minY = Math.max(0, Math.min(...ys) - pad);
  const maxX = Math.min(DATA.stock.width, Math.max(...xs) + pad);
  const maxY = Math.min(DATA.stock.height, Math.max(...ys) + pad);
  svg.setAttribute('viewBox', `${{minX}} ${{minY}} ${{maxX-minX}} ${{maxY-minY}}`);
}}
function render() {{
  const route = selectedRoute();
  svg.innerHTML = '';
  setViewBox(route);
  const stock = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  stock.setAttribute('x', 0);
  stock.setAttribute('y', 0);
  stock.setAttribute('width', DATA.stock.width);
  stock.setAttribute('height', DATA.stock.height);
  stock.setAttribute('fill', 'none');
  stock.setAttribute('stroke', '#111');
  stock.setAttribute('stroke-width', '2');
  svg.appendChild(stock);
  for (const a of route.actions) {{
    if (!showTravel && a.type === 'travel') continue;
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', a.x1);
    line.setAttribute('y1', a.y1);
    line.setAttribute('x2', a.x2);
    line.setAttribute('y2', a.y2);
    line.setAttribute('stroke', lineColor(a));
    line.setAttribute('stroke-width', a.type === 'cut' ? '3' : '2');
    line.setAttribute('stroke-linecap', 'round');
    if (dash(a)) line.setAttribute('stroke-dasharray', dash(a));
    line.setAttribute('opacity', a.type === 'cut' ? '0.78' : '0.62');
    svg.appendChild(line);
  }}
  const start = route.actions[0];
  if (start) {{
    const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    dot.setAttribute('cx', start.x1);
    dot.setAttribute('cy', start.y1);
    dot.setAttribute('r', 10);
    dot.setAttribute('fill', '#009E73');
    svg.appendChild(dot);
  }}
  document.getElementById('routeTitle').textContent = route.case + ' / ' + route.method;
  const m = DATA.summary[routeKey(route)] || {{}};
  document.getElementById('metrics').innerHTML = `
    <table>
    <tr><th>Metric</th><th>Value</th></tr>
    <tr><td>Cut actions</td><td>${{m.cut_action_count || ''}}</td></tr>
    <tr><td>Travel actions</td><td>${{m.travel_action_count || ''}}</td></tr>
    <tr><td>Planar cut length (mm)</td><td>${{Number(m.planar_cut_length_mm || 0).toFixed(1)}}</td></tr>
    <tr><td>Rapid XY length (mm)</td><td>${{Number(m.rapid_xy_length_mm || 0).toFixed(1)}}</td></tr>
    <tr><td>Estimated time (s)</td><td>${{Number(m.estimated_total_time_s || 0).toFixed(1)}}</td></tr>
    <tr><td>Out-of-bounds actions</td><td>${{m.out_of_bounds_action_count || '0'}}</td></tr>
    </table>`;
}}
select.addEventListener('change', render);
document.getElementById('toggleTravel').addEventListener('click', () => {{ showTravel = !showTravel; render(); }});
document.getElementById('fitRoute').addEventListener('click', () => {{ fitBounds = !fitBounds; render(); }});
render();
</script>
</body>
</html>
"""


def main() -> None:
    args = parse_args()
    routes = [route_payload(path) for path in args.diagnostics]
    summary_rows = read_csv(args.summary) if args.summary.exists() else []
    summary = {
        row["case_name"] + "||" + row["method"]: row
        for row in summary_rows
    }
    pair_summary = read_csv(args.pair_summary) if args.pair_summary.exists() else []
    payload = {
        "stock": {"width": args.stock_width_mm, "height": args.stock_height_mm},
        "routes": routes,
        "summary": summary,
        "pairSummary": pair_summary,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(build_html(payload), encoding="utf-8")
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
