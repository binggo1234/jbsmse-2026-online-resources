from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.export_gcode_from_diagnostics import NcTemplate, export_route


BASELINE_METHOD = "process_aware_beam"
PROPOSED_METHOD = "process_aware_beam_adaptive_polished"

DEFAULT_METRICS = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "full_experiments"
    / "formal_span_coverage_audit"
    / "chapter3_formal_hard_gate25_main_span_audit_metrics.csv"
)
DEFAULT_COVERAGE = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "full_experiments"
    / "formal_span_coverage_audit"
    / "geometric_coverage_audit"
    / "geometric_coverage_route_summary.csv"
)
DEFAULT_OUTPUT = (
    ROOT
    / "results"
    / "corrected_model_stage4"
    / "auxiliary_nc_cam_fusion_5case"
)


@dataclass(frozen=True)
class RoutePair:
    key: tuple[str, str, str]
    baseline: dict[str, str]
    proposed: dict[str, str]

    @property
    def board_id(self) -> str:
        return self.key[2]

    @property
    def rectangle_count(self) -> int:
        return int(float(self.baseline["rectangle_count"]))

    @property
    def travel_delta(self) -> float:
        return number(self.baseline, "travel_mode_cost") - number(
            self.proposed,
            "travel_mode_cost",
        )

    @property
    def travel_delta_pct(self) -> float:
        base = number(self.baseline, "travel_mode_cost")
        return 100.0 * self.travel_delta / base if base else 0.0


@dataclass(frozen=True)
class SelectedCase:
    case_id: str
    role: str
    description: str
    pair: RoutePair


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build a corrected five-case auxiliary NC/CAMotics/Fusion package "
            "from formal span-level route diagnostics."
        )
    )
    parser.add_argument("--metrics", type=Path, default=DEFAULT_METRICS)
    parser.add_argument("--coverage-summary", type=Path, default=DEFAULT_COVERAGE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def number(row: dict[str, str], field: str, default: float = 0.0) -> float:
    value = row.get(field, "")
    return float(value) if value != "" else default


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty CSV: {path}")
        return list(reader)


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"no rows to write: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def row_key(row: dict[str, str]) -> tuple[str, str, str]:
    return row["archive"], row["placements_member"], row["board_id"]


def load_pairs(metrics_path: Path) -> list[RoutePair]:
    grouped: dict[tuple[str, str, str], dict[str, dict[str, str]]] = {}
    for row in read_rows(metrics_path):
        method = row["method"]
        if method not in (BASELINE_METHOD, PROPOSED_METHOD):
            continue
        grouped.setdefault(row_key(row), {})[method] = row

    pairs = []
    for key, methods in grouped.items():
        if BASELINE_METHOD in methods and PROPOSED_METHOD in methods:
            pairs.append(RoutePair(key, methods[BASELINE_METHOD], methods[PROPOSED_METHOD]))
    if not pairs:
        raise ValueError(f"no baseline/proposed pairs found in {metrics_path}")
    return pairs


def choose_cases(pairs: list[RoutePair]) -> list[SelectedCase]:
    selected: list[SelectedCase] = []
    used: set[tuple[str, str, str]] = set()
    median_rect = sorted(pair.rectangle_count for pair in pairs)[len(pairs) // 2]

    def add(
        role: str,
        case_id: str,
        description: str,
        candidates: list[RoutePair],
        key,
    ) -> None:
        remaining = [pair for pair in candidates if pair.key not in used]
        if not remaining:
            raise ValueError(f"no candidate available for role {role}")
        pair = sorted(remaining, key=key)[0]
        selected.append(SelectedCase(case_id, role, description, pair))
        used.add(pair.key)

    add(
        "core_board340",
        "case_01_board340_core",
        "Board340 core visual/exportability case from the corrected formal diagnostics",
        [pair for pair in pairs if pair.board_id == "340"],
        key=lambda pair: (-pair.travel_delta_pct, pair.baseline["seed"]),
    )
    add(
        "small_layout",
        "case_02_small_layout",
        "Small production-derived layout with positive route-order difference",
        [pair for pair in pairs if pair.travel_delta > 1e-9],
        key=lambda pair: (pair.rectangle_count, -pair.travel_delta_pct, pair.board_id),
    )
    add(
        "median_layout",
        "case_03_median_layout",
        "Median-size production-derived layout with positive route-order difference",
        [pair for pair in pairs if pair.travel_delta > 1e-9],
        key=lambda pair: (
            abs(pair.rectangle_count - median_rect),
            -pair.travel_delta_pct,
            pair.board_id,
        ),
    )
    add(
        "high_gain",
        "case_04_high_gain",
        "High travel-mode saving layout outside the Board340 core case",
        [pair for pair in pairs if pair.travel_delta > 1e-9 and pair.board_id != "340"],
        key=lambda pair: (-pair.travel_delta_pct, -pair.travel_delta, pair.board_id),
    )
    add(
        "conservative_low_gain",
        "case_05_conservative_low_gain",
        "Low positive route-order difference used as a conservative auxiliary control",
        [pair for pair in pairs if pair.travel_delta > 1e-9],
        key=lambda pair: (pair.travel_delta_pct, pair.travel_delta, pair.board_id),
    )
    return selected


def coverage_by_diagnostics(coverage_path: Path) -> dict[str, dict[str, str]]:
    return {row["diagnostics_file"]: row for row in read_rows(coverage_path)}


def coverage_gate_row(
    case: SelectedCase,
    method_label: str,
    metrics_row: dict[str, str],
    coverage_rows: dict[str, dict[str, str]],
) -> dict[str, object]:
    diagnostics_file = metrics_row["diagnostics_file"]
    coverage = coverage_rows.get(diagnostics_file)
    if coverage is None:
        raise KeyError(f"missing coverage summary for {diagnostics_file}")
    ok = (
        coverage["issue_flag"] == "0"
        and float(coverage["geometry_coverage_ratio"]) >= 1.0 - 1e-12
        and int(coverage["geometry_partial_segment_count"]) == 0
        and int(coverage["geometry_missing_segment_count"]) == 0
    )
    return {
        "case_id": case.case_id,
        "case_role": case.role,
        "method_label": method_label,
        "method": metrics_row["method"],
        "board_id": metrics_row["board_id"],
        "rectangle_count": metrics_row["rectangle_count"],
        "primitive_segment_count": coverage["primitive_segment_count"],
        "geometry_full_segment_count": coverage["geometry_full_segment_count"],
        "geometry_partial_segment_count": coverage["geometry_partial_segment_count"],
        "geometry_missing_segment_count": coverage["geometry_missing_segment_count"],
        "geometry_coverage_ratio": coverage["geometry_coverage_ratio"],
        "issue_flag": coverage["issue_flag"],
        "coverage_gate_pass": ok,
        "diagnostics_file": diagnostics_file,
    }


def rewrite_camotics_project(path: Path, nc_name: str) -> None:
    project = json.loads(path.read_text(encoding="utf-8"))
    project["files"] = [nc_name]
    path.write_text(json.dumps(project, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def copy_diagnostics(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def dxf_pair(code: int, value: object) -> list[str]:
    return [str(code), str(value)]


def layer_name(raw: str) -> str:
    if raw.startswith("shared_edge"):
        return "SHARED_EDGE"
    if raw.startswith("near_shared"):
        return "NEAR_SHARED_CHANNEL"
    if raw.startswith("collinear_edge"):
        return "COLLINEAR_CHAIN"
    if raw.startswith("single"):
        return "SINGLE_EDGE"
    return "CUT_LINE"


def collect_cut_segments(path: Path) -> list[tuple[str, float, float, float, float]]:
    rows = read_rows(path)
    segments: list[tuple[str, float, float, float, float]] = []
    seen: set[tuple[str, int, int, int, int]] = set()
    for row in rows:
        if row.get("action_type") != "cut":
            continue
        x1 = number(row, "start_x")
        y1 = number(row, "start_y")
        x2 = number(row, "end_x")
        y2 = number(row, "end_y")
        if abs(x1 - x2) < 1e-9 and abs(y1 - y2) < 1e-9:
            continue
        layer = layer_name(row.get("cutting_unit_id", ""))
        key = (layer, round(x1 * 1000), round(y1 * 1000), round(x2 * 1000), round(y2 * 1000))
        reverse = (layer, key[3], key[4], key[1], key[2])
        if key in seen or reverse in seen:
            continue
        seen.add(key)
        segments.append((layer, x1, y1, x2, y2))
    if not segments:
        raise ValueError(f"no cut segments found in {path}")
    return segments


def write_line_entity(
    lines: list[str],
    layer: str,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
) -> None:
    lines.extend(dxf_pair(0, "LINE"))
    lines.extend(dxf_pair(8, layer))
    lines.extend(dxf_pair(10, f"{x1:.6f}"))
    lines.extend(dxf_pair(20, f"{y1:.6f}"))
    lines.extend(dxf_pair(30, "0.000000"))
    lines.extend(dxf_pair(11, f"{x2:.6f}"))
    lines.extend(dxf_pair(21, f"{y2:.6f}"))
    lines.extend(dxf_pair(31, "0.000000"))


def write_text_entity(lines: list[str], layer: str, x: float, y: float, height: float, text: str) -> None:
    lines.extend(dxf_pair(0, "TEXT"))
    lines.extend(dxf_pair(8, layer))
    lines.extend(dxf_pair(10, f"{x:.6f}"))
    lines.extend(dxf_pair(20, f"{y:.6f}"))
    lines.extend(dxf_pair(30, "0.000000"))
    lines.extend(dxf_pair(40, f"{height:.6f}"))
    lines.extend(dxf_pair(1, text))


def write_dxf(
    path: Path,
    case: SelectedCase,
    segments: list[tuple[str, float, float, float, float]],
    template: NcTemplate,
) -> None:
    lines: list[str] = []
    lines.extend(dxf_pair(0, "SECTION"))
    lines.extend(dxf_pair(2, "HEADER"))
    lines.extend(dxf_pair(9, "$INSUNITS"))
    lines.extend(dxf_pair(70, 4))
    lines.extend(dxf_pair(0, "ENDSEC"))
    lines.extend(dxf_pair(0, "SECTION"))
    lines.extend(dxf_pair(2, "TABLES"))
    lines.extend(dxf_pair(0, "TABLE"))
    lines.extend(dxf_pair(2, "LAYER"))
    for layer in (
        "STOCK",
        "SINGLE_EDGE",
        "SHARED_EDGE",
        "NEAR_SHARED_CHANNEL",
        "COLLINEAR_CHAIN",
        "CUT_LINE",
        "ANNOTATION",
    ):
        lines.extend(dxf_pair(0, "LAYER"))
        lines.extend(dxf_pair(2, layer))
        lines.extend(dxf_pair(70, 0))
        lines.extend(dxf_pair(62, 7))
        lines.extend(dxf_pair(6, "CONTINUOUS"))
    lines.extend(dxf_pair(0, "ENDTAB"))
    lines.extend(dxf_pair(0, "ENDSEC"))
    lines.extend(dxf_pair(0, "SECTION"))
    lines.extend(dxf_pair(2, "ENTITIES"))

    stock = [
        (0.0, 0.0),
        (template.stock_width_mm, 0.0),
        (template.stock_width_mm, template.stock_height_mm),
        (0.0, template.stock_height_mm),
    ]
    for (x1, y1), (x2, y2) in zip(stock, stock[1:] + stock[:1]):
        write_line_entity(lines, "STOCK", x1, y1, x2, y2)

    for layer, x1, y1, x2, y2 in segments:
        write_line_entity(lines, layer, x1, y1, x2, y2)

    write_text_entity(lines, "ANNOTATION", 20.0, template.stock_height_mm + 40.0, 24.0, case.case_id)
    write_text_entity(
        lines,
        "ANNOTATION",
        20.0,
        template.stock_height_mm + 70.0,
        18.0,
        "Corrected auxiliary DXF; units mm; use as pending Fusion exportability input",
    )
    lines.extend(dxf_pair(0, "ENDSEC"))
    lines.extend(dxf_pair(0, "EOF"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def pct_delta(before: float, after: float) -> float:
    return 100.0 * (before - after) / before if before else 0.0


def relative_source(path: Path) -> str:
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)


def build_readme(
    output_dir: Path,
    selected: list[SelectedCase],
    template: NcTemplate,
    metrics_path: Path,
    coverage_path: Path,
) -> None:
    case_lines = "\n".join(
        (
            f"- `{case.case_id}` ({case.role}): board {case.pair.board_id}, "
            f"{case.pair.rectangle_count} rectangles, seed {case.pair.baseline['seed']}."
        )
        for case in selected
    )
    text = f"""# Corrected Auxiliary NC/CAMotics/Fusion Bundle

This regenerated five-case bundle is derived only from the corrected formal
span-level diagnostics. It is an auxiliary exportability package, not formal
evidence for measured machine cycle time or commercial-CAM superiority.

## Source Evidence

- Metrics source: `{relative_source(metrics_path)}`
- Coverage source: `{relative_source(coverage_path)}`
- Formal gate: selected baseline/proposed routes must have `issue_flag=0`,
  `geometry_partial_segment_count=0`, `geometry_missing_segment_count=0`, and
  `geometry_coverage_ratio=1.0`.

## Selected Cases

{case_lines}

## Contents

- `nc_camotics/`: regenerated generic G-code and CAMotics projects.
- `diagnostics/`: copied corrected source diagnostics used for export.
- `fusion/dxf/`: DXF cut-line networks for Autodesk Fusion auxiliary checks.
- `fusion/nc_reference/`: regenerated baseline/proposed NC files for reference.
- `fusion/fusion_exported_nc/`: place manually exported Fusion NC files here.
- `fusion/fusion_screenshots/`: place Fusion simulation screenshots here.
- `case_index.csv`: case provenance and selected diagnostics.
- `coverage_gate_summary.csv`: corrected span-level coverage gate for every route.
- `pair_summary.csv`: fixed-template NC metrics for the regenerated route pairs.

## Locked NC Template

- Units: millimetres (`G21`)
- Coordinate mode: absolute (`G90`)
- Stock: {template.stock_width_mm:g} x {template.stock_height_mm:g} x {template.stock_thickness_mm:g} mm
- Tool diameter: {template.tool_diameter_mm:g} mm
- Safe Z: {template.z_safe_mm:g} mm
- Step-down: {template.step_down_mm:g} mm
- Final cutting depth: -{template.stock_thickness_mm:g} mm
- Spindle: {template.spindle_rpm:g} rpm
- Cut feed: {template.feed_cut_mm_min:g} mm/min
- Plunge feed: {template.feed_plunge_mm_min:g} mm/min
- Rapid feed used for parser estimates: {template.feed_rapid_mm_min:g} mm/min

## Evidence Boundary

The formal manuscript evidence remains the corrected 77-record span-level route
coverage audit. This folder only checks that selected corrected routes can be
exported into generic NC/CAMotics artifacts and prepared for a matched Fusion
Manufacture auxiliary workflow after manual regeneration.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def build_camotics_checklist(path: Path) -> None:
    text = """# CAMotics Checklist

Use this checklist for each `.camotics` project in `nc_camotics/`.

- [ ] Project opens without a G-code parse error.
- [ ] Stock is `2440 x 1220 x 18 mm`.
- [ ] Tool diameter is `6 mm`.
- [ ] Toolpath remains inside the stock envelope.
- [ ] Program reaches full depth under the fixed 3-pass template.
- [ ] Tool motion follows the expected corrected primitive-edge network.
- [ ] Screenshot, if taken, is stored with the same view settings for baseline/proposed.

These checks are auxiliary NC exportability checks only. They are not measured
cycle-time evidence or commercial-CAM validation.
"""
    path.write_text(text, encoding="utf-8")


def build_fusion_checklist(path: Path) -> None:
    text = """# Fusion Auxiliary Checklist

Fusion files in this bundle are pending auxiliary exportability inputs. They
are regenerated from corrected diagnostics, but Fusion NC exports and screenshots
must still be produced manually in Autodesk Fusion Manufacture.

Suggested workflow for each case:

1. Import `fusion/dxf/<case_id>.dxf` into Fusion with units in millimetres.
2. Create a milling setup with fixed stock `2440 x 1220 x 18 mm`.
3. Use a `6 mm` flat end mill/router bit.
4. Use a fixed-depth template: three `6 mm` passes to full `18 mm` depth.
5. Use `18000 rpm`, `3600 mm/min` cut feed, and `800 mm/min` plunge feed.
6. Use `2D Trace` for open cut-line networks, or `2D Contour` where Fusion
   accepts the selected geometry cleanly.
7. Simulate, export the Fusion NC file to `fusion/fusion_exported_nc/`, and
   record the result in `fusion/fusion_result_template.csv`.

Do not describe the Fusion result as a controlled commercial-CAM benchmark,
general superiority over commercial CAM, or measured shop-floor cycle time.
"""
    path.write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    metrics_path = args.metrics.resolve()
    coverage_path = args.coverage_summary.resolve()
    output_dir = args.output_dir.resolve()

    pairs = load_pairs(metrics_path)
    selected = choose_cases(pairs)
    coverage_rows = coverage_by_diagnostics(coverage_path)
    template = NcTemplate()

    if output_dir.exists():
        shutil.rmtree(output_dir)
    nc_dir = output_dir / "nc_camotics"
    diagnostics_dir = output_dir / "diagnostics"
    fusion_dir = output_dir / "fusion"
    dxf_dir = fusion_dir / "dxf"
    nc_reference_dir = fusion_dir / "nc_reference"
    (fusion_dir / "fusion_exported_nc").mkdir(parents=True, exist_ok=True)
    (fusion_dir / "fusion_screenshots").mkdir(parents=True, exist_ok=True)
    nc_dir.mkdir(parents=True, exist_ok=True)
    diagnostics_dir.mkdir(parents=True, exist_ok=True)
    dxf_dir.mkdir(parents=True, exist_ok=True)
    nc_reference_dir.mkdir(parents=True, exist_ok=True)

    route_rows: list[dict[str, object]] = []
    route_by_case_method: dict[tuple[str, str], dict[str, object]] = {}
    coverage_gate_rows: list[dict[str, object]] = []
    case_rows: list[dict[str, object]] = []
    fusion_rows: list[dict[str, object]] = []

    for case in selected:
        for method_label, metrics_row in (
            ("baseline", case.pair.baseline),
            ("proposed", case.pair.proposed),
        ):
            source = ROOT / metrics_row["diagnostics_file"]
            if not source.exists():
                raise FileNotFoundError(source)

            coverage_gate_rows.append(
                coverage_gate_row(case, method_label, metrics_row, coverage_rows)
            )
            diagnostic_copy = (
                diagnostics_dir
                / f"{case.case_id}_{method_label}_{metrics_row['method']}_diagnostics.csv"
            )
            copy_diagnostics(source, diagnostic_copy)

            metric = export_route(source, nc_dir, template)
            generated_nc = Path(metric.gcode_file)
            generated_camotics = generated_nc.with_suffix(".camotics")
            target_nc = nc_dir / f"{case.case_id}_{method_label}.nc"
            target_camotics = nc_dir / f"{case.case_id}_{method_label}.camotics"
            generated_nc.rename(target_nc)
            generated_camotics.rename(target_camotics)
            rewrite_camotics_project(target_camotics, target_nc.name)
            shutil.copy2(target_nc, nc_reference_dir / target_nc.name)

            row = asdict(metric)
            row.update(
                {
                    "case_id": case.case_id,
                    "case_role": case.role,
                    "case_description": case.description,
                    "board_id": metrics_row["board_id"],
                    "rectangle_count": metrics_row["rectangle_count"],
                    "archive": metrics_row["archive"],
                    "placements_member": metrics_row["placements_member"],
                    "seed": metrics_row["seed"],
                    "placement_method": metrics_row["placement_method"],
                    "method_label": method_label,
                    "diagnostics_copy": str(diagnostic_copy.relative_to(output_dir)),
                    "gcode_file": str(target_nc.relative_to(output_dir)),
                    "camotics_file": str(target_camotics.relative_to(output_dir)),
                }
            )
            route_rows.append(row)
            route_by_case_method[(case.case_id, method_label)] = row

        proposed_source = ROOT / case.pair.proposed["diagnostics_file"]
        segments = collect_cut_segments(proposed_source)
        dxf_file = dxf_dir / f"{case.case_id}.dxf"
        write_dxf(dxf_file, case, segments, template)

        baseline_route = route_by_case_method[(case.case_id, "baseline")]
        proposed_route = route_by_case_method[(case.case_id, "proposed")]
        case_rows.append(
            {
                "case_id": case.case_id,
                "case_role": case.role,
                "description": case.description,
                "board_id": case.pair.board_id,
                "rectangle_count": case.pair.rectangle_count,
                "archive": case.pair.baseline["archive"],
                "placements_member": case.pair.baseline["placements_member"],
                "seed": case.pair.baseline["seed"],
                "placement_method": case.pair.baseline["placement_method"],
                "baseline_diagnostics": baseline_route["diagnostics_copy"],
                "proposed_diagnostics": proposed_route["diagnostics_copy"],
                "baseline_nc": baseline_route["gcode_file"],
                "proposed_nc": proposed_route["gcode_file"],
                "baseline_camotics": baseline_route["camotics_file"],
                "proposed_camotics": proposed_route["camotics_file"],
                "fusion_dxf": str(dxf_file.relative_to(output_dir)),
                "fusion_cut_segment_count": len(segments),
            }
        )
        fusion_rows.append(
            {
                "case_id": case.case_id,
                "fusion_dxf_file": str(dxf_file.relative_to(output_dir)),
                "fusion_exported_nc": "",
                "fusion_screenshot": "",
                "post_processor": "",
                "toolpath_strategy": "2D Trace; 2D Contour where Fusion accepts the curve network",
                "stock_mm": "2440 x 1220 x 18",
                "tool_diameter_mm": "6",
                "stepdown_mm": "6",
                "cut_feed_mm_min": "3600",
                "plunge_feed_mm_min": "800",
                "fusion_simulation_status": "",
                "notes": "",
            }
        )

    pair_rows: list[dict[str, object]] = []
    for case in selected:
        baseline = route_by_case_method[(case.case_id, "baseline")]
        proposed = route_by_case_method[(case.case_id, "proposed")]
        base_time = float(baseline["estimated_total_time_s"])
        prop_time = float(proposed["estimated_total_time_s"])
        base_rapid = float(baseline["rapid_xy_length_mm"])
        prop_rapid = float(proposed["rapid_xy_length_mm"])
        pair_rows.append(
            {
                "case_id": case.case_id,
                "case_role": case.role,
                "board_id": case.pair.board_id,
                "rectangle_count": case.pair.rectangle_count,
                "baseline_estimated_total_time_s": f"{base_time:.6f}",
                "proposed_estimated_total_time_s": f"{prop_time:.6f}",
                "estimated_time_delta_s": f"{base_time - prop_time:.6f}",
                "estimated_time_reduction_pct": f"{pct_delta(base_time, prop_time):.6f}",
                "baseline_rapid_xy_length_mm": f"{base_rapid:.6f}",
                "proposed_rapid_xy_length_mm": f"{prop_rapid:.6f}",
                "rapid_xy_delta_mm": f"{base_rapid - prop_rapid:.6f}",
                "rapid_xy_reduction_pct": f"{pct_delta(base_rapid, prop_rapid):.6f}",
                "baseline_out_of_bounds": baseline["out_of_bounds_action_count"],
                "proposed_out_of_bounds": proposed["out_of_bounds_action_count"],
                "baseline_hard_penalty": f"{float(baseline['hard_penalty_sum']):.6f}",
                "proposed_hard_penalty": f"{float(proposed['hard_penalty_sum']):.6f}",
                "baseline_support_penalty": f"{float(baseline['support_rule_penalty_sum']):.6f}",
                "proposed_support_penalty": f"{float(proposed['support_rule_penalty_sum']):.6f}",
            }
        )

    write_rows(output_dir / "case_index.csv", case_rows)
    write_rows(output_dir / "route_summary.csv", route_rows)
    write_rows(output_dir / "pair_summary.csv", pair_rows)
    write_rows(output_dir / "coverage_gate_summary.csv", coverage_gate_rows)
    write_rows(fusion_dir / "fusion_result_template.csv", fusion_rows)
    build_readme(output_dir, selected, template, metrics_path, coverage_path)
    build_camotics_checklist(output_dir / "CAMOTICS_CHECKLIST.md")
    build_fusion_checklist(fusion_dir / "FUSION_CHECKLIST.md")

    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "boundary": "pending auxiliary NC/CAMotics/Fusion exportability evidence",
        "formal_metrics": str(metrics_path.relative_to(ROOT)),
        "coverage_summary": str(coverage_path.relative_to(ROOT)),
        "output_dir": str(output_dir.relative_to(ROOT)),
        "selection_methods": {
            "baseline": BASELINE_METHOD,
            "proposed": PROPOSED_METHOD,
        },
        "case_count": len(selected),
        "route_count": len(route_rows),
        "all_coverage_gates_pass": all(
            bool(row["coverage_gate_pass"]) for row in coverage_gate_rows
        ),
        "all_nc_bounds_pass": all(
            int(row["out_of_bounds_action_count"]) == 0 for row in route_rows
        ),
        "cases": case_rows,
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    zip_path = shutil.make_archive(str(output_dir), "zip", output_dir)
    print(f"wrote {output_dir.relative_to(ROOT)}")
    print(f"wrote {Path(zip_path).relative_to(ROOT)}")
    print(f"cases: {len(selected)}")
    print(f"routes: {len(route_rows)}")
    print(f"coverage gates pass: {manifest['all_coverage_gates_pass']}")
    print(f"NC bounds pass: {manifest['all_nc_bounds_pass']}")


if __name__ == "__main__":
    main()
