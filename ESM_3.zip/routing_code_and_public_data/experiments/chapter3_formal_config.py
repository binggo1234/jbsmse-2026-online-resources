from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

FORMAL_RUN_ID = "chapter3_formal_hard_gate25"
FORMAL_EXPERIMENT_PRESET = "paper-main"
FORMAL_REPEAT_CUT_POLICY = "hard"
FORMAL_TOOL_EVENT_MIN_TRAVEL_SAVING = 25.0
FORMAL_TOOL_EVENT_MIN_TRAVEL_SAVING_RATIO = 0.0
FORMAL_TOOL_EVENT_MIN_MACHINING_SAVING = 1e-9
FORMAL_BOOTSTRAP_SAMPLES = 5000
FORMAL_BOOTSTRAP_SEED = 20260502
FORMAL_RANDOM_SEED = 20260502

FORMAL_ARCHIVES = (
    Path(
        "<LOCAL_HOME>/Desktop/codex_handoff_20260502/data/"
        "paper_extended_suite_20260321_continuous_run_only_20260324_0001.zip"
    ),
    Path("<LOCAL_HOME>/Desktop/codex_handoff_20260502/data/review_overnight_20260422.zip"),
    Path(
        "<LOCAL_HOME>/Desktop/codex_handoff_20260502/data/"
        "strong_baseline_overnight_20260407_001243.zip"
    ),
)

FORMAL_MAX_MEMBERS_PER_ARCHIVE = 55
FORMAL_BOARDS_PER_MEMBER = 1
FORMAL_MIN_RECTANGLES = 20
FORMAL_MAX_RECTANGLES = 50

FORMAL_TIMEOUTS_SECONDS = {
    "main": 30.0,
    "external": 60.0,
    "metaheuristic": 90.0,
    "ablation": 30.0,
    "weight": 30.0,
    "event_gate": 120.0,
    "exact_gap": 120.0,
    "scalability": 30.0,
}

FORMAL_OUTPUT_STEMS = {
    "main": f"{FORMAL_RUN_ID}_main",
    "external": f"{FORMAL_RUN_ID}_external_baselines",
    "metaheuristic": f"{FORMAL_RUN_ID}_metaheuristics",
    "ablation": f"{FORMAL_RUN_ID}_ablation",
    "weight": f"{FORMAL_RUN_ID}_weight_sensitivity",
    "event_gate": f"{FORMAL_RUN_ID}_event_gate_sensitivity",
    "exact_gap": f"{FORMAL_RUN_ID}_exact_gap_8_12",
    "scalability": f"{FORMAL_RUN_ID}_scalability",
    "detour_cache": f"{FORMAL_RUN_ID}_detour_cache_sensitivity",
}

FORMAL_MAIN_METHODS = (
    "topology_process_aware",
    "process_local_search_multistart",
    "process_aware_beam",
    "process_aware_beam_adaptive_polished",
)
FORMAL_TARGET_METHOD = "process_aware_beam_adaptive_polished"
FORMAL_EXTERNAL_METHODS = (
    "greedy",
    "contour_tsp_2opt",
    "contour_aco",
    "endpoint_aware_gtsp",
    "path_distance_local_search",
    "topology",
    "topology_process_aware",
    "process_aware_sa",
    "process_aware_ga",
    "process_local_search_multistart",
    "process_aware_beam",
    FORMAL_TARGET_METHOD,
)
FORMAL_METAHEURISTIC_METHODS = (
    "process_aware_sa",
    "process_aware_ga",
    "process_local_search_multistart",
    FORMAL_TARGET_METHOD,
)
FORMAL_SCALABILITY_METHODS = (
    "topology_process_aware",
    "process_aware_beam",
    FORMAL_TARGET_METHOD,
)


@dataclass(frozen=True)
class FormalSuiteConfig:
    results_dir: Path = ROOT / "results" / "formal"
    figure_dir: Path = ROOT / "figures" / "formal"
    run_id: str = FORMAL_RUN_ID
    archives: tuple[Path, ...] = FORMAL_ARCHIVES
    max_members_per_archive: int = FORMAL_MAX_MEMBERS_PER_ARCHIVE
    boards_per_member: int = FORMAL_BOARDS_PER_MEMBER
    min_rectangles: int = FORMAL_MIN_RECTANGLES
    max_rectangles: int = FORMAL_MAX_RECTANGLES
    bootstrap_samples: int = FORMAL_BOOTSTRAP_SAMPLES
    bootstrap_seed: int = FORMAL_BOOTSTRAP_SEED


def archive_args(archives: tuple[Path, ...] = FORMAL_ARCHIVES) -> tuple[str, ...]:
    args: list[str] = []
    for archive in archives:
        args.extend(("--zip-path", str(archive)))
    return tuple(args)


def formal_layout_args(config: FormalSuiteConfig) -> tuple[str, ...]:
    return (
        "--max-members-per-archive",
        str(config.max_members_per_archive),
        "--boards-per-member",
        str(config.boards_per_member),
        "--min-rectangles",
        str(config.min_rectangles),
        "--max-rectangles",
        str(config.max_rectangles),
    )


def formal_process_args() -> tuple[str, ...]:
    return (
        "--experiment-preset",
        FORMAL_EXPERIMENT_PRESET,
        "--repeat-cut-policy",
        FORMAL_REPEAT_CUT_POLICY,
        "--tool-event-min-travel-saving",
        f"{FORMAL_TOOL_EVENT_MIN_TRAVEL_SAVING:g}",
        "--tool-event-min-travel-saving-ratio",
        f"{FORMAL_TOOL_EVENT_MIN_TRAVEL_SAVING_RATIO:g}",
        "--tool-event-min-machining-saving",
        f"{FORMAL_TOOL_EVENT_MIN_MACHINING_SAVING:g}",
    )
