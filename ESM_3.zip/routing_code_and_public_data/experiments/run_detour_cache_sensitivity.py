from __future__ import annotations

import argparse
import csv
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean, pstdev
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cnc_cutting.collision import effective_centerline_margin
from cnc_cutting.models import Panel, Point, ToolConfig
from cnc_cutting.travel import clear_detour_cache, _low_clearance_detour_points


DEFAULT_OUTPUT = ROOT / "results" / "detour_cache_sensitivity.csv"
DEFAULT_OBSTACLE_COUNTS = (1, 4, 9, 16, 25, 36, 49, 64)


@dataclass(frozen=True)
class DetourCacheSensitivityRow:
    obstacle_count: int
    estimated_grid_nodes: int
    repeats: int
    cold_ms_mean: float
    cold_ms_std: float
    cached_ms_mean: float
    cached_ms_std: float
    cache_speedup: float
    success_rate: float
    path_point_count_mean: float


def synthetic_obstacle_bounds(
    obstacle_count: int,
    *,
    panel_width: float = 1000.0,
    panel_height: float = 600.0,
) -> tuple[tuple[float, float, float, float], ...]:
    if obstacle_count <= 0:
        return ()

    side = math.ceil(math.sqrt(obstacle_count))
    usable_width = panel_width - 160.0
    usable_height = panel_height - 160.0
    cell_width = usable_width / max(side, 1)
    cell_height = usable_height / max(side, 1)
    obstacle_size = max(6.0, min(cell_width, cell_height) * 0.35)

    bounds: list[tuple[float, float, float, float]] = []
    for index in range(obstacle_count):
        row = index // side
        column = index % side
        center_x = 80.0 + (column + 0.5) * cell_width
        center_y = 80.0 + (row + 0.5) * cell_height
        half = obstacle_size / 2.0
        bounds.append((center_x - half, center_y - half, center_x + half, center_y + half))
    return tuple(bounds)


def estimated_detour_grid_nodes(
    start: Point,
    end: Point,
    obstacle_bounds: tuple[tuple[float, float, float, float], ...],
    panel: Panel,
    tool: ToolConfig,
) -> int:
    margin = effective_centerline_margin(tool)
    offset = max(tool.tool_radius + tool.safe_clearance, 1e-6)
    x_min = margin
    y_min = margin
    x_max = panel.panel_width - margin
    y_max = panel.panel_height - margin
    xs = {start.x, end.x, x_min, x_max}
    ys = {start.y, end.y, y_min, y_max}
    for min_x, min_y, max_x, max_y in obstacle_bounds:
        for x in (min_x - offset, max_x + offset):
            if x_min <= x <= x_max:
                xs.add(x)
        for y in (min_y - offset, max_y + offset):
            if y_min <= y <= y_max:
                ys.add(y)
    return len(xs) * len(ys)


def measure_detour_cache_case(
    obstacle_count: int,
    *,
    repeats: int = 5,
    panel: Panel | None = None,
    tool: ToolConfig | None = None,
) -> DetourCacheSensitivityRow:
    if panel is None:
        panel = Panel("synthetic-detour", 1000.0, 600.0)
    if tool is None:
        tool = ToolConfig(
            trim_margin=5.0,
            tool_diameter=6.0,
            safe_clearance=2.0,
            allow_low_clearance_detour=True,
        )

    repeats = max(1, repeats)
    start = Point(30.0, panel.panel_height / 2.0)
    end = Point(panel.panel_width - 30.0, panel.panel_height / 2.0)
    obstacle_bounds = synthetic_obstacle_bounds(
        obstacle_count,
        panel_width=panel.panel_width,
        panel_height=panel.panel_height,
    )

    cold_ms: list[float] = []
    cached_ms: list[float] = []
    path_point_counts: list[int] = []
    successes = 0
    for _ in range(repeats):
        clear_detour_cache()
        start_time = perf_counter()
        cold_points = _low_clearance_detour_points(start, end, obstacle_bounds, panel, tool)
        cold_ms.append((perf_counter() - start_time) * 1000.0)

        start_time = perf_counter()
        cached_points = _low_clearance_detour_points(start, end, obstacle_bounds, panel, tool)
        cached_ms.append((perf_counter() - start_time) * 1000.0)

        points = cached_points if cached_points is not None else cold_points
        if points is not None:
            successes += 1
            path_point_counts.append(len(points))
        else:
            path_point_counts.append(0)

    cold_mean = mean(cold_ms)
    cached_mean = mean(cached_ms)
    return DetourCacheSensitivityRow(
        obstacle_count=obstacle_count,
        estimated_grid_nodes=estimated_detour_grid_nodes(
            start,
            end,
            obstacle_bounds,
            panel,
            tool,
        ),
        repeats=repeats,
        cold_ms_mean=cold_mean,
        cold_ms_std=pstdev(cold_ms) if repeats > 1 else 0.0,
        cached_ms_mean=cached_mean,
        cached_ms_std=pstdev(cached_ms) if repeats > 1 else 0.0,
        cache_speedup=cold_mean / cached_mean if cached_mean > 0.0 else float("inf"),
        success_rate=successes / repeats,
        path_point_count_mean=mean(path_point_counts),
    )


def run_sensitivity(
    obstacle_counts: tuple[int, ...] = DEFAULT_OBSTACLE_COUNTS,
    *,
    repeats: int = 5,
) -> tuple[DetourCacheSensitivityRow, ...]:
    return tuple(
        measure_detour_cache_case(obstacle_count, repeats=repeats)
        for obstacle_count in obstacle_counts
    )


def write_rows(
    rows: tuple[DetourCacheSensitivityRow, ...],
    output_csv: Path,
) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(DetourCacheSensitivityRow.__dataclass_fields__),
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run detour A* cache runtime sensitivity on synthetic obstacle sets."
    )
    parser.add_argument("--output-csv", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument(
        "--obstacle-counts",
        type=int,
        nargs="+",
        default=list(DEFAULT_OBSTACLE_COUNTS),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = run_sensitivity(tuple(args.obstacle_counts), repeats=args.repeats)
    write_rows(rows, args.output_csv)
    for row in rows:
        print(
            f"obstacles={row.obstacle_count:>2} "
            f"nodes={row.estimated_grid_nodes:>5} "
            f"cold={row.cold_ms_mean:>8.3f}ms "
            f"cached={row.cached_ms_mean:>8.3f}ms "
            f"speedup={row.cache_speedup:>6.1f}x"
        )


if __name__ == "__main__":
    main()
