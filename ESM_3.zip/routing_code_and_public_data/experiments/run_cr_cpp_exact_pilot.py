from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import median

from cnc_cutting.io import load_layout
from experiments.cr_cpp_exact_pilot import (
    PilotMethod,
    PilotPlan,
    build_pilot_problem,
    solve_all_methods,
)


DEFAULT_LAYOUT_DIR = Path("data/public_benchmarks/layouts_2dpacklib30_stage7_kerf")
DEFAULT_CASE_FILES = (
    "public_NGCUT1.json",
    "public_NGCUT4.json",
    "public_NGCUT7.json",
    "public_NGCUT10.json",
    "public_CGCUT1.json",
    "public_NGCUT2.json",
    "public_NGCUT5.json",
    "public_NGCUT8.json",
)
POLICY_BASELINES = frozenset(
    {
        PilotMethod.REPEATED_2D_ORDER,
        PilotMethod.FIXED_TAB_ROUTE_OPTIMUM,
        PilotMethod.LAYER_FIRST_EXACT,
        PilotMethod.PART_LOCAL_RETAINED_EXACT,
    }
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen isolated CR-CPP exact pilot."
    )
    parser.add_argument("--layout-dir", type=Path, default=DEFAULT_LAYOUT_DIR)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/cr_cpp_exact_pilot"),
    )
    parser.add_argument("--max-parts", type=int, default=5)
    parser.add_argument(
        "--case-files",
        nargs="*",
        default=DEFAULT_CASE_FILES,
    )
    return parser.parse_args()


def _action_signature(plan: PilotPlan) -> tuple[tuple[str, str, str, int], ...]:
    return tuple(
        (
            action.part_id,
            action.phase.value,
            action.candidate_id,
            action.direction,
        )
        for action in plan.actions
    )


def _result_row(source_file: str, problem, plan: PilotPlan) -> dict[str, object]:
    metrics = plan.metrics
    audit = plan.audit
    return {
        "source_file": source_file,
        "case_id": problem.case_id,
        "source_part_count": problem.source_part_count,
        "pilot_part_count": len(problem.parts),
        "method": plan.method.value,
        "programmed_time_s": f"{metrics.programmed_time_s:.9f}",
        "cut_time_s": f"{metrics.cut_time_s:.9f}",
        "rapid_xy_time_s": f"{metrics.rapid_xy_time_s:.9f}",
        "plunge_time_s": f"{metrics.plunge_time_s:.9f}",
        "retract_time_s": f"{metrics.retract_time_s:.9f}",
        "cut_length_mm": f"{metrics.cut_length_mm:.6f}",
        "rapid_xy_length_mm": f"{metrics.rapid_xy_length_mm:.6f}",
        "plunge_distance_mm": f"{metrics.plunge_distance_mm:.6f}",
        "retract_distance_mm": f"{metrics.retract_distance_mm:.6f}",
        "plunge_count": metrics.plunge_count,
        "retract_count": metrics.retract_count,
        "tool_event_count": metrics.tool_event_count,
        "bridge_removal_length_mm": f"{metrics.bridge_removal_length_mm:.6f}",
        "early_release_count": metrics.early_release_count,
        "early_release_exposure_mm2_s": (
            f"{metrics.early_release_exposure_mm2_s:.6f}"
        ),
        "expanded_labels": plan.expanded_labels,
        "retained_labels": plan.retained_labels,
        "precedence_valid": int(audit.precedence_valid),
        "complete_final_coverage": int(audit.complete_final_coverage),
        "no_residual_bridge": int(audit.no_residual_bridge),
        "retention_until_release": int(audit.retention_until_release),
        "release_barrier_valid": int(audit.release_barrier_valid),
        "cutter_center_offset_valid": int(audit.cutter_center_offset_valid),
        "stock_envelope_valid": int(audit.stock_envelope_valid),
        "no_nominal_part_overlap": int(audit.no_nominal_part_overlap),
        "tool_channel_valid": int(audit.tool_channel_valid),
        "all_audits_passed": int(audit.all_passed),
        "action_signature": json.dumps(_action_signature(plan)),
    }


def _write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"no rows supplied for {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(rows[0]),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    result_rows: list[dict[str, object]] = []
    pair_rows: list[dict[str, object]] = []
    time_reductions: list[float] = []
    event_reductions: list[float] = []
    structural_differences = 0
    all_audits_passed = True
    bridge_burden_unchanged = True
    diagnostic_time_reductions: dict[PilotMethod, list[float]] = {
        method: []
        for method in PilotMethod
        if method is not PilotMethod.CONTROLLED_RELEASE_EXACT
    }
    diagnostic_event_reductions: dict[PilotMethod, list[float]] = {
        method: []
        for method in PilotMethod
        if method is not PilotMethod.CONTROLLED_RELEASE_EXACT
    }
    expansion_ratios_vs_part_local: list[float] = []

    for source_file in args.case_files:
        layout = load_layout(args.layout_dir / source_file)
        problem = build_pilot_problem(layout, max_parts=args.max_parts)
        plans = solve_all_methods(problem)
        by_method = {plan.method: plan for plan in plans}
        result_rows.extend(
            _result_row(source_file, problem, plan) for plan in plans
        )

        proposed = by_method[PilotMethod.CONTROLLED_RELEASE_EXACT]
        baseline = min(
            (by_method[method] for method in POLICY_BASELINES),
            key=lambda plan: (
                plan.metrics.programmed_time_s,
                plan.metrics.tool_event_count,
                plan.method.value,
            ),
        )
        part_local = by_method[PilotMethod.PART_LOCAL_RETAINED_EXACT]
        for method, comparator in by_method.items():
            if method is PilotMethod.CONTROLLED_RELEASE_EXACT:
                continue
            diagnostic_time_reductions[method].append(
                100.0
                * (
                    comparator.metrics.programmed_time_s
                    - proposed.metrics.programmed_time_s
                )
                / comparator.metrics.programmed_time_s
            )
            diagnostic_event_reductions[method].append(
                100.0
                * (
                    comparator.metrics.tool_event_count
                    - proposed.metrics.tool_event_count
                )
                / comparator.metrics.tool_event_count
            )
        expansion_ratios_vs_part_local.append(
            proposed.expanded_labels / part_local.expanded_labels
        )
        time_reduction = (
            100.0
            * (baseline.metrics.programmed_time_s - proposed.metrics.programmed_time_s)
            / baseline.metrics.programmed_time_s
        )
        event_reduction = (
            100.0
            * (baseline.metrics.tool_event_count - proposed.metrics.tool_event_count)
            / baseline.metrics.tool_event_count
        )
        structurally_different = (
            _action_signature(proposed) != _action_signature(part_local)
        )
        structural_differences += int(structurally_different)
        time_reductions.append(time_reduction)
        event_reductions.append(event_reduction)
        all_audits_passed = all_audits_passed and all(
            plan.audit.all_passed for plan in plans
        )
        bridge_burden_unchanged = bridge_burden_unchanged and abs(
            baseline.metrics.bridge_removal_length_mm
            - proposed.metrics.bridge_removal_length_mm
        ) <= 1e-9
        pair_rows.append(
            {
                "source_file": source_file,
                "case_id": problem.case_id,
                "strongest_policy_baseline": baseline.method.value,
                "baseline_programmed_time_s": (
                    f"{baseline.metrics.programmed_time_s:.9f}"
                ),
                "proposed_programmed_time_s": (
                    f"{proposed.metrics.programmed_time_s:.9f}"
                ),
                "programmed_time_reduction_pct": f"{time_reduction:.9f}",
                "baseline_tool_event_count": baseline.metrics.tool_event_count,
                "proposed_tool_event_count": proposed.metrics.tool_event_count,
                "tool_event_reduction_pct": f"{event_reduction:.9f}",
                "bridge_burden_unchanged": int(
                    abs(
                        baseline.metrics.bridge_removal_length_mm
                        - proposed.metrics.bridge_removal_length_mm
                    )
                    <= 1e-9
                ),
                "differs_from_part_local_retained": int(structurally_different),
                "all_audits_passed": int(
                    all(plan.audit.all_passed for plan in plans)
                ),
            }
        )

    median_time_reduction = median(time_reductions)
    median_event_reduction = median(event_reductions)
    structural_difference_fraction = structural_differences / len(args.case_files)
    evidence_gate = (
        median_time_reduction >= 5.0 or median_event_reduction >= 15.0
    )
    structural_gate = structural_difference_fraction >= 0.25
    passed = (
        all_audits_passed
        and bridge_burden_unchanged
        and evidence_gate
        and structural_gate
    )
    summary = {
        "status": "GO" if passed else "NO_GO",
        "case_count": len(args.case_files),
        "parts_per_case": args.max_parts,
        "median_programmed_time_reduction_pct": median_time_reduction,
        "median_tool_event_reduction_pct": median_event_reduction,
        "structural_difference_fraction_vs_part_local": (
            structural_difference_fraction
        ),
        "all_audits_passed": all_audits_passed,
        "bridge_burden_unchanged": bridge_burden_unchanged,
        "evidence_gate_passed": evidence_gate,
        "structural_gate_passed": structural_gate,
        "diagnostic_median_reduction_vs_method": {
            method.value: {
                "programmed_time_pct": median(
                    diagnostic_time_reductions[method]
                ),
                "tool_events_pct": median(
                    diagnostic_event_reductions[method]
                ),
            }
            for method in diagnostic_time_reductions
        },
        "mean_expanded_label_ratio_vs_part_local": (
            sum(expansion_ratios_vs_part_local)
            / len(expansion_ratios_vs_part_local)
        ),
        "frozen_gate": {
            "median_programmed_time_reduction_pct": 5.0,
            "or_median_tool_event_reduction_pct": 15.0,
            "minimum_structural_difference_fraction": 0.25,
        },
    }
    _write_csv(args.output_dir / "pilot_case_results.csv", result_rows)
    _write_csv(args.output_dir / "pilot_pair_summary.csv", pair_rows)
    (args.output_dir / "pilot_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (args.output_dir / "README.md").write_text(
        "# CR-CPP Exact Pilot\n\n"
        "This directory is generated by `experiments/run_cr_cpp_exact_pilot.py` "
        "under the frozen specification in "
        "`docs/cr_cpp_frozen_spec_and_novelty_kill_test.md`.\n\n"
        f"Frozen verdict: **{summary['status']}**.\n\n"
        f"- Cases: {summary['case_count']} deterministic five-part public layouts\n"
        f"- Median time reduction against the strongest baseline: "
        f"{summary['median_programmed_time_reduction_pct']:.2f}%\n"
        f"- Median tool-event reduction against the strongest baseline: "
        f"{summary['median_tool_event_reduction_pct']:.2f}%\n"
        f"- Structural difference from part-local retained exact: "
        f"{summary['structural_difference_fraction_vs_part_local']:.0%}\n"
        f"- All frozen correctness audits passed: "
        f"{summary['all_audits_passed']}\n\n"
        "The result is a programmed-kinematic and structural novelty kill-test, "
        "not machine-cycle validation and not evidence for the Stage 7 manuscript.\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
