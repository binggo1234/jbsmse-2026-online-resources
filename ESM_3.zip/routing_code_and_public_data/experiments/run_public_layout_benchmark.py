from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
from pathlib import Path
from time import perf_counter

from cnc_cutting.coverage_diagnostics import diagnose_route_coverage
from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.io import load_layout
from cnc_cutting.models import EdgeRole, Panel, Point, ToolConfig
from cnc_cutting.optimizer import (
    RoutePlan,
    plan_endpoint_aware_gtsp_route,
    plan_process_aware_beam_adaptive_polished_route,
    plan_process_aware_prefix_beam_mcts_route,
    plan_topology_route,
    wider_beam_search_config,
)
from cnc_cutting.process_model import build_process_model
from experiment_manifest import write_experiment_manifest
from run_chapter2_batch import (
    compact_beam_search_config,
    compact_local_search_config,
    compact_prefix_beam_mcts_config,
)


DEFAULT_METHODS = (
    "endpoint_aware_gtsp",
    "topology_process_aware",
    "process_aware_prefix_beam_mcts",
    "process_aware_beam_adaptive_polished",
)


@dataclass(frozen=True)
class PublicBenchmarkRow:
    layout_file: str
    panel_id: str
    method: str
    rectangle_count: int
    candidate_unit_count: int
    selected_unit_count: int
    action_count: int
    runtime_ms: float
    air_move_distance: float
    cutting_length: float
    machining_cost: float
    travel_mode_cost: float
    pierce_count: int
    lift_count: int
    safe_lift_count: int
    detour_count: int
    hard_penalty: float
    stability_penalty: float
    coverage_missing_segment_count: int
    coverage_repeated_segment_count: int
    cut_missing_segment_count: int
    cut_repeated_segment_count: int
    redundant_cut_action_count: int


def default_public_tool(
    trim_margin: float,
    tool_diameter: float,
    safe_clearance: float,
    geometric_kerf_compensation: bool,
) -> ToolConfig:
    return ToolConfig(
        trim_margin=trim_margin,
        tool_diameter=tool_diameter,
        safe_clearance=safe_clearance,
        centerline_boundary_margin=tool_diameter / 2.0,
        allow_safe_lift_over_released_parts=True,
        allow_low_clearance_detour=True,
        start_point=Point(trim_margin, trim_margin),
        geometric_kerf_compensation=geometric_kerf_compensation,
    )


def plan_method(
    method: str,
    *,
    units,
    panel: Panel,
    tool: ToolConfig,
    process_model,
    rectangle_count: int,
    repeat_cut_policy: str,
) -> RoutePlan:
    if method == "endpoint_aware_gtsp":
        return plan_endpoint_aware_gtsp_route(
            units,
            panel,
            tool,
            process_model=process_model,
        )
    if method == "topology_process_aware":
        return plan_topology_route(
            units,
            panel,
            tool,
            process_aware=True,
            process_model=process_model,
            repeat_cut_policy=repeat_cut_policy,
        )
    if method == "process_aware_prefix_beam_mcts":
        return plan_process_aware_prefix_beam_mcts_route(
            units,
            panel,
            tool,
            config=compact_prefix_beam_mcts_config(
                rectangle_count,
                repeat_cut_policy=repeat_cut_policy,
            ),
            process_model=process_model,
            repeat_cut_policy=repeat_cut_policy,
        )
    if method == "process_aware_beam_adaptive_polished":
        beam_config = compact_beam_search_config(
            rectangle_count,
            repeat_cut_policy=repeat_cut_policy,
        )
        return plan_process_aware_beam_adaptive_polished_route(
            units,
            panel,
            tool,
            beam_config=beam_config,
            fallback_beam_config=wider_beam_search_config(beam_config),
            polish_config=compact_local_search_config(
                rectangle_count,
                True,
                repeat_cut_policy=repeat_cut_policy,
            ),
            process_model=process_model,
            repeat_cut_policy=repeat_cut_policy,
        )
    raise ValueError(f"unsupported public benchmark method: {method}")


def run_layout(
    layout_path: Path,
    methods: tuple[str, ...],
    tool: ToolConfig,
    repeat_cut_policy: str,
    support_policy: str,
    min_support_count: int,
    min_support_ratio: float,
    min_area_normalized_support: float,
    adjacency_support_weight: float,
) -> tuple[PublicBenchmarkRow, ...]:
    layout = load_layout(layout_path)
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    process_model = build_process_model(
        layout,
        tool=tool,
        support_edge_roles=(
            EdgeRole.BOTTOM,
            EdgeRole.RIGHT,
            EdgeRole.TOP,
            EdgeRole.LEFT,
        ),
        min_remaining_support_count=min_support_count,
        min_remaining_support_length_ratio=min_support_ratio,
        min_area_normalized_support_length=min_area_normalized_support,
        adjacency_support_weight=adjacency_support_weight,
    )
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )

    rows: list[PublicBenchmarkRow] = []
    for method in methods:
        start = perf_counter()
        plan = plan_method(
            method,
            units=units,
            panel=panel,
            tool=tool,
            process_model=process_model,
            rectangle_count=len(layout.rectangles),
            repeat_cut_policy=repeat_cut_policy,
        )
        runtime_ms = (perf_counter() - start) * 1000.0
        coverage = diagnose_route_coverage(
            units,
            plan.selected_units,
            plan.actions,
            process_model=process_model,
        )
        rows.append(
            PublicBenchmarkRow(
                layout_file=str(layout_path),
                panel_id=layout.panel_id,
                method=method,
                rectangle_count=len(layout.rectangles),
                candidate_unit_count=len(units),
                selected_unit_count=len(plan.selected_units),
                action_count=len(plan.actions),
                runtime_ms=runtime_ms,
                air_move_distance=plan.metrics.air_move_distance,
                cutting_length=plan.metrics.cutting_length,
                machining_cost=plan.metrics.machining_cost,
                travel_mode_cost=plan.metrics.travel_mode_cost,
                pierce_count=plan.metrics.pierce_count,
                lift_count=plan.metrics.lift_count,
                safe_lift_count=plan.metrics.safe_lift_count,
                detour_count=plan.metrics.detour_count,
                hard_penalty=plan.metrics.hard_penalty,
                stability_penalty=plan.metrics.stability_penalty,
                coverage_missing_segment_count=(
                    coverage.coverage_missing_segment_count
                ),
                coverage_repeated_segment_count=(
                    coverage.coverage_repeated_segment_count
                ),
                cut_missing_segment_count=coverage.cut_missing_segment_count,
                cut_repeated_segment_count=coverage.cut_repeated_segment_count,
                redundant_cut_action_count=plan.metrics.redundant_cut_action_count,
            )
        )
    return tuple(rows)


def summarize(rows: tuple[PublicBenchmarkRow, ...]) -> list[dict[str, float | str | int]]:
    methods = sorted({row.method for row in rows})
    summary: list[dict[str, float | str | int]] = []
    for method in methods:
        subset = [row for row in rows if row.method == method]
        n = len(subset)
        summary.append(
            {
                "method": method,
                "n": n,
                "runtime_ms_mean": sum(row.runtime_ms for row in subset) / n,
                "machining_cost_mean": sum(row.machining_cost for row in subset) / n,
                "travel_mode_cost_mean": (
                    sum(row.travel_mode_cost for row in subset) / n
                ),
                "hard_penalty_mean": sum(row.hard_penalty for row in subset) / n,
                "stability_penalty_mean": (
                    sum(row.stability_penalty for row in subset) / n
                ),
                "coverage_missing_segment_count_sum": sum(
                    row.coverage_missing_segment_count for row in subset
                ),
            }
        )
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run planning-level CNC routing methods on public-layout JSON records."
    )
    parser.add_argument(
        "--layout-dir",
        type=Path,
        default=Path("data/public_benchmarks/layouts_2dpacklib30"),
    )
    parser.add_argument("--layout", action="append", type=Path, default=[])
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--methods", nargs="+", default=list(DEFAULT_METHODS))
    parser.add_argument("--output", type=Path, default=Path("results/formal/chapter3_public_layout_benchmark.csv"))
    parser.add_argument("--summary-output", type=Path, default=Path("results/formal/chapter3_public_layout_benchmark_summary.csv"))
    parser.add_argument("--manifest-output", type=Path, default=Path("results/formal/chapter3_public_layout_benchmark_manifest.json"))
    parser.add_argument("--trim-margin", type=float, default=5.0)
    parser.add_argument("--tool-diameter", type=float, default=6.0)
    parser.add_argument("--safe-clearance", type=float, default=0.0)
    parser.add_argument(
        "--geometric-kerf-compensation",
        action="store_true",
        default=True,
        help="Offset nominal part boundaries to tool-center trajectories (default).",
    )
    parser.add_argument(
        "--no-geometric-kerf-compensation",
        dest="geometric_kerf_compensation",
        action="store_false",
        help="Use nominal part boundaries as trajectories (legacy diagnostic only).",
    )
    parser.add_argument("--support-policy", choices=("all_edges",), default="all_edges")
    parser.add_argument("--min-support-count", type=int, default=1)
    parser.add_argument("--min-support-ratio", type=float, default=0.75)
    parser.add_argument("--min-area-normalized-support", type=float, default=0.0)
    parser.add_argument("--adjacency-support-weight", type=float, default=1.0)
    parser.add_argument("--repeat-cut-policy", choices=("hard", "soft", "off"), default="hard")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    layouts = list(args.layout)
    if args.layout_dir.exists():
        layouts.extend(sorted(args.layout_dir.glob("*.json")))
    layouts = [path for path in layouts if path.name != "manifest.json"]
    if args.limit is not None:
        layouts = layouts[: args.limit]
    if not layouts:
        raise SystemExit("no public layout JSON files found")

    tool = default_public_tool(
        args.trim_margin,
        args.tool_diameter,
        args.safe_clearance,
        args.geometric_kerf_compensation,
    )
    rows: list[PublicBenchmarkRow] = []
    for layout_path in layouts:
        rows.extend(
            run_layout(
                layout_path,
                tuple(args.methods),
                tool,
                args.repeat_cut_policy,
                args.support_policy,
                args.min_support_count,
                args.min_support_ratio,
                args.min_area_normalized_support,
                args.adjacency_support_weight,
            )
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0])))
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)

    summary = summarize(tuple(rows))
    with args.summary_output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)

    write_experiment_manifest(
        args.manifest_output,
        experiment_name="chapter3_public_layout_benchmark",
        args=args,
        outputs=(args.output, args.summary_output),
        extra={
            "layout_count": len(layouts),
            "layout_files": [str(path) for path in layouts],
            "methods": list(args.methods),
            "tool": {
                "trim_margin": args.trim_margin,
                "tool_diameter": args.tool_diameter,
                "safe_clearance": args.safe_clearance,
                "geometric_kerf_compensation": args.geometric_kerf_compensation,
            },
            "support_policy": args.support_policy,
            "repeat_cut_policy": args.repeat_cut_policy,
        },
    )
    print(f"wrote {args.output}")
    print(f"wrote {args.summary_output}")
    print(f"wrote {args.manifest_output}")


if __name__ == "__main__":
    main()
