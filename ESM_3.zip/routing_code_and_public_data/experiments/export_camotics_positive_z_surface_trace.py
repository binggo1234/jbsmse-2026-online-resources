from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Export a CAMotics-only positive-Z surface trace from geometric "
            "coverage audit rows. This is a visualization artifact, not a "
            "production NC post-process."
        )
    )
    parser.add_argument(
        "--segment-details",
        type=Path,
        default=Path(
            "results/corrected_model_stage4/geometric_coverage_audit/"
            "geometric_coverage_segment_details.csv"
        ),
    )
    parser.add_argument("--board-id", type=str, default="340")
    parser.add_argument(
        "--method",
        default="process_aware_beam_adaptive_polished",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/corrected_model_stage4/camotics_visual_board340_positive_z"),
    )
    parser.add_argument(
        "--output-name",
        default="case_large_board340_positive_z_visible_surface_trace.nc",
    )
    parser.add_argument("--stock-width-mm", type=float, default=2440.0)
    parser.add_argument("--stock-height-mm", type=float, default=1220.0)
    parser.add_argument("--stock-thickness-mm", type=float, default=18.0)
    parser.add_argument("--tool-diameter-mm", type=float, default=20.0)
    parser.add_argument("--z-safe-mm", type=float, default=25.0)
    parser.add_argument(
        "--trace-z-mm",
        type=float,
        default=15.0,
        help=(
            "Positive-Z trace height inside a 0..stock_thickness workpiece. "
            "With the default 18 mm stock, Z=15 creates a 3 mm surface groove."
        ),
    )
    parser.add_argument("--feed-cut-mm-min", type=float, default=3600.0)
    parser.add_argument("--feed-plunge-mm-min", type=float, default=800.0)
    parser.add_argument("--spindle-rpm", type=int, default=18000)
    return parser.parse_args()


def load_segments(path: Path, board_id: str, method: str) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        rows = [
            row
            for row in reader
            if row.get("board_id") == board_id
            and row.get("method") == method
            and row.get("status") == "full"
        ]
    if not rows:
        raise RuntimeError(
            f"no full-coverage rows found for board_id={board_id}, method={method}"
        )

    unique: list[dict[str, str]] = []
    seen: set[str] = set()
    for row in rows:
        segment_id = row["segment_id"]
        if segment_id in seen:
            continue
        seen.add(segment_id)
        unique.append(row)
    return unique


def write_gcode(path: Path, rows: list[dict[str, str]], args: argparse.Namespace) -> None:
    lines = [
        "(CAMotics visual audit: positive-Z surface trace)",
        "(Purpose: make every fully covered primitive edge visible on the stock top face)",
        "(Visualization only; not a production post-processor and not used for metrics)",
        f"(Board: {args.stock_width_mm:.3f} x {args.stock_height_mm:.3f} x "
        f"{args.stock_thickness_mm:.3f} mm, CAMotics stock Z=0..{args.stock_thickness_mm:.3f})",
        f"(Tool diameter: {args.tool_diameter_mm:.3f} mm)",
        f"(Trace Z: {args.trace_z_mm:.3f} mm; safe Z: {args.z_safe_mm:.3f} mm)",
        "G21",
        "G90",
        "G17",
        "T1 M6",
        f"G0 Z{args.z_safe_mm:.3f}",
        f"M3 S{args.spindle_rpm}",
    ]
    for index, row in enumerate(rows, start=1):
        sx = float(row["start_x"])
        sy = float(row["start_y"])
        ex = float(row["end_x"])
        ey = float(row["end_y"])
        lines.extend(
            [
                f"(Visual edge {index}: part {row['part_id']} segment {row['segment_id']})",
                f"G0 Z{args.z_safe_mm:.3f}",
                f"G0 X{sx:.3f} Y{sy:.3f}",
                f"G1 Z{args.trace_z_mm:.3f} F{args.feed_plunge_mm_min:.1f}",
                f"G1 X{ex:.3f} Y{ey:.3f} F{args.feed_cut_mm_min:.1f}",
                f"G0 Z{args.z_safe_mm:.3f}",
            ]
        )
    lines.extend([f"G0 Z{args.z_safe_mm:.3f}", "M5", "M30"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_camotics_project(gcode_path: Path, args: argparse.Namespace) -> Path:
    project_path = gcode_path.with_suffix(".camotics")
    project = {
        "units": "metric",
        "resolution-mode": "manual",
        "resolution": 0.5,
        "tools": {
            "1": {
                "units": "metric",
                "shape": "cylindrical",
                "length": 30.0,
                "diameter": args.tool_diameter_mm,
                "description": "Generic CNC router bit for visual audit",
            }
        },
        "workpiece": {
            "automatic": False,
            "margin": 0,
            "bounds": {
                "min": [0, 0, 0],
                "max": [
                    args.stock_width_mm,
                    args.stock_height_mm,
                    args.stock_thickness_mm,
                ],
            },
        },
        "files": [gcode_path.name],
    }
    project_path.write_text(
        json.dumps(project, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return project_path


def write_readme(output_dir: Path, gcode_path: Path, rows: list[dict[str, str]], args: argparse.Namespace) -> None:
    text = f"""# Board340 CAMotics Positive-Z Visual Trace

This folder contains a CAMotics-only visual audit file. It is designed for the
CAMotics convention shown in the GUI, where the workpiece occupies
`Z=0..{args.stock_thickness_mm:g}` rather than `Z=-{args.stock_thickness_mm:g}..0`.

- File: `{gcode_path.name}`
- Board ID: `{args.board_id}`
- Method: `{args.method}`
- Primitive edges emitted: `{len(rows)}`
- Stock: `{args.stock_width_mm:g} x {args.stock_height_mm:g} x {args.stock_thickness_mm:g} mm`
- Visual tool diameter: `{args.tool_diameter_mm:g} mm`
- Trace height: `Z={args.trace_z_mm:g}`; safe height: `Z={args.z_safe_mm:g}`

Use this only to confirm that all part boundaries are visually present in
CAMotics. It is not a production NC file and is not used for time, distance, or
paper metrics.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    rows = load_segments(args.segment_details, args.board_id, args.method)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    gcode_path = args.output_dir / args.output_name
    write_gcode(gcode_path, rows, args)
    project_path = write_camotics_project(gcode_path, args)
    write_readme(args.output_dir, gcode_path, rows, args)
    print(f"segments: {len(rows)}")
    print(f"nc: {gcode_path}")
    print(f"camotics: {project_path}")


if __name__ == "__main__":
    main()
