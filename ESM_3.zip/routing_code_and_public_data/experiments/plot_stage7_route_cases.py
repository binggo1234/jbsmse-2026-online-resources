from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from cnc_cutting.io import (
    PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
    load_chapter2_layouts_from_zip,
)


ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "results" / "corrected_model_stage7_kerf" / "auxiliary_nc_cam_fusion_5case"
ARCHIVE = ROOT / "results" / "corrected_model_stage7_kerf" / "kerf_layouts" / "stage7_kerf_layouts.zip"
CASES = ("case_02_small_layout", "case_04_high_gain")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def case_index() -> dict[str, dict[str, str]]:
    return {row["case_id"]: row for row in read_rows(BUNDLE / "case_index.csv")}


def pair_summary() -> dict[str, dict[str, str]]:
    return {row["case_id"]: row for row in read_rows(BUNDLE / "pair_summary.csv")}


def diagnostic_path(case_id: str, variant: str) -> Path:
    suffix = (
        "baseline_process_aware_beam_diagnostics.csv"
        if variant == "baseline"
        else "proposed_process_aware_beam_adaptive_polished_diagnostics.csv"
    )
    return BUNDLE / "diagnostics" / f"{case_id}_{suffix}"


def load_layout(row: dict[str, str]):
    member = row["record_member"]
    config = str(Path(member).with_name("config_dump.json"))
    return load_chapter2_layouts_from_zip(
        ARCHIVE,
        placements_member=member,
        config_member=config,
        board_ids=(row["board_id"],),
        placement_geometry_mode=PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
        tool_diameter=6.0,
    )[0]


def number(row: dict[str, str], key: str) -> float:
    value = row.get(key, "")
    return float(value) if value else 0.0


def draw_layout(ax, layout) -> None:
    for rectangle in layout.rectangles:
        ax.add_patch(
            Rectangle(
                (rectangle.x, rectangle.y),
                rectangle.width,
                rectangle.height,
                facecolor="#F8FAFC",
                edgecolor="#94A3B8",
                linewidth=0.35,
                alpha=0.65,
                zorder=0,
            )
        )
    ax.add_patch(
        Rectangle(
            (0, 0),
            layout.panel_width,
            layout.panel_height,
            fill=False,
            edgecolor="#111827",
            linewidth=0.8,
            zorder=6,
        )
    )


def milestone_indices(cut_rows: list[dict[str, str]]) -> set[int]:
    if not cut_rows:
        return set()
    positions = (0.0, 0.25, 0.5, 0.75, 1.0)
    return {
        int(cut_rows[round(position * (len(cut_rows) - 1))]["action_index"])
        for position in positions
    }


def draw_route(ax, rows: list[dict[str, str]], layout, title: str, metrics: str) -> LineCollection:
    draw_layout(ax, layout)
    cut_rows = [row for row in rows if row["action_type"] == "cut"]
    segments = [
        [(number(row, "start_x"), number(row, "start_y")),
         (number(row, "end_x"), number(row, "end_y"))]
        for row in cut_rows
    ]
    collection = LineCollection(
        segments,
        cmap="viridis",
        norm=Normalize(vmin=1, vmax=max(1, len(cut_rows))),
        linewidths=1.15,
        alpha=0.9,
        zorder=3,
    )
    collection.set_array(list(range(1, len(cut_rows) + 1)))
    ax.add_collection(collection)

    for row in rows:
        if row["action_type"] != "travel":
            continue
        mode = row.get("travel_mode", "")
        color = "#7C3AED" if mode == "safe_lift" else "#0891B2"
        ax.plot(
            [number(row, "start_x"), number(row, "end_x")],
            [number(row, "start_y"), number(row, "end_y")],
            color=color,
            linestyle="--",
            linewidth=0.65,
            alpha=0.42,
            zorder=1,
        )

    milestones = milestone_indices(cut_rows)
    for row in cut_rows:
        index = int(row["action_index"])
        if index not in milestones:
            continue
        x = (number(row, "start_x") + number(row, "end_x")) / 2.0
        y = (number(row, "start_y") + number(row, "end_y")) / 2.0
        ax.text(
            x,
            y,
            str(index + 1),
            ha="center",
            va="center",
            fontsize=5.5,
            color="#111827",
            bbox={
                "boxstyle": "circle,pad=0.18",
                "facecolor": "white",
                "edgecolor": "#334155",
                "linewidth": 0.45,
                "alpha": 0.94,
            },
            zorder=8,
        )

    padding = 0.02 * max(layout.panel_width, layout.panel_height)
    ax.set_xlim(-padding, layout.panel_width + padding)
    ax.set_ylim(-padding, layout.panel_height + padding)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.grid(False)
    ax.set_title(title, fontsize=8.5, loc="left", pad=3)
    ax.text(
        0.01,
        0.02,
        metrics,
        transform=ax.transAxes,
        fontsize=6.4,
        ha="left",
        va="bottom",
        bbox={"facecolor": "white", "edgecolor": "#CBD5E1", "alpha": 0.9, "pad": 2},
        zorder=9,
    )
    return collection


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "figures" / "corrected_model_stage7_kerf" / "fig_route_case_pair_summary.pdf",
    )
    args = parser.parse_args()
    index = case_index()
    pairs = pair_summary()
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.7), dpi=300)
    last_collection = None
    for row_index, case_id in enumerate(CASES):
        layout = load_layout(index[case_id])
        pair = pairs[case_id]
        for col_index, variant in enumerate(("baseline", "proposed")):
            rows = read_rows(diagnostic_path(case_id, variant))
            label = "Process-aware beam" if variant == "baseline" else "Adaptive beam+LS"
            metrics = (
                f"actions={len(rows)} | safe lifts={sum(number(row, 'safe_lift_count') for row in rows):.0f} | "
                f"detours={sum(number(row, 'detour_count') for row in rows):.0f}"
            )
            last_collection = draw_route(
                axes[row_index, col_index],
                rows,
                layout,
                f"{chr(65 + row_index * 2 + col_index)}  {case_id.replace('_', ' ')}: {label}",
                metrics,
            )
        axes[row_index, 1].text(
            0.99,
            0.98,
            f"paired $C_{{plan}}$ reduction: {float(pair['cplan_reduction_pct']):.2f}%",
            transform=axes[row_index, 1].transAxes,
            ha="right",
            va="top",
            fontsize=6.5,
            bbox={"facecolor": "white", "edgecolor": "#CBD5E1", "alpha": 0.9, "pad": 2},
        )

    handles = [
        Line2D([0], [0], color="#0891B2", linestyle="--", label="detour/low-clearance travel"),
        Line2D([0], [0], color="#7C3AED", linestyle="--", label="safe-lift travel"),
        Line2D([0], [0], marker="o", color="none", markeredgecolor="#334155", markerfacecolor="white", label="selected action index"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False, fontsize=7)
    if last_collection is not None:
        colorbar = fig.colorbar(last_collection, ax=axes, orientation="horizontal", fraction=0.025, pad=0.08, aspect=45)
        colorbar.set_label("Cut-action order (early to late)", fontsize=7)
        colorbar.ax.tick_params(labelsize=6)
    fig.subplots_adjust(left=0.02, right=0.99, top=0.96, bottom=0.16, hspace=0.16, wspace=0.08)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output)
    fig.savefig(args.output.with_suffix(".png"))
    plt.close(fig)
    print(args.output)


if __name__ == "__main__":
    main()
