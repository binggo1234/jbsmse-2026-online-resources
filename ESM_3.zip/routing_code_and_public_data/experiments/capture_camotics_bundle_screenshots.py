from __future__ import annotations

import argparse
import re
import subprocess
import time
from pathlib import Path

from PIL import Image


DEFAULT_APP = Path("/Applications/CAMotics.app")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Open each CAMotics project in the validation bundle and capture "
            "a consistent macOS window screenshot. Requires a logged-in macOS "
            "desktop session and Screen Recording/Accessibility permissions."
        )
    )
    parser.add_argument(
        "--bundle-dir",
        type=Path,
        default=Path("results/camotics_validation_bundle"),
    )
    parser.add_argument("--app", type=Path, default=DEFAULT_APP)
    parser.add_argument("--wait-s", type=float, default=4.0)
    parser.add_argument("--window-x", type=int, default=135)
    parser.add_argument("--window-y", type=int, default=33)
    parser.add_argument("--window-width", type=int, default=1200)
    parser.add_argument("--window-height", type=int, default=800)
    return parser.parse_args()


def run_osascript(*commands: str) -> str:
    args: list[str] = ["osascript"]
    for command in commands:
        args.extend(["-e", command])
    return subprocess.check_output(args, text=True).strip()


def quit_camotics() -> None:
    subprocess.run(
        ["osascript", "-e", 'tell application "CAMotics" to quit'],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(0.8)
    subprocess.run(
        ["killall", "camotics"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def desktop_bounds() -> tuple[int, int, int, int]:
    output = run_osascript('tell application "Finder" to get bounds of window of desktop')
    values = [int(v.strip()) for v in output.split(",")]
    if len(values) != 4:
        raise RuntimeError(f"unexpected desktop bounds: {output}")
    return tuple(values)  # type: ignore[return-value]


def set_window_bounds(x: int, y: int, width: int, height: int) -> None:
    run_osascript(
        'tell application "CAMotics" to activate',
        (
            'tell application "System Events" to tell process "CAMotics" '
            f'to set position of window 1 to {{{x}, {y}}}'
        ),
        (
            'tell application "System Events" to tell process "CAMotics" '
            f'to set size of window 1 to {{{width}, {height}}}'
        ),
    )


def window_bounds() -> tuple[int, int, int, int]:
    output = run_osascript(
        'tell application "CAMotics" to activate',
        (
            'tell application "System Events" to tell process "CAMotics" '
            "to get {position, size} of window 1"
        ),
    )
    values = [int(v) for v in re.findall(r"-?\d+", output)]
    if len(values) < 4:
        raise RuntimeError(f"unexpected window bounds: {output}")
    x, y, width, height = values[:4]
    return x, y, width, height


def capture_window(output: Path, x: int, y: int, width: int, height: int) -> None:
    tmp = output.with_suffix(".fullscreen.tmp.png")
    subprocess.check_call(["screencapture", "-x", str(tmp)])
    image = Image.open(tmp)
    _left, _top, right, bottom = desktop_bounds()
    screen_width_pt = right - _left
    screen_height_pt = bottom - _top
    scale_x = image.width / screen_width_pt
    scale_y = image.height / screen_height_pt
    crop = image.crop(
        (
            round(x * scale_x),
            round(y * scale_y),
            round((x + width) * scale_x),
            round((y + height) * scale_y),
        )
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    crop.save(output)
    tmp.unlink(missing_ok=True)


def screenshot_name(project: Path) -> str:
    return f"{project.stem}_camotics.png"


def main() -> None:
    args = parse_args()
    bundle_dir = args.bundle_dir
    screenshot_dir = bundle_dir / "screenshots"
    projects = sorted(bundle_dir.glob("case_*.camotics"))
    if not projects:
        raise FileNotFoundError(f"no .camotics projects in {bundle_dir}")
    if not args.app.exists():
        raise FileNotFoundError(args.app)

    for project in projects:
        quit_camotics()
        subprocess.check_call(["open", "-a", str(args.app), str(project)])
        time.sleep(args.wait_s)
        set_window_bounds(
            args.window_x,
            args.window_y,
            args.window_width,
            args.window_height,
        )
        time.sleep(0.6)
        x, y, width, height = window_bounds()
        output = screenshot_dir / screenshot_name(project)
        capture_window(output, x, y, width, height)
        print(f"wrote {output}")


if __name__ == "__main__":
    main()
