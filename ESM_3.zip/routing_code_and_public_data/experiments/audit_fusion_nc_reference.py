from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cnc_cutting.geometry import rectangle_edges
from cnc_cutting.io import (
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.metrics import evaluate_actions
from cnc_cutting.models import (
    CuttingAction,
    CuttingActionType,
    EdgeOrientation,
    EdgeRole,
    EdgeSegment,
    Layout,
    Panel,
    Point,
    SegmentSpan,
    ToolConfig,
    TravelMode,
)
from cnc_cutting.process_model import build_process_model
from cnc_cutting.spans import layout_edges_relations_and_spans


DEFAULT_DATA_ROOT = Path("<LOCAL_HOME>/Desktop/codex_handoff_20260502/data")
DEFAULT_BUNDLE_DIR = (
    ROOT
    / "results"
    / "corrected_model_stage5_full_rerun"
    / "fusion_manual_package_5case"
)
DEFAULT_FUSION_NC = Path("<LOCAL_HOME>/Desktop/case_01_board340_core_fusion_3pass_feedplunge.nc")
DEFAULT_OUTPUT_DIR = DEFAULT_BUNDLE_DIR / "fusion" / "fusion_nc_reference_audit"
TOLERANCE = 1e-6


@dataclass(frozen=True)
class NcMove:
    line_no: int
    command: str
    start_x: float
    start_y: float
    end_x: float
    end_y: float
    z: float
    feed: float | None
    raw_line: str

    @property
    def length(self) -> float:
        return math.hypot(self.end_x - self.start_x, self.end_y - self.start_y)


@dataclass(frozen=True)
class CaseContext:
    case_row: dict[str, str]
    layout: Layout
    tool: ToolConfig
    primitive_segments: dict[str, EdgeSegment]
    spans_by_segment: dict[str, tuple[SegmentSpan, ...]]


@dataclass(frozen=True)
class FusionMappedActionRow:
    case_id: str
    fusion_action_index: int
    nc_line_no: int
    start_x: float
    start_y: float
    end_x: float
    end_y: float
    z: float
    feed: float | None
    length_mm: float
    mapped_span_count: int
    mapped_segment_count: int
    partial_span_overlap_count: int
    mapped_span_ids: str
    mapped_segment_ids: str
    raw_line: str


@dataclass(frozen=True)
class CoverageRow:
    case_id: str
    item_type: str
    item_id: str
    segment_id: str
    part_id: str
    edge_role: str
    orientation: str
    start_axis: float
    end_axis: float
    length_mm: float
    covered_length_mm: float
    coverage_ratio: float
    status: str
    source_action_count: int
    source_actions: str
    merged_axis_intervals: str


@dataclass(frozen=True)
class FusionRouteDiagnosticRow:
    action_index: int
    action_type: str
    travel_mode: str
    start_x: float
    start_y: float
    end_x: float
    end_y: float
    length: float
    cutting_unit_id: str
    segment_id: str
    covered_span_ids: str
    source_nc_line_no: int


@dataclass(frozen=True)
class FusionAuditSummary:
    case_id: str
    board_id: str
    rectangle_count: int
    fusion_nc_file: str
    source_diagnostics: str
    final_depth: float
    final_depth_cut_segment_count: int
    mapped_cut_action_count: int
    unmapped_final_depth_cut_segment_count: int
    primitive_segment_count: int
    primitive_full_segment_count: int
    primitive_partial_segment_count: int
    primitive_missing_segment_count: int
    primitive_coverage_ratio: float
    atomic_span_count: int
    atomic_span_full_count: int
    atomic_span_partial_count: int
    atomic_span_missing_count: int
    atomic_span_coverage_ratio: float
    evaluator_action_count: int
    evaluator_cut_action_count: int
    evaluator_travel_action_count: int
    air_move_distance: float
    cutting_length: float
    pierce_count: int
    lift_count: int
    safe_lift_count: int
    detour_count: int
    travel_mode_cost: float
    machining_cost: float
    hard_penalty: float
    stability_penalty: float
    repeated_cut_segment_count: int
    repeated_cut_length: float
    redundant_cut_action_count: int
    coverage_issue_flag: int
    process_issue_flag: int
    issue_flag: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Parse a Fusion-posted NC file, map its final-depth cut moves back "
            "to the corrected primitive span model, and evaluate the resulting "
            "black-box Fusion route reference."
        )
    )
    parser.add_argument("--bundle-dir", type=Path, default=DEFAULT_BUNDLE_DIR)
    parser.add_argument("--case-id", default="case_01_board340_core")
    parser.add_argument("--fusion-nc", type=Path, default=DEFAULT_FUSION_NC)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--final-depth", type=float, default=-18.0)
    parser.add_argument("--depth-tolerance", type=float, default=1e-6)
    parser.add_argument(
        "--fixed-tolerance-mode",
        choices=("tool-radius", "exact"),
        default="tool-radius",
        help=(
            "Perpendicular tolerance for mapping NC centerlines to primitive "
            "edges. The coverage audit uses the physical tool-radius mode."
        ),
    )
    parser.add_argument(
        "--travel-mode",
        choices=("safe_lift", "low_clearance"),
        default="safe_lift",
        help="Planning-level mode assigned to inter-cut Fusion linking moves.",
    )
    return parser.parse_args()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty CSV: {path}")
        return list(reader)


def write_rows(path: Path, rows: Iterable[object], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row) if hasattr(row, "__dataclass_fields__") else row)


def relative(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT))
    except ValueError:
        return str(path)


def load_case_context(bundle_dir: Path, case_id: str, data_root: Path) -> CaseContext:
    case_rows = read_rows(bundle_dir / "case_index.csv")
    matches = [row for row in case_rows if row["case_id"] == case_id]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one case_id={case_id!r}, found {len(matches)}")
    row = matches[0]
    zip_path = data_root / row["archive"]
    if not zip_path.exists():
        raise FileNotFoundError(zip_path)
    cfg = load_chapter2_config_from_zip(zip_path, placements_member=row["placements_member"])
    tool = tool_config_from_chapter2_config(cfg)
    layout = load_chapter2_layouts_from_zip(
        zip_path,
        placements_member=row["placements_member"],
        board_ids=(row["board_id"],),
    )[0]
    segments, _, spans_by_segment = layout_edges_relations_and_spans(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    primitive_segments = {segment.segment_id: segment for segment in segments}
    return CaseContext(
        case_row=row,
        layout=layout,
        tool=tool,
        primitive_segments=primitive_segments,
        spans_by_segment=spans_by_segment,
    )


def parse_nc_xy_moves(path: Path) -> list[NcMove]:
    lines = path.read_text(errors="ignore").splitlines()
    absolute_mode = True
    motion_mode = "G0"
    state_x: float | None = None
    state_y: float | None = None
    state_z: float | None = None
    state_feed: float | None = None
    moves: list[NcMove] = []

    for line_no, raw_line in enumerate(lines, 1):
        line = raw_line.strip()
        if not line or line.startswith("("):
            continue
        g_codes = re.findall(r"\bG(\d+)\b", line)
        if "90" in g_codes:
            absolute_mode = True
        if "91" in g_codes:
            absolute_mode = False
        for code in g_codes:
            if code in ("0", "00"):
                motion_mode = "G0"
            elif code in ("1", "01"):
                motion_mode = "G1"
        words = {
            match.group(1): float(match.group(2))
            for match in re.finditer(r"([XYZF])([-+]?\d+(?:\.\d+)?)", line)
        }
        state_feed = words.get("F", state_feed)

        # G28 moves are machine-reference returns, not workpiece linking moves.
        if "28" in g_codes:
            continue

        def next_axis(axis: str, old: float | None) -> float | None:
            if axis not in words:
                return old
            value = words[axis]
            if absolute_mode or old is None:
                return value
            return old + value

        next_x = next_axis("X", state_x)
        next_y = next_axis("Y", state_y)
        next_z = next_axis("Z", state_z)

        if (
            state_x is not None
            and state_y is not None
            and next_x is not None
            and next_y is not None
            and (abs(next_x - state_x) > TOLERANCE or abs(next_y - state_y) > TOLERANCE)
            and next_z is not None
        ):
            moves.append(
                NcMove(
                    line_no=line_no,
                    command=motion_mode,
                    start_x=state_x,
                    start_y=state_y,
                    end_x=next_x,
                    end_y=next_y,
                    z=next_z,
                    feed=state_feed,
                    raw_line=line,
                )
            )
        state_x, state_y, state_z = next_x, next_y, next_z
    return moves


def point_orientation(x1: float, y1: float, x2: float, y2: float) -> EdgeOrientation | None:
    if abs(y1 - y2) <= TOLERANCE and abs(x1 - x2) > TOLERANCE:
        return EdgeOrientation.HORIZONTAL
    if abs(x1 - x2) <= TOLERANCE and abs(y1 - y2) > TOLERANCE:
        return EdgeOrientation.VERTICAL
    return None


def edge_axis_interval(segment: EdgeSegment) -> tuple[float, float]:
    if segment.orientation == EdgeOrientation.HORIZONTAL:
        return min(segment.start.x, segment.end.x), max(segment.start.x, segment.end.x)
    return min(segment.start.y, segment.end.y), max(segment.start.y, segment.end.y)


def edge_fixed_coordinate(segment: EdgeSegment) -> float:
    if segment.orientation == EdgeOrientation.HORIZONTAL:
        return segment.start.y
    return segment.start.x


def move_axis_interval(move: NcMove, orientation: EdgeOrientation) -> tuple[float, float]:
    if orientation == EdgeOrientation.HORIZONTAL:
        return min(move.start_x, move.end_x), max(move.start_x, move.end_x)
    return min(move.start_y, move.end_y), max(move.start_y, move.end_y)


def move_fixed_coordinate(move: NcMove, orientation: EdgeOrientation) -> float:
    if orientation == EdgeOrientation.HORIZONTAL:
        return move.start_y
    return move.start_x


def merge_intervals(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
    merged: list[list[float]] = []
    for left, right in sorted(intervals):
        if right <= left + TOLERANCE:
            continue
        if not merged or left > merged[-1][1] + TOLERANCE:
            merged.append([left, right])
        else:
            merged[-1][1] = max(merged[-1][1], right)
    return [(left, right) for left, right in merged]


def unique_join(values: Iterable[str]) -> str:
    return ";".join(dict.fromkeys(values))


def build_span_lookup(
    context: CaseContext,
) -> tuple[list[tuple[SegmentSpan, EdgeSegment]], dict[str, SegmentSpan]]:
    rows: list[tuple[SegmentSpan, EdgeSegment]] = []
    by_id: dict[str, SegmentSpan] = {}
    for segment_id, spans in context.spans_by_segment.items():
        segment = context.primitive_segments[segment_id]
        for span in spans:
            rows.append((span, segment))
            by_id[span.span_id] = span
    return rows, by_id


def map_moves_to_spans(
    case_id: str,
    moves: list[NcMove],
    context: CaseContext,
    fixed_tolerance: float,
) -> tuple[
    list[FusionMappedActionRow],
    dict[str, list[tuple[float, float, int]]],
    dict[str, list[tuple[float, float, int]]],
    list[tuple[NcMove, tuple[SegmentSpan, ...]]],
]:
    span_rows, _ = build_span_lookup(context)
    mapped_rows: list[FusionMappedActionRow] = []
    segment_intervals: dict[str, list[tuple[float, float, int]]] = defaultdict(list)
    span_intervals: dict[str, list[tuple[float, float, int]]] = defaultdict(list)
    mapped_actions: list[tuple[NcMove, tuple[SegmentSpan, ...]]] = []

    for action_index, move in enumerate(moves):
        orientation = point_orientation(move.start_x, move.start_y, move.end_x, move.end_y)
        if orientation is None:
            mapped_rows.append(
                FusionMappedActionRow(
                    case_id=case_id,
                    fusion_action_index=action_index,
                    nc_line_no=move.line_no,
                    start_x=move.start_x,
                    start_y=move.start_y,
                    end_x=move.end_x,
                    end_y=move.end_y,
                    z=move.z,
                    feed=move.feed,
                    length_mm=move.length,
                    mapped_span_count=0,
                    mapped_segment_count=0,
                    partial_span_overlap_count=0,
                    mapped_span_ids="",
                    mapped_segment_ids="",
                    raw_line=move.raw_line,
                )
            )
            continue
        move_left, move_right = move_axis_interval(move, orientation)
        move_fixed = move_fixed_coordinate(move, orientation)
        full_spans: list[SegmentSpan] = []
        partial_span_count = 0
        mapped_segments: list[str] = []

        for span, segment in span_rows:
            if span.orientation != orientation:
                continue
            if abs(edge_fixed_coordinate(segment) - move_fixed) > fixed_tolerance + TOLERANCE:
                continue
            span_left, span_right = span.start_axis, span.end_axis
            overlap_left = max(move_left, span_left)
            overlap_right = min(move_right, span_right)
            if overlap_right <= overlap_left + TOLERANCE:
                continue
            segment_intervals[span.segment_id].append(
                (overlap_left, overlap_right, action_index)
            )
            span_intervals[span.span_id].append((overlap_left, overlap_right, action_index))
            mapped_segments.append(span.segment_id)
            if (
                overlap_left <= span_left + TOLERANCE
                and overlap_right >= span_right - TOLERANCE
            ):
                full_spans.append(span)
            else:
                partial_span_count += 1

        mapped_rows.append(
            FusionMappedActionRow(
                case_id=case_id,
                fusion_action_index=action_index,
                nc_line_no=move.line_no,
                start_x=move.start_x,
                start_y=move.start_y,
                end_x=move.end_x,
                end_y=move.end_y,
                z=move.z,
                feed=move.feed,
                length_mm=move.length,
                mapped_span_count=len(full_spans),
                mapped_segment_count=len(set(mapped_segments)),
                partial_span_overlap_count=partial_span_count,
                mapped_span_ids=unique_join(span.span_id for span in full_spans),
                mapped_segment_ids=unique_join(mapped_segments),
                raw_line=move.raw_line,
            )
        )
        if full_spans:
            mapped_actions.append((move, tuple(dict.fromkeys(full_spans))))
    return mapped_rows, segment_intervals, span_intervals, mapped_actions


def interval_coverage(
    intervals: list[tuple[float, float, int]],
    length: float,
) -> tuple[float, float, str, str, str]:
    merged = merge_intervals([(left, right) for left, right, _ in intervals])
    covered = min(length, sum(right - left for left, right in merged))
    if covered <= TOLERANCE:
        status = "missing"
    elif covered < length - TOLERANCE:
        status = "partial"
    else:
        status = "full"
    actions = unique_join(str(action) for _, _, action in intervals)
    merged_text = ";".join(f"{left:.6f}-{right:.6f}" for left, right in merged)
    ratio = covered / length if length else 1.0
    return covered, min(1.0, ratio), status, actions, merged_text


def build_coverage_rows(
    case_id: str,
    context: CaseContext,
    segment_intervals: dict[str, list[tuple[float, float, int]]],
    span_intervals: dict[str, list[tuple[float, float, int]]],
) -> tuple[list[CoverageRow], list[CoverageRow]]:
    segment_rows: list[CoverageRow] = []
    for segment_id, segment in sorted(context.primitive_segments.items()):
        left, right = edge_axis_interval(segment)
        intervals = segment_intervals.get(segment_id, [])
        covered, ratio, status, actions, merged = interval_coverage(
            intervals,
            segment.length,
        )
        segment_rows.append(
            CoverageRow(
                case_id=case_id,
                item_type="primitive_segment",
                item_id=segment_id,
                segment_id=segment_id,
                part_id=segment.part_id,
                edge_role=segment.role.value,
                orientation=segment.orientation.value,
                start_axis=left,
                end_axis=right,
                length_mm=segment.length,
                covered_length_mm=covered,
                coverage_ratio=ratio,
                status=status,
                source_action_count=len({action for _, _, action in intervals}),
                source_actions=actions,
                merged_axis_intervals=merged,
            )
        )

    span_rows: list[CoverageRow] = []
    span_lookup, _ = build_span_lookup(context)
    for span, _segment in sorted(span_lookup, key=lambda item: item[0].span_id):
        intervals = span_intervals.get(span.span_id, [])
        covered, ratio, status, actions, merged = interval_coverage(
            intervals,
            span.length,
        )
        span_rows.append(
            CoverageRow(
                case_id=case_id,
                item_type="atomic_span",
                item_id=span.span_id,
                segment_id=span.segment_id,
                part_id=span.part_id,
                edge_role=span.role.value,
                orientation=span.orientation.value,
                start_axis=span.start_axis,
                end_axis=span.end_axis,
                length_mm=span.length,
                covered_length_mm=covered,
                coverage_ratio=ratio,
                status=status,
                source_action_count=len({action for _, _, action in intervals}),
                source_actions=actions,
                merged_axis_intervals=merged,
            )
        )
    return segment_rows, span_rows


def travel_mode_from_name(name: str) -> TravelMode:
    if name == "safe_lift":
        return TravelMode.SAFE_LIFT
    if name == "low_clearance":
        return TravelMode.LOW_CLEARANCE
    raise ValueError(name)


def build_evaluator_actions(
    mapped_actions: list[tuple[NcMove, tuple[SegmentSpan, ...]]],
    tool: ToolConfig,
    travel_mode: TravelMode,
) -> tuple[tuple[CuttingAction, ...], list[FusionRouteDiagnosticRow]]:
    actions: list[CuttingAction] = []
    diagnostics: list[FusionRouteDiagnosticRow] = []
    current = tool.start_point

    def append_diagnostic(action: CuttingAction, source_line: int = -1) -> None:
        diagnostics.append(
            FusionRouteDiagnosticRow(
                action_index=len(diagnostics),
                action_type=action.action_type.value,
                travel_mode=action.travel_mode.value,
                start_x=action.start.x,
                start_y=action.start.y,
                end_x=action.end.x,
                end_y=action.end.y,
                length=math.hypot(action.end.x - action.start.x, action.end.y - action.start.y),
                cutting_unit_id=action.cutting_unit_id or "",
                segment_id=action.segment_id or "",
                covered_span_ids=unique_join(
                    span.span_id for span in action.covered_spans
                ),
                source_nc_line_no=source_line,
            )
        )

    for move, spans in mapped_actions:
        start = Point(move.start_x, move.start_y)
        end = Point(move.end_x, move.end_y)
        if math.hypot(start.x - current.x, start.y - current.y) > TOLERANCE:
            travel = CuttingAction(
                CuttingActionType.TRAVEL,
                current,
                start,
                travel_mode=travel_mode,
            )
            actions.append(travel)
            append_diagnostic(travel)
        segment_ids = tuple(dict.fromkeys(span.segment_id for span in spans))
        cut = CuttingAction(
            CuttingActionType.CUT,
            start,
            end,
            cutting_unit_id=f"fusion_nc_line:{move.line_no}",
            covered_segment_ids=segment_ids,
            covered_spans=spans,
        )
        actions.append(cut)
        append_diagnostic(cut, source_line=move.line_no)
        current = end
    return tuple(actions), diagnostics


def count_status(rows: list[CoverageRow], status: str) -> int:
    return sum(1 for row in rows if row.status == status)


def coverage_ratio(rows: list[CoverageRow]) -> float:
    total = sum(row.length_mm for row in rows)
    covered = sum(min(row.length_mm, row.covered_length_mm) for row in rows)
    return covered / total if total else 1.0


def write_markdown(
    path: Path,
    summary: FusionAuditSummary,
    travel_mode: str,
) -> None:
    lines = [
        "# Fusion NC Reference Audit",
        "",
        f"Generated: {datetime.now(timezone.utc).isoformat()}",
        "",
        "This audit parses a Fusion-posted NC file as a black-box commercial-CAM "
        "reference, maps final-depth cut moves back to the corrected primitive-span "
        "model, and evaluates the recovered route with the shared process evaluator.",
        "",
        "## Inputs",
        "",
        f"- Case: `{summary.case_id}` / board `{summary.board_id}`",
        f"- Fusion NC: `{summary.fusion_nc_file}`",
        f"- Source diagnostics: `{summary.source_diagnostics}`",
        f"- Final depth used for route recovery: `{summary.final_depth:g}` mm",
        f"- Inter-cut travel mode assumption: `{travel_mode}`",
        "",
        "## Coverage",
        "",
        f"- Final-depth cut segments parsed: {summary.final_depth_cut_segment_count}",
        f"- Mapped final-depth cut segments: {summary.mapped_cut_action_count}",
        f"- Unmapped final-depth cut segments: {summary.unmapped_final_depth_cut_segment_count}",
        f"- Primitive segments: {summary.primitive_full_segment_count}/{summary.primitive_segment_count} full, "
        f"{summary.primitive_partial_segment_count} partial, {summary.primitive_missing_segment_count} missing",
        f"- Primitive coverage ratio: {summary.primitive_coverage_ratio:.12f}",
        f"- Atomic spans: {summary.atomic_span_full_count}/{summary.atomic_span_count} full, "
        f"{summary.atomic_span_partial_count} partial, {summary.atomic_span_missing_count} missing",
        f"- Atomic span coverage ratio: {summary.atomic_span_coverage_ratio:.12f}",
        "",
        "## Evaluator Metrics",
        "",
        "| Metric | Value |",
        "|---|---:|",
        f"| Air move distance | {summary.air_move_distance:.6f} |",
        f"| Cutting length | {summary.cutting_length:.6f} |",
        f"| Travel-mode cost | {summary.travel_mode_cost:.6f} |",
        f"| Machining cost | {summary.machining_cost:.6f} |",
        f"| Hard penalty | {summary.hard_penalty:.6f} |",
        f"| Stability penalty | {summary.stability_penalty:.6f} |",
        f"| Repeated cut count | {summary.repeated_cut_segment_count} |",
        f"| Repeated cut length | {summary.repeated_cut_length:.6f} |",
        f"| Redundant cut actions | {summary.redundant_cut_action_count} |",
        f"| Pierce / lift / safe-lift | {summary.pierce_count} / {summary.lift_count} / {summary.safe_lift_count} |",
        "",
        f"Coverage status: {'PASS' if summary.coverage_issue_flag == 0 else 'FAIL'}",
        f"Process-state status: {'PASS' if summary.process_issue_flag == 0 else 'FAIL'}",
        f"Overall status: {'PASS' if summary.issue_flag == 0 else 'FAIL'}",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def audit(args: argparse.Namespace) -> FusionAuditSummary:
    bundle_dir = args.bundle_dir.resolve()
    fusion_nc = args.fusion_nc.resolve()
    output_dir = args.output_dir.resolve()
    if not fusion_nc.exists():
        raise FileNotFoundError(fusion_nc)
    context = load_case_context(bundle_dir, args.case_id, args.data_root)
    fixed_tolerance = (
        context.tool.tool_radius if args.fixed_tolerance_mode == "tool-radius" else 0.0
    )

    all_moves = parse_nc_xy_moves(fusion_nc)
    final_moves = [
        move
        for move in all_moves
        if move.command == "G1" and abs(move.z - args.final_depth) <= args.depth_tolerance
    ]
    mapped_rows, segment_intervals, span_intervals, mapped_actions = map_moves_to_spans(
        args.case_id,
        final_moves,
        context,
        fixed_tolerance,
    )
    segment_rows, span_rows = build_coverage_rows(
        args.case_id,
        context,
        segment_intervals,
        span_intervals,
    )
    travel_mode = travel_mode_from_name(args.travel_mode)
    evaluator_actions, route_diagnostics = build_evaluator_actions(
        mapped_actions,
        context.tool,
        travel_mode,
    )
    process_model = build_process_model(
        context.layout,
        tool=context.tool,
        support_edge_roles=(EdgeRole.BOTTOM, EdgeRole.RIGHT, EdgeRole.TOP, EdgeRole.LEFT),
        min_remaining_support_count=1,
        min_remaining_support_length_ratio=0.75,
        min_area_normalized_support_length=0.0,
        adjacency_support_weight=1.0,
        max_collinear_gap=context.tool.min_channel_width,
    )
    panel = Panel(
        context.layout.panel_id,
        context.layout.panel_width,
        context.layout.panel_height,
    )
    metrics = evaluate_actions(
        evaluator_actions,
        panel,
        context.tool,
        process_model=process_model,
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    write_rows(
        output_dir / f"{args.case_id}_fusion_mapped_actions.csv",
        mapped_rows,
        list(FusionMappedActionRow.__dataclass_fields__),
    )
    write_rows(
        output_dir / f"{args.case_id}_fusion_segment_coverage.csv",
        segment_rows,
        list(CoverageRow.__dataclass_fields__),
    )
    write_rows(
        output_dir / f"{args.case_id}_fusion_span_coverage.csv",
        span_rows,
        list(CoverageRow.__dataclass_fields__),
    )
    write_rows(
        output_dir / f"{args.case_id}_fusion_reference_route_diagnostics.csv",
        route_diagnostics,
        list(FusionRouteDiagnosticRow.__dataclass_fields__),
    )

    unmapped = [
        row
        for row in mapped_rows
        if row.mapped_span_count == 0 and row.partial_span_overlap_count == 0
    ]
    coverage_issue_flag = int(
        bool(unmapped)
        or count_status(segment_rows, "partial") > 0
        or count_status(segment_rows, "missing") > 0
        or count_status(span_rows, "partial") > 0
        or count_status(span_rows, "missing") > 0
    )
    process_issue_flag = int(
        metrics.hard_penalty > 1e-9 or metrics.stability_penalty > 1e-9
    )
    issue_flag = int(coverage_issue_flag or process_issue_flag)
    summary = FusionAuditSummary(
        case_id=args.case_id,
        board_id=context.case_row["board_id"],
        rectangle_count=int(context.case_row["rectangle_count"]),
        fusion_nc_file=relative(fusion_nc),
        source_diagnostics=relative(bundle_dir / context.case_row["proposed_diagnostics"]),
        final_depth=args.final_depth,
        final_depth_cut_segment_count=len(final_moves),
        mapped_cut_action_count=len(mapped_actions),
        unmapped_final_depth_cut_segment_count=len(unmapped),
        primitive_segment_count=len(segment_rows),
        primitive_full_segment_count=count_status(segment_rows, "full"),
        primitive_partial_segment_count=count_status(segment_rows, "partial"),
        primitive_missing_segment_count=count_status(segment_rows, "missing"),
        primitive_coverage_ratio=coverage_ratio(segment_rows),
        atomic_span_count=len(span_rows),
        atomic_span_full_count=count_status(span_rows, "full"),
        atomic_span_partial_count=count_status(span_rows, "partial"),
        atomic_span_missing_count=count_status(span_rows, "missing"),
        atomic_span_coverage_ratio=coverage_ratio(span_rows),
        evaluator_action_count=len(evaluator_actions),
        evaluator_cut_action_count=sum(
            action.action_type == CuttingActionType.CUT for action in evaluator_actions
        ),
        evaluator_travel_action_count=sum(
            action.action_type == CuttingActionType.TRAVEL for action in evaluator_actions
        ),
        air_move_distance=metrics.air_move_distance,
        cutting_length=metrics.cutting_length,
        pierce_count=metrics.pierce_count,
        lift_count=metrics.lift_count,
        safe_lift_count=metrics.safe_lift_count,
        detour_count=metrics.detour_count,
        travel_mode_cost=metrics.travel_mode_cost,
        machining_cost=metrics.machining_cost,
        hard_penalty=metrics.hard_penalty,
        stability_penalty=metrics.stability_penalty,
        repeated_cut_segment_count=metrics.repeated_cut_segment_count,
        repeated_cut_length=metrics.repeated_cut_length,
        redundant_cut_action_count=metrics.redundant_cut_action_count,
        coverage_issue_flag=coverage_issue_flag,
        process_issue_flag=process_issue_flag,
        issue_flag=issue_flag,
    )
    write_rows(
        output_dir / f"{args.case_id}_fusion_audit_summary.csv",
        [summary],
        list(FusionAuditSummary.__dataclass_fields__),
    )
    write_markdown(
        output_dir / f"{args.case_id}_fusion_audit_summary.md",
        summary,
        args.travel_mode,
    )
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "bundle_dir": relative(bundle_dir),
        "case_id": args.case_id,
        "fusion_nc": relative(fusion_nc),
        "output_dir": relative(output_dir),
        "final_depth": args.final_depth,
        "fixed_tolerance_mode": args.fixed_tolerance_mode,
        "travel_mode": args.travel_mode,
        "issue_flag": summary.issue_flag,
        "summary": asdict(summary),
    }
    (output_dir / f"{args.case_id}_fusion_audit_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return summary


def main() -> None:
    args = parse_args()
    summary = audit(args)
    print(f"case_id={summary.case_id}")
    print(f"final_depth_cut_segments={summary.final_depth_cut_segment_count}")
    print(f"mapped_cut_actions={summary.mapped_cut_action_count}")
    print(f"unmapped_final_depth_cut_segments={summary.unmapped_final_depth_cut_segment_count}")
    print(
        "primitive_coverage="
        f"{summary.primitive_full_segment_count}/{summary.primitive_segment_count} "
        f"partial={summary.primitive_partial_segment_count} "
        f"missing={summary.primitive_missing_segment_count} "
        f"ratio={summary.primitive_coverage_ratio:.12f}"
    )
    print(
        "span_coverage="
        f"{summary.atomic_span_full_count}/{summary.atomic_span_count} "
        f"partial={summary.atomic_span_partial_count} "
        f"missing={summary.atomic_span_missing_count} "
        f"ratio={summary.atomic_span_coverage_ratio:.12f}"
    )
    print(
        "evaluator="
        f"machining_cost={summary.machining_cost:.6f} "
        f"travel_mode_cost={summary.travel_mode_cost:.6f} "
        f"hard_penalty={summary.hard_penalty:.6f} "
        f"stability_penalty={summary.stability_penalty:.6f}"
    )
    print(f"coverage_issue_flag={summary.coverage_issue_flag}")
    print(f"process_issue_flag={summary.process_issue_flag}")
    print(f"issue_flag={summary.issue_flag}")


if __name__ == "__main__":
    main()
