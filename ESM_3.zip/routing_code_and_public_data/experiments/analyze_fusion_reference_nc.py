from __future__ import annotations

import csv
import math
import re
from dataclasses import asdict, dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUNDLE_DIR = ROOT / "results" / "fusion_validation_bundle"
FUSION_NC_DIR = BUNDLE_DIR / "fusion_exported_nc"
REFERENCE_NC_DIR = BUNDLE_DIR / "nc_reference"
OUTPUT_CSV = BUNDLE_DIR / "fusion_reference_summary.csv"
PAIR_OUTPUT_CSV = BUNDLE_DIR / "fusion_reference_pair_summary.csv"

DEFAULT_FEED_RAPID_MM_MIN = 8000.0
DEFAULT_PLUNGE_FEED_MM_MIN = 800.0


@dataclass(frozen=True)
class NcMetrics:
    file: str
    route_label: str
    linear_g0_count: int
    linear_g1_count: int
    arc_count: int
    xy_cut_length_mm: float
    xyz_cut_length_mm: float
    rapid_xy_length_mm: float
    z_feed_length_mm: float
    lift_count: int
    plunge_count: int
    min_x_mm: float
    max_x_mm: float
    min_y_mm: float
    max_y_mm: float
    min_z_mm: float
    max_z_mm: float
    out_of_stock_xy_count: int
    estimated_cut_time_s: float
    estimated_rapid_xy_time_s: float
    estimated_z_feed_time_s: float
    estimated_total_time_s: float


def strip_comments(line: str) -> str:
    line = re.sub(r"\([^)]*\)", "", line)
    line = re.sub(r";.*", "", line)
    return line.strip().upper()


def parse_words(line: str) -> dict[str, float]:
    words: dict[str, float] = {}
    for match in re.finditer(r"([A-Z])\s*([-+]?\d+(?:\.\d*)?)", line):
        letter, value = match.groups()
        # Keep the last G code on a line as modal motion when there are multiple
        # G words, matching common controller behavior for simple metric parsing.
        words[letter] = float(value)
    return words


def all_g_codes(line: str) -> list[int]:
    return [int(float(value)) for value in re.findall(r"\bG\s*([-+]?\d+(?:\.\d*)?)", line)]


def distance_3d(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return math.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)


def distance_xy(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return math.hypot(b[0] - a[0], b[1] - a[1])


def arc_length(
    start: tuple[float, float, float],
    end: tuple[float, float, float],
    center_offsets: dict[str, float],
    plane: int,
    clockwise: bool,
) -> tuple[float, float]:
    """Return approximate (planar_arc_length, xyz_arc_length)."""
    if plane == 17:  # XY, I/J
        axes = (0, 1)
        center = (
            start[0] + center_offsets.get("I", 0.0),
            start[1] + center_offsets.get("J", 0.0),
        )
        orth_delta = end[2] - start[2]
    elif plane == 18:  # XZ, I/K
        axes = (0, 2)
        center = (
            start[0] + center_offsets.get("I", 0.0),
            start[2] + center_offsets.get("K", 0.0),
        )
        orth_delta = end[1] - start[1]
    else:  # G19 YZ, J/K
        axes = (1, 2)
        center = (
            start[1] + center_offsets.get("J", 0.0),
            start[2] + center_offsets.get("K", 0.0),
        )
        orth_delta = end[0] - start[0]

    s2 = (start[axes[0]], start[axes[1]])
    e2 = (end[axes[0]], end[axes[1]])
    radius = math.hypot(s2[0] - center[0], s2[1] - center[1])
    if radius <= 1e-9:
        length_3d = distance_3d(start, end)
        return distance_xy(start, end), length_3d
    a0 = math.atan2(s2[1] - center[1], s2[0] - center[0])
    a1 = math.atan2(e2[1] - center[1], e2[0] - center[0])
    delta = a1 - a0
    if clockwise and delta > 0:
        delta -= 2 * math.pi
    if not clockwise and delta < 0:
        delta += 2 * math.pi
    planar = abs(delta) * radius
    length_3d = math.hypot(planar, orth_delta)
    # XY projection is what matters for non-cutting travel reporting; for XZ/YZ
    # entry arcs, approximate by endpoint XY projection.
    xy = planar if plane == 17 else distance_xy(start, end)
    return xy, length_3d


def parse_nc(path: Path, route_label: str) -> NcMetrics:
    pos = (0.0, 0.0, 0.0)
    motion_mode = 0
    plane = 17
    feed_mm_min = 0.0
    min_x = max_x = pos[0]
    min_y = max_y = pos[1]
    min_z = max_z = pos[2]
    linear_g0_count = 0
    linear_g1_count = 0
    arc_count = 0
    xy_cut_length = 0.0
    xyz_cut_length = 0.0
    rapid_xy_length = 0.0
    z_feed_length = 0.0
    lift_count = 0
    plunge_count = 0
    out_of_stock_xy_count = 0
    estimated_cut_time = 0.0
    estimated_rapid_xy_time = 0.0
    estimated_z_feed_time = 0.0

    for raw_line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = strip_comments(raw_line)
        if not line:
            continue
        g_codes = all_g_codes(line)
        for code in g_codes:
            if code in (0, 1, 2, 3):
                motion_mode = code
            elif code in (17, 18, 19):
                plane = code
        words = parse_words(line)
        if "F" in words:
            feed_mm_min = words["F"]

        target = (
            words.get("X", pos[0]),
            words.get("Y", pos[1]),
            words.get("Z", pos[2]),
        )
        moved = distance_3d(pos, target) > 1e-9
        if not moved:
            continue

        min_x = min(min_x, target[0])
        max_x = max(max_x, target[0])
        min_y = min(min_y, target[1])
        max_y = max(max_y, target[1])
        min_z = min(min_z, target[2])
        max_z = max(max_z, target[2])
        if target[0] < -1e-6 or target[0] > 2440.0 + 1e-6 or target[1] < -1e-6 or target[1] > 1220.0 + 1e-6:
            out_of_stock_xy_count += 1

        xy_len = distance_xy(pos, target)
        xyz_len = distance_3d(pos, target)
        z_delta = target[2] - pos[2]

        if motion_mode == 0:
            linear_g0_count += 1
            rapid_xy_length += xy_len
            estimated_rapid_xy_time += 60.0 * xy_len / DEFAULT_FEED_RAPID_MM_MIN
        elif motion_mode == 1:
            linear_g1_count += 1
            if xy_len > 1e-9 and min(pos[2], target[2]) < 0:
                xy_cut_length += xy_len
                xyz_cut_length += xyz_len
                if feed_mm_min > 0:
                    estimated_cut_time += 60.0 * xyz_len / feed_mm_min
            elif abs(z_delta) > 1e-9:
                z_feed_length += abs(z_delta)
                if z_delta < 0:
                    plunge_count += 1
                else:
                    lift_count += 1
                feed = feed_mm_min if feed_mm_min > 0 else DEFAULT_PLUNGE_FEED_MM_MIN
                estimated_z_feed_time += 60.0 * abs(z_delta) / feed
        elif motion_mode in (2, 3):
            arc_count += 1
            arc_xy, arc_xyz = arc_length(
                pos,
                target,
                words,
                plane,
                clockwise=(motion_mode == 2),
            )
            if min(pos[2], target[2]) < 0:
                xy_cut_length += arc_xy
                xyz_cut_length += arc_xyz
                if feed_mm_min > 0:
                    estimated_cut_time += 60.0 * arc_xyz / feed_mm_min
            elif arc_xy > 1e-9:
                rapid_xy_length += arc_xy
                estimated_rapid_xy_time += 60.0 * arc_xy / DEFAULT_FEED_RAPID_MM_MIN

        pos = target

    return NcMetrics(
        file=str(path.relative_to(ROOT)),
        route_label=route_label,
        linear_g0_count=linear_g0_count,
        linear_g1_count=linear_g1_count,
        arc_count=arc_count,
        xy_cut_length_mm=xy_cut_length,
        xyz_cut_length_mm=xyz_cut_length,
        rapid_xy_length_mm=rapid_xy_length,
        z_feed_length_mm=z_feed_length,
        lift_count=lift_count,
        plunge_count=plunge_count,
        min_x_mm=min_x,
        max_x_mm=max_x,
        min_y_mm=min_y,
        max_y_mm=max_y,
        min_z_mm=min_z,
        max_z_mm=max_z,
        out_of_stock_xy_count=out_of_stock_xy_count,
        estimated_cut_time_s=estimated_cut_time,
        estimated_rapid_xy_time_s=estimated_rapid_xy_time,
        estimated_z_feed_time_s=estimated_z_feed_time,
        estimated_total_time_s=estimated_cut_time + estimated_rapid_xy_time + estimated_z_feed_time,
    )


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    fusion_files = sorted(FUSION_NC_DIR.glob("*_fusion_reference.nc"))
    if not fusion_files:
        raise FileNotFoundError(f"No Fusion reference NC files found in {FUSION_NC_DIR}")
    rows: list[dict[str, object]] = []
    for fusion_file in fusion_files:
        case_id = fusion_file.name.removesuffix("_fusion_reference.nc")
        proposed_file = REFERENCE_NC_DIR / f"{case_id}_proposed.nc"
        baseline_file = REFERENCE_NC_DIR / f"{case_id}_baseline.nc"
        for path, label in (
            (baseline_file, "planning_baseline_nc"),
            (proposed_file, "proposed_nc"),
            (fusion_file, "fusion_reference_nc"),
        ):
            if not path.exists():
                continue
            metrics = parse_nc(path, label)
            row = asdict(metrics)
            row["case_id"] = case_id
            rows.append(row)
    write_rows(OUTPUT_CSV, rows)
    by_case: dict[str, dict[str, dict[str, object]]] = {}
    for row in rows:
        by_case.setdefault(str(row["case_id"]), {})[str(row["route_label"])] = row
    pair_rows: list[dict[str, object]] = []
    for case_id, case_rows in sorted(by_case.items()):
        proposed = case_rows.get("proposed_nc")
        fusion = case_rows.get("fusion_reference_nc")
        if proposed is None or fusion is None:
            continue
        proposed_time = float(proposed["estimated_total_time_s"])
        fusion_time = float(fusion["estimated_total_time_s"])
        proposed_rapid = float(proposed["rapid_xy_length_mm"])
        fusion_rapid = float(fusion["rapid_xy_length_mm"])
        proposed_cut = float(proposed["xy_cut_length_mm"])
        fusion_cut = float(fusion["xy_cut_length_mm"])
        pair_rows.append(
            {
                "case_id": case_id,
                "proposed_time_s": f"{proposed_time:.3f}",
                "fusion_reference_time_s": f"{fusion_time:.3f}",
                "fusion_minus_proposed_time_s": f"{fusion_time - proposed_time:.3f}",
                "proposed_rapid_xy_mm": f"{proposed_rapid:.3f}",
                "fusion_rapid_xy_mm": f"{fusion_rapid:.3f}",
                "fusion_minus_proposed_rapid_xy_mm": f"{fusion_rapid - proposed_rapid:.3f}",
                "proposed_xy_cut_length_mm": f"{proposed_cut:.3f}",
                "fusion_xy_cut_length_mm": f"{fusion_cut:.3f}",
                "fusion_minus_proposed_xy_cut_length_mm": f"{fusion_cut - proposed_cut:.3f}",
                "fusion_arc_count": fusion["arc_count"],
                "fusion_min_z_mm": f"{float(fusion['min_z_mm']):.3f}",
                "fusion_out_of_stock_xy_count": fusion["out_of_stock_xy_count"],
                "interpretation": (
                    "black-box Fusion NC reference; not a controlled fixed-depth "
                    "algorithmic ablation"
                ),
            }
        )
    if pair_rows:
        write_rows(PAIR_OUTPUT_CSV, pair_rows)
    print(f"Wrote {OUTPUT_CSV}")
    if pair_rows:
        print(f"Wrote {PAIR_OUTPUT_CSV}")


if __name__ == "__main__":
    main()
