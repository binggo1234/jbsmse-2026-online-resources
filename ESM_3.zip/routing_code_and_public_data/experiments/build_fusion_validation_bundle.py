from __future__ import annotations

import csv
import shutil
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAMOTICS_DIR = ROOT / "results" / "camotics_validation_bundle"
OUTPUT_DIR = ROOT / "results" / "fusion_validation_bundle"


@dataclass(frozen=True)
class FusionCase:
    case_id: str
    description: str
    baseline_nc: str
    proposed_nc: str
    proposed_diagnostics: str


CASES: tuple[FusionCase, ...] = (
    FusionCase(
        "case_01_large_board",
        "Large production-derived route pair",
        "case_01_large_board_baseline.nc",
        "case_01_large_board_proposed.nc",
        "diagnostics/case_01_large_board_proposed_diagnostics.csv",
    ),
    FusionCase(
        "case_02_medium_board",
        "Medium production-derived route pair",
        "case_02_medium_board_baseline.nc",
        "case_02_medium_board_proposed.nc",
        "diagnostics/case_02_medium_board_proposed_diagnostics.csv",
    ),
    FusionCase(
        "case_03_small_board",
        "Small/ordinary production-derived route pair",
        "case_03_small_board_baseline.nc",
        "case_03_small_board_proposed.nc",
        "diagnostics/case_03_small_board_proposed_diagnostics.csv",
    ),
    FusionCase(
        "case_04_high_gain",
        "High rapid-XY-reduction route pair",
        "case_04_high_gain_baseline.nc",
        "case_04_high_gain_proposed.nc",
        "diagnostics/case_04_high_gain_proposed_diagnostics.csv",
    ),
    FusionCase(
        "case_05_low_gain",
        "Low NC-time-gain route pair used as a conservative control",
        "case_05_low_gain_baseline.nc",
        "case_05_low_gain_proposed.nc",
        "diagnostics/case_05_low_gain_proposed_diagnostics.csv",
    ),
)


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty CSV: {path}")
        return list(reader)


def num(row: dict[str, str], field: str) -> float:
    value = row.get(field, "")
    if value == "":
        return 0.0
    return float(value)


def layer_name(raw: str) -> str:
    if raw.startswith("shared_edge"):
        return "SHARED_EDGE"
    if raw.startswith("collinear_edge"):
        return "COLLINEAR_CHAIN"
    if raw.startswith("single"):
        return "SINGLE_EDGE"
    return "CUT_LINE"


def collect_cut_segments(path: Path) -> list[tuple[str, float, float, float, float]]:
    rows = read_rows(path)
    segments: list[tuple[str, float, float, float, float]] = []
    seen: set[tuple[str, int, int, int, int]] = set()
    for row in rows:
        if row.get("action_type") != "cut":
            continue
        x1 = num(row, "start_x")
        y1 = num(row, "start_y")
        x2 = num(row, "end_x")
        y2 = num(row, "end_y")
        if abs(x1 - x2) < 1e-9 and abs(y1 - y2) < 1e-9:
            continue
        layer = layer_name(row.get("cutting_unit_id", ""))
        # Round only for duplicate detection; keep original coordinates in output.
        key = (layer, round(x1 * 1000), round(y1 * 1000), round(x2 * 1000), round(y2 * 1000))
        rkey = (layer, key[3], key[4], key[1], key[2])
        if key in seen or rkey in seen:
            continue
        seen.add(key)
        segments.append((layer, x1, y1, x2, y2))
    if not segments:
        raise ValueError(f"no cut segments found in {path}")
    return segments


def dxf_pair(code: int, value: object) -> list[str]:
    return [str(code), str(value)]


def write_line_entity(
    lines: list[str],
    layer: str,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
) -> None:
    lines.extend(dxf_pair(0, "LINE"))
    lines.extend(dxf_pair(8, layer))
    lines.extend(dxf_pair(10, f"{x1:.6f}"))
    lines.extend(dxf_pair(20, f"{y1:.6f}"))
    lines.extend(dxf_pair(30, "0.000000"))
    lines.extend(dxf_pair(11, f"{x2:.6f}"))
    lines.extend(dxf_pair(21, f"{y2:.6f}"))
    lines.extend(dxf_pair(31, "0.000000"))


def write_text_entity(lines: list[str], layer: str, x: float, y: float, height: float, text: str) -> None:
    lines.extend(dxf_pair(0, "TEXT"))
    lines.extend(dxf_pair(8, layer))
    lines.extend(dxf_pair(10, f"{x:.6f}"))
    lines.extend(dxf_pair(20, f"{y:.6f}"))
    lines.extend(dxf_pair(30, "0.000000"))
    lines.extend(dxf_pair(40, f"{height:.6f}"))
    lines.extend(dxf_pair(1, text))


def write_dxf(path: Path, case: FusionCase, segments: list[tuple[str, float, float, float, float]]) -> None:
    lines: list[str] = []
    lines.extend(dxf_pair(0, "SECTION"))
    lines.extend(dxf_pair(2, "HEADER"))
    lines.extend(dxf_pair(9, "$INSUNITS"))
    lines.extend(dxf_pair(70, 4))  # millimetres
    lines.extend(dxf_pair(0, "ENDSEC"))
    lines.extend(dxf_pair(0, "SECTION"))
    lines.extend(dxf_pair(2, "TABLES"))
    lines.extend(dxf_pair(0, "TABLE"))
    lines.extend(dxf_pair(2, "LAYER"))
    for layer in (
        "STOCK",
        "SINGLE_EDGE",
        "SHARED_EDGE",
        "NEAR_SHARED_CHANNEL",
        "COLLINEAR_CHAIN",
        "CUT_LINE",
        "ANNOTATION",
    ):
        lines.extend(dxf_pair(0, "LAYER"))
        lines.extend(dxf_pair(2, layer))
        lines.extend(dxf_pair(70, 0))
        lines.extend(dxf_pair(62, 7))
        lines.extend(dxf_pair(6, "CONTINUOUS"))
    lines.extend(dxf_pair(0, "ENDTAB"))
    lines.extend(dxf_pair(0, "ENDSEC"))
    lines.extend(dxf_pair(0, "SECTION"))
    lines.extend(dxf_pair(2, "ENTITIES"))

    # Stock rectangle, matching the NC inspection template.
    stock = [(0.0, 0.0), (2440.0, 0.0), (2440.0, 1220.0), (0.0, 1220.0)]
    for (x1, y1), (x2, y2) in zip(stock, stock[1:] + stock[:1]):
        write_line_entity(lines, "STOCK", x1, y1, x2, y2)

    for layer, x1, y1, x2, y2 in segments:
        write_line_entity(lines, layer, x1, y1, x2, y2)

    write_text_entity(lines, "ANNOTATION", 20.0, 1260.0, 24.0, case.case_id)
    write_text_entity(lines, "ANNOTATION", 20.0, 1290.0, 18.0, "Units: mm; stock: 2440 x 1220 x 18; tool: 6 mm")
    lines.extend(dxf_pair(0, "ENDSEC"))
    lines.extend(dxf_pair(0, "EOF"))
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_fusion_checklist(path: Path) -> None:
    text = """# Fusion 零基础操作清单

这个文件夹用于生成一个**商业 CAM 黑箱参考线**。目标不是证明真实机床加工时间，而是让 Fusion Manufacture 在相同 stock、刀具、切深和进给设置下生成一条可对照的 2D Contour NC 路线。

建议先只跑 `case_03_small_board`，流程通了再跑其他 4 个案例。

## 0. 你需要用到的文件

- `dxf/case_XX_*.dxf`：导入 Fusion 的切割线网络。
- `nc_reference/case_XX_*_proposed.nc`：我们算法导出的 proposed route，用于对照。
- `fusion_result_template.csv`：导出 Fusion G-code 后记录文件名和截图。

## 1. 导入 DXF

1. 打开 Fusion。
2. 左上角确认在 `Design` 工作区。
3. 选择 `Insert` -> `Insert DXF`。
4. 选择 `dxf/case_03_small_board.dxf`。
5. 选择一个平面，例如 XY plane。
6. 单位保持 `mm`。
7. 点击 `OK`。

如果看到一个 `2440 x 1220 mm` 的大矩形和内部切割线，说明导入正确。

## 2. 进入 Manufacture 并建立 Setup

1. 左上角工作区切换到 `Manufacture`。
2. 点击 `Setup` -> `New Setup`。
3. Operation Type 选择 `Milling`。
4. Orientation 选 `Model orientation` 或保持默认 XY。
5. Stock 选 `Fixed size box`。
6. 设置：
   - Width/X: `2440 mm`
   - Depth/Y: `1220 mm`
   - Height/Z: `18 mm`
7. Stock offset 全部设为 `0 mm`。
8. WCS 原点建议选 stock 左下角或保持默认，但同一批案例必须一致。
9. 点击 `OK`。

## 3. 建立 6 mm 刀具

1. 点击 `Manage` -> `Tool Library`。
2. 新建一个 `Flat End Mill`。
3. Diameter 设置为 `6 mm`。
4. Flute length / Overall length 可保持默认，只要能仿真即可。
5. 命名为 `Generic 6 mm CNC router bit`。

## 4. 生成 Fusion 自己的 2D Contour 路线

1. 优先点击 `2D` -> `2D Contour`。如果 Fusion 不接受这些开放切割线，改用 `2D` -> `Trace`。
2. Tool 选择刚才的 `Generic 6 mm CNC router bit`。
3. Geometry 中选择 DXF 内部切割线/轮廓。
   - 如果 Fusion 不允许一次性选择所有线，先选几个主要闭合/开放链试跑。
   - 如果 `2D Contour` 对开放线段报错，使用 `Trace` 跟随草图线段；这仍然可以作为商业 CAM 的 NC-level reference。
   - 对本文而言，Fusion 参考线只作为黑箱 CAM reference，不要求手工调到最优。
4. Heights：
   - Top height: stock top 或 `0 mm`
   - Bottom height: `-18 mm`
5. Passes：
   - 勾选 `Multiple Depths`
   - Maximum roughing stepdown: `6 mm`
6. Linking：
   - Safe height/retract height 保持默认或设为 `5 mm`
7. Feeds & Speeds：
   - Spindle speed: `18000 rpm`
   - Cutting feedrate: `3600 mm/min`
   - Plunge feedrate: `800 mm/min`
8. 点击 `OK` 或 `Generate`。

## 5. Simulate

1. 右键刚生成的 toolpath。
2. 选择 `Simulate`。
3. 检查：
   - 没有明显红色碰撞/错误提示；
   - 刀路在 2440 x 1220 stock 内；
   - 轮廓基本覆盖切割线网络；
   - 能看到 Z 向分层切削。
4. 截图保存到 `fusion_screenshots/`。

## 6. Post Process 导出 G-code

1. 右键 Setup 或 toolpath。
2. 选择 `Post Process`。
3. Post processor 可以选择通用/GRBL/Generic 3-axis milling 类后处理。保持同一批案例一致即可。
4. Program name 用 `case_03_small_board_fusion_reference`。
5. 导出到 `fusion_exported_nc/`。

## 7. 记录结果

把导出的 `.nc` 文件路径和截图路径填入 `fusion_result_template.csv`。之后交给我，我会统一解析 NC 指标并生成论文表格。

## 论文中必须这样定位

推荐表述：

> Autodesk Fusion Manufacture was used as a black-box commercial CAM reference under matched stock, tool, depth-pass, and feed settings. The comparison is reported as an auxiliary NC-level reference, not as a controlled algorithmic ablation or measured shop-floor validation.

不要写：

- 我们击败了商业 CAM；
- Fusion 证明真实加工时间下降；
- 这是 VERICUT/NX 级别的 controller-level verification。
"""
    path.write_text(text, encoding="utf-8")


def write_readme(path: Path, rows: list[dict[str, object]]) -> None:
    case_lines = "\n".join(
        f"- `{row['case_id']}`: `{row['dxf_file']}`, proposed NC `{row['proposed_nc']}`"
        for row in rows
    )
    text = f"""# Fusion Validation Bundle

This bundle prepares a small Autodesk Fusion Manufacture reference check for
the panel-furniture CNC routing manuscript. It is intentionally separated from
the main algorithm outputs because Fusion is used as a black-box commercial CAM
reference rather than a controlled algorithmic baseline.

## Contents

- `dxf/`: DXF cut-line networks generated from representative proposed-route
  diagnostics. Each file includes the `2440 x 1220 mm` stock boundary.
- `nc_reference/`: baseline and proposed generic 3-axis NC exports already used
  in CAMotics inspection.
- `fusion_exported_nc/`: place Fusion post-processed `.nc` files here.
- `fusion_screenshots/`: place Fusion simulation screenshots here.
- `fusion_result_template.csv`: fill this after exporting Fusion NC files.
- `FUSION_ZERO_BASE_CHECKLIST.md`: step-by-step instructions for a first-time
  Fusion user.

## Selected Cases

{case_lines}

## Matched Template

- Stock: `2440 x 1220 x 18 mm`
- Tool: `6 mm` flat end mill/router bit
- Safe/retract height: approximately `5 mm`
- Step-down: `6 mm` to final depth `-18 mm`
- Spindle: `18000 rpm`
- Cutting feed: `3600 mm/min`
- Plunge feed: `800 mm/min`

## Boundary

This bundle supports an auxiliary commercial-CAM reference. It should not be
reported as measured machine cycle time, shop-floor validation, or a strict
like-for-like algorithmic ablation. Fusion's internal ordering, lead-in/out,
linking, and postprocessor decisions are black-box CAM policies.
"""
    path.write_text(text, encoding="utf-8")


def main() -> None:
    if not CAMOTICS_DIR.exists():
        raise FileNotFoundError(CAMOTICS_DIR)
    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)
    for subdir in ("dxf", "nc_reference", "fusion_exported_nc", "fusion_screenshots"):
        (OUTPUT_DIR / subdir).mkdir(parents=True, exist_ok=True)

    rows: list[dict[str, object]] = []
    template_rows: list[dict[str, object]] = []
    for case in CASES:
        diag_path = CAMOTICS_DIR / case.proposed_diagnostics
        segments = collect_cut_segments(diag_path)
        dxf_file = OUTPUT_DIR / "dxf" / f"{case.case_id}.dxf"
        write_dxf(dxf_file, case, segments)

        for source_name in (case.baseline_nc, case.proposed_nc):
            source = CAMOTICS_DIR / source_name
            if not source.exists():
                raise FileNotFoundError(source)
            shutil.copy2(source, OUTPUT_DIR / "nc_reference" / source.name)

        row = {
            "case_id": case.case_id,
            "description": case.description,
            "dxf_file": f"dxf/{dxf_file.name}",
            "proposed_nc": f"nc_reference/{case.proposed_nc}",
            "baseline_nc": f"nc_reference/{case.baseline_nc}",
            "cut_segment_count": len(segments),
        }
        rows.append(row)
        template_rows.append(
            {
                "case_id": case.case_id,
                "fusion_dxf_file": row["dxf_file"],
                "fusion_exported_nc": "",
                "fusion_screenshot": "",
                "post_processor": "",
                "toolpath_strategy": "2D Contour; Trace fallback for open sketch curves",
                "stock_mm": "2440 x 1220 x 18",
                "tool_diameter_mm": "6",
                "stepdown_mm": "6",
                "cut_feed_mm_min": "3600",
                "plunge_feed_mm_min": "800",
                "fusion_simulation_status": "",
                "notes": "",
            }
        )

    write_csv(OUTPUT_DIR / "case_index.csv", rows)
    write_csv(OUTPUT_DIR / "fusion_result_template.csv", template_rows)
    write_fusion_checklist(OUTPUT_DIR / "FUSION_ZERO_BASE_CHECKLIST.md")
    write_readme(OUTPUT_DIR / "README.md", rows)

    archive_base = OUTPUT_DIR.with_suffix("")
    zip_path = shutil.make_archive(str(archive_base), "zip", OUTPUT_DIR)
    print(f"Wrote {OUTPUT_DIR}")
    print(f"Wrote {zip_path}")


if __name__ == "__main__":
    main()
