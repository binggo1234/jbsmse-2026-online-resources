from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
from pathlib import Path

from cnc_cutting.cutting_units import build_candidate_cutting_units
from cnc_cutting.geometry import expand_rectangle
from cnc_cutting.io import (
    PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
    load_chapter2_config_from_zip,
    load_chapter2_layouts_from_zip,
    tool_config_from_chapter2_config,
)
from cnc_cutting.manufacturability import audit_cutting_units
from cnc_cutting.models import CuttingUnitType


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LAYOUT_DIR = ROOT / "results" / "corrected_model_stage7_kerf" / "kerf_layouts"


@dataclass(frozen=True)
class KerfLayoutAudit:
    record_id: str
    board_id: str
    part_count: int
    candidate_unit_count: int
    primitive_span_count: int
    shared_centerline_unit_count: int
    envelope_overlap_count: int
    stock_boundary_violation_count: int
    finished_dimension_violation_count: int
    swept_disk_gouge_count: int
    manufacturable: bool


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit Stage 7 kerf-aware layouts.")
    parser.add_argument(
        "--archive",
        type=Path,
        default=DEFAULT_LAYOUT_DIR / "stage7_kerf_layouts.zip",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=DEFAULT_LAYOUT_DIR / "stage7_kerf_layout_manifest.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results" / "corrected_model_stage7_kerf" / "layout_audit",
    )
    return parser.parse_args()


def _strict_overlap(first, second, tolerance: float = 1e-6) -> bool:
    return (
        first.min_x < second.max_x - tolerance
        and first.max_x > second.min_x + tolerance
        and first.min_y < second.max_y - tolerance
        and first.max_y > second.min_y + tolerance
    )


def audit_record(archive: Path, row: dict[str, str]) -> KerfLayoutAudit:
    placement_member = row["placements_member"]
    config_member = row["config_member"]
    config = load_chapter2_config_from_zip(
        archive,
        placements_member=placement_member,
        config_member=config_member,
    )
    tool = tool_config_from_chapter2_config(config)
    if not tool.geometric_kerf_compensation:
        raise ValueError(f"{row['record_id']} does not enable kerf compensation")
    layout = load_chapter2_layouts_from_zip(
        archive,
        placements_member=placement_member,
        config_member=config_member,
        board_ids=(row["selected_board_id"],),
        placement_geometry_mode=PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
        tool_diameter=tool.tool_diameter,
    )[0]
    envelopes = [
        expand_rectangle(rectangle, tool.tool_radius)
        for rectangle in layout.rectangles
    ]
    overlap_count = sum(
        _strict_overlap(first, second)
        for index, first in enumerate(envelopes)
        for second in envelopes[index + 1 :]
    )
    boundary_count = sum(
        envelope.min_x < tool.trim_margin - 1e-6
        or envelope.min_y < tool.trim_margin - 1e-6
        or envelope.max_x > layout.panel_width - tool.trim_margin + 1e-6
        or envelope.max_y > layout.panel_height - tool.trim_margin + 1e-6
        for envelope in envelopes
    )
    units = build_candidate_cutting_units(layout, tool)
    violations = audit_cutting_units(units, layout, tool.tool_radius)
    finished_count = sum(
        violation.violation_type
        in {"incorrect_centerline_offset", "centerline_does_not_cover_nominal_span", "non_axis_aligned_cut"}
        for violation in violations
    )
    gouge_count = sum(
        violation.violation_type == "swept_disk_gouges_nominal_part"
        for violation in violations
    )
    primitive_spans = {
        span.span_id
        for unit in units
        if unit.unit_type == CuttingUnitType.SINGLE_EDGE
        for span in unit.covered_spans
    }
    return KerfLayoutAudit(
        record_id=row["record_id"],
        board_id=row["selected_board_id"],
        part_count=len(layout.rectangles),
        candidate_unit_count=len(units),
        primitive_span_count=len(primitive_spans),
        shared_centerline_unit_count=sum(
            unit.unit_type == CuttingUnitType.SHARED_EDGE for unit in units
        ),
        envelope_overlap_count=overlap_count,
        stock_boundary_violation_count=boundary_count,
        finished_dimension_violation_count=finished_count,
        swept_disk_gouge_count=gouge_count,
        manufacturable=(
            overlap_count == 0
            and boundary_count == 0
            and finished_count == 0
            and gouge_count == 0
        ),
    )


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with args.manifest.open(newline="", encoding="utf-8-sig") as handle:
        manifest = list(csv.DictReader(handle))
    audits = [audit_record(args.archive, row) for row in manifest]
    output_csv = args.output_dir / "stage7_kerf_layout_audit.csv"
    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(audits[0])))
        writer.writeheader()
        writer.writerows(asdict(audit) for audit in audits)

    failed = [audit for audit in audits if not audit.manufacturable]
    summary = args.output_dir / "README.md"
    summary.write_text(
        "\n".join(
            (
                "# Stage 7 Kerf Layout Audit",
                "",
                f"- Audited records: {len(audits)}",
                f"- Manufacturable records: {len(audits) - len(failed)}",
                f"- Failed records: {len(failed)}",
                f"- Envelope overlaps: {sum(a.envelope_overlap_count for a in audits)}",
                f"- Stock-boundary violations: {sum(a.stock_boundary_violation_count for a in audits)}",
                f"- Finished-dimension violations: {sum(a.finished_dimension_violation_count for a in audits)}",
                f"- Swept-disk gouges: {sum(a.swept_disk_gouge_count for a in audits)}",
                f"- Shared compensated centerline candidates: {sum(a.shared_centerline_unit_count for a in audits)}",
                "",
            )
        ),
        encoding="utf-8",
    )
    print(f"audited_records={len(audits)}")
    print(f"manufacturable_records={len(audits) - len(failed)}")
    print(f"failed_records={len(failed)}")
    print(f"output={output_csv}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
