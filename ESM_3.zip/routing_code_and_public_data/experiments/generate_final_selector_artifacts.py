from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
TARGET_METHOD = "process_aware_beam_adaptive_polished"
METHOD_ORDER = (
    "topology_process_aware",
    "process_local_search_multistart",
    "process_aware_beam",
    TARGET_METHOD,
)
METHOD_LABELS = {
    "topology_process_aware": "Topology-aware",
    "process_local_search_multistart": "Multi-start LS",
    "process_aware_beam": "Process-aware beam",
    TARGET_METHOD: "Final selector",
    "greedy": "Greedy",
    "path_distance_local_search": "Path-LS",
    "topology": "Topology",
}
METHOD_COLORS = {
    "topology_process_aware": "#8C8C8C",
    "process_local_search_multistart": "#56B4E9",
    "process_aware_beam": "#0072B2",
    TARGET_METHOD: "#E76F51",
    "greedy": "#9CA3AF",
    "path_distance_local_search": "#A3A3A3",
    "topology": "#B0BEC5",
}


plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 9.5,
        "axes.titlesize": 10.5,
        "axes.titleweight": "bold",
        "axes.labelsize": 9.5,
        "legend.fontsize": 8.2,
        "legend.frameon": False,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.18,
        "grid.linestyle": "-",
    }
)


def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def number(row: dict[str, str], key: str, default: float = 0.0) -> float:
    value = row.get(key, "")
    if value == "":
        return default
    return float(value)


def label(method: str) -> str:
    return METHOD_LABELS.get(method, method)


def fmt(value: float, digits: int = 2) -> str:
    if abs(value) >= 1000:
        return f"{value:,.{digits}f}"
    return f"{value:.{digits}f}"


def fmt_p_value(value: str) -> str:
    if value == "":
        return ""
    parsed = float(value)
    if parsed < 1e-4:
        return "<1e-4"
    return f"{parsed:.4f}"


def write_csv(rows: list[dict[str, str]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def latex_escape(text: str) -> str:
    return (
        text.replace("\\", "\\textbackslash{}")
        .replace("&", "\\&")
        .replace("%", "\\%")
        .replace("_", "\\_")
        .replace("#", "\\#")
    )


def write_latex_table(
    rows: list[dict[str, str]],
    path: Path,
    caption: str,
    latex_label: str,
) -> None:
    if not rows:
        return
    columns = list(rows[0].keys())
    align = "l" + "r" * (len(columns) - 1)
    lines = [
        "\\begin{table}[t]",
        "\\centering",
        f"\\caption{{{latex_escape(caption)}}}",
        f"\\label{{{latex_label}}}",
        f"\\begin{{tabular}}{{{align}}}",
        "\\toprule",
        " & ".join(latex_escape(column.replace("_", " ")) for column in columns)
        + " \\\\",
        "\\midrule",
    ]
    for row in rows:
        lines.append(" & ".join(latex_escape(str(row[column])) for column in columns) + " \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def save_figure(fig: plt.Figure, output_dir: Path, stem: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_dir / f"{stem}.pdf")
    fig.savefig(output_dir / f"{stem}.png", dpi=300)
    plt.close(fig)


def main_method_table(summary_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    by_method = {row["method"]: row for row in summary_rows}
    output: list[dict[str, str]] = []
    for method in METHOD_ORDER:
        row = by_method.get(method)
        if row is None:
            continue
        output.append(
            {
                "method": label(method),
                "n": row["n"],
                "travel_cost": fmt(number(row, "travel_mode_cost_mean"), 1),
                "air_move": fmt(number(row, "air_move_distance_mean"), 1),
                "safe_lift": fmt(number(row, "safe_lift_count_mean"), 2),
                "detour": fmt(number(row, "detour_count_mean"), 2),
                "hard": fmt(number(row, "hard_penalty_mean"), 2),
                "support_rule": fmt(number(row, "stability_penalty_mean"), 2),
                "repeat_cut": fmt(number(row, "cut_repeated_segment_count_mean"), 2),
                "runtime_ms": fmt(number(row, "runtime_ms_mean"), 1),
            }
        )
    return output


def statistical_table(stat_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    metrics = {"process_key", "machining_cost", "travel_mode_cost"}
    output: list[dict[str, str]] = []
    for row in stat_rows:
        if row["metric"] not in metrics:
            continue
        output.append(
            {
                "baseline": label(row["baseline_method"]),
                "metric": row["metric"].replace("_", " "),
                "reduction_pct": fmt(number(row, "reduction_mean"), 2),
                "ci95": (
                    f"[{fmt(number(row, 'reduction_ci95_low'), 2)}, "
                    f"{fmt(number(row, 'reduction_ci95_high'), 2)}]"
                ),
                "wins_ties_losses": f"{row['wins']}/{row['ties']}/{row['losses']}",
                "p_value": fmt_p_value(row.get("sign_test_p", "")),
            }
        )
    return output


def optimality_gap_table(gap_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    for method in (
        "process_aware_beam",
        "process_local_search_multistart",
        TARGET_METHOD,
    ):
        match = next((row for row in gap_rows if row["method"] == method), None)
        if match is None:
            continue
        output.append(
            {
                "method": label(method),
                "n": match["n"],
                "mean_gap": fmt(number(match, "travel_mode_cost_gap_mean"), 2),
                "comparable_gap": fmt(
                    number(match, "comparable_travel_mode_cost_gap_mean"), 2
                ),
                "tie_count": match["process_key_tie_count"],
                "loss_count": match["process_key_loss_count"],
            }
        )
    return output


def route_case_table(route_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    grouped: dict[tuple[str, str, str], dict[str, dict[str, str]]] = defaultdict(dict)
    for row in route_rows:
        key = (row["archive"], row["placements_member"], row["board_id"])
        grouped[key][row["method"]] = row

    cases: list[dict[str, str | float | int]] = []
    for (archive, member, board_id), methods in grouped.items():
        beam = methods.get("process_aware_beam")
        final = methods.get(TARGET_METHOD)
        topology = methods.get("topology_process_aware")
        if beam is None or final is None or topology is None:
            continue
        beam_cost = number(beam, "travel_mode_cost")
        final_cost = number(final, "travel_mode_cost")
        cases.append(
            {
                "archive": archive,
                "placements_member": member,
                "board_id": board_id,
                "rectangles": int(number(final, "rectangle_count")),
                "selected_units": int(number(final, "selected_unit_count")),
                "beam_cost": beam_cost,
                "final_cost": final_cost,
                "gain_vs_beam": beam_cost - final_cost,
                "gain_pct_vs_beam": (
                    100.0 * (beam_cost - final_cost) / beam_cost if beam_cost else 0.0
                ),
                "beam_detour": number(beam, "detour_count"),
                "final_detour": number(final, "detour_count"),
                "beam_safe_lift": number(beam, "safe_lift_count"),
                "final_safe_lift": number(final, "safe_lift_count"),
            }
        )

    selected: list[dict[str, str | float | int]] = []
    seen_boards: set[tuple[str, str]] = set()
    candidates = [
        sorted(cases, key=lambda row: float(row["gain_vs_beam"]), reverse=True),
        sorted(
            [row for row in cases if 25 <= int(row["rectangles"]) <= 32],
            key=lambda row: float(row["gain_vs_beam"]),
            reverse=True,
        ),
        sorted(
            [row for row in cases if 20 <= int(row["rectangles"]) <= 24],
            key=lambda row: float(row["gain_vs_beam"]),
            reverse=True,
        ),
    ]
    names = ("large_gain", "medium_case", "small_case")
    for name, bucket in zip(names, candidates):
        for row in bucket:
            board_key = (str(row["archive"]), str(row["placements_member"]))
            if board_key in seen_boards:
                continue
            seen_boards.add(board_key)
            row = dict(row)
            row["case_name"] = name
            selected.append(row)
            break

    output: list[dict[str, str]] = []
    for row in selected:
        output.append(
            {
                "case_name": str(row["case_name"]),
                "archive": str(row["archive"]),
                "board_id": str(row["board_id"]),
                "rectangles": str(row["rectangles"]),
                "selected_units": str(row["selected_units"]),
                "beam_cost": fmt(float(row["beam_cost"]), 1),
                "final_cost": fmt(float(row["final_cost"]), 1),
                "gain_vs_beam": fmt(float(row["gain_vs_beam"]), 1),
                "gain_pct_vs_beam": fmt(float(row["gain_pct_vs_beam"]), 2),
                "beam_detour": fmt(float(row["beam_detour"]), 0),
                "final_detour": fmt(float(row["final_detour"]), 0),
                "beam_safe_lift": fmt(float(row["beam_safe_lift"]), 0),
                "final_safe_lift": fmt(float(row["final_safe_lift"]), 0),
                "placements_member": str(row["placements_member"]),
            }
        )
    return output


def plot_main_summary(summary_rows: list[dict[str, str]], output_dir: Path) -> None:
    ordered = [row for method in METHOD_ORDER for row in summary_rows if row["method"] == method]
    labels = [label(row["method"]) for row in ordered]
    colors = [METHOD_COLORS[row["method"]] for row in ordered]
    x = np.arange(len(ordered))

    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.65))
    panels = [
        ("travel_mode_cost_mean", "Travel-mode cost", "Mean cost"),
        ("air_move_distance_mean", "Air move distance", "Mean distance (mm)"),
        ("runtime_ms_mean", "Runtime", "Mean runtime (ms)"),
    ]
    for ax, (key, title, ylabel) in zip(axes, panels):
        values = [number(row, key) for row in ordered]
        ax.bar(x, values, color=colors, edgecolor="white", linewidth=0.6)
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=25, ha="right")
        for idx, value in enumerate(values):
            ax.text(idx, value * 1.012, fmt(value, 0), ha="center", va="bottom", fontsize=7)
    fig.tight_layout()
    save_figure(fig, output_dir, "fig_final_selector_main_summary")


def plot_statistical_reduction(stat_rows: list[dict[str, str]], output_dir: Path) -> None:
    rows = [
        row
        for row in stat_rows
        if row["metric"] == "travel_mode_cost"
        and row["baseline_method"] in METHOD_ORDER
        and row["baseline_method"] != TARGET_METHOD
    ]
    rows.sort(key=lambda row: METHOD_ORDER.index(row["baseline_method"]))
    y = np.arange(len(rows))
    reductions = [number(row, "reduction_mean") for row in rows]
    low = [number(row, "reduction_ci95_low") for row in rows]
    high = [number(row, "reduction_ci95_high") for row in rows]
    xerr = np.array(
        [[r - l for r, l in zip(reductions, low)], [h - r for h, r in zip(high, reductions)]]
    )

    fig, ax = plt.subplots(figsize=(5.0, 2.3))
    ax.barh(
        y,
        reductions,
        xerr=xerr,
        color=[METHOD_COLORS[row["baseline_method"]] for row in rows],
        edgecolor="white",
        linewidth=0.6,
        capsize=3,
    )
    ax.axvline(0.0, color="#111827", linewidth=0.8)
    ax.set_yticks(y)
    ax.set_yticklabels([label(row["baseline_method"]) for row in rows])
    ax.invert_yaxis()
    ax.set_xlabel("Travel-mode cost reduction of final selector (%)")
    ax.set_title("Paired reduction on 77 real boards")
    for idx, value in enumerate(reductions):
        ax.text(value + 0.25, idx, f"{value:.2f}%", va="center", fontsize=8)
    fig.tight_layout()
    save_figure(fig, output_dir, "fig_final_selector_paired_reduction")


def plot_optimality_gap(gap_rows: list[dict[str, str]], output_dir: Path) -> None:
    methods = (
        "process_aware_beam",
        "process_local_search_multistart",
        TARGET_METHOD,
    )
    ordered = [row for method in methods for row in gap_rows if row["method"] == method]
    labels = [label(row["method"]) for row in ordered]
    colors = [METHOD_COLORS.get(row["method"], "#999999") for row in ordered]
    x = np.arange(len(ordered))
    gaps = [number(row, "comparable_travel_mode_cost_gap_mean") for row in ordered]
    losses = [number(row, "process_key_loss_count") for row in ordered]

    fig, axes = plt.subplots(1, 2, figsize=(6.2, 2.55))
    axes[0].bar(x, gaps, color=colors, edgecolor="white", linewidth=0.6)
    axes[0].axhline(0.0, color="#111827", linewidth=0.75)
    axes[0].set_title("Portfolio gap")
    axes[0].set_ylabel("Mean comparable gap")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(labels, rotation=25, ha="right")

    axes[1].bar(x, losses, color=colors, edgecolor="white", linewidth=0.6)
    axes[1].set_title("Process-key losses")
    axes[1].set_ylabel("Loss count")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(labels, rotation=25, ha="right")
    for idx, value in enumerate(losses):
        axes[1].text(idx, value + 0.25, f"{int(value)}", ha="center", va="bottom", fontsize=8)

    fig.tight_layout()
    save_figure(fig, output_dir, "fig_final_selector_portfolio_gap")


def write_index(path: Path, artifacts: dict[str, Path]) -> None:
    lines = [
        "# Final Selector Artifacts",
        "",
        "Generated from the protected portfolio v2 experiment outputs.",
        "",
    ]
    for name, artifact_path in artifacts.items():
        lines.append(f"- {name}: `{artifact_path}`")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--main-summary",
        type=Path,
        default=ROOT
        / "results"
        / "chapter3_main_hard_gate25_real_77_20_50_protected_portfolio_v2_summary.csv",
    )
    parser.add_argument(
        "--main-detail",
        type=Path,
        default=ROOT
        / "results"
        / "chapter3_main_hard_gate25_real_77_20_50_protected_portfolio_v2.csv",
    )
    parser.add_argument(
        "--statistical",
        type=Path,
        default=ROOT
        / "results"
        / "chapter3_main_hard_gate25_real_77_20_50_protected_portfolio_v2_statistical.csv",
    )
    parser.add_argument(
        "--gap-summary",
        type=Path,
        default=ROOT
        / "results"
        / "chapter3_optimality_gap_real_8_12_protected_portfolio_v2_summary.csv",
    )
    parser.add_argument(
        "--tables-dir",
        type=Path,
        default=ROOT / "results" / "paper_artifacts_final_selector",
    )
    parser.add_argument(
        "--figures-dir",
        type=Path,
        default=ROOT / "figures" / "paper_artifacts_final_selector",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary_rows = load_rows(args.main_summary)
    detail_rows = load_rows(args.main_detail)
    stat_rows = load_rows(args.statistical)
    gap_rows = load_rows(args.gap_summary)

    artifacts: dict[str, Path] = {}

    main_table = main_method_table(summary_rows)
    main_csv = args.tables_dir / "table_final_selector_main_summary.csv"
    write_csv(main_table, main_csv)
    write_latex_table(
        main_table,
        args.tables_dir / "table_final_selector_main_summary.tex",
        "Final selector comparison on 77 real boards with 20-50 rectangles.",
        "tab:final-selector-main-summary",
    )
    artifacts["main summary table"] = main_csv

    stat_table = statistical_table(stat_rows)
    stat_csv = args.tables_dir / "table_final_selector_statistical.csv"
    write_csv(stat_table, stat_csv)
    write_latex_table(
        stat_table,
        args.tables_dir / "table_final_selector_statistical.tex",
        "Paired statistical comparison against final selector.",
        "tab:final-selector-statistical",
    )
    artifacts["statistical table"] = stat_csv

    gap_table = optimality_gap_table(gap_rows)
    gap_csv = args.tables_dir / "table_final_selector_portfolio_gap.csv"
    write_csv(gap_table, gap_csv)
    write_latex_table(
        gap_table,
        args.tables_dir / "table_final_selector_portfolio_gap.tex",
        "Small real-board portfolio gap for 8-12 rectangles.",
        "tab:final-selector-portfolio-gap",
    )
    artifacts["portfolio gap table"] = gap_csv

    route_table = route_case_table(detail_rows)
    route_csv = args.tables_dir / "table_final_selector_route_cases.csv"
    write_csv(route_table, route_csv)
    artifacts["route case table"] = route_csv

    plot_main_summary(summary_rows, args.figures_dir)
    plot_statistical_reduction(stat_rows, args.figures_dir)
    plot_optimality_gap(gap_rows, args.figures_dir)
    artifacts["main summary figure"] = (
        args.figures_dir / "fig_final_selector_main_summary.pdf"
    )
    artifacts["paired reduction figure"] = (
        args.figures_dir / "fig_final_selector_paired_reduction.pdf"
    )
    artifacts["portfolio gap figure"] = (
        args.figures_dir / "fig_final_selector_portfolio_gap.pdf"
    )
    for route_stem in (
        "fig_route_case_large_gain",
        "fig_route_case_medium",
        "fig_route_case_small",
    ):
        route_png = args.figures_dir / f"{route_stem}.png"
        if route_png.exists():
            artifacts[route_stem.replace("fig_", "").replace("_", " ")] = route_png
    for metrics_stem in (
        "route_case_large_gain_metrics",
        "route_case_medium_metrics",
        "route_case_small_metrics",
    ):
        metrics_path = args.tables_dir / f"{metrics_stem}.csv"
        if metrics_path.exists():
            artifacts[metrics_stem.replace("_", " ")] = metrics_path

    index_path = args.tables_dir / "final_selector_artifact_index.md"
    write_index(index_path, artifacts)
    artifacts["artifact index"] = index_path

    print(f"tables: {args.tables_dir}")
    print(f"figures: {args.figures_dir}")
    for path in artifacts.values():
        print(f"wrote: {path}")


if __name__ == "__main__":
    main()
