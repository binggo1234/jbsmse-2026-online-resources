from __future__ import annotations

import argparse
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXTERNAL_RESULTS = (
    ROOT
    / "results"
    / "formal"
    / "chapter3_formal_hard_gate25_external_baselines.csv"
)
DEFAULT_GTSP_RESULTS = (
    ROOT
    / "results"
    / "formal"
    / "chapter3_formal_hard_gate25_endpoint_aware_gtsp.csv"
)
DEFAULT_OUTPUT = (
    ROOT
    / "results"
    / "formal"
    / "chapter3_formal_hard_gate25_external_baselines_with_gtsp.csv"
)
DEFAULT_METHODS = (
    "contour_tsp_2opt",
    "contour_aco",
    "endpoint_aware_gtsp",
    "process_aware_beam_adaptive_polished",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Combine the formal contour, endpoint-aware GTSP, and target-method "
            "rows after validating that they use the same layout records."
        )
    )
    parser.add_argument(
        "--external-results",
        type=Path,
        default=DEFAULT_EXTERNAL_RESULTS,
    )
    parser.add_argument("--gtsp-results", type=Path, default=DEFAULT_GTSP_RESULTS)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--methods", nargs="+", default=DEFAULT_METHODS)
    return parser.parse_args()


def case_id(row: dict[str, str]) -> tuple[str, str, str]:
    return row["archive"], row["placements_member"], row["board_id"]


def read_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"empty result CSV: {path}")
        rows = list(reader)
    return list(reader.fieldnames), rows


def combine_rows(
    external_rows: list[dict[str, str]],
    gtsp_rows: list[dict[str, str]],
    methods: tuple[str, ...],
) -> list[dict[str, str]]:
    selected = [
        row
        for row in (*external_rows, *gtsp_rows)
        if row.get("method") in methods
    ]
    indexed = {(case_id(row), row["method"]): row for row in selected}
    gtsp_cases = {
        case_id(row)
        for row in gtsp_rows
        if row.get("method") == "endpoint_aware_gtsp"
    }
    if not gtsp_cases:
        raise ValueError("no endpoint_aware_gtsp rows found")

    missing = [
        (record, method)
        for record in sorted(gtsp_cases)
        for method in methods
        if (record, method) not in indexed
    ]
    if missing:
        raise ValueError(
            "comparison rows are not fully paired; first missing pair: "
            f"{missing[0]}"
        )

    unexpected_cases = {
        case_id(row)
        for row in selected
        if case_id(row) not in gtsp_cases
    }
    if unexpected_cases:
        raise ValueError(
            "comparison inputs contain records outside the GTSP run: "
            f"{sorted(unexpected_cases)[0]}"
        )

    return [
        indexed[(record, method)]
        for record in sorted(gtsp_cases)
        for method in methods
    ]


def main() -> None:
    args = parse_args()
    external_fields, external_rows = read_rows(args.external_results)
    gtsp_fields, gtsp_rows = read_rows(args.gtsp_results)
    if external_fields != gtsp_fields:
        raise ValueError("external and GTSP result schemas differ")

    methods = tuple(args.methods)
    combined = combine_rows(external_rows, gtsp_rows, methods)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=external_fields,
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(combined)

    print(
        f"wrote: {args.output} "
        f"({len(combined) // len(methods)} records x {len(methods)} methods)"
    )


if __name__ == "__main__":
    main()
