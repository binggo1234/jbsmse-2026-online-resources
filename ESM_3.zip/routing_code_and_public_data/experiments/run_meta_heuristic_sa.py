from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "experiments"))

from run_chapter2_batch import DEFAULT_ARCHIVES
from run_final_chapter3_main import (
    DEFAULT_STAT_METRICS,
    build_batch_command,
    build_statistical_command,
    final_experiment_paths,
    run_command,
)


DEFAULT_OUTPUT_STEM = "chapter3_process_aware_metaheuristics_real_20_50"
DEFAULT_TARGET_METHOD = "process_aware_beam_adaptive_polished"
DEFAULT_METHODS = (
    "process_aware_sa",
    "process_aware_ga",
    "process_local_search_multistart",
    DEFAULT_TARGET_METHOD,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run apples-to-apples process-aware SA/GA baselines against the "
            "Chapter 3 target method."
        )
    )
    parser.add_argument("--results-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--output-stem", default=DEFAULT_OUTPUT_STEM)
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=55)
    parser.add_argument("--boards-per-member", type=int, default=1)
    parser.add_argument("--min-rectangles", type=int, default=20)
    parser.add_argument("--max-rectangles", type=int, default=50)
    parser.add_argument("--task-timeout-seconds", type=float, default=90.0)
    parser.add_argument(
        "--methods",
        nargs="+",
        default=list(DEFAULT_METHODS),
        choices=DEFAULT_METHODS,
    )
    parser.add_argument("--target-method", default=DEFAULT_TARGET_METHOD)
    parser.add_argument(
        "--experiment-preset",
        choices=("paper-main",),
        default="paper-main",
    )
    parser.add_argument(
        "--repeat-cut-policy",
        choices=("hard", "soft", "off"),
        default="hard",
    )
    parser.add_argument("--disable-tool-event-gate", action="store_true")
    parser.add_argument("--tool-event-min-travel-saving", type=float, default=25.0)
    parser.add_argument("--tool-event-min-travel-saving-ratio", type=float, default=0.0)
    parser.add_argument("--tool-event-min-machining-saving", type=float, default=1e-9)
    parser.add_argument("--bootstrap-samples", type=int, default=5000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260502)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-progress-bar", action="store_true")
    parser.add_argument("--skip-statistics", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    paths = final_experiment_paths(args.results_dir, args.output_stem)
    zip_paths = tuple(args.zip_paths) if args.zip_paths else DEFAULT_ARCHIVES
    methods = tuple(args.methods)
    batch_command = build_batch_command(
        paths,
        python_executable=sys.executable,
        zip_paths=zip_paths,
        methods=methods,
        experiment_preset=args.experiment_preset,
        repeat_cut_policy=args.repeat_cut_policy,
        tool_event_gate_enabled=not args.disable_tool_event_gate,
        tool_event_min_travel_saving=args.tool_event_min_travel_saving,
        tool_event_min_travel_saving_ratio=args.tool_event_min_travel_saving_ratio,
        tool_event_min_machining_saving=args.tool_event_min_machining_saving,
        max_members_per_archive=args.max_members_per_archive,
        boards_per_member=args.boards_per_member,
        min_rectangles=args.min_rectangles,
        max_rectangles=args.max_rectangles,
        task_timeout_seconds=args.task_timeout_seconds,
        fresh=not args.resume,
        progress_bar=not args.no_progress_bar,
    )
    run_command(batch_command, dry_run=args.dry_run)

    if args.skip_statistics:
        return

    baselines = tuple(method for method in methods if method != args.target_method)
    statistical_command = build_statistical_command(
        paths,
        python_executable=sys.executable,
        target_method=args.target_method,
        baseline_methods=baselines,
        metrics=DEFAULT_STAT_METRICS,
        bootstrap_samples=args.bootstrap_samples,
        bootstrap_seed=args.bootstrap_seed,
    )
    run_command(statistical_command, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
