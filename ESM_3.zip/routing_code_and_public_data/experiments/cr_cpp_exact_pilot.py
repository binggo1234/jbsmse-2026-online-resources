from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import hypot

from cnc_cutting.models import Layout, PlacedRectangle, Point


TOLERANCE = 1e-9


class PilotPhase(str, Enum):
    ROUGH = "rough"
    THROUGH = "through"
    RELEASE = "release"


class PilotMethod(str, Enum):
    REPEATED_2D_ORDER = "repeated_2d_order"
    FIXED_TAB_ROUTE_OPTIMUM = "fixed_tab_route_optimum"
    LAYER_FIRST_EXACT = "layer_first_exact"
    PART_LOCAL_RETAINED_EXACT = "part_local_retained_exact"
    CONTROLLED_RELEASE_EXACT = "controlled_release_exact"
    EARLY_RELEASE_REFERENCE = "early_release_reference"


@dataclass(frozen=True)
class KinematicTemplate:
    tool_diameter_mm: float = 6.0
    tab_width_mm: float = 8.0
    shallow_depth_mm: float = 9.0
    full_depth_mm: float = 18.0
    safe_z_mm: float = 5.0
    feed_cut_mm_min: float = 3600.0
    feed_plunge_mm_min: float = 800.0
    feed_rapid_mm_min: float = 8000.0
    start_point: Point = Point(0.0, 0.0)

    def __post_init__(self) -> None:
        if self.tool_diameter_mm <= 0.0:
            raise ValueError("tool_diameter_mm must be positive")
        if self.tab_width_mm <= 0.0:
            raise ValueError("tab_width_mm must be positive")
        if not 0.0 < self.shallow_depth_mm < self.full_depth_mm:
            raise ValueError("depths must satisfy 0 < shallow < full")
        if self.safe_z_mm < 0.0:
            raise ValueError("safe_z_mm must be non-negative")
        if min(
            self.feed_cut_mm_min,
            self.feed_plunge_mm_min,
            self.feed_rapid_mm_min,
        ) <= 0.0:
            raise ValueError("all programmed feeds must be positive")

    @property
    def tool_radius_mm(self) -> float:
        return self.tool_diameter_mm / 2.0


@dataclass(frozen=True)
class RetentionCandidate:
    candidate_id: str
    part_id: str
    side: str
    start: Point
    end: Point
    width_mm: float


@dataclass(frozen=True)
class PilotPart:
    part_id: str
    nominal: PlacedRectangle
    offset_min_x: float
    offset_min_y: float
    offset_max_x: float
    offset_max_y: float
    perimeter_mm: float
    candidates: tuple[RetentionCandidate, ...]

    @property
    def area_mm2(self) -> float:
        return self.nominal.width * self.nominal.height


@dataclass(frozen=True)
class PilotProblem:
    case_id: str
    panel_width_mm: float
    panel_height_mm: float
    parts: tuple[PilotPart, ...]
    template: KinematicTemplate
    source_part_count: int
    geometry_feasible: bool
    geometry_issues: tuple[str, ...]


@dataclass(frozen=True)
class PilotAction:
    action_id: str
    part_id: str
    phase: PilotPhase
    candidate_id: str
    direction: int
    start: Point
    end: Point
    depth_mm: float
    cut_length_mm: float


@dataclass(frozen=True)
class PilotMetrics:
    cut_length_mm: float = 0.0
    rapid_xy_length_mm: float = 0.0
    plunge_distance_mm: float = 0.0
    retract_distance_mm: float = 0.0
    plunge_count: int = 0
    retract_count: int = 0
    cut_time_s: float = 0.0
    rapid_xy_time_s: float = 0.0
    plunge_time_s: float = 0.0
    retract_time_s: float = 0.0
    bridge_removal_length_mm: float = 0.0
    early_release_count: int = 0
    early_release_exposure_mm2_s: float = 0.0

    @property
    def programmed_time_s(self) -> float:
        return (
            self.cut_time_s
            + self.rapid_xy_time_s
            + self.plunge_time_s
            + self.retract_time_s
        )

    @property
    def tool_event_count(self) -> int:
        return self.plunge_count + self.retract_count


@dataclass(frozen=True)
class PilotAudit:
    precedence_valid: bool
    complete_final_coverage: bool
    no_residual_bridge: bool
    retention_until_release: bool
    release_barrier_valid: bool
    cutter_center_offset_valid: bool
    stock_envelope_valid: bool
    no_nominal_part_overlap: bool
    tool_channel_valid: bool

    @property
    def all_passed(self) -> bool:
        return all(
            (
                self.precedence_valid,
                self.complete_final_coverage,
                self.no_residual_bridge,
                self.retention_until_release,
                self.release_barrier_valid,
                self.cutter_center_offset_valid,
                self.stock_envelope_valid,
                self.no_nominal_part_overlap,
                self.tool_channel_valid,
            )
        )


@dataclass(frozen=True)
class PilotPlan:
    method: PilotMethod
    actions: tuple[PilotAction, ...]
    metrics: PilotMetrics
    audit: PilotAudit
    expanded_labels: int
    retained_labels: int


@dataclass(frozen=True)
class _Label:
    stages: tuple[int, ...]
    choices: tuple[int, ...]
    current_point: Point
    current_depth_mm: float | None
    actions: tuple[PilotAction, ...]
    metrics: PilotMetrics


def _distance(first: Point, second: Point) -> float:
    return hypot(second.x - first.x, second.y - first.y)


def _same_point(first: Point, second: Point) -> bool:
    return _distance(first, second) <= TOLERANCE


def _rectangle_axis_gaps(
    first: PlacedRectangle,
    second: PlacedRectangle,
) -> tuple[float, float]:
    dx = max(first.min_x - second.max_x, second.min_x - first.max_x, 0.0)
    dy = max(first.min_y - second.max_y, second.min_y - first.max_y, 0.0)
    return dx, dy


def _nominal_rectangles_overlap(
    first: PlacedRectangle,
    second: PlacedRectangle,
) -> bool:
    overlap_x = min(first.max_x, second.max_x) - max(first.min_x, second.min_x)
    overlap_y = min(first.max_y, second.max_y) - max(first.min_y, second.min_y)
    return overlap_x > TOLERANCE and overlap_y > TOLERANCE


def _retention_candidates(
    rectangle: PlacedRectangle,
    template: KinematicTemplate,
) -> tuple[RetentionCandidate, ...]:
    radius = template.tool_radius_mm
    min_x = rectangle.min_x - radius
    max_x = rectangle.max_x + radius
    min_y = rectangle.min_y - radius
    max_y = rectangle.max_y + radius
    half_tab = template.tab_width_mm / 2.0
    center_x = (min_x + max_x) / 2.0
    center_y = (min_y + max_y) / 2.0
    if max_x - min_x <= template.tab_width_mm + TOLERANCE:
        raise ValueError(f"part {rectangle.part_id} is too narrow for the pilot tab")
    if max_y - min_y <= template.tab_width_mm + TOLERANCE:
        raise ValueError(f"part {rectangle.part_id} is too short for the pilot tab")
    return (
        RetentionCandidate(
            candidate_id=f"{rectangle.part_id}:bottom",
            part_id=rectangle.part_id,
            side="bottom",
            start=Point(center_x - half_tab, min_y),
            end=Point(center_x + half_tab, min_y),
            width_mm=template.tab_width_mm,
        ),
        RetentionCandidate(
            candidate_id=f"{rectangle.part_id}:right",
            part_id=rectangle.part_id,
            side="right",
            start=Point(max_x, center_y - half_tab),
            end=Point(max_x, center_y + half_tab),
            width_mm=template.tab_width_mm,
        ),
    )


def build_pilot_problem(
    layout: Layout,
    template: KinematicTemplate | None = None,
    max_parts: int = 5,
) -> PilotProblem:
    if template is None:
        template = KinematicTemplate()
    if max_parts <= 0:
        raise ValueError("max_parts must be positive")
    if len(layout.rectangles) < max_parts:
        raise ValueError(
            f"pilot requires at least {max_parts} parts; got {len(layout.rectangles)}"
        )

    selected = layout.rectangles[:max_parts]
    radius = template.tool_radius_mm
    parts = tuple(
        PilotPart(
            part_id=rectangle.part_id,
            nominal=rectangle,
            offset_min_x=rectangle.min_x - radius,
            offset_min_y=rectangle.min_y - radius,
            offset_max_x=rectangle.max_x + radius,
            offset_max_y=rectangle.max_y + radius,
            perimeter_mm=2.0
            * (rectangle.width + rectangle.height + 4.0 * radius),
            candidates=_retention_candidates(rectangle, template),
        )
        for rectangle in selected
    )

    issues: list[str] = []
    for part in parts:
        if (
            part.offset_min_x < -TOLERANCE
            or part.offset_min_y < -TOLERANCE
            or part.offset_max_x > layout.panel_width + TOLERANCE
            or part.offset_max_y > layout.panel_height + TOLERANCE
        ):
            issues.append(f"{part.part_id}: offset contour leaves the stock envelope")
    for index, first in enumerate(parts):
        for second in parts[index + 1 :]:
            if _nominal_rectangles_overlap(first.nominal, second.nominal):
                issues.append(
                    f"{first.part_id}/{second.part_id}: nominal rectangles overlap"
                )
                continue
            dx, dy = _rectangle_axis_gaps(first.nominal, second.nominal)
            if (
                dx + TOLERANCE < template.tool_diameter_mm
                and dy + TOLERANCE < template.tool_diameter_mm
            ):
                issues.append(
                    f"{first.part_id}/{second.part_id}: cutter-center envelopes "
                    f"conflict for the {template.tool_diameter_mm:.6f} mm tool"
                )

    suffix = f"_first{max_parts}" if len(layout.rectangles) > max_parts else ""
    return PilotProblem(
        case_id=f"{layout.panel_id}{suffix}",
        panel_width_mm=layout.panel_width,
        panel_height_mm=layout.panel_height,
        parts=parts,
        template=template,
        source_part_count=len(layout.rectangles),
        geometry_feasible=not issues,
        geometry_issues=tuple(issues),
    )


def _action_variants(
    problem: PilotProblem,
    part_index: int,
    phase: PilotPhase,
    candidate_index: int,
) -> tuple[PilotAction, PilotAction]:
    part = problem.parts[part_index]
    candidate = part.candidates[candidate_index]
    if phase is PilotPhase.ROUGH:
        depth = problem.template.shallow_depth_mm
        cut_length = part.perimeter_mm
        endpoints = ((candidate.start, candidate.start), (candidate.end, candidate.end))
    elif phase is PilotPhase.THROUGH:
        depth = problem.template.full_depth_mm
        cut_length = part.perimeter_mm - candidate.width_mm
        endpoints = ((candidate.start, candidate.end), (candidate.end, candidate.start))
    else:
        depth = problem.template.full_depth_mm
        cut_length = candidate.width_mm
        endpoints = ((candidate.start, candidate.end), (candidate.end, candidate.start))
    variants = tuple(
        PilotAction(
            action_id=(
                f"{part.part_id}:{phase.value}:{candidate.side}:d{direction}"
            ),
            part_id=part.part_id,
            phase=phase,
            candidate_id=candidate.candidate_id,
            direction=direction,
            start=start,
            end=end,
            depth_mm=depth,
            cut_length_mm=cut_length,
        )
        for direction, (start, end) in enumerate(endpoints)
    )
    return variants[0], variants[1]


def _offset_geometry_valid(problem: PilotProblem) -> bool:
    radius = problem.template.tool_radius_mm
    tab_width = problem.template.tab_width_mm
    for part in problem.parts:
        expected = (
            part.nominal.min_x - radius,
            part.nominal.min_y - radius,
            part.nominal.max_x + radius,
            part.nominal.max_y + radius,
        )
        actual = (
            part.offset_min_x,
            part.offset_min_y,
            part.offset_max_x,
            part.offset_max_y,
        )
        if any(abs(first - second) > TOLERANCE for first, second in zip(expected, actual)):
            return False
        expected_perimeter = 2.0 * (
            part.nominal.width + part.nominal.height + 4.0 * radius
        )
        if abs(part.perimeter_mm - expected_perimeter) > TOLERANCE:
            return False
        if len(part.candidates) != 2:
            return False
        for candidate in part.candidates:
            if candidate.part_id != part.part_id:
                return False
            if abs(_distance(candidate.start, candidate.end) - tab_width) > TOLERANCE:
                return False
            if candidate.side == "bottom":
                if (
                    abs(candidate.start.y - part.offset_min_y) > TOLERANCE
                    or abs(candidate.end.y - part.offset_min_y) > TOLERANCE
                ):
                    return False
            elif candidate.side == "right":
                if (
                    abs(candidate.start.x - part.offset_max_x) > TOLERANCE
                    or abs(candidate.end.x - part.offset_max_x) > TOLERANCE
                ):
                    return False
            else:
                return False
    return True


def _phase_for_stage(stage: int) -> PilotPhase:
    if stage == 0:
        return PilotPhase.ROUGH
    if stage == 1:
        return PilotPhase.THROUGH
    if stage == 2:
        return PilotPhase.RELEASE
    raise ValueError(f"stage {stage} has no outgoing action")


def _advance_metrics(
    problem: PilotProblem,
    label: _Label,
    action: PilotAction,
) -> PilotMetrics:
    template = problem.template
    rapid_xy = 0.0
    plunge = 0.0
    retract = 0.0
    plunge_count = 0
    retract_count = 0

    if label.current_depth_mm is None:
        rapid_xy = _distance(label.current_point, action.start)
        plunge = template.safe_z_mm + action.depth_mm
        plunge_count = 1
    elif (
        _same_point(label.current_point, action.start)
        and action.depth_mm + TOLERANCE >= label.current_depth_mm
    ):
        plunge = max(action.depth_mm - label.current_depth_mm, 0.0)
        plunge_count = int(plunge > TOLERANCE)
    else:
        retract = label.current_depth_mm + template.safe_z_mm
        retract_count = 1
        rapid_xy = _distance(label.current_point, action.start)
        plunge = template.safe_z_mm + action.depth_mm
        plunge_count = 1

    cut_time = action.cut_length_mm / template.feed_cut_mm_min * 60.0
    rapid_time = rapid_xy / template.feed_rapid_mm_min * 60.0
    plunge_time = plunge / template.feed_plunge_mm_min * 60.0
    retract_time = retract / template.feed_rapid_mm_min * 60.0
    transition_time = cut_time + rapid_time + plunge_time + retract_time
    all_through_complete = all(stage >= 2 for stage in label.stages)
    released_area = sum(
        part.area_mm2
        for part, stage in zip(problem.parts, label.stages)
        if stage == 3
    )
    exposure = 0.0 if all_through_complete else released_area * transition_time
    early_release = int(
        action.phase is PilotPhase.RELEASE and not all_through_complete
    )
    previous = label.metrics
    return PilotMetrics(
        cut_length_mm=previous.cut_length_mm + action.cut_length_mm,
        rapid_xy_length_mm=previous.rapid_xy_length_mm + rapid_xy,
        plunge_distance_mm=previous.plunge_distance_mm + plunge,
        retract_distance_mm=previous.retract_distance_mm + retract,
        plunge_count=previous.plunge_count + plunge_count,
        retract_count=previous.retract_count + retract_count,
        cut_time_s=previous.cut_time_s + cut_time,
        rapid_xy_time_s=previous.rapid_xy_time_s + rapid_time,
        plunge_time_s=previous.plunge_time_s + plunge_time,
        retract_time_s=previous.retract_time_s + retract_time,
        bridge_removal_length_mm=(
            previous.bridge_removal_length_mm
            + (action.cut_length_mm if action.phase is PilotPhase.RELEASE else 0.0)
        ),
        early_release_count=previous.early_release_count + early_release,
        early_release_exposure_mm2_s=(
            previous.early_release_exposure_mm2_s + exposure
        ),
    )


def _transition(
    problem: PilotProblem,
    label: _Label,
    part_index: int,
    candidate_index: int,
    action: PilotAction,
) -> _Label:
    stage = label.stages[part_index]
    stages = list(label.stages)
    stages[part_index] = stage + 1
    choices = list(label.choices)
    if stage == 0:
        choices[part_index] = candidate_index
    return _Label(
        stages=tuple(stages),
        choices=tuple(choices),
        current_point=action.end,
        current_depth_mm=action.depth_mm,
        actions=label.actions + (action,),
        metrics=_advance_metrics(problem, label, action),
    )


def _finalize_metrics(problem: PilotProblem, label: _Label) -> PilotMetrics:
    if label.current_depth_mm is None:
        return label.metrics
    template = problem.template
    retract = label.current_depth_mm + template.safe_z_mm
    previous = label.metrics
    return PilotMetrics(
        cut_length_mm=previous.cut_length_mm,
        rapid_xy_length_mm=previous.rapid_xy_length_mm,
        plunge_distance_mm=previous.plunge_distance_mm,
        retract_distance_mm=previous.retract_distance_mm + retract,
        plunge_count=previous.plunge_count,
        retract_count=previous.retract_count + 1,
        cut_time_s=previous.cut_time_s,
        rapid_xy_time_s=previous.rapid_xy_time_s,
        plunge_time_s=previous.plunge_time_s,
        retract_time_s=(
            previous.retract_time_s
            + retract / template.feed_rapid_mm_min * 60.0
        ),
        bridge_removal_length_mm=previous.bridge_removal_length_mm,
        early_release_count=previous.early_release_count,
        early_release_exposure_mm2_s=previous.early_release_exposure_mm2_s,
    )


def _sequence_signature(actions: tuple[PilotAction, ...]) -> tuple[str, ...]:
    return tuple(action.action_id for action in actions)


def _label_rank(label: _Label) -> tuple:
    return (
        label.metrics.programmed_time_s,
        label.metrics.rapid_xy_length_mm,
        label.metrics.tool_event_count,
        _sequence_signature(label.actions),
    )


def _state_key(label: _Label) -> tuple:
    return (
        label.stages,
        label.choices,
        round(label.current_point.x, 9),
        round(label.current_point.y, 9),
        None
        if label.current_depth_mm is None
        else round(label.current_depth_mm, 9),
    )


def _allowed_part_indices(method: PilotMethod, stages: tuple[int, ...]) -> tuple[int, ...]:
    incomplete = tuple(index for index, stage in enumerate(stages) if stage < 3)
    if method is PilotMethod.LAYER_FIRST_EXACT:
        minimum_stage = min(stages)
        return tuple(index for index, stage in enumerate(stages) if stage == minimum_stage)

    if method is PilotMethod.PART_LOCAL_RETAINED_EXACT:
        if all(stage >= 2 for stage in stages):
            return tuple(index for index, stage in enumerate(stages) if stage == 2)
        active = tuple(index for index, stage in enumerate(stages) if stage == 1)
        if active:
            return active
        return tuple(index for index, stage in enumerate(stages) if stage == 0)

    if method is PilotMethod.EARLY_RELEASE_REFERENCE:
        active = tuple(index for index, stage in enumerate(stages) if stage in {1, 2})
        if active:
            return active
        return tuple(index for index, stage in enumerate(stages) if stage == 0)

    if method in {
        PilotMethod.FIXED_TAB_ROUTE_OPTIMUM,
        PilotMethod.CONTROLLED_RELEASE_EXACT,
    }:
        if not all(stage >= 2 for stage in stages):
            return tuple(index for index in incomplete if stages[index] < 2)
        return incomplete

    raise ValueError(f"method {method.value} is not an exact-search mode")


def _audit_plan(
    problem: PilotProblem,
    method: PilotMethod,
    actions: tuple[PilotAction, ...],
    metrics: PilotMetrics,
) -> PilotAudit:
    by_part = {part.part_id: [] for part in problem.parts}
    for action in actions:
        by_part[action.part_id].append(action)
    precedence_valid = True
    complete_coverage = True
    no_residual_bridge = True
    retention_until_release = True
    for part in problem.parts:
        part_actions = by_part[part.part_id]
        phases = tuple(action.phase for action in part_actions)
        if phases != (
            PilotPhase.ROUGH,
            PilotPhase.THROUGH,
            PilotPhase.RELEASE,
        ):
            precedence_valid = False
            retention_until_release = False
            continue
        if len({action.candidate_id for action in part_actions}) != 1:
            precedence_valid = False
        rough, through, release = part_actions
        if abs(rough.cut_length_mm - part.perimeter_mm) > TOLERANCE:
            complete_coverage = False
        if abs(
            through.cut_length_mm + release.cut_length_mm - part.perimeter_mm
        ) > TOLERANCE:
            complete_coverage = False
            no_residual_bridge = False

    release_barrier_required = method is not PilotMethod.EARLY_RELEASE_REFERENCE
    release_barrier_valid = (
        metrics.early_release_count == 0 if release_barrier_required else True
    )
    stock_envelope_valid = not any(
        "stock envelope" in issue for issue in problem.geometry_issues
    )
    no_overlap = not any(
        "nominal rectangles overlap" in issue for issue in problem.geometry_issues
    )
    tool_channel_valid = not any(
        "cutter-center envelopes conflict" in issue
        for issue in problem.geometry_issues
    )
    return PilotAudit(
        precedence_valid=precedence_valid,
        complete_final_coverage=complete_coverage,
        no_residual_bridge=no_residual_bridge,
        retention_until_release=retention_until_release,
        release_barrier_valid=release_barrier_valid,
        cutter_center_offset_valid=_offset_geometry_valid(problem),
        stock_envelope_valid=stock_envelope_valid,
        no_nominal_part_overlap=no_overlap,
        tool_channel_valid=tool_channel_valid,
    )


def solve_exact(problem: PilotProblem, method: PilotMethod) -> PilotPlan:
    if method is PilotMethod.REPEATED_2D_ORDER:
        return solve_repeated_2d_order(problem)
    if not problem.geometry_feasible:
        raise ValueError(
            f"pilot geometry is infeasible: {'; '.join(problem.geometry_issues)}"
        )

    part_count = len(problem.parts)
    initial = _Label(
        stages=(0,) * part_count,
        choices=(-1,) * part_count,
        current_point=problem.template.start_point,
        current_depth_mm=None,
        actions=(),
        metrics=PilotMetrics(),
    )
    layer = {_state_key(initial): initial}
    expanded = 0
    retained = 1
    for _ in range(3 * part_count):
        next_layer: dict[tuple, _Label] = {}
        for label in layer.values():
            for part_index in _allowed_part_indices(method, label.stages):
                stage = label.stages[part_index]
                phase = _phase_for_stage(stage)
                if stage == 0:
                    candidate_indices = (
                        (0,)
                        if method is PilotMethod.FIXED_TAB_ROUTE_OPTIMUM
                        else tuple(range(len(problem.parts[part_index].candidates)))
                    )
                else:
                    candidate_indices = (label.choices[part_index],)
                for candidate_index in candidate_indices:
                    for action in _action_variants(
                        problem,
                        part_index,
                        phase,
                        candidate_index,
                    ):
                        candidate = _transition(
                            problem,
                            label,
                            part_index,
                            candidate_index,
                            action,
                        )
                        key = _state_key(candidate)
                        incumbent = next_layer.get(key)
                        if incumbent is None or _label_rank(candidate) < _label_rank(
                            incumbent
                        ):
                            next_layer[key] = candidate
                        expanded += 1
        if not next_layer:
            raise RuntimeError(f"exact pilot search exhausted for {method.value}")
        retained += len(next_layer)
        layer = next_layer

    best_label = min(
        layer.values(),
        key=lambda label: (
            _finalize_metrics(problem, label).programmed_time_s,
            _finalize_metrics(problem, label).rapid_xy_length_mm,
            _finalize_metrics(problem, label).tool_event_count,
            _sequence_signature(label.actions),
        ),
    )
    metrics = _finalize_metrics(problem, best_label)
    audit = _audit_plan(problem, method, best_label.actions, metrics)
    return PilotPlan(
        method=method,
        actions=best_label.actions,
        metrics=metrics,
        audit=audit,
        expanded_labels=expanded,
        retained_labels=retained,
    )


def solve_repeated_2d_order(problem: PilotProblem) -> PilotPlan:
    if not problem.geometry_feasible:
        raise ValueError(
            f"pilot geometry is infeasible: {'; '.join(problem.geometry_issues)}"
        )
    remaining = set(range(len(problem.parts)))
    order: list[int] = []
    current = problem.template.start_point
    while remaining:
        part_index = min(
            remaining,
            key=lambda index: (
                min(
                    _distance(current, endpoint)
                    for endpoint in (
                        problem.parts[index].candidates[0].start,
                        problem.parts[index].candidates[0].end,
                    )
                ),
                problem.parts[index].part_id,
            ),
        )
        order.append(part_index)
        current = problem.parts[part_index].candidates[0].start
        remaining.remove(part_index)

    label = _Label(
        stages=(0,) * len(problem.parts),
        choices=(-1,) * len(problem.parts),
        current_point=problem.template.start_point,
        current_depth_mm=None,
        actions=(),
        metrics=PilotMetrics(),
    )
    expanded = 0
    for stage in range(3):
        for part_index in order:
            phase = _phase_for_stage(stage)
            variants = _action_variants(problem, part_index, phase, 0)
            candidates = tuple(
                _transition(problem, label, part_index, 0, action)
                for action in variants
            )
            label = min(candidates, key=_label_rank)
            expanded += len(candidates)

    metrics = _finalize_metrics(problem, label)
    method = PilotMethod.REPEATED_2D_ORDER
    return PilotPlan(
        method=method,
        actions=label.actions,
        metrics=metrics,
        audit=_audit_plan(problem, method, label.actions, metrics),
        expanded_labels=expanded,
        retained_labels=1,
    )


def solve_all_methods(problem: PilotProblem) -> tuple[PilotPlan, ...]:
    return tuple(
        solve_exact(problem, method)
        for method in (
            PilotMethod.REPEATED_2D_ORDER,
            PilotMethod.FIXED_TAB_ROUTE_OPTIMUM,
            PilotMethod.LAYER_FIRST_EXACT,
            PilotMethod.PART_LOCAL_RETAINED_EXACT,
            PilotMethod.CONTROLLED_RELEASE_EXACT,
            PilotMethod.EARLY_RELEASE_REFERENCE,
        )
    )
