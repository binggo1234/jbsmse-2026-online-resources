from __future__ import annotations

import argparse
import csv
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from statistics import mean, pstdev

from experiment_manifest import write_experiment_manifest
from progress_bar import TerminalProgressBar
from progress_log import prepare_progress_log
from process_options import (
    add_experiment_preset_arg,
    add_repeat_cut_policy_args,
    add_stability_model_args,
    add_tool_event_gate_args,
    apply_experiment_preset,
)
from run_chapter2_batch import (
    DEFAULT_ARCHIVES,
    BatchRouteRow,
    append_rows,
    batch_key,
    board_counts_from_zip,
    iter_case_rows,
    load_existing_rows,
    prepare_stream_output,
    sample_placement_members,
)
from run_final_chapter3_main import DEFAULT_TARGET_METHOD, ROOT


DEFAULT_OUTPUT_STEM = "chapter3_scalability_real_bins_hard_gate25"
DEFAULT_METHODS = (
    "topology_process_aware",
    "process_aware_beam",
    DEFAULT_TARGET_METHOD,
)


@dataclass(frozen=True)
class ScaleBin:
    name: str
    min_rectangles: int
    max_rectangles: int

    def contains(self, rectangle_count: int) -> bool:
        return self.min_rectangles <= rectangle_count <= self.max_rectangles


DEFAULT_SCALE_BINS = (
    ScaleBin("010_015", 10, 15),
    ScaleBin("016_020", 16, 20),
    ScaleBin("021_025", 21, 25),
    ScaleBin("026_030", 26, 30),
    ScaleBin("031_050", 31, 50),
)


@dataclass(frozen=True)
class ScaleCandidate:
    scale_bin: str
    archive: Path
    placements_member: str
    board_id: str
    rectangle_count: int


@dataclass(frozen=True)
class ScaleSummaryRow:
    scale_bin: str
    min_rectangles: int
    max_rectangles: int
    method: str
    n: int
    rectangle_count_mean: float
    rectangle_count_std: float
    candidate_unit_count_mean: float
    runtime_ms_mean: float
    runtime_ms_std: float
    runtime_ms_per_rectangle_mean: float
    air_move_distance_mean: float
    air_move_distance_std: float
    air_move_distance_per_rectangle_mean: float
    travel_mode_cost_mean: float
    travel_mode_cost_std: float
    travel_mode_cost_per_rectangle_mean: float
    hard_penalty_mean: float
    stability_penalty_mean: float
    cut_repeated_segment_count_mean: float
    cut_duplicate_segment_length_mean: float
    redundant_cut_action_count_mean: float
    safe_lift_count_mean: float
    detour_count_mean: float


def final_scalability_paths(
    results_dir: Path,
    output_stem: str | Path,
) -> tuple[Path, Path, Path, Path, Path]:
    base = Path(output_stem)
    if base.parent == Path("."):
        base = results_dir / base.name
    route_csv = base.with_suffix(".csv")
    summary_csv = base.with_name(f"{base.name}_summary.csv")
    selection_csv = base.with_name(f"{base.name}_selection.csv")
    progress_csv = base.with_name(f"{base.name}_progress.csv")
    manifest_json = base.with_name(f"{base.name}_manifest.json")
    return route_csv, summary_csv, selection_csv, progress_csv, manifest_json


def scale_bin_for_count(
    rectangle_count: int,
    bins: tuple[ScaleBin, ...] = DEFAULT_SCALE_BINS,
) -> ScaleBin | None:
    for bin_spec in bins:
        if bin_spec.contains(rectangle_count):
            return bin_spec
    return None


def discover_scale_candidates(
    archives: tuple[Path, ...],
    *,
    bins: tuple[ScaleBin, ...] = DEFAULT_SCALE_BINS,
    max_members_per_archive: int,
) -> tuple[ScaleCandidate, ...]:
    candidates: list[ScaleCandidate] = []
    for archive in archives:
        for member in sample_placement_members(archive, max_members_per_archive):
            for board_id, rectangle_count in board_counts_from_zip(archive, member).items():
                bin_spec = scale_bin_for_count(rectangle_count, bins)
                if bin_spec is None:
                    continue
                candidates.append(
                    ScaleCandidate(
                        scale_bin=bin_spec.name,
                        archive=archive,
                        placements_member=member,
                        board_id=board_id,
                        rectangle_count=rectangle_count,
                    )
                )
    return tuple(candidates)


def select_balanced_candidates(
    candidates: tuple[ScaleCandidate, ...],
    *,
    bins: tuple[ScaleBin, ...] = DEFAULT_SCALE_BINS,
    max_boards_per_bin: int,
) -> tuple[ScaleCandidate, ...]:
    grouped: dict[str, list[ScaleCandidate]] = defaultdict(list)
    for candidate in candidates:
        grouped[candidate.scale_bin].append(candidate)

    selected: list[ScaleCandidate] = []
    for bin_spec in bins:
        bin_candidates = sorted(
            grouped.get(bin_spec.name, ()),
            key=lambda item: (
                item.archive.name,
                item.placements_member.replace("\\", "/"),
                _board_sort_key(item.board_id),
            ),
        )
        unique_first: list[ScaleCandidate] = []
        duplicate_pool: list[ScaleCandidate] = []
        seen_layout_keys: set[tuple[str, str, int]] = set()
        for candidate in bin_candidates:
            layout_key = (
                candidate.archive.name,
                candidate.board_id,
                candidate.rectangle_count,
            )
            if layout_key in seen_layout_keys:
                duplicate_pool.append(candidate)
                continue
            seen_layout_keys.add(layout_key)
            unique_first.append(candidate)
        selected.extend((unique_first + duplicate_pool)[:max_boards_per_bin])
    return tuple(selected)


def write_candidate_selection(
    candidates: tuple[ScaleCandidate, ...],
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "scale_bin",
        "archive",
        "placements_member",
        "board_id",
        "rectangle_count",
    ]
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for candidate in candidates:
            writer.writerow(
                {
                    "scale_bin": candidate.scale_bin,
                    "archive": candidate.archive.name,
                    "placements_member": candidate.placements_member,
                    "board_id": candidate.board_id,
                    "rectangle_count": candidate.rectangle_count,
                }
            )


def summarize_scale_rows(
    rows: tuple[BatchRouteRow, ...],
    *,
    bins: tuple[ScaleBin, ...] = DEFAULT_SCALE_BINS,
) -> tuple[ScaleSummaryRow, ...]:
    grouped: dict[tuple[str, str], list[BatchRouteRow]] = defaultdict(list)
    bin_by_name = {bin_spec.name: bin_spec for bin_spec in bins}
    for row in rows:
        bin_spec = scale_bin_for_count(row.rectangle_count, bins)
        if bin_spec is None:
            continue
        grouped[(bin_spec.name, row.method)].append(row)

    summaries: list[ScaleSummaryRow] = []
    for bin_spec in bins:
        methods = sorted(method for scale_bin, method in grouped if scale_bin == bin_spec.name)
        for method in methods:
            items = grouped[(bin_spec.name, method)]
            rectangle_counts = [row.rectangle_count for row in items]
            runtime_values = [row.runtime_ms for row in items]
            air_values = [row.air_move_distance for row in items]
            travel_values = [row.travel_mode_cost for row in items]
            summaries.append(
                ScaleSummaryRow(
                    scale_bin=bin_spec.name,
                    min_rectangles=bin_by_name[bin_spec.name].min_rectangles,
                    max_rectangles=bin_by_name[bin_spec.name].max_rectangles,
                    method=method,
                    n=len(items),
                    rectangle_count_mean=mean(rectangle_counts),
                    rectangle_count_std=_pstdev(rectangle_counts),
                    candidate_unit_count_mean=mean(row.candidate_unit_count for row in items),
                    runtime_ms_mean=mean(runtime_values),
                    runtime_ms_std=_pstdev(runtime_values),
                    runtime_ms_per_rectangle_mean=mean(
                        row.runtime_ms / row.rectangle_count for row in items
                    ),
                    air_move_distance_mean=mean(air_values),
                    air_move_distance_std=_pstdev(air_values),
                    air_move_distance_per_rectangle_mean=mean(
                        row.air_move_distance / row.rectangle_count for row in items
                    ),
                    travel_mode_cost_mean=mean(travel_values),
                    travel_mode_cost_std=_pstdev(travel_values),
                    travel_mode_cost_per_rectangle_mean=mean(
                        row.travel_mode_cost / row.rectangle_count for row in items
                    ),
                    hard_penalty_mean=mean(row.hard_penalty for row in items),
                    stability_penalty_mean=mean(row.stability_penalty for row in items),
                    cut_repeated_segment_count_mean=mean(
                        row.cut_repeated_segment_count for row in items
                    ),
                    cut_duplicate_segment_length_mean=mean(
                        row.cut_duplicate_segment_length for row in items
                    ),
                    redundant_cut_action_count_mean=mean(
                        row.redundant_cut_action_count for row in items
                    ),
                    safe_lift_count_mean=mean(row.safe_lift_count for row in items),
                    detour_count_mean=mean(row.detour_count for row in items),
                )
            )
    return tuple(summaries)


def write_scale_summary(rows: tuple[ScaleSummaryRow, ...], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        output_path.write_text("", encoding="utf-8")
        return
    fieldnames = [field.name for field in fields(rows[0])]
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def filter_relevant_rows(
    rows: tuple[BatchRouteRow, ...],
    selected_candidates: tuple[ScaleCandidate, ...],
    methods: tuple[str, ...],
) -> tuple[BatchRouteRow, ...]:
    selected_keys = {
        (candidate.archive.name, candidate.placements_member, candidate.board_id)
        for candidate in selected_candidates
    }
    method_set = set(methods)
    return tuple(
        row
        for row in rows
        if (row.archive, row.placements_member, row.board_id) in selected_keys
        and row.method in method_set
    )


def print_candidate_summary(
    selected_candidates: tuple[ScaleCandidate, ...],
    bins: tuple[ScaleBin, ...],
) -> None:
    for bin_spec in bins:
        count = sum(1 for candidate in selected_candidates if candidate.scale_bin == bin_spec.name)
        print(
            f"selected: {bin_spec.name} "
            f"range={bin_spec.min_rectangles}-{bin_spec.max_rectangles} n={count}",
            flush=True,
        )


def print_scale_summary(rows: tuple[ScaleSummaryRow, ...]) -> None:
    for row in rows:
        print(
            f"{row.scale_bin:<7} {row.method:<38} n={row.n:<3} "
            f"rect={row.rectangle_count_mean:>5.2f} "
            f"runtime={row.runtime_ms_mean:>9.3f} ms "
            f"cost={row.travel_mode_cost_mean:>10.3f} "
            f"repeat={row.cut_repeated_segment_count_mean:>5.2f} "
            f"hard={row.hard_penalty_mean:>5.2f} "
            f"stability={row.stability_penalty_mean:>5.2f}",
            flush=True,
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the fixed Chapter 3 real-layout scalability experiment.",
    )
    parser.add_argument("--results-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--output-stem", default=DEFAULT_OUTPUT_STEM)
    parser.add_argument("--zip-path", type=Path, action="append", dest="zip_paths")
    parser.add_argument("--max-members-per-archive", type=int, default=55)
    parser.add_argument("--max-boards-per-bin", type=int, default=20)
    parser.add_argument(
        "--methods",
        nargs="+",
        default=list(DEFAULT_METHODS),
        choices=(
            "topology_process_aware",
            "process_aware_beam",
            "process_aware_beam_polished",
            DEFAULT_TARGET_METHOD,
        ),
    )
    parser.add_argument("--task-timeout-seconds", type=float, default=30.0)
    parser.add_argument(
        "--algorithm-seed",
        type=int,
        default=None,
        help=(
            "Random seed for stochastic routing methods. This matches "
            "run_chapter2_batch.py when scalability reuses its shared runner."
        ),
    )
    parser.add_argument("--fresh", action="store_true", help="Overwrite existing CSVs.")
    parser.add_argument("--progress-bar", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    add_experiment_preset_arg(parser)
    parser.set_defaults(experiment_preset="paper-main")
    add_stability_model_args(parser)
    add_tool_event_gate_args(parser)
    add_repeat_cut_policy_args(parser)
    return apply_experiment_preset(parser.parse_args())


def main() -> int:
    args = parse_args()
    archives = tuple(args.zip_paths or DEFAULT_ARCHIVES)
    methods = tuple(args.methods)
    route_csv, summary_csv, selection_csv, progress_csv, manifest_json = (
        final_scalability_paths(args.results_dir, args.output_stem)
    )
    all_candidates = discover_scale_candidates(
        archives,
        max_members_per_archive=args.max_members_per_archive,
    )
    selected_candidates = select_balanced_candidates(
        all_candidates,
        max_boards_per_bin=args.max_boards_per_bin,
    )
    if not selected_candidates:
        raise ValueError("no scale candidates found; relax bin or archive filters")

    print_candidate_summary(selected_candidates, DEFAULT_SCALE_BINS)
    if args.dry_run:
        print(f"selection -> {selection_csv}")
        print(f"routes -> {route_csv}")
        print(f"summary -> {summary_csv}")
        return 0

    write_candidate_selection(selected_candidates, selection_csv)
    progress_output = progress_csv
    existing_rows = load_existing_rows(route_csv) if not args.fresh else ()
    completed_keys = {batch_key(row) for row in existing_rows}
    prepare_stream_output(route_csv, resume=not args.fresh)
    prepare_progress_log(progress_output, resume=not args.fresh)
    rows: list[BatchRouteRow] = list(existing_rows)

    if existing_rows:
        print(f"resume: loaded {len(existing_rows)} existing rows from {route_csv}")

    progress_bar = TerminalProgressBar(
        len(selected_candidates) * len(methods),
        enabled=args.progress_bar,
    )
    progress_bar.start("scale method tasks")

    for candidate in selected_candidates:
        print(
            f"case: bin={candidate.scale_bin} archive={candidate.archive.name} "
            f"board={candidate.board_id} rectangles={candidate.rectangle_count}",
            flush=True,
        )
        for row in iter_case_rows(
            candidate.archive,
            candidate.placements_member,
            candidate.board_id,
            methods,
            args,
            completed_keys=completed_keys,
            progress_output=progress_output,
            task_timeout_seconds=args.task_timeout_seconds,
            progress_bar=progress_bar,
        ):
            append_rows((row,), route_csv)
            rows.append(row)
            completed_keys.add(batch_key(row))

    relevant_rows = filter_relevant_rows(tuple(rows), selected_candidates, methods)
    if not relevant_rows:
        raise ValueError("no route rows produced for selected scale candidates")
    summary_rows = summarize_scale_rows(relevant_rows)
    write_scale_summary(summary_rows, summary_csv)
    write_experiment_manifest(
        manifest_json,
        experiment_name="chapter3_real_layout_scalability",
        args=args,
        archives=archives,
        outputs=(route_csv, summary_csv, selection_csv, progress_output),
        root=ROOT,
        extra={
            "row_count": len(relevant_rows),
            "selected_candidate_count": len(selected_candidates),
            "methods": methods,
            "scale_bins": [asdict(bin_spec) for bin_spec in DEFAULT_SCALE_BINS],
        },
    )
    print(f"wrote: {route_csv}")
    print(f"wrote: {summary_csv}")
    print(f"wrote: {selection_csv}")
    print(f"wrote: {progress_output}")
    print(f"wrote: {manifest_json}")
    print_scale_summary(summary_rows)
    return 0


def _pstdev(values) -> float:
    values = list(values)
    return pstdev(values) if len(values) > 1 else 0.0


def _board_sort_key(value: str) -> tuple[int, float | str]:
    try:
        return (0, float(value))
    except ValueError:
        return (1, value)


if __name__ == "__main__":
    raise SystemExit(main())
