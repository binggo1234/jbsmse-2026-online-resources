from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
PROCESS_KEY_ROOT = (
    ROOT / "results" / "corrected_model_stage6_process_key_rerun" / "formal"
)
EVENT_GATE_ROOT = ROOT / "results" / "corrected_model_stage5_full_rerun" / "formal"

BLUE = "#0072B2"
ORANGE = "#E69F00"
GREEN = "#009E73"
GRAY = "#6B7280"


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def planning_cost(row: dict[str, str]) -> float:
    return float(row["cutting_length"]) + float(row["travel_mode_cost"])


def grouped_means(
    rows: list[dict[str, str]], key: str
) -> dict[str, dict[str, float]]:
    groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        groups[row[key]].append(row)
    return {
        name: {
            "cplan": mean(planning_cost(row) for row in group),
            "travel": mean(float(row["travel_mode_cost"]) for row in group),
        }
        for name, group in groups.items()
    }


def reduction(reference: float, value: float) -> float:
    return 100.0 * (reference - value) / reference


def add_bar_labels(
    ax: plt.Axes,
    bars,
    fmt: str = "{:.1f}",
    *,
    show_zero: bool = False,
) -> None:
    for bar in bars:
        value = bar.get_height()
        if abs(value) < 0.05 and not show_zero:
            continue
        ax.annotate(
            fmt.format(value),
            (bar.get_x() + bar.get_width() / 2.0, value),
            xytext=(0, 3),
            textcoords="offset points",
            ha="center",
            va="bottom",
            fontsize=6.7,
        )


def build_summary(args: argparse.Namespace) -> list[dict[str, object]]:
    search = grouped_means(read_rows(args.search_input), "method")
    topology = search["topology_process_aware"]
    method_order = (
        ("Topology", "topology_process_aware"),
        ("Beam", "process_aware_beam"),
        ("Beam+LS", "process_aware_beam_polished"),
        ("Final", "process_aware_beam_adaptive_polished"),
    )

    rows: list[dict[str, object]] = []
    for label, method in method_order:
        values = search[method]
        rows.append(
            {
                "panel": "search",
                "setting": label,
                "cplan_mean": values["cplan"],
                "travel_mean": values["travel"],
                "cplan_reduction_pct": reduction(topology["cplan"], values["cplan"]),
                "travel_reduction_pct": reduction(topology["travel"], values["travel"]),
            }
        )

    for row in read_rows(args.gate_input):
        rows.append(
            {
                "panel": "event_gate",
                "setting": row["strategy"],
                "cplan_reduction_pct": float(row["machining_cost_reduction_pct_mean"]),
                "travel_reduction_pct": float(row["travel_mode_cost_reduction_pct_mean"]),
                "tool_event_increase_count": int(row["tool_event_increase_count"]),
                "tool_event_delta_mean": float(row["tool_event_delta_mean"]),
            }
        )

    for policy, path in (
        ("Hard", args.repeat_hard_input),
        ("Soft", args.repeat_soft_input),
        ("Off", args.repeat_off_input),
    ):
        policy_rows = read_rows(path)
        rows.append(
            {
                "panel": "repeat_policy",
                "setting": policy,
                "cplan_mean": mean(planning_cost(row) for row in policy_rows),
                "repeated_spans_mean": mean(
                    float(row["process_repeated_span_count"]) for row in policy_rows
                ),
            }
        )
    return rows


def write_summary(rows: list[dict[str, object]], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({field for row in rows for field in row})
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def plot_summary(rows: list[dict[str, object]], output: Path) -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 8,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.linewidth": 0.8,
        }
    )
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.45), dpi=300)

    search = [row for row in rows if row["panel"] == "search"]
    x = list(range(len(search)))
    width = 0.36
    cplan_bars = axes[0].bar(
        [value - width / 2 for value in x],
        [float(row["cplan_reduction_pct"]) for row in search],
        width,
        color=BLUE,
        label=r"$C_{plan}$",
    )
    travel_bars = axes[0].bar(
        [value + width / 2 for value in x],
        [float(row["travel_reduction_pct"]) for row in search],
        width,
        color=ORANGE,
        label="Travel",
    )
    add_bar_labels(axes[0], cplan_bars)
    add_bar_labels(axes[0], travel_bars)
    axes[0].set_xticks(x, [str(row["setting"]) for row in search], rotation=22)
    axes[0].set_ylabel("Reduction vs topology (%)")
    axes[0].set_ylim(0, 23)
    axes[0].set_title("A  Search components", loc="left", fontweight="bold")
    axes[0].legend(frameon=False, loc="upper left")

    gates = [row for row in rows if row["panel"] == "event_gate"]
    gate_order = {"no_gate": 0, "fixed_100": 1, "current": 2, "strict": 3}
    gates.sort(key=lambda row: gate_order[str(row["setting"])])
    labels = [
        f"Off\n(+{int(gates[0]['tool_event_increase_count'])})",
        f"100\n(+{int(gates[1]['tool_event_increase_count'])})",
        f"25\n(+{int(gates[2]['tool_event_increase_count'])})",
        f"Strict\n(+{int(gates[3]['tool_event_increase_count'])})",
    ]
    x = list(range(len(gates)))
    cplan_bars = axes[1].bar(
        [value - width / 2 for value in x],
        [float(row["cplan_reduction_pct"]) for row in gates],
        width,
        color=BLUE,
        label=r"$C_{plan}$",
    )
    travel_bars = axes[1].bar(
        [value + width / 2 for value in x],
        [float(row["travel_reduction_pct"]) for row in gates],
        width,
        color=ORANGE,
        label="Travel",
    )
    add_bar_labels(axes[1], cplan_bars, "{:.2f}")
    add_bar_labels(axes[1], travel_bars, "{:.2f}")
    axes[1].set_xticks(x, labels)
    axes[1].set_ylabel("Reduction vs beam (%)")
    axes[1].set_ylim(0, 4.9)
    axes[1].set_title("B  Event-Gate safeguard", loc="left", fontweight="bold")

    repeat = [row for row in rows if row["panel"] == "repeat_policy"]
    repeat_order = {"Hard": 0, "Soft": 1, "Off": 2}
    repeat.sort(key=lambda row: repeat_order[str(row["setting"])])
    x = list(range(len(repeat)))
    repeated_bars = axes[2].bar(
        x,
        [float(row["repeated_spans_mean"]) for row in repeat],
        0.55,
        color=GREEN,
        label="Repeated spans",
    )
    add_bar_labels(axes[2], repeated_bars, "{:.1f}", show_zero=True)
    axes[2].set_xticks(x, [str(row["setting"]) for row in repeat])
    axes[2].set_ylabel("Repeated spans (mean)", color=GREEN)
    axes[2].tick_params(axis="y", labelcolor=GREEN)
    axes[2].set_ylim(0, 52)
    twin = axes[2].twinx()
    twin.plot(
        x,
        [float(row["cplan_mean"]) / 1000.0 for row in repeat],
        color=BLUE,
        marker="o",
        linewidth=1.4,
        label=r"$C_{plan}$",
    )
    for index, row in enumerate(repeat):
        offset = (7, 0) if index < 2 else (-7, 0)
        twin.annotate(
            f"{float(row['cplan_mean']) / 1000.0:.1f}",
            (index, float(row["cplan_mean"]) / 1000.0),
            xytext=offset,
            textcoords="offset points",
            ha="left" if index < 2 else "right",
            va="center",
            fontsize=6.7,
            color=BLUE,
        )
    twin.set_ylabel(r"Mean $C_{plan}$ ($\times 10^3$)", color=BLUE)
    twin.tick_params(axis="y", labelcolor=BLUE)
    twin.set_ylim(34, 47)
    axes[2].set_title("C  Repeat-cut policy", loc="left", fontweight="bold")

    for ax in axes:
        ax.spines["top"].set_visible(False)
        ax.grid(axis="y", color="#D1D5DB", linewidth=0.5, alpha=0.6)
        ax.set_axisbelow(True)
    twin.spines["top"].set_visible(False)

    fig.tight_layout(w_pad=1.2)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, bbox_inches="tight")
    fig.savefig(output.with_suffix(".png"), bbox_inches="tight")
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--search-input",
        type=Path,
        default=PROCESS_KEY_ROOT
        / "chapter3_formal_hard_gate25_ablation_search_components_hard_gate25.csv",
    )
    parser.add_argument(
        "--gate-input",
        type=Path,
        default=EVENT_GATE_ROOT
        / "chapter3_formal_hard_gate25_event_gate_sensitivity_summary.csv",
    )
    for policy in ("hard", "soft", "off"):
        parser.add_argument(
            f"--repeat-{policy}-input",
            type=Path,
            default=PROCESS_KEY_ROOT
            / f"chapter3_formal_hard_gate25_ablation_repeat_policy_{policy}.csv",
        )
    parser.add_argument(
        "--figure-output",
        type=Path,
        default=ROOT
        / "figures"
        / "corrected_model_stage6_process_key_rerun"
        / "formal"
        / "fig_ablation_effects.pdf",
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=ROOT
        / "results"
        / "corrected_model_stage6_process_key_rerun"
        / "paper_tables"
        / "corrected_ablation_figure_metrics.csv",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = build_summary(args)
    write_summary(rows, args.summary_output)
    plot_summary(rows, args.figure_output)
    print(f"summary: {args.summary_output}")
    print(f"figure: {args.figure_output}")


if __name__ == "__main__":
    main()
