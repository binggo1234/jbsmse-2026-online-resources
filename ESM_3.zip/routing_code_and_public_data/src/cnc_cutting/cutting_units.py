from __future__ import annotations

from .geometry import compensated_rectangle_edges
from .models import (
    BoundaryRelation,
    BoundaryRelationType,
    CuttingUnit,
    CuttingUnitType,
    EdgeSegment,
    Layout,
    Point,
    SegmentSpan,
    ToolConfig,
)
from .spans import (
    all_bounds,
    axis_bounds,
    build_segment_spans,
    fixed_coordinate,
    layout_edges_relations_and_spans,
    overlap_bounds,
    point_from_axis,
    span_segment_ids,
    spans_for_segment_interval,
)


def _unit_id_for_span(segment: EdgeSegment, span: SegmentSpan) -> str:
    segment_lo, segment_hi = axis_bounds(segment)
    if (
        abs(span.start_axis - segment_lo) <= 1e-6
        and abs(span.end_axis - segment_hi) <= 1e-6
    ):
        return f"single:{segment.segment_id}"
    return f"single:{span.span_id}"


def _span_points_for_segment(
    segment: EdgeSegment,
    span: SegmentSpan,
    trajectory_segment: EdgeSegment | None = None,
    tolerance: float = 1e-6,
) -> tuple[Point, Point]:
    trajectory = trajectory_segment or segment
    fixed = fixed_coordinate(trajectory)
    nominal_lo, nominal_hi = axis_bounds(segment)
    trajectory_lo, trajectory_hi = axis_bounds(trajectory)
    mapped_lo = (
        trajectory_lo
        if abs(span.start_axis - nominal_lo) <= tolerance
        else span.start_axis
    )
    mapped_hi = (
        trajectory_hi
        if abs(span.end_axis - nominal_hi) <= tolerance
        else span.end_axis
    )
    if segment.orientation.value == "horizontal":
        forward = trajectory.start.x <= trajectory.end.x
    else:
        forward = trajectory.start.y <= trajectory.end.y
    start_axis, end_axis = (
        (mapped_lo, mapped_hi)
        if forward
        else (mapped_hi, mapped_lo)
    )
    return (
        point_from_axis(segment.orientation, fixed, start_axis),
        point_from_axis(segment.orientation, fixed, end_axis),
    )


def primitive_cutting_units(
    segments: tuple[EdgeSegment, ...],
    spans_by_segment: dict[str, tuple[SegmentSpan, ...]] | None = None,
    trajectory_segments_by_id: dict[str, EdgeSegment] | None = None,
) -> tuple[CuttingUnit, ...]:
    if spans_by_segment is None:
        spans_by_segment = build_segment_spans(segments)

    units: list[CuttingUnit] = []
    for segment in segments:
        for span in spans_by_segment.get(segment.segment_id, ()):
            trajectory_segment = (
                trajectory_segments_by_id.get(segment.segment_id)
                if trajectory_segments_by_id is not None
                else None
            )
            start, end = _span_points_for_segment(
                segment,
                span,
                trajectory_segment=trajectory_segment,
            )
            units.append(
                CuttingUnit(
                    unit_id=_unit_id_for_span(segment, span),
                    unit_type=CuttingUnitType.SINGLE_EDGE,
                    segments=(segment,),
                    start=start,
                    end=end,
                    covered_segment_ids=(segment.segment_id,),
                    covered_spans=(span,),
                )
            )
    return tuple(units)


def relation_cutting_unit(
    relation: BoundaryRelation,
    spans_by_segment: dict[str, tuple[SegmentSpan, ...]] | None = None,
    nominal_segments_by_id: dict[str, EdgeSegment] | None = None,
    tolerance: float = 1e-6,
) -> CuttingUnit | None:
    first = relation.first
    second = relation.second
    if spans_by_segment is None:
        spans_by_segment = build_segment_spans((first, second), (relation,), tolerance)
    nominal_first = (
        nominal_segments_by_id.get(first.segment_id, first)
        if nominal_segments_by_id is not None
        else first
    )
    nominal_second = (
        nominal_segments_by_id.get(second.segment_id, second)
        if nominal_segments_by_id is not None
        else second
    )
    segments = tuple(
        sorted(
            (nominal_first, nominal_second),
            key=lambda segment: (axis_bounds(segment)[0], segment.segment_id),
        )
    )
    relation_key = f"{relation.relation_type.value}:{first.segment_id}|{second.segment_id}"

    if relation.relation_type == BoundaryRelationType.SHARED_EDGE:
        lo, hi = overlap_bounds(first, second)
        if hi - lo <= tolerance:
            return None
        fixed_axis = fixed_coordinate(first)
        unit_type = CuttingUnitType.SHARED_EDGE
        requires_bridge_cut = False
    elif relation.relation_type == BoundaryRelationType.NEAR_SHARED_EDGE:
        lo, hi = overlap_bounds(first, second)
        if hi - lo <= tolerance:
            return None
        fixed_axis = (fixed_coordinate(first) + fixed_coordinate(second)) / 2.0
        unit_type = CuttingUnitType.NEAR_SHARED_CHANNEL
        requires_bridge_cut = False
    elif relation.relation_type == BoundaryRelationType.COLLINEAR_EDGE:
        lo, hi = all_bounds((first, second))
        fixed_axis = fixed_coordinate(first)
        unit_type = CuttingUnitType.COLLINEAR_CHAIN
        requires_bridge_cut = relation.axial_gap > tolerance
    else:
        return None

    covered_spans = tuple(
        span
        for segment in segments
        for span in spans_for_segment_interval(
            spans_by_segment,
            segment,
            max(lo, axis_bounds(segment)[0]),
            min(hi, axis_bounds(segment)[1]),
            tolerance=tolerance,
        )
    )
    if not covered_spans:
        return None

    return CuttingUnit(
        unit_id=relation_key,
        unit_type=unit_type,
        segments=segments,
        start=point_from_axis(first.orientation, fixed_axis, lo),
        end=point_from_axis(first.orientation, fixed_axis, hi),
        relation_types=(relation.relation_type,),
        covered_segment_ids=span_segment_ids(covered_spans),
        covered_spans=covered_spans,
        requires_bridge_cut=requires_bridge_cut,
    )


def relation_cutting_units(
    relations: tuple[BoundaryRelation, ...],
    spans_by_segment: dict[str, tuple[SegmentSpan, ...]] | None = None,
    nominal_segments_by_id: dict[str, EdgeSegment] | None = None,
    tolerance: float = 1e-6,
) -> tuple[CuttingUnit, ...]:
    units: list[CuttingUnit] = []
    seen_unit_ids: set[str] = set()
    for relation in relations:
        unit = relation_cutting_unit(
            relation,
            spans_by_segment=spans_by_segment,
            nominal_segments_by_id=nominal_segments_by_id,
            tolerance=tolerance,
        )
        if unit is None or unit.unit_id in seen_unit_ids:
            continue
        units.append(unit)
        seen_unit_ids.add(unit.unit_id)
    return tuple(units)


def build_candidate_cutting_units(
    layout: Layout,
    tool: ToolConfig,
    max_collinear_gap: float = float("inf"),
    tolerance: float = 1e-6,
) -> tuple[CuttingUnit, ...]:
    segments, relations, spans_by_segment = layout_edges_relations_and_spans(
        layout,
        tool,
        max_collinear_gap=max_collinear_gap,
        tolerance=tolerance,
    )
    nominal_segments_by_id = {segment.segment_id: segment for segment in segments}
    trajectory_segments_by_id = None
    if tool.geometric_kerf_compensation:
        trajectory_segments_by_id = {
            segment.segment_id: segment
            for rectangle in layout.rectangles
            for segment in compensated_rectangle_edges(rectangle, tool.tool_radius)
        }
    return primitive_cutting_units(
        segments,
        spans_by_segment=spans_by_segment,
        trajectory_segments_by_id=trajectory_segments_by_id,
    ) + relation_cutting_units(
        relations,
        spans_by_segment=spans_by_segment,
        nominal_segments_by_id=nominal_segments_by_id,
        tolerance=tolerance,
    )
