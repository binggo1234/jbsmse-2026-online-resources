from __future__ import annotations

from dataclasses import dataclass
from math import inf

from .geometry import euclidean_distance
from .models import CuttingUnit, Point
from .topology_operators import DirectedUnitCandidate


ContourOption = tuple[DirectedUnitCandidate, ...]
ContourOptions = dict[str, tuple[ContourOption, ...]]


@dataclass(frozen=True)
class EndpointAwareGTSPConfig:
    max_iterations: int = 6
    max_neighbors_per_iteration: int = 400

    def __post_init__(self) -> None:
        if self.max_iterations < 0:
            raise ValueError("max_iterations must be non-negative")
        if self.max_neighbors_per_iteration <= 0:
            raise ValueError("max_neighbors_per_iteration must be positive")


@dataclass(frozen=True)
class EndpointAwareGTSPResult:
    part_order: tuple[str, ...]
    directed_units: tuple[DirectedUnitCandidate, ...]
    travel_distance: float
    evaluated_neighbors: int
    accepted_moves: int


def _option_key(option: ContourOption) -> tuple:
    return tuple(
        (candidate.unit.unit_id, candidate.is_reversed) for candidate in option
    )


def _best_options_for_order(
    part_order: tuple[str, ...],
    contour_options: ContourOptions,
    start_point: Point,
) -> tuple[tuple[ContourOption, ...], float]:
    if not part_order:
        return (), 0.0

    first_options = contour_options[part_order[0]]
    costs = [
        euclidean_distance(start_point, option[0].start)
        for option in first_options
    ]
    parents: list[list[int]] = []

    for previous_part_id, part_id in zip(part_order, part_order[1:]):
        previous_options = contour_options[previous_part_id]
        current_options = contour_options[part_id]
        next_costs: list[float] = []
        current_parents: list[int] = []
        for current_option in current_options:
            best_cost = inf
            best_parent = 0
            for previous_index, previous_option in enumerate(previous_options):
                transition_cost = euclidean_distance(
                    previous_option[-1].end,
                    current_option[0].start,
                )
                candidate_cost = costs[previous_index] + transition_cost
                if (
                    candidate_cost < best_cost - 1e-9
                    or (
                        abs(candidate_cost - best_cost) <= 1e-9
                        and _option_key(previous_option)
                        < _option_key(previous_options[best_parent])
                    )
                ):
                    best_cost = candidate_cost
                    best_parent = previous_index
            next_costs.append(best_cost)
            current_parents.append(best_parent)
        costs = next_costs
        parents.append(current_parents)

    final_options = contour_options[part_order[-1]]
    final_index = min(
        range(len(final_options)),
        key=lambda index: (costs[index], _option_key(final_options[index])),
    )
    selected_indices = [final_index]
    for current_parents in reversed(parents):
        selected_indices.append(current_parents[selected_indices[-1]])
    selected_indices.reverse()
    selected_options = tuple(
        contour_options[part_id][option_index]
        for part_id, option_index in zip(part_order, selected_indices)
    )
    return selected_options, costs[final_index]


def _nearest_endpoint_order(
    contour_options: ContourOptions,
    start_point: Point,
) -> tuple[str, ...]:
    remaining = set(contour_options)
    current_point = start_point
    ordered: list[str] = []
    while remaining:
        part_id, option = min(
            (
                (part_id, option)
                for part_id in remaining
                for option in contour_options[part_id]
            ),
            key=lambda item: (
                euclidean_distance(current_point, item[1][0].start),
                item[0],
                _option_key(item[1]),
            ),
        )
        ordered.append(part_id)
        current_point = option[-1].end
        remaining.remove(part_id)
    return tuple(ordered)


def _candidate_orders(
    order: tuple[str, ...],
    max_neighbors: int,
) -> tuple[tuple[str, ...], ...]:
    neighbors: list[tuple[str, ...]] = []
    seen: set[tuple[str, ...]] = set()

    for left in range(len(order) - 1):
        for right in range(left + 1, len(order)):
            candidate = (
                order[:left]
                + tuple(reversed(order[left : right + 1]))
                + order[right + 1 :]
            )
            if candidate not in seen:
                neighbors.append(candidate)
                seen.add(candidate)
            if len(neighbors) >= max_neighbors:
                return tuple(neighbors)

    for source in range(len(order)):
        part_id = order[source]
        reduced = order[:source] + order[source + 1 :]
        for destination in range(len(order)):
            candidate = (
                reduced[:destination]
                + (part_id,)
                + reduced[destination:]
            )
            if candidate == order or candidate in seen:
                continue
            neighbors.append(candidate)
            seen.add(candidate)
            if len(neighbors) >= max_neighbors:
                return tuple(neighbors)
    return tuple(neighbors)


def endpoint_aware_gtsp_order(
    contour_options: ContourOptions,
    start_point: Point,
    config: EndpointAwareGTSPConfig | None = None,
) -> EndpointAwareGTSPResult:
    """Jointly optimize contour order, entry corner, and cutting direction.

    The generalized routing clusters are part contours. Each cluster contains
    all executable corner/direction options, and dynamic programming chooses
    the globally best option sequence for every tested contour permutation.
    """

    if config is None:
        config = EndpointAwareGTSPConfig()
    if not contour_options:
        return EndpointAwareGTSPResult((), (), 0.0, 0, 0)
    if any(not options for options in contour_options.values()):
        raise ValueError("every contour cluster must contain at least one option")

    best_order = _nearest_endpoint_order(contour_options, start_point)
    best_options, best_distance = _best_options_for_order(
        best_order,
        contour_options,
        start_point,
    )
    evaluated_neighbors = 0
    accepted_moves = 0

    for _ in range(config.max_iterations):
        improving_order: tuple[str, ...] | None = None
        improving_options: tuple[ContourOption, ...] | None = None
        improving_distance = best_distance
        for candidate_order in _candidate_orders(
            best_order,
            config.max_neighbors_per_iteration,
        ):
            candidate_options, candidate_distance = _best_options_for_order(
                candidate_order,
                contour_options,
                start_point,
            )
            evaluated_neighbors += 1
            if (
                candidate_distance < improving_distance - 1e-9
                or (
                    abs(candidate_distance - improving_distance) <= 1e-9
                    and improving_order is not None
                    and candidate_order < improving_order
                )
            ):
                improving_order = candidate_order
                improving_options = candidate_options
                improving_distance = candidate_distance
        if improving_order is None or improving_options is None:
            break
        best_order = improving_order
        best_options = improving_options
        best_distance = improving_distance
        accepted_moves += 1

    return EndpointAwareGTSPResult(
        part_order=best_order,
        directed_units=tuple(
            candidate
            for option in best_options
            for candidate in option
        ),
        travel_distance=best_distance,
        evaluated_neighbors=evaluated_neighbors,
        accepted_moves=accepted_moves,
    )
