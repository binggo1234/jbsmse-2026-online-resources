from __future__ import annotations

from dataclasses import dataclass
from math import floor
from time import perf_counter

from .geometry import euclidean_distance
from .models import CuttingUnit, Point
from .topology_operators import DirectedUnitCandidate, directed_unit_candidates


@dataclass(frozen=True)
class StaticRoutingLowerBoundResult:
    optimality_proven: bool
    termination_reason: str
    travel_distance_lower_bound: float
    directed_units: tuple[DirectedUnitCandidate, ...]
    runtime_seconds: float


def _scaled_distance(first: Point, second: Point, scale: int) -> int:
    return floor(euclidean_distance(first, second) * scale + 1e-9)


def exact_static_routing_lower_bound(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
    *,
    timeout_seconds: float | None = None,
    distance_scale: int = 1_000_000,
) -> StaticRoutingLowerBoundResult:
    """Solve a static oriented-unit routing relaxation exactly with CP-SAT.

    Released-part obstacles, support-state transitions, and tool-event costs are
    omitted. The resulting travel distance is therefore a valid lower bound for
    the full state-dependent process-routing problem.
    """

    start_time = perf_counter()
    if distance_scale <= 0:
        raise ValueError("distance_scale must be positive")
    if not units:
        return StaticRoutingLowerBoundResult(
            optimality_proven=True,
            termination_reason="complete",
            travel_distance_lower_bound=0.0,
            directed_units=(),
            runtime_seconds=perf_counter() - start_time,
        )

    try:
        from ortools.sat.python import cp_model
    except ImportError as exc:
        raise RuntimeError(
            "OR-Tools is required for the certified static routing lower bound; "
            "install the project 'exact' optional dependency"
        ) from exc

    directed_by_unit = tuple(directed_unit_candidates(unit) for unit in units)
    candidates = tuple(
        candidate
        for unit_candidates in directed_by_unit
        for candidate in unit_candidates
    )
    unit_index_by_node: dict[int, int] = {}
    candidate_by_node: dict[int, DirectedUnitCandidate] = {}
    nodes_by_unit: list[list[int]] = [[] for _ in units]
    node = 1
    for unit_index, unit_candidates in enumerate(directed_by_unit):
        for candidate in unit_candidates:
            unit_index_by_node[node] = unit_index
            candidate_by_node[node] = candidate
            nodes_by_unit[unit_index].append(node)
            node += 1

    model = cp_model.CpModel()
    selected = {
        candidate_node: model.NewBoolVar(f"selected_{candidate_node}")
        for candidate_node in candidate_by_node
    }
    for unit_nodes in nodes_by_unit:
        model.Add(sum(selected[candidate_node] for candidate_node in unit_nodes) == 1)

    arcs: list[tuple[int, int, object]] = []
    arc_variables: dict[tuple[int, int], object] = {}
    objective_terms: list[object] = []

    for candidate_node, candidate in candidate_by_node.items():
        self_loop = selected[candidate_node].Not()
        arcs.append((candidate_node, candidate_node, self_loop))

        start_arc = model.NewBoolVar(f"arc_0_{candidate_node}")
        arcs.append((0, candidate_node, start_arc))
        arc_variables[(0, candidate_node)] = start_arc
        objective_terms.append(
            _scaled_distance(start_point, candidate.start, distance_scale) * start_arc
        )

        end_arc = model.NewBoolVar(f"arc_{candidate_node}_0")
        arcs.append((candidate_node, 0, end_arc))
        arc_variables[(candidate_node, 0)] = end_arc

    candidate_nodes = tuple(candidate_by_node)
    for source_node in candidate_nodes:
        source = candidate_by_node[source_node]
        source_unit_index = unit_index_by_node[source_node]
        for destination_node in candidate_nodes:
            if (
                source_node == destination_node
                or source_unit_index == unit_index_by_node[destination_node]
            ):
                continue
            destination = candidate_by_node[destination_node]
            arc = model.NewBoolVar(f"arc_{source_node}_{destination_node}")
            arcs.append((source_node, destination_node, arc))
            arc_variables[(source_node, destination_node)] = arc
            objective_terms.append(
                _scaled_distance(
                    source.end,
                    destination.start,
                    distance_scale,
                )
                * arc
            )

    model.AddCircuit(arcs)
    model.Minimize(sum(objective_terms))

    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 0
    if timeout_seconds is not None:
        solver.parameters.max_time_in_seconds = timeout_seconds
    status = solver.Solve(model)
    runtime_seconds = perf_counter() - start_time
    if status != cp_model.OPTIMAL:
        reason = "timeout" if status == cp_model.FEASIBLE else "not_solved"
        return StaticRoutingLowerBoundResult(
            optimality_proven=False,
            termination_reason=reason,
            travel_distance_lower_bound=0.0,
            directed_units=(),
            runtime_seconds=runtime_seconds,
        )

    ordered: list[DirectedUnitCandidate] = []
    current_node = 0
    while True:
        next_nodes = [
            destination
            for (source, destination), variable in arc_variables.items()
            if source == current_node and solver.BooleanValue(variable)
        ]
        if len(next_nodes) != 1:
            raise AssertionError("exact static route must have one selected successor")
        next_node = next_nodes[0]
        if next_node == 0:
            break
        ordered.append(candidate_by_node[next_node])
        current_node = next_node

    return StaticRoutingLowerBoundResult(
        optimality_proven=True,
        termination_reason="complete",
        travel_distance_lower_bound=solver.ObjectiveValue() / distance_scale,
        directed_units=tuple(ordered),
        runtime_seconds=runtime_seconds,
    )
