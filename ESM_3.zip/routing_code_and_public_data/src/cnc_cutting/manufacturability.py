from __future__ import annotations

from dataclasses import dataclass

from .geometry import expand_rectangle, segment_crosses_axis_aligned_rectangle_interior
from .models import CuttingUnit, EdgeOrientation, EdgeRole, Layout, PlacedRectangle
from .spans import axis_bounds


@dataclass(frozen=True)
class ManufacturabilityViolation:
    violation_type: str
    cutting_unit_id: str
    part_id: str
    span_id: str = ""


def expected_centerline_fixed_coordinate(
    rectangle: PlacedRectangle,
    role: EdgeRole,
    tool_radius: float,
) -> float:
    if role == EdgeRole.BOTTOM:
        return rectangle.min_y - tool_radius
    if role == EdgeRole.TOP:
        return rectangle.max_y + tool_radius
    if role == EdgeRole.LEFT:
        return rectangle.min_x - tool_radius
    return rectangle.max_x + tool_radius


def finished_dimension_violations(
    unit: CuttingUnit,
    rectangles_by_id: dict[str, PlacedRectangle],
    tool_radius: float,
    tolerance: float = 1e-6,
) -> tuple[ManufacturabilityViolation, ...]:
    if abs(unit.start.y - unit.end.y) <= tolerance:
        orientation = EdgeOrientation.HORIZONTAL
        fixed_coordinate = unit.start.y
        trajectory_bounds = sorted((unit.start.x, unit.end.x))
    elif abs(unit.start.x - unit.end.x) <= tolerance:
        orientation = EdgeOrientation.VERTICAL
        fixed_coordinate = unit.start.x
        trajectory_bounds = sorted((unit.start.y, unit.end.y))
    else:
        return (
            ManufacturabilityViolation(
                "non_axis_aligned_cut",
                unit.unit_id,
                "",
            ),
        )

    violations: list[ManufacturabilityViolation] = []
    for span in unit.covered_spans:
        rectangle = rectangles_by_id[span.part_id]
        expected_fixed = expected_centerline_fixed_coordinate(
            rectangle,
            span.role,
            tool_radius,
        )
        if span.orientation != orientation or abs(fixed_coordinate - expected_fixed) > tolerance:
            violations.append(
                ManufacturabilityViolation(
                    "incorrect_centerline_offset",
                    unit.unit_id,
                    span.part_id,
                    span.span_id,
                )
            )
            continue
        if (
            trajectory_bounds[0] > span.start_axis + tolerance
            or trajectory_bounds[1] < span.end_axis - tolerance
        ):
            violations.append(
                ManufacturabilityViolation(
                    "centerline_does_not_cover_nominal_span",
                    unit.unit_id,
                    span.part_id,
                    span.span_id,
                )
            )
    return tuple(violations)


def swept_disk_no_gouge_violations(
    unit: CuttingUnit,
    layout: Layout,
    tool_radius: float,
) -> tuple[ManufacturabilityViolation, ...]:
    violations: list[ManufacturabilityViolation] = []
    for rectangle in layout.rectangles:
        expanded = expand_rectangle(rectangle, tool_radius)
        bounds = (expanded.min_x, expanded.min_y, expanded.max_x, expanded.max_y)
        if segment_crosses_axis_aligned_rectangle_interior(
            unit.start,
            unit.end,
            bounds,
        ):
            violations.append(
                ManufacturabilityViolation(
                    "swept_disk_gouges_nominal_part",
                    unit.unit_id,
                    rectangle.part_id,
                )
            )
    return tuple(violations)


def audit_cutting_units(
    units: tuple[CuttingUnit, ...],
    layout: Layout,
    tool_radius: float,
) -> tuple[ManufacturabilityViolation, ...]:
    rectangles_by_id = {
        rectangle.part_id: rectangle for rectangle in layout.rectangles
    }
    violations: list[ManufacturabilityViolation] = []
    for unit in units:
        violations.extend(
            finished_dimension_violations(
                unit,
                rectangles_by_id,
                tool_radius,
            )
        )
        violations.extend(swept_disk_no_gouge_violations(unit, layout, tool_radius))
    return tuple(violations)
