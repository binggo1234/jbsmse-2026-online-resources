from __future__ import annotations

from collections.abc import Iterable

from .geometry import expand_rectangle, rectangle_corners, rectangle_edges
from .models import (
    BoundaryRelationType,
    CuttingProcessModel,
    EdgeRole,
    Layout,
    ToolConfig,
)
from .relations import detect_boundary_relations
from .spans import layout_edges_relations_and_spans


def build_process_model(
    layout: Layout,
    tool: ToolConfig | None = None,
    support_edge_role: EdgeRole | None = EdgeRole.TOP,
    support_edge_roles: Iterable[EdgeRole] | None = None,
    min_remaining_support_count: int = 1,
    min_remaining_support_length_ratio: float = 0.0,
    min_area_normalized_support_length: float = 0.0,
    adjacency_support_weight: float = 0.0,
    max_collinear_gap: float = float("inf"),
    tolerance: float = 1e-6,
) -> CuttingProcessModel:
    if tool is None:
        tool = ToolConfig()
    if support_edge_roles is None:
        support_roles = () if support_edge_role is None else (support_edge_role,)
    else:
        support_roles = tuple(dict.fromkeys(support_edge_roles))

    part_segment_ids: dict[str, frozenset[str]] = {}
    segment_part_ids: dict[str, str] = {}
    part_polygons = {
        rectangle.part_id: rectangle_corners(rectangle)
        for rectangle in layout.rectangles
    }
    part_collision_polygons = {
        rectangle.part_id: rectangle_corners(
            expand_rectangle(rectangle, tool.tool_radius)
            if tool.geometric_kerf_compensation
            else rectangle
        )
        for rectangle in layout.rectangles
    }
    _, _, spans_by_segment = layout_edges_relations_and_spans(
        layout,
        tool,
        max_collinear_gap=max_collinear_gap,
        tolerance=tolerance,
    )
    support_segment_ids: dict[str, frozenset[str]] = {}
    part_span_ids: dict[str, frozenset[str]] = {}
    segment_span_ids: dict[str, frozenset[str]] = {}
    span_part_ids: dict[str, str] = {}
    span_segment_ids: dict[str, str] = {}
    support_span_ids: dict[str, frozenset[str]] = {}
    segment_lengths: dict[str, float] = {}
    span_lengths: dict[str, float] = {}
    part_areas: dict[str, float] = {}
    part_support_lengths: dict[str, float] = {}
    all_edges = []

    for rectangle in layout.rectangles:
        edges = rectangle_edges(rectangle)
        all_edges.extend(edges)
        part_segment_ids[rectangle.part_id] = frozenset(
            edge.segment_id for edge in edges
        )
        rectangle_span_ids: list[str] = []
        part_areas[rectangle.part_id] = rectangle.width * rectangle.height
        for edge in edges:
            segment_part_ids[edge.segment_id] = rectangle.part_id
            segment_lengths[edge.segment_id] = edge.length
            edge_spans = spans_by_segment.get(edge.segment_id, ())
            segment_span_ids[edge.segment_id] = frozenset(
                span.span_id for span in edge_spans
            )
            for span in edge_spans:
                rectangle_span_ids.append(span.span_id)
                span_part_ids[span.span_id] = rectangle.part_id
                span_segment_ids[span.span_id] = edge.segment_id
                span_lengths[span.span_id] = span.length
        part_span_ids[rectangle.part_id] = frozenset(rectangle_span_ids)
        if support_roles:
            support_ids = frozenset(
                edge.segment_id
                for edge in edges
                if edge.role in support_roles
            )
            support_spans = frozenset(
                span.span_id
                for edge in edges
                if edge.role in support_roles
                for span in spans_by_segment.get(edge.segment_id, ())
            )
            support_segment_ids[rectangle.part_id] = support_ids
            support_span_ids[rectangle.part_id] = support_spans
            part_support_lengths[rectangle.part_id] = sum(
                span_lengths[span_id] for span_id in support_spans
            )

    adjacency_support_lengths = build_adjacency_support_lengths(
        tuple(all_edges),
        min_channel_width=(
            tool.min_channel_width if tool.geometric_kerf_compensation else 0.0
        ),
        include_near_shared=tool.geometric_kerf_compensation,
    )

    return CuttingProcessModel(
        part_segment_ids=part_segment_ids,
        segment_part_ids=segment_part_ids,
        part_polygons=part_polygons,
        part_collision_polygons=part_collision_polygons,
        part_span_ids=part_span_ids,
        segment_span_ids=segment_span_ids,
        span_part_ids=span_part_ids,
        span_segment_ids=span_segment_ids,
        support_segment_ids=support_segment_ids,
        support_span_ids=support_span_ids,
        segment_lengths=segment_lengths,
        span_lengths=span_lengths,
        part_areas=part_areas,
        part_support_lengths=part_support_lengths,
        part_adjacency_support_lengths=adjacency_support_lengths,
        adjacency_support_weight=adjacency_support_weight,
        min_remaining_support_count=min_remaining_support_count,
        min_remaining_support_length_ratio=min_remaining_support_length_ratio,
        min_area_normalized_support_length=min_area_normalized_support_length,
    )


def build_adjacency_support_lengths(
    edges,
    min_channel_width: float = 0.0,
    include_near_shared: bool = False,
) -> dict[str, dict[str, float]]:
    adjacency: dict[str, dict[str, float]] = {}
    relations = detect_boundary_relations(
        edges,
        min_channel_width=min_channel_width,
        max_collinear_gap=0.0,
    )
    for relation in relations:
        accepted_relation_types = {BoundaryRelationType.SHARED_EDGE}
        if include_near_shared:
            accepted_relation_types.add(BoundaryRelationType.NEAR_SHARED_EDGE)
        if relation.relation_type not in accepted_relation_types:
            continue
        first_part = relation.first.part_id
        second_part = relation.second.part_id
        if first_part == second_part:
            continue
        adjacency.setdefault(first_part, {})[second_part] = (
            adjacency.setdefault(first_part, {}).get(second_part, 0.0)
            + relation.overlap_length
        )
        adjacency.setdefault(second_part, {})[first_part] = (
            adjacency.setdefault(second_part, {}).get(first_part, 0.0)
            + relation.overlap_length
        )
    return adjacency
