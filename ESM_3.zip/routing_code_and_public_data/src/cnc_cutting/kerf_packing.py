from __future__ import annotations

from dataclasses import dataclass, field
import random


TOLERANCE = 1e-9


@dataclass(frozen=True)
class KerfPackingPart:
    part_id: str
    raw_part_id: str
    nominal_width: float
    nominal_height: float
    envelope_width: float
    envelope_height: float


@dataclass(frozen=True)
class PackingRectangle:
    x: float
    y: float
    width: float
    height: float

    @property
    def max_x(self) -> float:
        return self.x + self.width

    @property
    def max_y(self) -> float:
        return self.y + self.height


@dataclass(frozen=True)
class PackedPart:
    part: KerfPackingPart
    envelope: PackingRectangle
    rotated: bool


@dataclass
class PackedBoard:
    board_id: int
    panel_width: float
    panel_height: float
    trim: float
    placed: list[PackedPart] = field(default_factory=list)
    free_rectangles: list[PackingRectangle] = field(default_factory=list)


def _contains(outer: PackingRectangle, inner: PackingRectangle) -> bool:
    return (
        inner.x >= outer.x - TOLERANCE
        and inner.y >= outer.y - TOLERANCE
        and inner.max_x <= outer.max_x + TOLERANCE
        and inner.max_y <= outer.max_y + TOLERANCE
    )


def _intersects(first: PackingRectangle, second: PackingRectangle) -> bool:
    return not (
        second.x >= first.max_x - TOLERANCE
        or second.max_x <= first.x + TOLERANCE
        or second.y >= first.max_y - TOLERANCE
        or second.max_y <= first.y + TOLERANCE
    )


def _split_free_rectangle(
    free_rectangle: PackingRectangle,
    used: PackingRectangle,
) -> list[PackingRectangle]:
    if not _intersects(free_rectangle, used):
        return [free_rectangle]
    candidates = [
        PackingRectangle(
            free_rectangle.x,
            free_rectangle.y,
            used.x - free_rectangle.x,
            free_rectangle.height,
        ),
        PackingRectangle(
            used.max_x,
            free_rectangle.y,
            free_rectangle.max_x - used.max_x,
            free_rectangle.height,
        ),
        PackingRectangle(
            free_rectangle.x,
            free_rectangle.y,
            free_rectangle.width,
            used.y - free_rectangle.y,
        ),
        PackingRectangle(
            free_rectangle.x,
            used.max_y,
            free_rectangle.width,
            free_rectangle.max_y - used.max_y,
        ),
    ]
    return [
        rectangle
        for rectangle in candidates
        if rectangle.width > TOLERANCE and rectangle.height > TOLERANCE
    ]


def _prune_free_rectangles(
    rectangles: list[PackingRectangle],
) -> list[PackingRectangle]:
    return [
        rectangle
        for index, rectangle in enumerate(rectangles)
        if not any(
            index != other_index and _contains(other, rectangle)
            for other_index, other in enumerate(rectangles)
        )
    ]


def _new_board(
    board_id: int,
    panel_width: float,
    panel_height: float,
    trim: float,
) -> PackedBoard:
    usable_width = panel_width - 2.0 * trim
    usable_height = panel_height - 2.0 * trim
    if usable_width <= 0.0 or usable_height <= 0.0:
        raise ValueError("trim leaves no usable board area")
    return PackedBoard(
        board_id=board_id,
        panel_width=panel_width,
        panel_height=panel_height,
        trim=trim,
        free_rectangles=[
            PackingRectangle(trim, trim, usable_width, usable_height)
        ],
    )


def _orientations(
    part: KerfPackingPart,
    allow_rotation: bool,
) -> tuple[tuple[float, float, bool], ...]:
    base = ((part.envelope_width, part.envelope_height, False),)
    if (
        not allow_rotation
        or abs(part.envelope_width - part.envelope_height) <= TOLERANCE
    ):
        return base
    return base + ((part.envelope_height, part.envelope_width, True),)


def _place_part(
    board: PackedBoard,
    part: KerfPackingPart,
    allow_rotation: bool,
) -> bool:
    best = None
    for free_rectangle in board.free_rectangles:
        for width, height, rotated in _orientations(part, allow_rotation):
            if (
                width > free_rectangle.width + TOLERANCE
                or height > free_rectangle.height + TOLERANCE
            ):
                continue
            candidate = PackingRectangle(
                free_rectangle.x,
                free_rectangle.y,
                width,
                height,
            )
            area_fit = (
                free_rectangle.width * free_rectangle.height - width * height
            )
            remaining_width = max(0.0, free_rectangle.width - width)
            remaining_height = max(0.0, free_rectangle.height - height)
            key = (
                area_fit,
                min(remaining_width, remaining_height),
                max(remaining_width, remaining_height),
                free_rectangle.y,
                free_rectangle.x,
                int(rotated),
            )
            if best is None or key < best[0]:
                best = (key, candidate, rotated)
    if best is None:
        return False

    _, used, rotated = best
    board.placed.append(PackedPart(part=part, envelope=used, rotated=rotated))
    split_rectangles: list[PackingRectangle] = []
    for free_rectangle in board.free_rectangles:
        split_rectangles.extend(_split_free_rectangle(free_rectangle, used))
    board.free_rectangles = _prune_free_rectangles(split_rectangles)
    return True


def pack_kerf_envelopes(
    parts: tuple[KerfPackingPart, ...],
    panel_width: float,
    panel_height: float,
    trim: float,
    allow_rotation: bool = True,
    order_seed: int | None = None,
    order_top_k: int = 1,
) -> tuple[PackedBoard, ...]:
    """Pack all tool-inflated envelopes with deterministic MaxRects BAF."""

    if not parts:
        return ()
    ranked = sorted(
        parts,
        key=lambda part: (
            -max(part.envelope_width, part.envelope_height),
            -(part.envelope_width * part.envelope_height),
            part.part_id,
        ),
    )
    if order_top_k <= 0:
        raise ValueError("order_top_k must be positive")
    if order_seed is None or order_top_k == 1:
        ordered = ranked
    else:
        generator = random.Random(order_seed)
        pool = list(ranked)
        ordered = []
        while pool:
            selected_index = generator.randrange(min(order_top_k, len(pool)))
            ordered.append(pool.pop(selected_index))
    remaining = ordered
    boards: list[PackedBoard] = []
    while remaining:
        board = _new_board(
            len(boards) + 1,
            panel_width,
            panel_height,
            trim,
        )
        next_remaining = [
            part
            for part in remaining
            if not _place_part(board, part, allow_rotation)
        ]
        if not board.placed:
            raise ValueError(
                f"part {remaining[0].part_id} does not fit the trimmed stock"
            )
        boards.append(board)
        remaining = next_remaining
    return tuple(boards)


def select_formal_board(
    boards: tuple[PackedBoard, ...],
    minimum_parts: int = 20,
    maximum_parts: int = 50,
) -> PackedBoard:
    eligible = [
        board
        for board in boards
        if minimum_parts <= len(board.placed) <= maximum_parts
    ]
    if not eligible:
        raise ValueError(
            f"no packed board contains {minimum_parts}--{maximum_parts} parts"
        )
    return max(
        eligible,
        key=lambda board: (
            len(board.placed),
            sum(
                packed.part.nominal_width * packed.part.nominal_height
                for packed in board.placed
            ),
            -board.board_id,
        ),
    )
