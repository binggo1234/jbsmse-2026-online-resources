from __future__ import annotations

import random
from dataclasses import dataclass, replace

from .exact_dp import ExactDPConfig, exact_process_dp_order
from .geometry import direction_vector, euclidean_distance
from .gtsp_baseline import EndpointAwareGTSPConfig, endpoint_aware_gtsp_order
from .local_search import (
    BeamSearchConfig,
    DEFAULT_REPEAT_CUT_POLICY,
    GeneticAlgorithmConfig,
    LocalSearchConfig,
    PrefixBeamMCTSConfig,
    SimulatedAnnealingConfig,
    improve_directed_unit_order,
    path_distance_local_search_order,
    process_aware_genetic_order,
    process_aware_prefix_beam_mcts_order,
    process_aware_simulated_annealing_order,
    process_local_search_multistart_order,
    process_aware_beam_search_order,
    process_aware_beam_polished_search_order,
    process_metric_key,
    process_aware_unit_order,
    topology_local_search_order,
    validate_repeat_cut_policy,
)
from .metrics import evaluate_actions, materialize_action_clearance
from .models import (
    CuttingAction,
    CuttingActionType,
    CuttingProcessModel,
    CuttingUnit,
    CuttingUnitType,
    Panel,
    PathMetrics,
    Point,
    ToolConfig,
)
from .topology_operators import TopologyWeights, topology_aware_unit_actions
from .topology_operators import DirectedUnitCandidate, directed_units_to_actions


@dataclass(frozen=True)
class RoutePlan:
    selected_units: tuple[CuttingUnit, ...]
    actions: tuple[CuttingAction, ...]
    metrics: PathMetrics


MIN_TRAVEL_COST_SAVING_PER_EXTRA_TOOL_EVENT = 25.0
MIN_TRAVEL_COST_SAVING_RATIO_PER_EXTRA_TOOL_EVENT = 0.0
MIN_MACHINING_COST_SAVING_FOR_EXTRA_TOOL_EVENT = 1e-9


@dataclass(frozen=True)
class ToolEventGateConfig:
    enabled: bool = True
    min_travel_saving_per_extra_event: float = (
        MIN_TRAVEL_COST_SAVING_PER_EXTRA_TOOL_EVENT
    )
    min_travel_saving_ratio_per_extra_event: float = (
        MIN_TRAVEL_COST_SAVING_RATIO_PER_EXTRA_TOOL_EVENT
    )
    min_machining_saving: float = MIN_MACHINING_COST_SAVING_FOR_EXTRA_TOOL_EVENT

    def __post_init__(self) -> None:
        if self.min_travel_saving_per_extra_event < 0.0:
            raise ValueError("min_travel_saving_per_extra_event must be non-negative")
        if self.min_travel_saving_ratio_per_extra_event < 0.0:
            raise ValueError("min_travel_saving_ratio_per_extra_event must be non-negative")
        if self.min_machining_saving < 0.0:
            raise ValueError("min_machining_saving must be non-negative")


DEFAULT_TOOL_EVENT_GATE_CONFIG = ToolEventGateConfig()


def _tool_event_count(metrics: PathMetrics) -> int:
    return metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count


def _tool_event_increase_justified(
    candidate: PathMetrics,
    alternative: PathMetrics,
    tool_event_gate: ToolEventGateConfig = DEFAULT_TOOL_EVENT_GATE_CONFIG,
) -> bool:
    if not tool_event_gate.enabled:
        return True

    extra_events = _tool_event_count(candidate) - _tool_event_count(alternative)
    if extra_events <= 0:
        return True

    travel_saving = alternative.travel_mode_cost - candidate.travel_mode_cost
    machining_saving = alternative.machining_cost - candidate.machining_cost
    required_saving_per_event = max(
        tool_event_gate.min_travel_saving_per_extra_event,
        alternative.travel_mode_cost
        * tool_event_gate.min_travel_saving_ratio_per_extra_event,
    )
    return (
        machining_saving > tool_event_gate.min_machining_saving
        and travel_saving >= required_saving_per_event * extra_events
    )


def _resolved_repeat_cut_policy(
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
    *configs,
) -> str:
    for config in configs:
        if config is not None and hasattr(config, "repeat_cut_policy"):
            return validate_repeat_cut_policy(config.repeat_cut_policy)
    return validate_repeat_cut_policy(repeat_cut_policy)


def _local_search_config_with_policy(
    config: LocalSearchConfig | None,
    repeat_cut_policy: str,
) -> LocalSearchConfig:
    if config is not None:
        return config
    return LocalSearchConfig(repeat_cut_policy=repeat_cut_policy)


def _beam_search_config_with_policy(
    config: BeamSearchConfig | None,
    repeat_cut_policy: str,
) -> BeamSearchConfig:
    if config is not None:
        return config
    return BeamSearchConfig(repeat_cut_policy=repeat_cut_policy)


def _prefix_beam_mcts_config_with_policy(
    config: PrefixBeamMCTSConfig | None,
    repeat_cut_policy: str,
) -> PrefixBeamMCTSConfig:
    if config is not None:
        return config
    return PrefixBeamMCTSConfig(repeat_cut_policy=repeat_cut_policy)


def _exact_dp_config_with_policy(
    config: ExactDPConfig | None,
    repeat_cut_policy: str,
) -> ExactDPConfig:
    if config is not None:
        return config
    return ExactDPConfig(repeat_cut_policy=repeat_cut_policy)


def _route_passes_tool_event_gate(
    candidate: RoutePlan,
    alternatives: tuple[RoutePlan, ...],
    tool_event_gate: ToolEventGateConfig = DEFAULT_TOOL_EVENT_GATE_CONFIG,
) -> bool:
    return all(
        _tool_event_increase_justified(
            candidate.metrics,
            alternative.metrics,
            tool_event_gate=tool_event_gate,
        )
        for alternative in alternatives
        if alternative is not candidate
    )


def wider_beam_search_config(config: BeamSearchConfig | None = None) -> BeamSearchConfig:
    """Return the wider beam setting used for failure-risk fallback cases."""

    if config is None:
        config = BeamSearchConfig()

    wide_width = config.beam_width + 2
    candidate_pool_size = (
        None if config.candidate_pool_size is None else config.candidate_pool_size + 6
    )
    max_expansions_per_node = (
        None
        if config.max_expansions_per_node is None
        else config.max_expansions_per_node + 12
    )
    max_layer_expansions = (
        None if config.max_layer_expansions is None else wide_width * 7
    )
    return replace(
        config,
        beam_width=wide_width,
        candidate_pool_size=candidate_pool_size,
        max_expansions_per_node=max_expansions_per_node,
        max_layer_expansions=max_layer_expansions,
    )


def _best_process_route(
    plans: tuple[RoutePlan, ...],
    protected_plans: tuple[RoutePlan, ...] = (),
    tool_event_gate: ToolEventGateConfig = DEFAULT_TOOL_EVENT_GATE_CONFIG,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    if not plans:
        raise ValueError("at least one route plan is required")

    protected_plan_ids = {id(plan) for plan in protected_plans}
    gated_plans = tuple(
        plan
        for plan in plans
        if id(plan) in protected_plan_ids
        or _route_passes_tool_event_gate(plan, plans, tool_event_gate=tool_event_gate)
    )
    if not gated_plans:
        gated_plans = plans
    return min(
        gated_plans,
        key=lambda plan: process_metric_key(
            plan.metrics,
            repeat_cut_policy=repeat_cut_policy,
        ),
    )


def _beam_fallback_needed(
    beam_plan: RoutePlan,
    reference_plan: RoutePlan,
    margin: float,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> bool:
    if process_metric_key(
        beam_plan.metrics,
        repeat_cut_policy=repeat_cut_policy,
    ) >= process_metric_key(
        reference_plan.metrics,
        repeat_cut_policy=repeat_cut_policy,
    ):
        return True
    return (beam_plan.metrics.travel_mode_cost - reference_plan.metrics.travel_mode_cost) > -margin


def _route_from_search_result(
    selected_units: tuple[CuttingUnit, ...],
    result,
) -> RoutePlan:
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def _polish_beam_route(
    selected_units: tuple[CuttingUnit, ...],
    beam_result,
    panel: Panel,
    tool: ToolConfig,
    polish_config: LocalSearchConfig | None,
    process_model: CuttingProcessModel | None,
) -> RoutePlan:
    if not beam_result.directed_units:
        return _route_from_search_result(selected_units, beam_result)
    if polish_config is None:
        polish_config = LocalSearchConfig(
            max_iterations=2,
            first_improvement=True,
            max_swap_span=6,
            max_relocate_span=6,
            max_two_opt_span=6,
            max_neighbors_per_iteration=160,
            process_aware_initial_order=True,
        )
    polished = improve_directed_unit_order(
        beam_result.directed_units,
        panel,
        tool,
        config=polish_config,
        process_model=process_model,
    )
    return _route_from_search_result(selected_units, polished)


def _unit_priority(unit: CuttingUnit) -> tuple[int, int, float, str]:
    type_priority = {
        CuttingUnitType.SHARED_EDGE: 0,
        CuttingUnitType.NEAR_SHARED_CHANNEL: 1,
        CuttingUnitType.COLLINEAR_CHAIN: 2,
        CuttingUnitType.SINGLE_EDGE: 3,
    }[unit.unit_type]
    return (
        type_priority,
        -len(_unit_coverage_ids(unit)),
        euclidean_distance(unit.start, unit.end),
        unit.unit_id,
    )


def _unit_coverage_ids(unit: CuttingUnit) -> tuple[str, ...]:
    if unit.covered_spans:
        return tuple(span.span_id for span in unit.covered_spans)
    return unit.covered_segment_ids


def _unit_repeated_length(
    unit: CuttingUnit,
    repeated_ids: set[str],
) -> float:
    if unit.covered_spans:
        return sum(span.length for span in unit.covered_spans if span.span_id in repeated_ids)
    return sum(
        segment.length
        for segment in unit.segments
        if segment.segment_id in repeated_ids
    )


def _dynamic_unit_priority(
    unit: CuttingUnit,
    covered_ids: set[str],
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple[int, float, int, int, float, str]:
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    unit_ids = set(_unit_coverage_ids(unit))
    new_ids = unit_ids - covered_ids
    repeated_ids = unit_ids & covered_ids
    static_priority = _unit_priority(unit)
    repeated_length = _unit_repeated_length(unit, repeated_ids)
    if repeat_cut_policy == "soft":
        return (
            static_priority[0],
            len(repeated_ids),
            repeated_length,
            -len(new_ids),
            static_priority[2],
            static_priority[3],
        )
    return (
        len(repeated_ids),
        repeated_length,
        -len(new_ids),
        static_priority[0],
        static_priority[2],
        static_priority[3],
    )


def select_coverage_units(
    units: tuple[CuttingUnit, ...],
    allow_bridge_cut: bool = False,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple[CuttingUnit, ...]:
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    selected: list[CuttingUnit] = []
    covered_ids: set[str] = set()
    remaining = [
        unit
        for unit in units
        if allow_bridge_cut or not unit.requires_bridge_cut
    ]

    if repeat_cut_policy == "off":
        for unit in sorted(remaining, key=_unit_priority):
            unit_ids = set(_unit_coverage_ids(unit))
            if not unit_ids or unit_ids <= covered_ids:
                continue
            selected.append(unit)
            covered_ids.update(unit_ids)
        return tuple(selected)

    while True:
        candidates = [
            unit
            for unit in remaining
            if set(_unit_coverage_ids(unit)) - covered_ids
        ]
        if not candidates:
            break
        unit = min(
            candidates,
            key=lambda candidate: _dynamic_unit_priority(
                candidate,
                covered_ids,
                repeat_cut_policy=repeat_cut_policy,
            ),
        )
        selected.append(unit)
        covered_ids.update(_unit_coverage_ids(unit))
        remaining.remove(unit)

    return tuple(selected)


def _directed_unit_points(
    unit: CuttingUnit,
    current_point: Point,
) -> tuple[Point, Point]:
    forward_distance = euclidean_distance(current_point, unit.start)
    reverse_distance = euclidean_distance(current_point, unit.end)
    if unit.is_reversible and reverse_distance < forward_distance:
        return (unit.end, unit.start)
    return (unit.start, unit.end)


def _unit_segment_id(unit: CuttingUnit) -> str | None:
    if len(unit.covered_segment_ids) == 1:
        return unit.covered_segment_ids[0]
    return None


def greedy_unit_actions(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
) -> tuple[CuttingAction, ...]:
    remaining = list(units)
    current_point = start_point
    actions: list[CuttingAction] = []

    while remaining:
        unit = min(
            remaining,
            key=lambda candidate: min(
                euclidean_distance(current_point, candidate.start),
                euclidean_distance(current_point, candidate.end)
                if candidate.is_reversible
                else float("inf"),
            ),
        )
        entry, exit_point = _directed_unit_points(unit, current_point)
        if euclidean_distance(current_point, entry) > 1e-9:
            actions.append(
                CuttingAction(
                    action_type=CuttingActionType.TRAVEL,
                    start=current_point,
                    end=entry,
                    cutting_unit_id=unit.unit_id,
                    covered_segment_ids=unit.covered_segment_ids,
                    covered_spans=unit.covered_spans,
                )
            )
        actions.append(
            CuttingAction(
                action_type=CuttingActionType.CUT,
                start=entry,
                end=exit_point,
                segment_id=_unit_segment_id(unit),
                cutting_unit_id=unit.unit_id,
                covered_segment_ids=unit.covered_segment_ids,
                covered_spans=unit.covered_spans,
            )
        )
        current_point = exit_point
        remaining.remove(unit)

    return tuple(actions)


CONTOUR_ROLE_ORDER = (
    "bottom",
    "right",
    "top",
    "left",
)


def _primitive_contour_units(units: tuple[CuttingUnit, ...]) -> tuple[CuttingUnit, ...]:
    return tuple(
        unit
        for unit in units
        if unit.unit_type == CuttingUnitType.SINGLE_EDGE
        and len(unit.segments) == 1
        and len(unit.covered_segment_ids) == 1
    )


def _part_center(units: tuple[CuttingUnit, ...]) -> Point:
    points = tuple(
        point
        for unit in units
        for segment in unit.segments
        for point in (segment.start, segment.end)
    )
    return Point(
        (min(point.x for point in points) + max(point.x for point in points)) / 2.0,
        (min(point.y for point in points) + max(point.y for point in points)) / 2.0,
    )


def _contour_path_length(
    ordered_parts: tuple[tuple[str, tuple[CuttingUnit, ...]], ...],
    start_point: Point,
) -> float:
    if not ordered_parts:
        return 0.0
    current = start_point
    total = 0.0
    for _, part_units in ordered_parts:
        center = _part_center(part_units)
        total += euclidean_distance(current, center)
        current = center
    return total


def _two_opt_contour_order(
    ordered_parts: tuple[tuple[str, tuple[CuttingUnit, ...]], ...],
    start_point: Point,
) -> tuple[tuple[str, tuple[CuttingUnit, ...]], ...]:
    if len(ordered_parts) < 4:
        return ordered_parts

    best = ordered_parts
    best_length = _contour_path_length(best, start_point)
    improved = True
    while improved:
        improved = False
        for left in range(len(best) - 1):
            for right in range(left + 1, len(best)):
                candidate = (
                    best[:left]
                    + tuple(reversed(best[left : right + 1]))
                    + best[right + 1 :]
                )
                candidate_length = _contour_path_length(candidate, start_point)
                if candidate_length + 1e-9 < best_length:
                    best = candidate
                    best_length = candidate_length
                    improved = True
                    break
            if improved:
                break
    return best


def _nearest_contour_order(
    grouped_units: dict[str, tuple[CuttingUnit, ...]],
    start_point: Point,
) -> tuple[tuple[str, tuple[CuttingUnit, ...]], ...]:
    remaining = sorted(grouped_units.items(), key=lambda item: item[0])
    current = start_point
    ordered: list[tuple[str, tuple[CuttingUnit, ...]]] = []
    while remaining:
        index, (part_id, part_units) = min(
            enumerate(remaining),
            key=lambda item: (
                euclidean_distance(current, _part_center(item[1][1])),
                item[1][0],
            ),
        )
        ordered.append((part_id, part_units))
        current = _part_center(part_units)
        remaining.pop(index)
    return _two_opt_contour_order(tuple(ordered), start_point)


def _aco_contour_order(
    grouped_units: dict[str, tuple[CuttingUnit, ...]],
    start_point: Point,
    *,
    ant_count: int | None = None,
    iterations: int = 48,
    alpha: float = 1.0,
    beta: float = 2.0,
    evaporation: float = 0.35,
    seed: int = 20260531,
) -> tuple[tuple[str, tuple[CuttingUnit, ...]], ...]:
    ordered_parts = tuple(sorted(grouped_units.items(), key=lambda item: item[0]))
    part_count = len(ordered_parts)
    if part_count < 3:
        return _nearest_contour_order(grouped_units, start_point)

    if ant_count is None:
        ant_count = min(max(part_count, 12), 32)
    ant_count = max(1, ant_count)
    iterations = max(1, iterations)
    evaporation = min(max(evaporation, 0.0), 0.95)

    centers = tuple(_part_center(part_units) for _, part_units in ordered_parts)
    start_node = part_count
    pheromone = [[1.0 for _ in range(part_count)] for _ in range(part_count + 1)]
    rng = random.Random(seed)

    def distance_from(current_index: int, candidate_index: int) -> float:
        current = start_point if current_index == start_node else centers[current_index]
        return euclidean_distance(current, centers[candidate_index])

    def route_from_indices(
        indices: tuple[int, ...],
    ) -> tuple[tuple[str, tuple[CuttingUnit, ...]], ...]:
        return tuple(ordered_parts[index] for index in indices)

    def route_length(indices: tuple[int, ...]) -> float:
        return _contour_path_length(route_from_indices(indices), start_point)

    def weighted_choice(
        current_index: int,
        remaining_indices: tuple[int, ...],
    ) -> int:
        weights: list[tuple[int, float]] = []
        for candidate_index in remaining_indices:
            distance = distance_from(current_index, candidate_index)
            heuristic = 1.0 / max(distance, 1e-9)
            weight = (pheromone[current_index][candidate_index] ** alpha) * (
                heuristic**beta
            )
            weights.append((candidate_index, weight))
        total_weight = sum(weight for _, weight in weights)
        if total_weight <= 0.0:
            return min(remaining_indices)
        threshold = rng.random() * total_weight
        running = 0.0
        for candidate_index, weight in weights:
            running += weight
            if running >= threshold:
                return candidate_index
        return weights[-1][0]

    nearest = _nearest_contour_order(grouped_units, start_point)
    best_indices = tuple(ordered_parts.index(part) for part in nearest)
    best_length = route_length(best_indices)

    for _ in range(iterations):
        iteration_routes: list[tuple[tuple[int, ...], float]] = []
        for _ in range(ant_count):
            remaining = tuple(range(part_count))
            current_index = start_node
            route: list[int] = []
            while remaining:
                next_index = weighted_choice(current_index, remaining)
                route.append(next_index)
                current_index = next_index
                remaining = tuple(index for index in remaining if index != next_index)

            route_indices = tuple(route)
            length = route_length(route_indices)
            iteration_routes.append((route_indices, length))
            if length + 1e-9 < best_length:
                best_indices = route_indices
                best_length = length

        for row in pheromone:
            for index, value in enumerate(row):
                row[index] = max(value * (1.0 - evaporation), 1e-9)

        for route_indices, length in iteration_routes:
            deposit = 1.0 / max(length, 1e-9)
            current_index = start_node
            for next_index in route_indices:
                pheromone[current_index][next_index] += deposit
                current_index = next_index

    return route_from_indices(best_indices)


def _directed_unit(
    unit: CuttingUnit,
    reversed_direction: bool = False,
) -> DirectedUnitCandidate:
    if reversed_direction:
        start = unit.end
        end = unit.start
    else:
        start = unit.start
        end = unit.end
    return DirectedUnitCandidate(
        unit=unit,
        start=start,
        end=end,
        direction=direction_vector(start, end),
        is_reversed=reversed_direction,
    )


def _clockwise_contour_options(
    part_units: tuple[CuttingUnit, ...],
) -> tuple[tuple[DirectedUnitCandidate, ...], ...]:
    role_units = {
        unit.segments[0].role.value: unit
        for unit in part_units
        if len(unit.segments) == 1
    }
    if not all(role in role_units for role in CONTOUR_ROLE_ORDER):
        return ()

    options: list[tuple[DirectedUnitCandidate, ...]] = []
    role_count = len(CONTOUR_ROLE_ORDER)
    for start_index in range(role_count):
        clockwise_roles = tuple(
            CONTOUR_ROLE_ORDER[(start_index + offset) % role_count]
            for offset in range(role_count)
        )
        options.append(
            tuple(_directed_unit(role_units[role]) for role in clockwise_roles)
        )

        counter_clockwise_roles = tuple(
            CONTOUR_ROLE_ORDER[(start_index - offset) % role_count]
            for offset in range(role_count)
        )
        options.append(
            tuple(
                _directed_unit(role_units[role], reversed_direction=True)
                for role in counter_clockwise_roles
            )
        )
    return tuple(options)


def _greedy_part_unit_option(
    part_units: tuple[CuttingUnit, ...],
    current_point: Point,
) -> tuple[DirectedUnitCandidate, ...]:
    remaining = list(part_units)
    directed: list[DirectedUnitCandidate] = []
    current = current_point
    while remaining:
        unit = min(
            remaining,
            key=lambda candidate: min(
                euclidean_distance(current, candidate.start),
                euclidean_distance(current, candidate.end)
                if candidate.is_reversible
                else float("inf"),
            ),
        )
        reversed_direction = (
            unit.is_reversible
            and euclidean_distance(current, unit.end)
            < euclidean_distance(current, unit.start)
        )
        directed_unit = _directed_unit(unit, reversed_direction=reversed_direction)
        directed.append(directed_unit)
        current = directed_unit.end
        remaining.remove(unit)
    return tuple(directed)


def _group_primitive_contour_units(
    units: tuple[CuttingUnit, ...],
) -> dict[str, tuple[CuttingUnit, ...]]:
    grouped: dict[str, list[CuttingUnit]] = {}
    for unit in _primitive_contour_units(units):
        grouped.setdefault(unit.segments[0].part_id, []).append(unit)
    return {
        part_id: tuple(sorted(part_units, key=lambda unit: unit.segments[0].role.value))
        for part_id, part_units in grouped.items()
    }


def _directed_units_for_contour_order(
    ordered_parts: tuple[tuple[str, tuple[CuttingUnit, ...]], ...],
    start_point: Point,
) -> tuple[DirectedUnitCandidate, ...]:
    current = start_point
    directed_units: list[DirectedUnitCandidate] = []
    for _, part_units in ordered_parts:
        options = _clockwise_contour_options(part_units)
        if not options:
            best_option = _greedy_part_unit_option(part_units, current)
        else:
            best_option = min(
                options,
                key=lambda option: (
                    euclidean_distance(current, option[0].start),
                    option[0].unit.unit_id,
                    option[0].is_reversed,
                ),
            )
        directed_units.extend(best_option)
        current = best_option[-1].end
    return tuple(directed_units)


def contour_tsp_2opt_directed_units(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
) -> tuple[DirectedUnitCandidate, ...]:
    """Return a contour-sequencing baseline over primitive part contours.

    This intentionally ignores shared/near-shared/collinear composite units and
    process-state priorities. It represents a literature-style external baseline:
    sequence independent part contours by nearest-neighbor plus 2-opt, then cut
    each contour continuously from the nearest feasible corner.
    """

    ordered_groups = _group_primitive_contour_units(units)
    return _directed_units_for_contour_order(
        _nearest_contour_order(ordered_groups, start_point),
        start_point,
    )


def contour_aco_directed_units(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
    seed: int = 20260531,
) -> tuple[DirectedUnitCandidate, ...]:
    """Return an ACO-style contour-sequencing external baseline.

    The baseline keeps the same independent primitive-contour execution model as
    the TSP+2-opt contour baseline, but sequences contours with a deterministic
    ant-colony search over part centers.
    """

    ordered_groups = _group_primitive_contour_units(units)
    return _directed_units_for_contour_order(
        _aco_contour_order(ordered_groups, start_point, seed=seed),
        start_point,
    )


def endpoint_aware_gtsp_directed_units(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
    config: EndpointAwareGTSPConfig | None = None,
) -> tuple[DirectedUnitCandidate, ...]:
    """Return an endpoint-aware generalized contour-routing baseline.

    Each primitive part contour is a GTSP cluster whose states represent the
    four entry corners and two cutting directions. Dynamic programming selects
    the best state sequence for every tested contour order, while deterministic
    2-opt and relocate neighborhoods improve the contour permutation.
    """

    grouped = _group_primitive_contour_units(units)
    contour_options = {
        part_id: _clockwise_contour_options(part_units)
        for part_id, part_units in grouped.items()
    }
    if any(not options for options in contour_options.values()):
        raise ValueError(
            "endpoint-aware GTSP requires four-edge rectangular part contours"
        )
    return endpoint_aware_gtsp_order(
        contour_options,
        start_point,
        config=config,
    ).directed_units


def contour_tsp_2opt_unit_actions(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
) -> tuple[CuttingAction, ...]:
    return directed_units_to_actions(
        contour_tsp_2opt_directed_units(units, start_point),
        start_point=start_point,
    )


def contour_aco_unit_actions(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
    seed: int = 20260531,
) -> tuple[CuttingAction, ...]:
    return directed_units_to_actions(
        contour_aco_directed_units(units, start_point, seed=seed),
        start_point=start_point,
    )


def endpoint_aware_gtsp_unit_actions(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
    config: EndpointAwareGTSPConfig | None = None,
) -> tuple[CuttingAction, ...]:
    return directed_units_to_actions(
        endpoint_aware_gtsp_directed_units(
            units,
            start_point,
            config=config,
        ),
        start_point=start_point,
    )


def plan_greedy_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    actions = materialize_action_clearance(
        greedy_unit_actions(selected_units, tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=actions,
        metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
    )


def plan_contour_tsp_2opt_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
) -> RoutePlan:
    selected_units = _primitive_contour_units(units)
    actions = materialize_action_clearance(
        contour_tsp_2opt_unit_actions(selected_units, tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=actions,
        metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
    )


def plan_contour_aco_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
    seed: int = 20260531,
) -> RoutePlan:
    selected_units = _primitive_contour_units(units)
    actions = materialize_action_clearance(
        contour_aco_unit_actions(selected_units, tool.start_point, seed=seed),
        panel,
        tool,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=actions,
        metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
    )


def plan_endpoint_aware_gtsp_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    config: EndpointAwareGTSPConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> RoutePlan:
    selected_units = _primitive_contour_units(units)
    actions = materialize_action_clearance(
        endpoint_aware_gtsp_unit_actions(
            selected_units,
            tool.start_point,
            config=config,
        ),
        panel,
        tool,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=actions,
        metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
    )


def plan_topology_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    weights: TopologyWeights | None = None,
    process_model: CuttingProcessModel | None = None,
    candidate_pool_size: int | None = None,
    process_aware: bool = False,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    if process_model is None or not process_aware:
        actions = topology_aware_unit_actions(
            selected_units,
            start_point=tool.start_point,
            weights=weights,
            candidate_pool_size=candidate_pool_size,
        )
    else:
        actions = directed_units_to_actions(
            process_aware_unit_order(
                selected_units,
                panel=panel,
                tool=tool,
                process_model=process_model,
                candidate_pool_size=candidate_pool_size,
                repeat_cut_policy=repeat_cut_policy,
            ),
            start_point=tool.start_point,
        )
    actions = materialize_action_clearance(
        actions,
        panel,
        tool,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=actions,
        metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
    )


def plan_local_search_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(repeat_cut_policy, config)
    config = _local_search_config_with_policy(config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = topology_local_search_order(
        selected_units,
        panel=panel,
        tool=tool,
        config=config,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def plan_path_distance_local_search_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(repeat_cut_policy, config)
    config = _local_search_config_with_policy(config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = path_distance_local_search_order(
        selected_units,
        panel=panel,
        tool=tool,
        config=config,
        process_model=process_model,
    )
    actions = materialize_action_clearance(
        directed_units_to_actions(result.directed_units, start_point=tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=actions,
        metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
    )


def plan_process_local_search_multistart_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(repeat_cut_policy, config)
    config = _local_search_config_with_policy(config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = process_local_search_multistart_order(
        selected_units,
        panel=panel,
        tool=tool,
        config=config,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def plan_process_aware_simulated_annealing_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: SimulatedAnnealingConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(
        repeat_cut_policy,
        config.neighborhood if config is not None else None,
    )
    if config is None:
        default_config = SimulatedAnnealingConfig()
        config = SimulatedAnnealingConfig(
            neighborhood=replace(
                default_config.neighborhood,
                repeat_cut_policy=repeat_cut_policy,
            )
        )
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = process_aware_simulated_annealing_order(
        selected_units,
        panel=panel,
        tool=tool,
        config=config,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def plan_process_aware_genetic_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: GeneticAlgorithmConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(repeat_cut_policy, config)
    if config is None:
        config = GeneticAlgorithmConfig(repeat_cut_policy=repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = process_aware_genetic_order(
        selected_units,
        panel=panel,
        tool=tool,
        config=config,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def plan_process_aware_prefix_beam_mcts_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: PrefixBeamMCTSConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(repeat_cut_policy, config)
    config = _prefix_beam_mcts_config_with_policy(config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = process_aware_prefix_beam_mcts_order(
        selected_units,
        panel=panel,
        tool=tool,
        config=config,
        process_model=process_model,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def plan_exact_process_dp_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: ExactDPConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(repeat_cut_policy, config)
    config = _exact_dp_config_with_policy(config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = exact_process_dp_order(
        selected_units,
        panel=panel,
        tool=tool,
        process_model=process_model,
        config=config,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def plan_process_aware_beam_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    config: BeamSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(repeat_cut_policy, config)
    config = _beam_search_config_with_policy(config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = process_aware_beam_search_order(
        selected_units,
        panel=panel,
        tool=tool,
        process_model=process_model,
        config=config,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )


def plan_process_aware_beam_adaptive_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    beam_config: BeamSearchConfig | None = None,
    fallback_beam_config: BeamSearchConfig | None = None,
    topology_candidate_pool_size: int | None = None,
    fallback_margin: float = 1000.0,
    process_model: CuttingProcessModel | None = None,
    tool_event_gate: ToolEventGateConfig = DEFAULT_TOOL_EVENT_GATE_CONFIG,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    """Bounded portfolio planner that expands beam search only on risky cases.

    The topology route is a cheap process-aware reference. The default beam result is
    accepted when it clearly dominates that reference; otherwise a wider beam is
    evaluated and the best process-metric route is returned.
    """

    repeat_cut_policy = _resolved_repeat_cut_policy(
        repeat_cut_policy,
        beam_config,
        fallback_beam_config,
    )
    beam_config = _beam_search_config_with_policy(beam_config, repeat_cut_policy)
    fallback_beam_config = (
        fallback_beam_config
        if fallback_beam_config is not None
        else wider_beam_search_config(beam_config)
    )

    topology_plan = plan_topology_route(
        units,
        panel,
        tool,
        allow_bridge_cut=allow_bridge_cut,
        candidate_pool_size=topology_candidate_pool_size,
        process_aware=True,
        process_model=process_model,
        repeat_cut_policy=repeat_cut_policy,
    )
    beam_plan = plan_process_aware_beam_route(
        units,
        panel,
        tool,
        allow_bridge_cut=allow_bridge_cut,
        config=beam_config,
        process_model=process_model,
        repeat_cut_policy=repeat_cut_policy,
    )
    candidates = [topology_plan, beam_plan]
    if _beam_fallback_needed(
        beam_plan,
        topology_plan,
        fallback_margin,
        repeat_cut_policy=repeat_cut_policy,
    ):
        candidates.append(
            plan_process_aware_beam_route(
                units,
                panel,
                tool,
                allow_bridge_cut=allow_bridge_cut,
                config=fallback_beam_config,
                process_model=process_model,
                repeat_cut_policy=repeat_cut_policy,
            )
        )
    return _best_process_route(
        tuple(candidates),
        protected_plans=(beam_plan,),
        tool_event_gate=tool_event_gate,
        repeat_cut_policy=repeat_cut_policy,
    )


def plan_process_aware_beam_adaptive_polished_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    beam_config: BeamSearchConfig | None = None,
    fallback_beam_config: BeamSearchConfig | None = None,
    polish_config: LocalSearchConfig | None = None,
    topology_candidate_pool_size: int | None = None,
    fallback_margin: float = 1000.0,
    process_model: CuttingProcessModel | None = None,
    tool_event_gate: ToolEventGateConfig = DEFAULT_TOOL_EVENT_GATE_CONFIG,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    """Adaptive portfolio with process-aware local polishing as a candidate."""

    repeat_cut_policy = _resolved_repeat_cut_policy(
        repeat_cut_policy,
        beam_config,
        fallback_beam_config,
        polish_config,
    )
    beam_config = _beam_search_config_with_policy(beam_config, repeat_cut_policy)
    fallback_beam_config = (
        fallback_beam_config
        if fallback_beam_config is not None
        else wider_beam_search_config(beam_config)
    )
    polish_config = _local_search_config_with_policy(polish_config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    topology_plan = plan_topology_route(
        units,
        panel,
        tool,
        allow_bridge_cut=allow_bridge_cut,
        candidate_pool_size=topology_candidate_pool_size,
        process_aware=True,
        process_model=process_model,
        repeat_cut_policy=repeat_cut_policy,
    )
    beam_result = process_aware_beam_search_order(
        selected_units,
        panel,
        tool,
        process_model=process_model,
        config=beam_config,
    )
    beam_plan = _route_from_search_result(selected_units, beam_result)
    polished_plan = _polish_beam_route(
        selected_units,
        beam_result,
        panel,
        tool,
        polish_config=polish_config,
        process_model=process_model,
    )
    multistart_result = process_local_search_multistart_order(
        selected_units,
        panel=panel,
        tool=tool,
        config=polish_config,
        process_model=process_model,
    )
    multistart_plan = _route_from_search_result(selected_units, multistart_result)
    protected_plans = [beam_plan, polished_plan, multistart_plan]
    candidates = [topology_plan, beam_plan, polished_plan, multistart_plan]
    if _beam_fallback_needed(
        beam_plan,
        topology_plan,
        fallback_margin,
        repeat_cut_policy=repeat_cut_policy,
    ):
        fallback_result = process_aware_beam_search_order(
            selected_units,
            panel,
            tool,
            process_model=process_model,
            config=fallback_beam_config,
        )
        fallback_plan = _route_from_search_result(selected_units, fallback_result)
        fallback_polished_plan = _polish_beam_route(
            selected_units,
            fallback_result,
            panel,
            tool,
            polish_config=polish_config,
            process_model=process_model,
        )
        candidates.extend((fallback_plan, fallback_polished_plan))
        protected_plans.extend((fallback_plan, fallback_polished_plan))
    return _best_process_route(
        tuple(candidates),
        protected_plans=tuple(protected_plans),
        tool_event_gate=tool_event_gate,
        repeat_cut_policy=repeat_cut_policy,
    )


def plan_process_aware_beam_polished_route(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    allow_bridge_cut: bool = False,
    beam_config: BeamSearchConfig | None = None,
    polish_config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> RoutePlan:
    repeat_cut_policy = _resolved_repeat_cut_policy(
        repeat_cut_policy,
        beam_config,
        polish_config,
    )
    beam_config = _beam_search_config_with_policy(beam_config, repeat_cut_policy)
    polish_config = _local_search_config_with_policy(polish_config, repeat_cut_policy)
    selected_units = select_coverage_units(
        units,
        allow_bridge_cut=allow_bridge_cut,
        repeat_cut_policy=repeat_cut_policy,
    )
    result = process_aware_beam_polished_search_order(
        selected_units,
        panel=panel,
        tool=tool,
        process_model=process_model,
        beam_config=beam_config,
        polish_config=polish_config,
    )
    return RoutePlan(
        selected_units=selected_units,
        actions=result.actions,
        metrics=result.metrics,
    )
