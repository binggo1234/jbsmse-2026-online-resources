from __future__ import annotations

from dataclasses import dataclass
from math import inf
from time import perf_counter

from .geometry import euclidean_distance
from .local_search import (
    DEFAULT_REPEAT_CUT_POLICY,
    apply_candidate_incremental,
    process_aware_unit_order,
    process_metric_key,
    validate_repeat_cut_policy,
)
from .metrics import evaluate_actions, finalize_metrics, materialize_action_clearance
from .models import (
    CuttingAction,
    CuttingProcessModel,
    CuttingUnit,
    IncrementalMetricsState,
    Panel,
    PathMetrics,
    ToolConfig,
)
from .topology_operators import (
    DirectedUnitCandidate,
    directed_unit_candidates,
    directed_units_to_actions,
)


@dataclass(frozen=True)
class ExactDPConfig:
    max_units: int = 12
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY

    def __post_init__(self) -> None:
        validate_repeat_cut_policy(self.repeat_cut_policy)


@dataclass(frozen=True)
class ExactDPNode:
    unit_mask: int
    directed_units: tuple[DirectedUnitCandidate, ...]
    state: IncrementalMetricsState


@dataclass(frozen=True)
class ExactDPResult:
    directed_units: tuple[DirectedUnitCandidate, ...]
    actions: tuple[CuttingAction, ...]
    metrics: PathMetrics
    expanded_nodes: int
    retained_states: int


@dataclass(frozen=True)
class ExactBranchAndBoundConfig:
    timeout_seconds: float | None = None
    max_expanded_nodes: int | None = None
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY
    objective_scope: str = "process_key"

    def __post_init__(self) -> None:
        validate_repeat_cut_policy(self.repeat_cut_policy)
        if self.objective_scope not in {"process_key", "feasibility_cost"}:
            raise ValueError(
                "objective_scope must be 'process_key' or 'feasibility_cost'"
            )
        if self.timeout_seconds is not None and self.timeout_seconds <= 0.0:
            raise ValueError("timeout_seconds must be positive")
        if self.max_expanded_nodes is not None and self.max_expanded_nodes <= 0:
            raise ValueError("max_expanded_nodes must be positive")


@dataclass(frozen=True)
class ExactBranchAndBoundResult:
    directed_units: tuple[DirectedUnitCandidate, ...]
    actions: tuple[CuttingAction, ...]
    metrics: PathMetrics
    optimality_proven: bool
    termination_reason: str
    runtime_seconds: float
    expanded_nodes: int
    pruned_by_bound: int
    pruned_by_dominance: int
    retained_states: int


def _candidate_signature(candidate: DirectedUnitCandidate) -> tuple[str, bool]:
    return (candidate.unit.unit_id, candidate.is_reversed)


def _node_state_signature(
    mask: int,
    candidate: DirectedUnitCandidate,
    state: IncrementalMetricsState,
) -> tuple:
    return (
        mask,
        _candidate_signature(candidate),
        state.current_point,
        state.current_direction,
        state.is_tool_down,
        state.current_cutting_unit_id,
        tuple(sorted(state.processed_segments)),
        tuple(sorted(state.processed_span_ids)),
        tuple(sorted(state.released_part_ids)),
        tuple(sorted(state.unstable_part_ids)),
        state.processed_polygons,
        state.processed_polygon_bounds,
    )


def _sequence_signature(
    directed_units: tuple[DirectedUnitCandidate, ...],
) -> tuple[tuple[str, bool], ...]:
    return tuple(_candidate_signature(candidate) for candidate in directed_units)


def _node_rank(
    node: ExactDPNode,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple:
    return (
        process_metric_key(
            finalize_metrics(node.state),
            repeat_cut_policy=repeat_cut_policy,
        ),
        _sequence_signature(node.directed_units),
    )


def exact_process_dp_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
    config: ExactDPConfig | None = None,
) -> ExactDPResult:
    """Solve a small cutting-unit ordering instance by dynamic programming.

    This routine is intentionally capped by ``ExactDPConfig.max_units`` and is
    meant for small optimality-gap experiments, not for production-scale boards.
    """

    if config is None:
        config = ExactDPConfig()
    if len(units) > config.max_units:
        raise ValueError(
            f"exact DP supports at most {config.max_units} units; got {len(units)}"
        )

    if not units:
        actions: tuple[CuttingAction, ...] = ()
        metrics = evaluate_actions(actions, panel, tool, process_model=process_model)
        return ExactDPResult(
            directed_units=(),
            actions=actions,
            metrics=metrics,
            expanded_nodes=0,
            retained_states=1,
        )

    directed_by_unit = tuple(directed_unit_candidates(unit) for unit in units)
    full_mask = (1 << len(units)) - 1
    layers: dict[tuple, ExactDPNode] = {
        (0,): ExactDPNode(
            unit_mask=0,
            directed_units=(),
            state=IncrementalMetricsState(current_point=tool.start_point),
        )
    }
    expanded_nodes = 0
    retained_state_count = 1

    for _ in range(len(units)):
        next_layers: dict[tuple, ExactDPNode] = {}
        for node in layers.values():
            for unit_index, directed_candidates in enumerate(directed_by_unit):
                unit_bit = 1 << unit_index
                if node.unit_mask & unit_bit:
                    continue
                next_mask = node.unit_mask | unit_bit
                for candidate in directed_candidates:
                    next_state = apply_candidate_incremental(
                        candidate,
                        node.state,
                        panel,
                        tool,
                        process_model=process_model,
                    )
                    next_node = ExactDPNode(
                        unit_mask=next_mask,
                        directed_units=node.directed_units + (candidate,),
                        state=next_state,
                    )
                    signature = _node_state_signature(
                        next_mask,
                        candidate,
                        next_state,
                    )
                    incumbent = next_layers.get(signature)
                    if incumbent is None or _node_rank(
                        next_node,
                        repeat_cut_policy=config.repeat_cut_policy,
                    ) < _node_rank(
                        incumbent,
                        repeat_cut_policy=config.repeat_cut_policy,
                    ):
                        next_layers[signature] = next_node
                    expanded_nodes += 1
        retained_state_count += len(next_layers)
        layers = next_layers

    complete_nodes = [
        node
        for node in layers.values()
        if node.unit_mask == full_mask and len(node.directed_units) == len(units)
    ]
    if not complete_nodes:
        actions = ()
        return ExactDPResult(
            directed_units=(),
            actions=actions,
            metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
            expanded_nodes=expanded_nodes,
            retained_states=retained_state_count,
        )

    best = min(
        complete_nodes,
        key=lambda node: (
            process_metric_key(
                finalize_metrics(node.state),
                repeat_cut_policy=config.repeat_cut_policy,
            ),
            _sequence_signature(node.directed_units),
        ),
    )
    actions = materialize_action_clearance(
        directed_units_to_actions(best.directed_units, start_point=tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return ExactDPResult(
        directed_units=best.directed_units,
        actions=actions,
        metrics=finalize_metrics(best.state),
        expanded_nodes=expanded_nodes,
        retained_states=retained_state_count,
    )


def _evaluate_directed_order(
    directed_units: tuple[DirectedUnitCandidate, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None,
) -> tuple[IncrementalMetricsState, PathMetrics]:
    state = IncrementalMetricsState(current_point=tool.start_point)
    for candidate in directed_units:
        state = apply_candidate_incremental(
            candidate,
            state,
            panel,
            tool,
            process_model=process_model,
        )
    return state, finalize_metrics(state)


def _unit_distance(first: CuttingUnit, second: CuttingUnit) -> float:
    return min(
        euclidean_distance(first.start, second.start),
        euclidean_distance(first.start, second.end),
        euclidean_distance(first.end, second.start),
        euclidean_distance(first.end, second.end),
    )


def _minimum_assignment_cost(costs: tuple[tuple[float, ...], ...]) -> float:
    """Return the minimum square assignment cost using the Hungarian method."""

    size = len(costs)
    if size == 0:
        return 0.0
    potentials_left = [0.0] * (size + 1)
    potentials_right = [0.0] * (size + 1)
    matching = [0] * (size + 1)
    predecessor = [0] * (size + 1)
    for left in range(1, size + 1):
        matching[0] = left
        right0 = 0
        minimum = [inf] * (size + 1)
        used = [False] * (size + 1)
        while True:
            used[right0] = True
            left0 = matching[right0]
            delta = inf
            right1 = 0
            for right in range(1, size + 1):
                if used[right]:
                    continue
                reduced = (
                    costs[left0 - 1][right - 1]
                    - potentials_left[left0]
                    - potentials_right[right]
                )
                if reduced < minimum[right]:
                    minimum[right] = reduced
                    predecessor[right] = right0
                if minimum[right] < delta:
                    delta = minimum[right]
                    right1 = right
            for right in range(size + 1):
                if used[right]:
                    potentials_left[matching[right]] += delta
                    potentials_right[right] -= delta
                else:
                    minimum[right] -= delta
            right0 = right1
            if matching[right0] == 0:
                break
        while True:
            right1 = predecessor[right0]
            matching[right0] = matching[right1]
            right0 = right1
            if right0 == 0:
                break
    return -potentials_right[0]


def _assignment_travel_lower_bound(
    remaining_indices: list[int],
    current_point,
    units: tuple[CuttingUnit, ...],
    pair_distances: tuple[tuple[float, ...], ...],
) -> float:
    if not remaining_indices:
        return 0.0
    size = len(remaining_indices) + 1
    prohibited = 1e15
    rows: list[tuple[float, ...]] = []
    rows.append(
        tuple(
            min(
                euclidean_distance(current_point, units[index].start),
                euclidean_distance(current_point, units[index].end),
            )
            for index in remaining_indices
        )
        + (prohibited,)
    )
    for source_index in remaining_indices:
        rows.append(
            tuple(
                (
                    prohibited
                    if source_index == destination_index
                    else pair_distances[source_index][destination_index]
                )
                for destination_index in remaining_indices
            )
            + (0.0,)
        )
    if any(len(row) != size for row in rows):
        raise AssertionError("assignment relaxation must be square")
    return _minimum_assignment_cost(tuple(rows))


def _travel_lower_bound(
    remaining_mask: int,
    current_point,
    units: tuple[CuttingUnit, ...],
    pair_distances: tuple[tuple[float, ...], ...],
    mst_cache: dict[int, float],
) -> float:
    remaining_indices = [
        index for index in range(len(units)) if remaining_mask & (1 << index)
    ]
    if not remaining_indices:
        return 0.0

    connection = min(
        min(
            euclidean_distance(current_point, units[index].start),
            euclidean_distance(current_point, units[index].end),
        )
        for index in remaining_indices
    )
    incoming_bound = sum(
        min(
            min(
                euclidean_distance(current_point, units[index].start),
                euclidean_distance(current_point, units[index].end),
            ),
            min(
                (
                    pair_distances[index][other_index]
                    for other_index in remaining_indices
                    if other_index != index
                ),
                default=inf,
            ),
        )
        for index in remaining_indices
    )
    cached = mst_cache.get(remaining_mask)
    assignment_bound = 0.0
    if len(remaining_indices) >= max(len(units) - 2, 1):
        assignment_bound = _assignment_travel_lower_bound(
            remaining_indices,
            current_point,
            units,
            pair_distances,
        )
    if cached is not None:
        return max(connection + cached, incoming_bound, assignment_bound)

    if len(remaining_indices) == 1:
        mst_cache[remaining_mask] = 0.0
        return max(connection, incoming_bound, assignment_bound)

    tree_indices = {remaining_indices[0]}
    outside = set(remaining_indices[1:])
    best_connection = {
        index: pair_distances[remaining_indices[0]][index]
        for index in outside
    }
    mst_cost = 0.0
    while outside:
        next_index = min(
            outside,
            key=lambda index: (best_connection[index], index),
        )
        mst_cost += best_connection[next_index]
        outside.remove(next_index)
        tree_indices.add(next_index)
        for index in outside:
            best_connection[index] = min(
                best_connection[index],
                pair_distances[next_index][index],
            )
    mst_cache[remaining_mask] = mst_cost
    return max(connection + mst_cost, incoming_bound, assignment_bound)


def _prefix_lower_bound_key(
    state: IncrementalMetricsState,
    remaining_cutting_length: float,
    travel_distance_lower_bound: float,
    tool: ToolConfig,
    repeat_cut_policy: str,
    objective_scope: str,
) -> tuple:
    metrics = state.metrics
    minimum_travel_weight = min(
        tool.low_clearance_travel_weight,
        tool.detour_travel_weight,
        tool.safe_lift_travel_weight,
    )
    travel_cost_lower_bound = (
        metrics.travel_mode_cost
        + travel_distance_lower_bound * minimum_travel_weight
    )
    machining_cost_lower_bound = (
        metrics.cutting_length
        + remaining_cutting_length
        + travel_cost_lower_bound
    )
    tool_events = metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count

    if repeat_cut_policy == "off":
        key = (
            metrics.hard_penalty,
            metrics.stability_penalty,
            machining_cost_lower_bound,
            tool_events,
            travel_cost_lower_bound,
            metrics.air_move_distance + travel_distance_lower_bound,
            metrics.turn_penalty,
            -inf,
        )
        return key[:3] if objective_scope == "feasibility_cost" else key
    if repeat_cut_policy == "soft":
        key = (
            metrics.hard_penalty,
            metrics.stability_penalty,
            machining_cost_lower_bound + metrics.repeated_cut_length,
            metrics.repeated_cut_segment_count,
            metrics.redundant_cut_action_count,
            tool_events,
            travel_cost_lower_bound,
            metrics.air_move_distance + travel_distance_lower_bound,
            metrics.turn_penalty,
            -inf,
        )
        return key[:5] if objective_scope == "feasibility_cost" else key
    key = (
        metrics.hard_penalty,
        metrics.stability_penalty,
        metrics.repeated_cut_segment_count,
        metrics.repeated_cut_length,
        metrics.redundant_cut_action_count,
        machining_cost_lower_bound,
        tool_events,
        travel_cost_lower_bound,
        metrics.air_move_distance + travel_distance_lower_bound,
        metrics.turn_penalty,
        -inf,
    )
    return key[:6] if objective_scope == "feasibility_cost" else key


def _objective_key(
    metrics: PathMetrics,
    *,
    repeat_cut_policy: str,
    objective_scope: str,
) -> tuple:
    key = process_metric_key(metrics, repeat_cut_policy=repeat_cut_policy)
    if objective_scope == "process_key":
        return key
    if repeat_cut_policy == "off":
        return key[:3]
    if repeat_cut_policy == "soft":
        return key[:5]
    return key[:6]


def exact_process_branch_and_bound_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
    config: ExactBranchAndBoundConfig | None = None,
    incumbent_directed_units: tuple[DirectedUnitCandidate, ...] | None = None,
) -> ExactBranchAndBoundResult:
    """Exactly optimize a fixed cutting-unit set when the search is certified.

    The search enumerates every unit permutation and executable orientation.
    A returned route is globally optimal for the supplied unit set only when
    ``optimality_proven`` is true.
    """

    if config is None:
        config = ExactBranchAndBoundConfig()
    start_time = perf_counter()

    if not units:
        metrics = evaluate_actions((), panel, tool, process_model=process_model)
        return ExactBranchAndBoundResult(
            directed_units=(),
            actions=(),
            metrics=metrics,
            optimality_proven=True,
            termination_reason="complete",
            runtime_seconds=perf_counter() - start_time,
            expanded_nodes=0,
            pruned_by_bound=0,
            pruned_by_dominance=0,
            retained_states=1,
        )

    unit_ids = tuple(unit.unit_id for unit in units)
    if len(set(unit_ids)) != len(unit_ids):
        raise ValueError("cutting-unit identifiers must be unique")
    expected_unit_ids = set(unit_ids)

    heuristic_directed_units = process_aware_unit_order(
        units,
        panel,
        tool,
        process_model=process_model,
        repeat_cut_policy=config.repeat_cut_policy,
    )
    incumbent_candidates = [heuristic_directed_units]
    if incumbent_directed_units is not None:
        if {
            candidate.unit.unit_id for candidate in incumbent_directed_units
        } != expected_unit_ids or len(incumbent_directed_units) != len(units):
            raise ValueError(
                "incumbent route must contain every supplied unit exactly once"
            )
        incumbent_candidates.append(incumbent_directed_units)
    evaluated_incumbents = [
        (
            directed_units,
            _evaluate_directed_order(
                directed_units,
                panel,
                tool,
                process_model,
            )[1],
        )
        for directed_units in incumbent_candidates
    ]
    best_directed_units, best_metrics = min(
        evaluated_incumbents,
        key=lambda item: (
            _objective_key(
                item[1],
                repeat_cut_policy=config.repeat_cut_policy,
                objective_scope=config.objective_scope,
            ),
            _sequence_signature(item[0]),
        ),
    )
    best_key = _objective_key(
        best_metrics,
        repeat_cut_policy=config.repeat_cut_policy,
        objective_scope=config.objective_scope,
    )

    directed_by_unit = tuple(directed_unit_candidates(unit) for unit in units)
    unit_lengths = tuple(
        euclidean_distance(unit.start, unit.end) for unit in units
    )
    pair_distances = tuple(
        tuple(_unit_distance(first, second) for second in units)
        for first in units
    )
    full_mask = (1 << len(units)) - 1
    mst_cache: dict[int, float] = {}
    dominance_cache: dict[tuple, tuple] = {}
    expanded_nodes = 0
    pruned_by_bound = 0
    pruned_by_dominance = 0
    termination_reason = "complete"

    class SearchLimitReached(Exception):
        pass

    def check_limits() -> None:
        nonlocal termination_reason
        if (
            config.timeout_seconds is not None
            and perf_counter() - start_time >= config.timeout_seconds
        ):
            termination_reason = "timeout"
            raise SearchLimitReached
        if (
            config.max_expanded_nodes is not None
            and expanded_nodes >= config.max_expanded_nodes
        ):
            termination_reason = "node_limit"
            raise SearchLimitReached

    def search(
        mask: int,
        state: IncrementalMetricsState,
        prefix: tuple[DirectedUnitCandidate, ...],
        remaining_cutting_length: float,
    ) -> None:
        nonlocal best_directed_units
        nonlocal best_metrics
        nonlocal best_key
        nonlocal expanded_nodes
        nonlocal pruned_by_bound
        nonlocal pruned_by_dominance

        check_limits()
        if mask == full_mask:
            complete_metrics = finalize_metrics(state)
            complete_key = _objective_key(
                complete_metrics,
                repeat_cut_policy=config.repeat_cut_policy,
                objective_scope=config.objective_scope,
            )
            if (complete_key, _sequence_signature(prefix)) < (
                best_key,
                _sequence_signature(best_directed_units),
            ):
                best_directed_units = prefix
                best_metrics = complete_metrics
                best_key = complete_key
            return

        remaining_mask = full_mask ^ mask
        travel_lower_bound = _travel_lower_bound(
            remaining_mask,
            state.current_point,
            units,
            pair_distances,
            mst_cache,
        )
        lower_bound_key = _prefix_lower_bound_key(
            state,
            remaining_cutting_length,
            travel_lower_bound,
            tool,
            config.repeat_cut_policy,
            config.objective_scope,
        )
        if lower_bound_key >= best_key:
            pruned_by_bound += 1
            return

        children: list[
            tuple[
                tuple,
                int,
                DirectedUnitCandidate,
                IncrementalMetricsState,
            ]
        ] = []
        for unit_index, candidates in enumerate(directed_by_unit):
            unit_bit = 1 << unit_index
            if mask & unit_bit:
                continue
            next_mask = mask | unit_bit
            for candidate in candidates:
                next_state = apply_candidate_incremental(
                    candidate,
                    state,
                    panel,
                    tool,
                    process_model=process_model,
                )
                expanded_nodes += 1
                next_remaining_cutting_length = (
                    remaining_cutting_length - unit_lengths[unit_index]
                )
                next_remaining_mask = full_mask ^ next_mask
                next_travel_lower_bound = _travel_lower_bound(
                    next_remaining_mask,
                    next_state.current_point,
                    units,
                    pair_distances,
                    mst_cache,
                )
                next_lower_bound_key = _prefix_lower_bound_key(
                    next_state,
                    next_remaining_cutting_length,
                    next_travel_lower_bound,
                    tool,
                    config.repeat_cut_policy,
                    config.objective_scope,
                )
                if next_lower_bound_key >= best_key:
                    pruned_by_bound += 1
                    continue
                next_signature = _node_state_signature(
                    next_mask,
                    candidate,
                    next_state,
                )
                next_rank = _objective_key(
                    next_state.metrics,
                    repeat_cut_policy=config.repeat_cut_policy,
                    objective_scope=config.objective_scope,
                )
                incumbent_rank = dominance_cache.get(next_signature)
                if incumbent_rank is not None and incumbent_rank <= next_rank:
                    pruned_by_dominance += 1
                    continue
                dominance_cache[next_signature] = next_rank
                children.append(
                    (
                        next_lower_bound_key,
                        unit_index,
                        candidate,
                        next_state,
                    )
                )

        children.sort(
            key=lambda item: (
                item[0],
                euclidean_distance(state.current_point, item[2].start),
                item[2].unit.unit_id,
                item[2].is_reversed,
            )
        )
        for _, unit_index, candidate, next_state in children:
            search(
                mask | (1 << unit_index),
                next_state,
                prefix + (candidate,),
                remaining_cutting_length - unit_lengths[unit_index],
            )

    try:
        search(
            0,
            IncrementalMetricsState(current_point=tool.start_point),
            (),
            sum(unit_lengths),
        )
        optimality_proven = True
    except SearchLimitReached:
        optimality_proven = False

    actions = materialize_action_clearance(
        directed_units_to_actions(best_directed_units, start_point=tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return ExactBranchAndBoundResult(
        directed_units=best_directed_units,
        actions=actions,
        metrics=best_metrics,
        optimality_proven=optimality_proven,
        termination_reason=termination_reason,
        runtime_seconds=perf_counter() - start_time,
        expanded_nodes=expanded_nodes,
        pruned_by_bound=pruned_by_bound,
        pruned_by_dominance=pruned_by_dominance,
        retained_states=len(dominance_cache),
    )
