from __future__ import annotations

from collections import defaultdict

from .geometry import compensated_rectangle_edges, rectangle_edges
from .models import (
    BoundaryRelation,
    BoundaryRelationType,
    EdgeOrientation,
    EdgeSegment,
    Layout,
    Point,
    SegmentSpan,
    ToolConfig,
)
from .relations import detect_boundary_relations


SPAN_ID_PRECISION = 9


def axis_bounds(segment: EdgeSegment) -> tuple[float, float]:
    if segment.orientation == EdgeOrientation.HORIZONTAL:
        return (min(segment.start.x, segment.end.x), max(segment.start.x, segment.end.x))
    return (min(segment.start.y, segment.end.y), max(segment.start.y, segment.end.y))


def fixed_coordinate(segment: EdgeSegment) -> float:
    if segment.orientation == EdgeOrientation.HORIZONTAL:
        return segment.start.y
    return segment.start.x


def point_from_axis(
    orientation: EdgeOrientation,
    fixed_axis: float,
    axis: float,
) -> Point:
    if orientation == EdgeOrientation.HORIZONTAL:
        return Point(axis, fixed_axis)
    return Point(fixed_axis, axis)


def overlap_bounds(first: EdgeSegment, second: EdgeSegment) -> tuple[float, float]:
    first_lo, first_hi = axis_bounds(first)
    second_lo, second_hi = axis_bounds(second)
    return (max(first_lo, second_lo), min(first_hi, second_hi))


def all_bounds(segments: tuple[EdgeSegment, ...]) -> tuple[float, float]:
    lows: list[float] = []
    highs: list[float] = []
    for segment in segments:
        lo, hi = axis_bounds(segment)
        lows.append(lo)
        highs.append(hi)
    return (min(lows), max(highs))


def span_id(segment: EdgeSegment, lo: float, hi: float) -> str:
    return (
        f"{segment.segment_id}@"
        f"{lo:.{SPAN_ID_PRECISION}f}:{hi:.{SPAN_ID_PRECISION}f}"
    )


def deduplicate_axis_values(values: list[float], tolerance: float) -> tuple[float, ...]:
    if not values:
        return ()
    ordered = sorted(values)
    deduplicated = [ordered[0]]
    for value in ordered[1:]:
        if abs(value - deduplicated[-1]) <= tolerance:
            continue
        deduplicated.append(value)
    return tuple(deduplicated)


def build_segment_spans(
    segments: tuple[EdgeSegment, ...],
    relations: tuple[BoundaryRelation, ...] = (),
    tolerance: float = 1e-6,
) -> dict[str, tuple[SegmentSpan, ...]]:
    endpoints: dict[str, list[float]] = defaultdict(list)
    segment_by_id = {segment.segment_id: segment for segment in segments}
    for segment in segments:
        lo, hi = axis_bounds(segment)
        endpoints[segment.segment_id].extend((lo, hi))

    for relation in relations:
        if relation.relation_type not in (
            BoundaryRelationType.SHARED_EDGE,
            BoundaryRelationType.NEAR_SHARED_EDGE,
        ):
            continue
        relation_lo, relation_hi = overlap_bounds(relation.first, relation.second)
        first_nominal = segment_by_id[relation.first.segment_id]
        second_nominal = segment_by_id[relation.second.segment_id]
        first_lo, first_hi = axis_bounds(first_nominal)
        second_lo, second_hi = axis_bounds(second_nominal)
        first_bounds = (
            max(relation_lo, first_lo),
            min(relation_hi, first_hi),
        )
        second_bounds = (
            max(relation_lo, second_lo),
            min(relation_hi, second_hi),
        )
        if first_bounds[1] - first_bounds[0] > tolerance:
            endpoints[relation.first.segment_id].extend(first_bounds)
        if second_bounds[1] - second_bounds[0] > tolerance:
            endpoints[relation.second.segment_id].extend(second_bounds)

    spans_by_segment: dict[str, tuple[SegmentSpan, ...]] = {}
    for segment_id, values in endpoints.items():
        segment = segment_by_id[segment_id]
        axis_values = deduplicate_axis_values(values, tolerance)
        spans: list[SegmentSpan] = []
        for lo, hi in zip(axis_values, axis_values[1:]):
            if hi - lo <= tolerance:
                continue
            spans.append(
                SegmentSpan(
                    span_id=span_id(segment, lo, hi),
                    segment_id=segment.segment_id,
                    part_id=segment.part_id,
                    role=segment.role,
                    orientation=segment.orientation,
                    start_axis=lo,
                    end_axis=hi,
                )
            )
        spans_by_segment[segment_id] = tuple(spans)
    return spans_by_segment


def layout_edges_relations_and_spans(
    layout: Layout,
    tool: ToolConfig,
    max_collinear_gap: float = float("inf"),
    tolerance: float = 1e-6,
) -> tuple[
    tuple[EdgeSegment, ...],
    tuple[BoundaryRelation, ...],
    dict[str, tuple[SegmentSpan, ...]],
]:
    segments = tuple(
        segment
        for rectangle in layout.rectangles
        for segment in rectangle_edges(rectangle)
    )
    trajectory_segments = (
        tuple(
            segment
            for rectangle in layout.rectangles
            for segment in compensated_rectangle_edges(rectangle, tool.tool_radius)
        )
        if tool.geometric_kerf_compensation
        else segments
    )
    relations = detect_boundary_relations(
        trajectory_segments,
        min_channel_width=(
            0.0 if tool.geometric_kerf_compensation else tool.min_channel_width
        ),
        max_collinear_gap=max_collinear_gap,
        tolerance=tolerance,
    )
    return (
        segments,
        relations,
        build_segment_spans(segments, relations, tolerance=tolerance),
    )


def spans_for_segment_interval(
    spans_by_segment: dict[str, tuple[SegmentSpan, ...]],
    segment: EdgeSegment,
    lo: float,
    hi: float,
    tolerance: float = 1e-6,
) -> tuple[SegmentSpan, ...]:
    return tuple(
        span
        for span in spans_by_segment.get(segment.segment_id, ())
        if span.start_axis >= lo - tolerance and span.end_axis <= hi + tolerance
    )


def span_segment_ids(spans: tuple[SegmentSpan, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(span.segment_id for span in spans))


def span_ids(spans: tuple[SegmentSpan, ...]) -> tuple[str, ...]:
    return tuple(span.span_id for span in spans)
