from __future__ import annotations

from dataclasses import dataclass, field
from math import ceil, exp, log, sqrt
import random

from .geometry import euclidean_distance
from .metrics import (
    add_metrics,
    apply_action_incremental,
    evaluate_actions,
    finalize_metrics,
    materialize_action_clearance,
    subtract_metrics,
)
from .models import (
    CuttingAction,
    CuttingActionType,
    CuttingProcessModel,
    IncrementalMetricsState,
    CuttingUnit,
    Panel,
    PathMetrics,
    Point,
    ToolConfig,
)
from .travel import plan_travel_actions
from .topology_operators import (
    DirectedUnitCandidate,
    directed_unit_candidates,
    directed_units_to_actions,
    nearest_candidate_units,
    topology_aware_unit_order,
    transition_score,
    unit_part_ids,
    unit_segment_id,
)


REPEAT_CUT_POLICIES = ("hard", "soft", "off")
DEFAULT_REPEAT_CUT_POLICY = "hard"


def unit_coverage_count(unit: CuttingUnit) -> int:
    return len(unit.covered_spans or unit.covered_segment_ids)


def validate_repeat_cut_policy(policy: str) -> str:
    if policy not in REPEAT_CUT_POLICIES:
        choices = ", ".join(REPEAT_CUT_POLICIES)
        raise ValueError(f"repeat_cut_policy must be one of: {choices}")
    return policy


@dataclass(frozen=True)
class LocalSearchConfig:
    max_iterations: int = 50
    enable_swap: bool = True
    enable_relocate: bool = True
    enable_two_opt: bool = True
    first_improvement: bool = False
    max_swap_span: int | None = None
    max_relocate_span: int | None = None
    max_two_opt_span: int | None = None
    max_neighbors_per_iteration: int | None = None
    topology_candidate_pool_size: int | None = None
    process_aware_initial_order: bool = False
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY

    def __post_init__(self) -> None:
        validate_repeat_cut_policy(self.repeat_cut_policy)


def _reached_neighbor_limit(
    neighbors: list,
    max_neighbors: int | None,
) -> bool:
    return max_neighbors is not None and len(neighbors) >= max_neighbors


@dataclass(frozen=True)
class LocalSearchResult:
    directed_units: tuple[DirectedUnitCandidate, ...]
    actions: tuple[CuttingAction, ...]
    metrics: PathMetrics
    iterations: int
    improved: bool


@dataclass(frozen=True)
class SimulatedAnnealingConfig:
    max_iterations: int = 250
    initial_temperature: float = 1_000_000.0
    cooling_rate: float = 0.97
    min_temperature: float = 1e-3
    seed: int = 20260502
    neighborhood: LocalSearchConfig = LocalSearchConfig(
        max_iterations=1,
        first_improvement=False,
        max_swap_span=8,
        max_relocate_span=8,
        max_two_opt_span=8,
        max_neighbors_per_iteration=96,
        process_aware_initial_order=True,
    )

    def __post_init__(self) -> None:
        if self.max_iterations < 0:
            raise ValueError("max_iterations must be non-negative")
        if self.initial_temperature <= 0.0:
            raise ValueError("initial_temperature must be positive")
        if not 0.0 < self.cooling_rate <= 1.0:
            raise ValueError("cooling_rate must be in (0, 1]")
        if self.min_temperature <= 0.0:
            raise ValueError("min_temperature must be positive")


@dataclass(frozen=True)
class GeneticAlgorithmConfig:
    population_size: int = 24
    generations: int = 40
    elite_count: int = 2
    mutation_rate: float = 0.20
    crossover_rate: float = 0.85
    seed: int = 20260502
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY
    topology_candidate_pool_size: int | None = None

    def __post_init__(self) -> None:
        validate_repeat_cut_policy(self.repeat_cut_policy)
        if self.population_size < 2:
            raise ValueError("population_size must be at least 2")
        if self.generations < 0:
            raise ValueError("generations must be non-negative")
        if not 1 <= self.elite_count < self.population_size:
            raise ValueError("elite_count must be in [1, population_size)")
        if not 0.0 <= self.mutation_rate <= 1.0:
            raise ValueError("mutation_rate must be in [0, 1]")
        if not 0.0 <= self.crossover_rate <= 1.0:
            raise ValueError("crossover_rate must be in [0, 1]")


@dataclass(frozen=True)
class BeamSearchConfig:
    beam_width: int = 8
    candidate_pool_size: int | None = 32
    max_expansions_per_node: int | None = None
    max_layer_expansions: int | None = None
    diversity_bucket_limit: int | None = None
    min_expansions_per_parent: int = 0
    unstable_min_expansions_per_parent: int = 0
    unstable_layer_expansion_multiplier: float = 1.0
    unstable_layer_expansion_bonus: int = 0
    completion_aware_prerank: bool = False
    unstable_completion_focus_count: int | None = None
    use_state_dominance: bool = False
    use_lower_bound_rank: bool = False
    lower_bound_slot_fraction: float = 0.0
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY

    def __post_init__(self) -> None:
        validate_repeat_cut_policy(self.repeat_cut_policy)
        if not 0.0 <= self.lower_bound_slot_fraction <= 1.0:
            raise ValueError("lower_bound_slot_fraction must be in [0, 1]")


@dataclass(frozen=True)
class PrefixBeamMCTSConfig:
    iterations: int = 128
    candidate_pool_size: int | None = 24
    max_expansions_per_node: int | None = 8
    rollout_top_k: int = 4
    exploration_weight: float = 1.0
    seed: int = 20260502
    completion_aware_prerank: bool = True
    unstable_completion_focus_count: int | None = 2
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY

    def __post_init__(self) -> None:
        validate_repeat_cut_policy(self.repeat_cut_policy)
        if self.iterations < 1:
            raise ValueError("iterations must be positive")
        if (
            self.max_expansions_per_node is not None
            and self.max_expansions_per_node < 1
        ):
            raise ValueError("max_expansions_per_node must be positive when set")
        if self.rollout_top_k < 1:
            raise ValueError("rollout_top_k must be positive")
        if self.exploration_weight < 0.0:
            raise ValueError("exploration_weight must be non-negative")


@dataclass(frozen=True)
class BeamSearchResult:
    directed_units: tuple[DirectedUnitCandidate, ...]
    actions: tuple[CuttingAction, ...]
    metrics: PathMetrics
    expanded_nodes: int
    diagnostics: tuple["BeamLayerDiagnostics", ...] = ()


def process_aware_exact_candidate_limit(candidate_pool_size: int | None) -> int | None:
    if candidate_pool_size is None:
        return None
    return max(16, candidate_pool_size // 3)


@dataclass(frozen=True)
class BeamLayerDiagnostics:
    depth: int
    input_beam_count: int
    unstable_input_prefix_count: int
    raw_expansion_count: int
    effective_layer_expansion_limit: int
    layer_expansion_count: int
    layer_pruned_count: int
    parent_quota_added_count: int
    parent_quota_pruned_count: int
    evaluated_node_count: int
    duplicate_pruned_count: int
    state_dominance_pruned_count: int
    process_queue_seed_count: int
    lower_bound_queue_seed_count: int
    diversity_pruned_count: int
    fallback_added_count: int
    output_beam_count: int
    best_hard_penalty: float
    best_stability_penalty: float
    best_travel_mode_cost: float
    best_air_move_distance: float
    worst_stability_penalty: float
    worst_travel_mode_cost: float
    unstable_prefix_count: int
    released_part_count_max: int


@dataclass(frozen=True)
class NeighborMove:
    directed_units: tuple[DirectedUnitCandidate, ...]
    affected_start_index: int
    affected_stop_index: int


@dataclass(frozen=True)
class BeamSearchNode:
    directed_units: tuple[DirectedUnitCandidate, ...]
    remaining_units: tuple[CuttingUnit, ...]
    state: IncrementalMetricsState
    previous_unit: CuttingUnit | None = None


@dataclass(frozen=True)
class BeamSearchExpansion:
    parent: BeamSearchNode
    candidate: DirectedUnitCandidate
    transition_cost: float
    rank: tuple


@dataclass
class PrefixBeamMCTSNode:
    beam_node: BeamSearchNode
    parent: "PrefixBeamMCTSNode | None" = None
    children: list["PrefixBeamMCTSNode"] = field(default_factory=list)
    untried: list[tuple[DirectedUnitCandidate, float]] | None = None
    visits: int = 0
    best_energy: float = float("inf")
    best_key: tuple | None = None
    best_directed_units: tuple[DirectedUnitCandidate, ...] = ()
    best_metrics: PathMetrics | None = None


def reverse_candidate(candidate: DirectedUnitCandidate) -> DirectedUnitCandidate | None:
    if not candidate.unit.is_reversible:
        return None
    return DirectedUnitCandidate(
        unit=candidate.unit,
        start=candidate.end,
        end=candidate.start,
        direction=(-candidate.direction[0], -candidate.direction[1]),
        is_reversed=not candidate.is_reversed,
    )


def evaluate_directed_units(
    directed_units: tuple[DirectedUnitCandidate, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
) -> tuple[tuple[CuttingAction, ...], PathMetrics]:
    actions = materialize_action_clearance(
        directed_units_to_actions(directed_units, start_point=tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return actions, evaluate_actions(actions, panel, tool, process_model=process_model)


def candidate_actions_from_state(
    candidate: DirectedUnitCandidate,
    state: IncrementalMetricsState,
) -> tuple[CuttingAction, ...]:
    actions: list[CuttingAction] = []
    if euclidean_distance(state.current_point, candidate.start) > 1e-9:
        actions.append(
            CuttingAction(
                action_type=CuttingActionType.TRAVEL,
                start=state.current_point,
                end=candidate.start,
                cutting_unit_id=candidate.unit.unit_id,
                covered_segment_ids=candidate.unit.covered_segment_ids,
                covered_spans=candidate.unit.covered_spans,
            )
        )
    actions.append(
        CuttingAction(
            action_type=CuttingActionType.CUT,
            start=candidate.start,
            end=candidate.end,
            segment_id=unit_segment_id(candidate.unit),
            cutting_unit_id=candidate.unit.unit_id,
            covered_segment_ids=candidate.unit.covered_segment_ids,
            covered_spans=candidate.unit.covered_spans,
        )
    )
    return tuple(actions)


def apply_candidate_incremental(
    candidate: DirectedUnitCandidate,
    state: IncrementalMetricsState,
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
) -> IncrementalMetricsState:
    next_state = state
    for action in candidate_actions_from_state(candidate, state):
        if action.action_type == CuttingActionType.TRAVEL:
            planned_actions = plan_travel_actions(
                action.start,
                action.end,
                next_state,
                panel,
                tool,
                cutting_unit_id=action.cutting_unit_id,
                covered_segment_ids=action.covered_segment_ids,
                covered_spans=action.covered_spans,
            )
        else:
            planned_actions = (action,)
        for planned_action in planned_actions:
            next_state = apply_action_incremental(
                planned_action,
                next_state,
                panel,
                tool,
                process_model=process_model,
            )
    return next_state


def build_prefix_states(
    directed_units: tuple[DirectedUnitCandidate, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
) -> tuple[IncrementalMetricsState, ...]:
    state = IncrementalMetricsState(current_point=tool.start_point)
    states = [state]
    for candidate in directed_units:
        state = apply_candidate_incremental(
            candidate,
            state,
            panel,
            tool,
            process_model=process_model,
        )
        states.append(state)
    return tuple(states)


def evaluate_directed_units_from_prefix(
    directed_units: tuple[DirectedUnitCandidate, ...],
    start_index: int,
    prefix_state: IncrementalMetricsState,
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
) -> PathMetrics:
    state = prefix_state
    for candidate in directed_units[start_index:]:
        state = apply_candidate_incremental(
            candidate,
            state,
            panel,
            tool,
            process_model=process_model,
        )
    return finalize_metrics(state)


def _state_rejoins_suffix(
    state: IncrementalMetricsState,
    reference_state: IncrementalMetricsState,
) -> bool:
    return (
        state.current_point == reference_state.current_point
        and state.current_direction == reference_state.current_direction
        and state.is_tool_down == reference_state.is_tool_down
        and state.current_cutting_unit_id == reference_state.current_cutting_unit_id
        and state.processed_segments == reference_state.processed_segments
        and state.processed_span_ids == reference_state.processed_span_ids
        and state.released_part_ids == reference_state.released_part_ids
        and state.unstable_part_ids == reference_state.unstable_part_ids
        and tuple(sorted(state.processed_polygon_bounds))
        == tuple(sorted(reference_state.processed_polygon_bounds))
    )


def evaluate_neighbor_move_metrics(
    move: NeighborMove,
    prefix_states: tuple[IncrementalMetricsState, ...],
    current_metrics: PathMetrics,
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
) -> PathMetrics:
    stop_index = min(move.affected_stop_index, len(move.directed_units))
    state = prefix_states[move.affected_start_index]
    for candidate in move.directed_units[move.affected_start_index : stop_index]:
        state = apply_candidate_incremental(
            candidate,
            state,
            panel,
            tool,
            process_model=process_model,
        )

    if stop_index >= len(move.directed_units):
        return finalize_metrics(state)

    reference_state = prefix_states[stop_index]
    if _state_rejoins_suffix(state, reference_state):
        suffix_delta = subtract_metrics(current_metrics, reference_state.metrics)
        return add_metrics(state.metrics, suffix_delta)

    return evaluate_directed_units_from_prefix(
        move.directed_units,
        stop_index,
        state,
        panel,
        tool,
        process_model=process_model,
    )


def process_metric_key(
    metrics: PathMetrics,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple:
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    if repeat_cut_policy == "off":
        return (
            metrics.hard_penalty,
            metrics.stability_penalty,
            metrics.machining_cost,
            metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
            metrics.travel_mode_cost,
            metrics.air_move_distance,
            metrics.turn_penalty,
            -metrics.continuity_reward,
        )
    if repeat_cut_policy == "soft":
        return (
            metrics.hard_penalty,
            metrics.stability_penalty,
            metrics.machining_cost + metrics.repeated_cut_length,
            metrics.repeated_cut_segment_count,
            metrics.redundant_cut_action_count,
            metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
            metrics.travel_mode_cost,
            metrics.air_move_distance,
            metrics.turn_penalty,
            -metrics.continuity_reward,
        )
    return (
        metrics.hard_penalty,
        metrics.stability_penalty,
        metrics.repeated_cut_segment_count,
        metrics.repeated_cut_length,
        metrics.redundant_cut_action_count,
        metrics.machining_cost,
        metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
        metrics.travel_mode_cost,
        metrics.air_move_distance,
        metrics.turn_penalty,
        -metrics.continuity_reward,
    )


def process_metric_energy(
    metrics: PathMetrics,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> float:
    """Scalar surrogate used only by stochastic process-aware baselines.

    Deterministic comparisons still use ``process_metric_key``. The scalar gives
    the Metropolis and roulette-free GA operators a finite energy while preserving
    the same dominant process hierarchy through large decreasing weights.
    """

    key = process_metric_key(metrics, repeat_cut_policy=repeat_cut_policy)
    weights = (
        1e12,
        1e10,
        1e8,
        1e6,
        1e5,
        1e3,
        1e2,
        1.0,
        1e-3,
        1e-3,
        1e-3,
    )
    return sum(float(value) * weights[index] for index, value in enumerate(key))


def path_distance_metric_key(
    metrics: PathMetrics,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple:
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    if repeat_cut_policy == "off":
        return (
            metrics.hard_penalty,
            metrics.machining_cost,
            metrics.travel_mode_cost,
            metrics.air_move_distance,
            metrics.turn_penalty,
            metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
        )
    if repeat_cut_policy == "soft":
        return (
            metrics.hard_penalty,
            metrics.machining_cost + metrics.repeated_cut_length,
            metrics.repeated_cut_segment_count,
            metrics.redundant_cut_action_count,
            metrics.travel_mode_cost,
            metrics.air_move_distance,
            metrics.turn_penalty,
            metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
        )
    return (
        metrics.hard_penalty,
        metrics.repeated_cut_segment_count,
        metrics.repeated_cut_length,
        metrics.redundant_cut_action_count,
        metrics.machining_cost,
        metrics.travel_mode_cost,
        metrics.air_move_distance,
        metrics.turn_penalty,
        metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
    )


def process_state_metric_key(
    state: IncrementalMetricsState,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple:
    metrics = state.metrics
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    if repeat_cut_policy == "off":
        return (
            metrics.hard_penalty,
            metrics.stability_penalty + float(len(state.unstable_part_ids)),
            metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
            metrics.travel_mode_cost,
            metrics.air_move_distance,
            metrics.turn_penalty,
            -metrics.continuity_reward,
        )
    if repeat_cut_policy == "soft":
        return (
            metrics.hard_penalty,
            metrics.stability_penalty + float(len(state.unstable_part_ids)),
            metrics.repeated_cut_length,
            metrics.repeated_cut_segment_count,
            metrics.redundant_cut_action_count,
            metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
            metrics.travel_mode_cost,
            metrics.air_move_distance,
            metrics.turn_penalty,
            -metrics.continuity_reward,
        )
    return (
        metrics.hard_penalty,
        metrics.stability_penalty + float(len(state.unstable_part_ids)),
        metrics.repeated_cut_segment_count,
        metrics.repeated_cut_length,
        metrics.redundant_cut_action_count,
        metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count,
        metrics.travel_mode_cost,
        metrics.air_move_distance,
        metrics.turn_penalty,
        -metrics.continuity_reward,
    )


def unit_process_part_ids(
    unit: CuttingUnit,
    process_model: CuttingProcessModel | None,
) -> frozenset[str]:
    if process_model is None:
        return frozenset()
    span_part_ids = {
        process_model.span_part_ids[span.span_id]
        for span in unit.covered_spans
        if span.span_id in process_model.span_part_ids
    }
    if span_part_ids:
        return frozenset(span_part_ids)
    return frozenset(
        process_model.segment_part_ids[segment_id]
        for segment_id in unit.covered_segment_ids
        if segment_id in process_model.segment_part_ids
    )


def completion_candidate_units(
    remaining: list[CuttingUnit],
    state: IncrementalMetricsState,
    process_model: CuttingProcessModel | None,
    focus_count: int | None = None,
) -> tuple[CuttingUnit, ...]:
    if process_model is None or not state.unstable_part_ids:
        return ()
    unstable_part_ids = state.unstable_part_ids
    if focus_count is not None and focus_count > 0:
        unstable_part_ids = set(
            sorted(
                unstable_part_ids,
                key=lambda part_id: _unstable_part_completion_rank(
                    part_id,
                    remaining,
                    state,
                    process_model,
                ),
            )[:focus_count]
        )
    return tuple(
        unit
        for unit in remaining
        if unit_process_part_ids(unit, process_model) & unstable_part_ids
    )


def _unstable_part_completion_rank(
    part_id: str,
    remaining: list[CuttingUnit],
    state: IncrementalMetricsState,
    process_model: CuttingProcessModel,
) -> tuple[int, float, str]:
    remaining_ids = (
        process_model.part_span_ids.get(part_id, frozenset())
        - state.processed_span_ids
        if process_model.part_span_ids
        else process_model.part_segment_ids.get(part_id, frozenset())
        - state.processed_segments
    )
    nearest_distance = min(
        (
            min(
                euclidean_distance(state.current_point, unit.start),
                euclidean_distance(state.current_point, unit.end)
                if unit.is_reversible
                else float("inf"),
            )
            for unit in remaining
            if part_id in unit_process_part_ids(unit, process_model)
        ),
        default=float("inf"),
    )
    return (len(remaining_ids), nearest_distance, part_id)


def process_aware_candidate_units(
    remaining: list[CuttingUnit],
    state: IncrementalMetricsState,
    process_model: CuttingProcessModel | None,
    candidate_pool_size: int | None,
    unstable_completion_focus_count: int | None = None,
) -> tuple[CuttingUnit, ...]:
    completion_units = completion_candidate_units(
        remaining,
        state,
        process_model,
        focus_count=unstable_completion_focus_count,
    )
    if completion_units:
        return completion_units
    return nearest_candidate_units(
        remaining,
        current_point=state.current_point,
        candidate_pool_size=candidate_pool_size,
    )


def process_aware_unit_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
    candidate_pool_size: int | None = None,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple[DirectedUnitCandidate, ...]:
    repeat_cut_policy = validate_repeat_cut_policy(repeat_cut_policy)
    remaining = list(units)
    directed_candidate_cache = {
        unit.unit_id: directed_unit_candidates(unit)
        for unit in units
    }
    state = IncrementalMetricsState(current_point=tool.start_point)
    previous_unit: CuttingUnit | None = None
    ordered: list[DirectedUnitCandidate] = []

    while remaining:
        candidate_units = process_aware_candidate_units(
            remaining,
            state=state,
            process_model=process_model,
            candidate_pool_size=candidate_pool_size,
        )
        best_candidate: DirectedUnitCandidate | None = None
        best_state: IncrementalMetricsState | None = None
        best_key: tuple | None = None

        directed_candidates = tuple(
            directed_candidate
            for unit in candidate_units
            for directed_candidate in directed_candidate_cache[unit.unit_id]
        )
        exact_candidate_limit = process_aware_exact_candidate_limit(candidate_pool_size)
        if (
            exact_candidate_limit is not None
            and not state.unstable_part_ids
            and len(directed_candidates) > exact_candidate_limit
        ):
            directed_candidates = tuple(
                sorted(
                    directed_candidates,
                    key=lambda candidate: (
                        transition_score(
                            candidate,
                            current_point=state.current_point,
                            previous_direction=state.current_direction,
                            previous_unit=previous_unit,
                        ),
                        euclidean_distance(state.current_point, candidate.start),
                        candidate.unit.unit_id,
                        candidate.is_reversed,
                    ),
                )[:exact_candidate_limit]
            )

        for candidate in directed_candidates:
            next_state = apply_candidate_incremental(
                candidate,
                state,
                panel,
                tool,
                process_model=process_model,
            )
            key = (
                process_state_metric_key(
                    next_state,
                    repeat_cut_policy=repeat_cut_policy,
                ),
                transition_score(
                    candidate,
                    current_point=state.current_point,
                    previous_direction=state.current_direction,
                    previous_unit=previous_unit,
                ),
                candidate.unit.unit_id,
                candidate.is_reversed,
            )
            if best_key is None or key < best_key:
                best_candidate = candidate
                best_state = next_state
                best_key = key

        if best_candidate is None or best_state is None:
            break

        ordered.append(best_candidate)
        remaining.remove(best_candidate.unit)
        previous_unit = best_candidate.unit
        state = best_state

    return tuple(ordered)


def _beam_markov_state_signature(node: BeamSearchNode) -> tuple:
    """Return every state component that can affect a future transition.

    Accumulated metrics are excluded: for an identical Markov state and
    identical remaining units, the lexicographically better metric prefix
    dominates because each continuation has the same future transition deltas.
    """

    return (
        tuple(sorted(unit.unit_id for unit in node.remaining_units)),
        node.state.current_point,
        node.state.current_direction,
        node.state.is_tool_down,
        node.state.current_cutting_unit_id,
        tuple(sorted(node.state.processed_segments)),
        tuple(sorted(node.state.processed_span_ids)),
        tuple(sorted(node.state.unstable_part_ids)),
        tuple(sorted(node.state.released_part_ids)),
        node.state.processed_polygons,
        node.state.processed_polygon_bounds,
    )


def _unit_endpoint_distance(first: CuttingUnit, second: CuttingUnit) -> float:
    return min(
        euclidean_distance(first.start, second.start),
        euclidean_distance(first.start, second.end),
        euclidean_distance(first.end, second.start),
        euclidean_distance(first.end, second.end),
    )


def _minimum_incident_distances(
    units: tuple[CuttingUnit, ...],
) -> dict[str, float]:
    if len(units) < 2:
        return {unit.unit_id: 0.0 for unit in units}
    return {
        unit.unit_id: min(
            _unit_endpoint_distance(unit, other)
            for other in units
            if other.unit_id != unit.unit_id
        )
        for unit in units
    }


def state_dependent_travel_lower_bound(
    current_point: Point,
    remaining_units: tuple[CuttingUnit, ...],
    minimum_incident_by_unit: dict[str, float] | None = None,
) -> float:
    """Lower-bound remaining air travel by a connection and degree relaxation.

    The relaxation ignores orientation, release obstacles, detours, and tool
    events. Every executable route must connect the current point to the
    remaining unit set and connect all remaining units. Half the sum of each
    remaining unit's globally minimum incident distance lower-bounds a spanning
    tree, even after some neighboring units have already been removed.
    """

    if not remaining_units:
        return 0.0
    connection = min(
        min(
            euclidean_distance(current_point, unit.start),
            euclidean_distance(current_point, unit.end),
        )
        for unit in remaining_units
    )
    if len(remaining_units) == 1:
        return connection
    incident_distances = (
        minimum_incident_by_unit
        if minimum_incident_by_unit is not None
        else _minimum_incident_distances(remaining_units)
    )
    spanning_tree_lower_bound = 0.5 * sum(
        incident_distances[unit.unit_id] for unit in remaining_units
    )
    return connection + spanning_tree_lower_bound


def _beam_prefix_lower_bound_key(
    node: BeamSearchNode,
    tool: ToolConfig,
    repeat_cut_policy: str,
    minimum_incident_by_unit: dict[str, float],
) -> tuple:
    metrics = node.state.metrics
    support_state_priority = (
        metrics.stability_penalty + float(len(node.state.unstable_part_ids))
    )
    remaining_cutting_length = sum(
        euclidean_distance(unit.start, unit.end) for unit in node.remaining_units
    )
    travel_distance_lower_bound = state_dependent_travel_lower_bound(
        node.state.current_point,
        node.remaining_units,
        minimum_incident_by_unit,
    )
    minimum_travel_weight = min(
        tool.low_clearance_travel_weight,
        tool.detour_travel_weight,
        tool.safe_lift_travel_weight,
    )
    travel_cost_lower_bound = (
        metrics.travel_mode_cost
        + travel_distance_lower_bound * minimum_travel_weight
    )
    machining_cost_lower_bound = (
        metrics.cutting_length
        + remaining_cutting_length
        + travel_cost_lower_bound
    )
    tool_events = metrics.pierce_count + metrics.lift_count + metrics.safe_lift_count
    if repeat_cut_policy == "off":
        return (
            metrics.hard_penalty,
            support_state_priority,
            machining_cost_lower_bound,
            tool_events,
            travel_cost_lower_bound,
            metrics.air_move_distance + travel_distance_lower_bound,
            metrics.turn_penalty,
            float("-inf"),
        )
    if repeat_cut_policy == "soft":
        return (
            metrics.hard_penalty,
            support_state_priority,
            machining_cost_lower_bound + metrics.repeated_cut_length,
            metrics.repeated_cut_segment_count,
            metrics.redundant_cut_action_count,
            tool_events,
            travel_cost_lower_bound,
            metrics.air_move_distance + travel_distance_lower_bound,
            metrics.turn_penalty,
            float("-inf"),
        )
    return (
        metrics.hard_penalty,
        support_state_priority,
        metrics.repeated_cut_segment_count,
        metrics.repeated_cut_length,
        metrics.redundant_cut_action_count,
        machining_cost_lower_bound,
        tool_events,
        travel_cost_lower_bound,
        metrics.air_move_distance + travel_distance_lower_bound,
        metrics.turn_penalty,
        float("-inf"),
    )


def _beam_node_part_ids(
    node: BeamSearchNode,
    process_model: CuttingProcessModel | None,
) -> tuple[str, ...]:
    if node.previous_unit is None:
        return ()
    process_part_ids = unit_process_part_ids(node.previous_unit, process_model)
    if process_part_ids:
        return tuple(sorted(process_part_ids))
    return unit_part_ids(node.previous_unit)


def _beam_diversity_signature(
    node: BeamSearchNode,
    process_model: CuttingProcessModel | None,
) -> tuple:
    return (
        _beam_node_part_ids(node, process_model),
        tuple(sorted(node.state.unstable_part_ids)),
        len(node.state.released_part_ids),
        node.state.current_direction,
    )


def _select_beam_nodes(
    ranked_nodes: list[tuple[tuple, BeamSearchNode]],
    beam_width: int,
    diversity_bucket_limit: int | None,
    process_model: CuttingProcessModel | None,
) -> tuple[tuple[BeamSearchNode, ...], int, int]:
    ordered = sorted(ranked_nodes, key=lambda item: item[0])
    if diversity_bucket_limit is None or diversity_bucket_limit <= 0:
        return tuple(node for _, node in ordered[:beam_width]), 0, 0

    selected: list[BeamSearchNode] = []
    selected_ids: set[int] = set()
    bucket_counts: dict[tuple, int] = {}
    diversity_pruned_count = 0
    for _, node in ordered:
        signature = _beam_diversity_signature(node, process_model)
        if bucket_counts.get(signature, 0) >= diversity_bucket_limit:
            diversity_pruned_count += 1
            continue
        selected.append(node)
        selected_ids.add(id(node))
        bucket_counts[signature] = bucket_counts.get(signature, 0) + 1
        if len(selected) >= beam_width:
            return tuple(selected), diversity_pruned_count, 0

    fallback_added_count = 0
    for _, node in ordered:
        if id(node) in selected_ids:
            continue
        selected.append(node)
        fallback_added_count += 1
        if len(selected) >= beam_width:
            break
    return tuple(selected), diversity_pruned_count, fallback_added_count


def _dual_queue_ranked_nodes(
    ranked_nodes: list[tuple[tuple, tuple, BeamSearchNode]],
    beam_width: int,
    lower_bound_slot_fraction: float,
) -> tuple[list[tuple[tuple, BeamSearchNode]], int, int]:
    """Interleave protected process-state and lower-bound queue seeds.

    Both queues rank the same evaluated child nodes. The function changes only
    which nodes receive the finite beam slots; it does not request additional
    process-evaluator calls.
    """

    process_order = sorted(ranked_nodes, key=lambda item: item[0])
    lower_bound_order = sorted(ranked_nodes, key=lambda item: item[1])
    lower_bound_quota = min(
        beam_width,
        max(0, beam_width - ceil(beam_width * (1.0 - lower_bound_slot_fraction))),
    )
    process_quota = beam_width - lower_bound_quota
    ordered: list[BeamSearchNode] = []
    selected_ids: set[int] = set()

    def append_unique(
        source: list[tuple[tuple, tuple, BeamSearchNode]],
        quota: int,
    ) -> int:
        added = 0
        for _, _, node in source:
            if id(node) in selected_ids:
                continue
            ordered.append(node)
            selected_ids.add(id(node))
            added += 1
            if added >= quota:
                break
        return added

    process_seed_count = append_unique(process_order, process_quota)
    lower_bound_seed_count = append_unique(lower_bound_order, lower_bound_quota)

    process_index = 0
    bound_index = 0
    while len(ordered) < len(ranked_nodes):
        added = False
        while process_index < len(process_order):
            node = process_order[process_index][2]
            process_index += 1
            if id(node) in selected_ids:
                continue
            ordered.append(node)
            selected_ids.add(id(node))
            added = True
            break
        while bound_index < len(lower_bound_order):
            node = lower_bound_order[bound_index][2]
            bound_index += 1
            if id(node) in selected_ids:
                continue
            ordered.append(node)
            selected_ids.add(id(node))
            added = True
            break
        if not added:
            break

    return (
        [((index,), node) for index, node in enumerate(ordered)],
        process_seed_count,
        lower_bound_seed_count,
    )


def _beam_node_rank(
    node: BeamSearchNode,
    tool: ToolConfig,
    minimum_incident_by_unit: dict[str, float],
    transition_cost: float = 0.0,
    is_reversed: bool = False,
    use_lower_bound_rank: bool = False,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple:
    process_key = (
        _beam_prefix_lower_bound_key(
            node,
            tool,
            repeat_cut_policy,
            minimum_incident_by_unit,
        )
        if use_lower_bound_rank
        else process_state_metric_key(node.state, repeat_cut_policy=repeat_cut_policy)
    )
    return (
        process_key,
        transition_cost,
        len(node.remaining_units),
        node.previous_unit.unit_id if node.previous_unit is not None else "",
        is_reversed,
    )


def _beam_expansion_rank(
    node: BeamSearchNode,
    candidate: DirectedUnitCandidate,
    transition_cost: float,
    process_model: CuttingProcessModel | None = None,
    completion_aware_prerank: bool = False,
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> tuple:
    unstable_overlap_count = 0
    covered_segment_count = 0
    if completion_aware_prerank:
        candidate_part_ids = unit_process_part_ids(candidate.unit, process_model)
        unstable_overlap_count = len(candidate_part_ids & node.state.unstable_part_ids)
        covered_segment_count = unit_coverage_count(candidate.unit)
    return (
        process_state_metric_key(node.state, repeat_cut_policy=repeat_cut_policy),
        -unstable_overlap_count,
        -covered_segment_count,
        transition_cost,
        euclidean_distance(node.state.current_point, candidate.start),
        len(node.remaining_units),
        candidate.unit.unit_id,
        candidate.is_reversed,
    )


def _limited_directed_candidates(
    candidate_units: tuple[CuttingUnit, ...],
    directed_candidate_cache: dict[str, tuple[DirectedUnitCandidate, ...]],
    state: IncrementalMetricsState,
    previous_unit: CuttingUnit | None,
    max_expansions: int | None,
    process_model: CuttingProcessModel | None,
    completion_aware_prerank: bool = False,
) -> tuple[tuple[DirectedUnitCandidate, float], ...]:
    candidates = tuple(
        (
            directed_candidate,
            transition_score(
                directed_candidate,
                current_point=state.current_point,
                previous_direction=state.current_direction,
                previous_unit=previous_unit,
            ),
        )
        for unit in candidate_units
        for directed_candidate in directed_candidate_cache[unit.unit_id]
    )
    unstable_part_ids = state.unstable_part_ids
    ordered = sorted(
        candidates,
        key=lambda item: (
            (
                -len(unit_process_part_ids(item[0].unit, process_model) & unstable_part_ids)
                if completion_aware_prerank
                else 0
            ),
            -unit_coverage_count(item[0].unit) if completion_aware_prerank else 0,
            item[1],
            euclidean_distance(state.current_point, item[0].start),
            item[0].unit.unit_id,
            item[0].is_reversed,
        ),
    )
    if max_expansions is None:
        return tuple(ordered)
    return tuple(ordered[:max_expansions])


def _effective_layer_expansion_limit(
    config: BeamSearchConfig,
    unstable_parent_count: int,
) -> int | None:
    if config.max_layer_expansions is None:
        return None

    base_limit = max(0, config.max_layer_expansions)
    if unstable_parent_count <= 0:
        return base_limit

    multiplier = max(1.0, config.unstable_layer_expansion_multiplier)
    bonus = max(0, config.unstable_layer_expansion_bonus)
    return max(base_limit, ceil(base_limit * multiplier) + bonus)


def _limited_beam_expansions(
    beam: tuple[BeamSearchNode, ...],
    directed_candidate_cache: dict[str, tuple[DirectedUnitCandidate, ...]],
    process_model: CuttingProcessModel | None,
    config: BeamSearchConfig,
) -> tuple[tuple[BeamSearchExpansion, ...], int, int, int, int, int]:
    parent_expansions: list[tuple[BeamSearchNode, tuple[BeamSearchExpansion, ...]]] = []
    raw_expansion_count = 0
    unstable_parent_count = sum(1 for node in beam if node.state.unstable_part_ids)
    for node in beam:
        candidate_units = process_aware_candidate_units(
            list(node.remaining_units),
            state=node.state,
            process_model=process_model,
            candidate_pool_size=config.candidate_pool_size,
            unstable_completion_focus_count=config.unstable_completion_focus_count,
        )
        node_expansions: list[BeamSearchExpansion] = []
        for candidate, transition_cost in _limited_directed_candidates(
            candidate_units,
            directed_candidate_cache,
            node.state,
            node.previous_unit,
            config.max_expansions_per_node,
            process_model,
            config.completion_aware_prerank,
        ):
            node_expansions.append(
                BeamSearchExpansion(
                    parent=node,
                    candidate=candidate,
                    transition_cost=transition_cost,
                    rank=_beam_expansion_rank(
                        node,
                        candidate,
                        transition_cost,
                        process_model=process_model,
                        completion_aware_prerank=config.completion_aware_prerank,
                        repeat_cut_policy=config.repeat_cut_policy,
                    ),
                )
            )
        raw_expansion_count += len(node_expansions)
        parent_expansions.append((node, tuple(node_expansions)))

    expansions = [
        expansion
        for _, node_expansions in parent_expansions
        for expansion in node_expansions
    ]
    expansions.sort(key=lambda expansion: expansion.rank)
    layer_expansion_limit = _effective_layer_expansion_limit(
        config,
        unstable_parent_count=unstable_parent_count,
    )
    if layer_expansion_limit is None:
        return tuple(expansions), 0, 0, 0, raw_expansion_count, unstable_parent_count

    selected: list[BeamSearchExpansion] = []
    selected_ids: set[int] = set()
    quota_added_count = 0
    parent_quota = max(0, config.min_expansions_per_parent)
    unstable_parent_quota = max(parent_quota, config.unstable_min_expansions_per_parent)

    if parent_quota > 0 or unstable_parent_quota > 0:
        for node, node_expansions in parent_expansions:
            quota = (
                unstable_parent_quota
                if node.state.unstable_part_ids
                else parent_quota
            )
            if quota <= 0:
                continue
            for expansion in node_expansions[:quota]:
                if len(selected) >= layer_expansion_limit:
                    break
                selected.append(expansion)
                selected_ids.add(id(expansion))
                quota_added_count += 1
            if len(selected) >= layer_expansion_limit:
                break

    for expansion in expansions:
        if len(selected) >= layer_expansion_limit:
            break
        if id(expansion) in selected_ids:
            continue
        selected.append(expansion)
        selected_ids.add(id(expansion))

    layer_pruned_count = max(0, raw_expansion_count - len(selected))
    quota_pruned_count = max(
        0,
        sum(
            min(
                (
                    unstable_parent_quota
                    if node.state.unstable_part_ids
                    else parent_quota
                ),
                len(node_expansions),
            )
            for node, node_expansions in parent_expansions
        )
        - quota_added_count,
    )
    return (
        tuple(selected),
        layer_pruned_count,
        quota_added_count,
        quota_pruned_count,
        layer_expansion_limit,
        unstable_parent_count,
    )


def _beam_layer_diagnostics(
    depth: int,
    input_beam_count: int,
    unstable_input_prefix_count: int,
    raw_expansion_count: int,
    effective_layer_expansion_limit: int,
    layer_expansion_count: int,
    layer_pruned_count: int,
    parent_quota_added_count: int,
    parent_quota_pruned_count: int,
    evaluated_node_count: int,
    duplicate_pruned_count: int,
    state_dominance_pruned_count: int,
    process_queue_seed_count: int,
    lower_bound_queue_seed_count: int,
    diversity_pruned_count: int,
    fallback_added_count: int,
    output_beam: tuple[BeamSearchNode, ...],
    repeat_cut_policy: str = DEFAULT_REPEAT_CUT_POLICY,
) -> BeamLayerDiagnostics:
    if output_beam:
        metrics = tuple(finalize_metrics(node.state) for node in output_beam)
        best_by_process = min(
            metrics,
            key=lambda item: process_metric_key(
                item,
                repeat_cut_policy=repeat_cut_policy,
            ),
        )
        worst_stability = max(metric.stability_penalty for metric in metrics)
        worst_travel = max(metric.travel_mode_cost for metric in metrics)
        released_max = max(len(node.state.released_part_ids) for node in output_beam)
        unstable_count = sum(1 for node in output_beam if node.state.unstable_part_ids)
    else:
        best_by_process = PathMetrics()
        worst_stability = 0.0
        worst_travel = 0.0
        released_max = 0
        unstable_count = 0

    return BeamLayerDiagnostics(
        depth=depth,
        input_beam_count=input_beam_count,
        unstable_input_prefix_count=unstable_input_prefix_count,
        raw_expansion_count=raw_expansion_count,
        effective_layer_expansion_limit=effective_layer_expansion_limit,
        layer_expansion_count=layer_expansion_count,
        layer_pruned_count=layer_pruned_count,
        parent_quota_added_count=parent_quota_added_count,
        parent_quota_pruned_count=parent_quota_pruned_count,
        evaluated_node_count=evaluated_node_count,
        duplicate_pruned_count=duplicate_pruned_count,
        state_dominance_pruned_count=state_dominance_pruned_count,
        process_queue_seed_count=process_queue_seed_count,
        lower_bound_queue_seed_count=lower_bound_queue_seed_count,
        diversity_pruned_count=diversity_pruned_count,
        fallback_added_count=fallback_added_count,
        output_beam_count=len(output_beam),
        best_hard_penalty=best_by_process.hard_penalty,
        best_stability_penalty=best_by_process.stability_penalty,
        best_travel_mode_cost=best_by_process.travel_mode_cost,
        best_air_move_distance=best_by_process.air_move_distance,
        worst_stability_penalty=worst_stability,
        worst_travel_mode_cost=worst_travel,
        unstable_prefix_count=unstable_count,
        released_part_count_max=released_max,
    )


def process_aware_beam_search_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
    config: BeamSearchConfig | None = None,
) -> BeamSearchResult:
    if config is None:
        config = BeamSearchConfig()
    if config.beam_width < 1:
        raise ValueError("beam_width must be at least 1")

    directed_candidate_cache = {
        unit.unit_id: directed_unit_candidates(unit)
        for unit in units
    }
    minimum_incident_by_unit = (
        _minimum_incident_distances(units)
        if config.use_lower_bound_rank or config.lower_bound_slot_fraction > 0.0
        else {}
    )
    beam: tuple[BeamSearchNode, ...] = (
        BeamSearchNode(
            directed_units=(),
            remaining_units=units,
            state=IncrementalMetricsState(current_point=tool.start_point),
        ),
    )
    expanded_nodes = 0
    diagnostics: list[BeamLayerDiagnostics] = []

    for depth in range(len(units)):
        next_nodes: list[tuple[tuple, tuple, BeamSearchNode]] = []
        input_beam_count = len(beam)
        (
            expansions,
            layer_pruned_count,
            parent_quota_added_count,
            parent_quota_pruned_count,
            effective_layer_expansion_limit,
            unstable_input_prefix_count,
        ) = _limited_beam_expansions(
            beam,
            directed_candidate_cache,
            process_model,
            config,
        )
        raw_expansion_count = len(expansions) + layer_pruned_count
        for expansion in expansions:
            candidate = expansion.candidate
            node = expansion.parent
            next_state = apply_candidate_incremental(
                candidate,
                node.state,
                panel,
                tool,
                process_model=process_model,
            )
            remaining = tuple(
                unit
                for unit in node.remaining_units
                if unit.unit_id != candidate.unit.unit_id
            )
            next_node = BeamSearchNode(
                directed_units=node.directed_units + (candidate,),
                remaining_units=remaining,
                state=next_state,
                previous_unit=candidate.unit,
            )
            next_nodes.append(
                (
                    _beam_node_rank(
                        next_node,
                        tool,
                        minimum_incident_by_unit,
                        transition_cost=expansion.transition_cost,
                        is_reversed=candidate.is_reversed,
                        use_lower_bound_rank=False,
                        repeat_cut_policy=config.repeat_cut_policy,
                    ),
                    _beam_node_rank(
                        next_node,
                        tool,
                        minimum_incident_by_unit,
                        transition_cost=expansion.transition_cost,
                        is_reversed=candidate.is_reversed,
                        use_lower_bound_rank=(
                            config.use_lower_bound_rank
                            or config.lower_bound_slot_fraction > 0.0
                        ),
                        repeat_cut_policy=config.repeat_cut_policy,
                    ),
                    next_node,
                )
            )
            expanded_nodes += 1

        if not next_nodes:
            diagnostics.append(
                _beam_layer_diagnostics(
                    depth=depth,
                    input_beam_count=input_beam_count,
                    unstable_input_prefix_count=unstable_input_prefix_count,
                    raw_expansion_count=raw_expansion_count,
                    effective_layer_expansion_limit=effective_layer_expansion_limit,
                    layer_expansion_count=len(expansions),
                    layer_pruned_count=layer_pruned_count,
                    parent_quota_added_count=parent_quota_added_count,
                    parent_quota_pruned_count=parent_quota_pruned_count,
                    evaluated_node_count=0,
                    duplicate_pruned_count=0,
                    state_dominance_pruned_count=0,
                    process_queue_seed_count=0,
                    lower_bound_queue_seed_count=0,
                    diversity_pruned_count=0,
                    fallback_added_count=0,
                    output_beam=(),
                    repeat_cut_policy=config.repeat_cut_policy,
                )
            )
            break

        deduplicated: dict[
            tuple,
            tuple[tuple, tuple, BeamSearchNode, tuple],
        ] = {}
        duplicate_pruned_count = 0
        state_dominance_pruned_count = 0
        for process_rank, lower_bound_rank, node in next_nodes:
            signature = (
                _beam_markov_state_signature(node)
                if config.use_state_dominance
                else (
                    tuple(sorted(unit.unit_id for unit in node.remaining_units)),
                    node.state.current_point,
                    node.state.current_direction,
                    tuple(sorted(node.state.unstable_part_ids)),
                    tuple(sorted(node.state.released_part_ids)),
                )
            )
            cost_key = process_metric_key(
                node.state.metrics,
                repeat_cut_policy=config.repeat_cut_policy,
            )
            incumbent = deduplicated.get(signature)
            if incumbent is None:
                deduplicated[signature] = (
                    process_rank,
                    lower_bound_rank,
                    node,
                    cost_key,
                )
                continue
            (
                incumbent_process_rank,
                incumbent_lower_bound_rank,
                _,
                incumbent_cost_key,
            ) = incumbent
            active_rank = (
                lower_bound_rank if config.use_lower_bound_rank else process_rank
            )
            incumbent_active_rank = (
                incumbent_lower_bound_rank
                if config.use_lower_bound_rank
                else incumbent_process_rank
            )
            if not config.use_state_dominance:
                duplicate_pruned_count += 1
                if active_rank < incumbent_active_rank:
                    deduplicated[signature] = (
                        process_rank,
                        lower_bound_rank,
                        node,
                        cost_key,
                    )
                continue
            if cost_key == incumbent_cost_key:
                duplicate_pruned_count += 1
            else:
                state_dominance_pruned_count += 1
            if (cost_key, process_rank, lower_bound_rank) < (
                incumbent_cost_key,
                incumbent_process_rank,
                incumbent_lower_bound_rank,
            ):
                deduplicated[signature] = (
                    process_rank,
                    lower_bound_rank,
                    node,
                    cost_key,
                )

        process_queue_seed_count = 0
        lower_bound_queue_seed_count = 0
        if config.lower_bound_slot_fraction > 0.0:
            (
                selection_nodes,
                process_queue_seed_count,
                lower_bound_queue_seed_count,
            ) = _dual_queue_ranked_nodes(
                [
                    (process_rank, lower_bound_rank, node)
                    for process_rank, lower_bound_rank, node, _ in deduplicated.values()
                ],
                config.beam_width,
                config.lower_bound_slot_fraction,
            )
        else:
            selection_nodes = [
                (
                    lower_bound_rank if config.use_lower_bound_rank else process_rank,
                    node,
                )
                for process_rank, lower_bound_rank, node, _ in deduplicated.values()
            ]
        beam, diversity_pruned_count, fallback_added_count = _select_beam_nodes(
            selection_nodes,
            beam_width=config.beam_width,
            diversity_bucket_limit=config.diversity_bucket_limit,
            process_model=process_model,
        )
        diagnostics.append(
            _beam_layer_diagnostics(
                depth=depth,
                input_beam_count=input_beam_count,
                unstable_input_prefix_count=unstable_input_prefix_count,
                raw_expansion_count=raw_expansion_count,
                effective_layer_expansion_limit=effective_layer_expansion_limit,
                layer_expansion_count=len(expansions),
                layer_pruned_count=layer_pruned_count,
                parent_quota_added_count=parent_quota_added_count,
                parent_quota_pruned_count=parent_quota_pruned_count,
                evaluated_node_count=len(next_nodes),
                duplicate_pruned_count=duplicate_pruned_count,
                state_dominance_pruned_count=state_dominance_pruned_count,
                process_queue_seed_count=process_queue_seed_count,
                lower_bound_queue_seed_count=lower_bound_queue_seed_count,
                diversity_pruned_count=diversity_pruned_count,
                fallback_added_count=fallback_added_count,
                output_beam=beam,
                repeat_cut_policy=config.repeat_cut_policy,
            )
        )

    if not beam:
        actions: tuple[CuttingAction, ...] = ()
        return BeamSearchResult(
            directed_units=(),
            actions=actions,
            metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
            expanded_nodes=expanded_nodes,
            diagnostics=tuple(diagnostics),
        )

    final_nodes = sorted(
        beam,
        key=lambda node: (
            len(node.remaining_units),
            process_metric_key(
                finalize_metrics(node.state),
                repeat_cut_policy=config.repeat_cut_policy,
            ),
            tuple(candidate.unit.unit_id for candidate in node.directed_units),
        ),
    )
    best = final_nodes[0]
    actions = materialize_action_clearance(
        directed_units_to_actions(best.directed_units, start_point=tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return BeamSearchResult(
        directed_units=best.directed_units,
        actions=actions,
        metrics=finalize_metrics(best.state),
        expanded_nodes=expanded_nodes,
        diagnostics=tuple(diagnostics),
    )


def _prefix_mcts_candidate_expansions(
    node: PrefixBeamMCTSNode,
    directed_candidate_cache: dict[str, tuple[DirectedUnitCandidate, ...]],
    process_model: CuttingProcessModel | None,
    config: PrefixBeamMCTSConfig,
) -> list[tuple[DirectedUnitCandidate, float]]:
    if node.untried is None:
        candidate_units = process_aware_candidate_units(
            list(node.beam_node.remaining_units),
            state=node.beam_node.state,
            process_model=process_model,
            candidate_pool_size=config.candidate_pool_size,
            unstable_completion_focus_count=config.unstable_completion_focus_count,
        )
        node.untried = list(
            _limited_directed_candidates(
                candidate_units,
                directed_candidate_cache,
                node.beam_node.state,
                node.beam_node.previous_unit,
                config.max_expansions_per_node,
                process_model,
                config.completion_aware_prerank,
            )
        )
    return node.untried


def _prefix_mcts_expand_child(
    node: PrefixBeamMCTSNode,
    candidate: DirectedUnitCandidate,
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None,
) -> PrefixBeamMCTSNode:
    next_state = apply_candidate_incremental(
        candidate,
        node.beam_node.state,
        panel,
        tool,
        process_model=process_model,
    )
    remaining = tuple(
        unit
        for unit in node.beam_node.remaining_units
        if unit.unit_id != candidate.unit.unit_id
    )
    child = PrefixBeamMCTSNode(
        beam_node=BeamSearchNode(
            directed_units=node.beam_node.directed_units + (candidate,),
            remaining_units=remaining,
            state=next_state,
            previous_unit=candidate.unit,
        ),
        parent=node,
    )
    node.children.append(child)
    return child


def _prefix_mcts_select_child(
    node: PrefixBeamMCTSNode,
    config: PrefixBeamMCTSConfig,
) -> PrefixBeamMCTSNode | None:
    if not node.children:
        return None
    parent_visits = max(1, node.visits)

    def score(child: PrefixBeamMCTSNode) -> tuple[float, str]:
        if child.visits <= 0:
            return (float("inf"), "")
        exploitation = -child.best_energy
        exploration = config.exploration_weight * sqrt(
            log(parent_visits + 1.0) / float(child.visits)
        )
        previous_unit_id = (
            child.beam_node.previous_unit.unit_id
            if child.beam_node.previous_unit is not None
            else ""
        )
        return (exploitation + exploration, previous_unit_id)

    return max(node.children, key=score)


def _prefix_mcts_rollout(
    start_node: PrefixBeamMCTSNode,
    directed_candidate_cache: dict[str, tuple[DirectedUnitCandidate, ...]],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None,
    config: PrefixBeamMCTSConfig,
    rng: random.Random,
) -> tuple[tuple[DirectedUnitCandidate, ...], PathMetrics]:
    current = start_node.beam_node
    while current.remaining_units:
        candidate_units = process_aware_candidate_units(
            list(current.remaining_units),
            state=current.state,
            process_model=process_model,
            candidate_pool_size=config.candidate_pool_size,
            unstable_completion_focus_count=config.unstable_completion_focus_count,
        )
        directed_candidates = _limited_directed_candidates(
            candidate_units,
            directed_candidate_cache,
            current.state,
            current.previous_unit,
            config.max_expansions_per_node,
            process_model,
            config.completion_aware_prerank,
        )
        if not directed_candidates:
            break
        if len(directed_candidates) == 1:
            candidate = directed_candidates[0][0]
        else:
            top_k = min(config.rollout_top_k, len(directed_candidates))
            candidate = directed_candidates[rng.randrange(top_k)][0]
        next_state = apply_candidate_incremental(
            candidate,
            current.state,
            panel,
            tool,
            process_model=process_model,
        )
        remaining = tuple(
            unit
            for unit in current.remaining_units
            if unit.unit_id != candidate.unit.unit_id
        )
        current = BeamSearchNode(
            directed_units=current.directed_units + (candidate,),
            remaining_units=remaining,
            state=next_state,
            previous_unit=candidate.unit,
        )
    return current.directed_units, finalize_metrics(current.state)


def _prefix_mcts_backpropagate(
    node: PrefixBeamMCTSNode,
    directed_units: tuple[DirectedUnitCandidate, ...],
    metrics: PathMetrics,
    repeat_cut_policy: str,
) -> None:
    key = process_metric_key(metrics, repeat_cut_policy=repeat_cut_policy)
    energy = process_metric_energy(metrics, repeat_cut_policy=repeat_cut_policy)
    current: PrefixBeamMCTSNode | None = node
    while current is not None:
        current.visits += 1
        if current.best_key is None or key < current.best_key:
            current.best_key = key
            current.best_energy = energy
            current.best_directed_units = directed_units
            current.best_metrics = metrics
        current = current.parent


def process_aware_prefix_beam_mcts_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
    config: PrefixBeamMCTSConfig | None = None,
) -> BeamSearchResult:
    """Process-aware prefix-tree Monte Carlo baseline.

    This baseline shares the deterministic process evaluator with beam search,
    SA, and GA, but samples prefix completions through a UCT-style tree policy.
    It is intended as a stronger high-order search comparator, not as the main
    event-gated selector.
    """

    if config is None:
        config = PrefixBeamMCTSConfig()

    if not units:
        actions: tuple[CuttingAction, ...] = ()
        return BeamSearchResult(
            directed_units=(),
            actions=actions,
            metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
            expanded_nodes=0,
        )

    rng = random.Random(config.seed)
    directed_candidate_cache = {
        unit.unit_id: directed_unit_candidates(unit)
        for unit in units
    }
    root = PrefixBeamMCTSNode(
        beam_node=BeamSearchNode(
            directed_units=(),
            remaining_units=units,
            state=IncrementalMetricsState(current_point=tool.start_point),
        )
    )
    expanded_nodes = 0

    for _ in range(config.iterations):
        node = root
        while node.beam_node.remaining_units:
            untried = _prefix_mcts_candidate_expansions(
                node,
                directed_candidate_cache,
                process_model,
                config,
            )
            if untried:
                top_k = min(config.rollout_top_k, len(untried))
                index = 0 if top_k == 1 else rng.randrange(top_k)
                candidate, _ = untried.pop(index)
                node = _prefix_mcts_expand_child(
                    node,
                    candidate,
                    panel,
                    tool,
                    process_model,
                )
                expanded_nodes += 1
                break
            selected = _prefix_mcts_select_child(node, config)
            if selected is None:
                break
            node = selected

        directed_units, metrics = (
            (node.beam_node.directed_units, finalize_metrics(node.beam_node.state))
            if not node.beam_node.remaining_units
            else _prefix_mcts_rollout(
                node,
                directed_candidate_cache,
                panel,
                tool,
                process_model,
                config,
                rng,
            )
        )
        _prefix_mcts_backpropagate(
            node,
            directed_units,
            metrics,
            repeat_cut_policy=config.repeat_cut_policy,
        )

    if root.best_key is None or root.best_metrics is None:
        directed_units = process_aware_unit_order(
            units,
            panel=panel,
            tool=tool,
            process_model=process_model,
            candidate_pool_size=config.candidate_pool_size,
            repeat_cut_policy=config.repeat_cut_policy,
        )
        actions, metrics = evaluate_directed_units(
            directed_units,
            panel,
            tool,
            process_model=process_model,
        )
    else:
        directed_units = root.best_directed_units
        metrics = root.best_metrics
        actions = materialize_action_clearance(
            directed_units_to_actions(directed_units, start_point=tool.start_point),
            panel,
            tool,
            process_model=process_model,
        )

    return BeamSearchResult(
        directed_units=directed_units,
        actions=actions,
        metrics=metrics,
        expanded_nodes=expanded_nodes,
    )


def nearest_neighbor_unit_order(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
) -> tuple[DirectedUnitCandidate, ...]:
    remaining = list(units)
    directed_candidate_cache = {
        unit.unit_id: directed_unit_candidates(unit)
        for unit in units
    }
    current_point = start_point
    ordered: list[DirectedUnitCandidate] = []

    while remaining:
        best_unit = min(
            remaining,
            key=lambda unit: min(
                euclidean_distance(current_point, unit.start),
                euclidean_distance(current_point, unit.end)
                if unit.is_reversible
                else float("inf"),
            ),
        )
        best = min(
            directed_candidate_cache[best_unit.unit_id],
            key=lambda candidate: euclidean_distance(current_point, candidate.start),
        )
        ordered.append(best)
        remaining.remove(best_unit)
        current_point = best.end

    return tuple(ordered)


def swap_neighbor_moves(
    directed_units: tuple[DirectedUnitCandidate, ...],
    max_span: int | None = None,
    max_neighbors: int | None = None,
) -> tuple[NeighborMove, ...]:
    neighbors: list[NeighborMove] = []
    for first in range(len(directed_units)):
        for second in range(first + 1, len(directed_units)):
            if max_span is not None and second - first > max_span:
                continue
            candidate = list(directed_units)
            candidate[first], candidate[second] = candidate[second], candidate[first]
            neighbors.append(
                NeighborMove(
                    tuple(candidate),
                    first,
                    min(len(directed_units), second + 2),
                )
            )
            if _reached_neighbor_limit(neighbors, max_neighbors):
                return tuple(neighbors)
    return tuple(neighbors)


def swap_neighbors(
    directed_units: tuple[DirectedUnitCandidate, ...],
    max_span: int | None = None,
    max_neighbors: int | None = None,
) -> tuple[tuple[DirectedUnitCandidate, ...], ...]:
    return tuple(
        move.directed_units
        for move in swap_neighbor_moves(directed_units, max_span, max_neighbors)
    )


def relocate_neighbor_moves(
    directed_units: tuple[DirectedUnitCandidate, ...],
    max_span: int | None = None,
    max_neighbors: int | None = None,
) -> tuple[NeighborMove, ...]:
    neighbors: list[NeighborMove] = []
    for source in range(len(directed_units)):
        for target in range(len(directed_units)):
            if source == target:
                continue
            if max_span is not None and abs(target - source) > max_span:
                continue
            candidate = list(directed_units)
            item = candidate.pop(source)
            candidate.insert(target, item)
            affected_start = min(source, target)
            affected_end = max(source, target)
            neighbors.append(
                NeighborMove(
                    tuple(candidate),
                    affected_start,
                    min(len(directed_units), affected_end + 2),
                )
            )
            if _reached_neighbor_limit(neighbors, max_neighbors):
                return tuple(neighbors)
    return tuple(neighbors)


def relocate_neighbors(
    directed_units: tuple[DirectedUnitCandidate, ...],
    max_span: int | None = None,
    max_neighbors: int | None = None,
) -> tuple[tuple[DirectedUnitCandidate, ...], ...]:
    return tuple(
        move.directed_units
        for move in relocate_neighbor_moves(directed_units, max_span, max_neighbors)
    )


def two_opt_neighbor_moves(
    directed_units: tuple[DirectedUnitCandidate, ...],
    max_span: int | None = None,
    max_neighbors: int | None = None,
) -> tuple[NeighborMove, ...]:
    neighbors: list[NeighborMove] = []
    for start in range(len(directed_units)):
        for end in range(start + 1, len(directed_units)):
            if max_span is not None and end - start > max_span:
                continue
            block = directed_units[start : end + 1]
            reversed_block: list[DirectedUnitCandidate] = []
            feasible = True
            for candidate in reversed(block):
                reversed_candidate = reverse_candidate(candidate)
                if reversed_candidate is None:
                    feasible = False
                    break
                reversed_block.append(reversed_candidate)
            if not feasible:
                continue
            neighbors.append(
                NeighborMove(
                    directed_units[:start]
                    + tuple(reversed_block)
                    + directed_units[end + 1 :],
                    start,
                    min(len(directed_units), end + 2),
                )
            )
            if _reached_neighbor_limit(neighbors, max_neighbors):
                return tuple(neighbors)
    return tuple(neighbors)


def two_opt_neighbors(
    directed_units: tuple[DirectedUnitCandidate, ...],
    max_span: int | None = None,
    max_neighbors: int | None = None,
) -> tuple[tuple[DirectedUnitCandidate, ...], ...]:
    return tuple(
        move.directed_units
        for move in two_opt_neighbor_moves(directed_units, max_span, max_neighbors)
    )


def local_neighbor_moves(
    directed_units: tuple[DirectedUnitCandidate, ...],
    config: LocalSearchConfig,
) -> tuple[NeighborMove, ...]:
    neighbors: list[NeighborMove] = []
    max_neighbors = config.max_neighbors_per_iteration
    if config.enable_swap:
        remaining = None if max_neighbors is None else max_neighbors - len(neighbors)
        if remaining is None or remaining > 0:
            neighbors.extend(
                swap_neighbor_moves(
                    directed_units,
                    max_span=config.max_swap_span,
                    max_neighbors=remaining,
                )
            )
    if config.enable_relocate:
        remaining = None if max_neighbors is None else max_neighbors - len(neighbors)
        if remaining is None or remaining > 0:
            neighbors.extend(
                relocate_neighbor_moves(
                    directed_units,
                    max_span=config.max_relocate_span,
                    max_neighbors=remaining,
                )
            )
    if config.enable_two_opt:
        remaining = None if max_neighbors is None else max_neighbors - len(neighbors)
        if remaining is None or remaining > 0:
            neighbors.extend(
                two_opt_neighbor_moves(
                    directed_units,
                    max_span=config.max_two_opt_span,
                    max_neighbors=remaining,
                )
            )
    return tuple(neighbors)


def local_neighbors(
    directed_units: tuple[DirectedUnitCandidate, ...],
    config: LocalSearchConfig,
) -> tuple[tuple[DirectedUnitCandidate, ...], ...]:
    return tuple(move.directed_units for move in local_neighbor_moves(directed_units, config))


def improve_directed_unit_order(
    directed_units: tuple[DirectedUnitCandidate, ...],
    panel: Panel,
    tool: ToolConfig,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> LocalSearchResult:
    if config is None:
        config = LocalSearchConfig()

    current = directed_units
    current_actions, current_metrics = evaluate_directed_units(
        current,
        panel,
        tool,
        process_model=process_model,
    )
    improved = False

    for iteration in range(config.max_iterations):
        prefix_states = build_prefix_states(
            current,
            panel,
            tool,
            process_model=process_model,
        )
        best_neighbor = current
        best_metrics = current_metrics
        best_key = process_metric_key(
            current_metrics,
            repeat_cut_policy=config.repeat_cut_policy,
        )

        for move in local_neighbor_moves(current, config):
            neighbor_metrics = evaluate_neighbor_move_metrics(
                move,
                prefix_states,
                current_metrics,
                panel,
                tool,
                process_model=process_model,
            )
            neighbor_key = process_metric_key(
                neighbor_metrics,
                repeat_cut_policy=config.repeat_cut_policy,
            )
            if neighbor_key < best_key:
                best_neighbor = move.directed_units
                best_metrics = neighbor_metrics
                best_key = neighbor_key
                if config.first_improvement:
                    break

        if best_neighbor == current:
            return LocalSearchResult(
                directed_units=current,
                actions=current_actions,
                metrics=current_metrics,
                iterations=iteration,
                improved=improved,
            )

        current = best_neighbor
        current_actions = materialize_action_clearance(
            directed_units_to_actions(current, start_point=tool.start_point),
            panel,
            tool,
            process_model=process_model,
        )
        current_metrics = best_metrics
        improved = True

    return LocalSearchResult(
        directed_units=current,
        actions=current_actions,
        metrics=current_metrics,
        iterations=config.max_iterations,
        improved=improved,
    )


def improve_directed_unit_order_by_path_distance(
    directed_units: tuple[DirectedUnitCandidate, ...],
    panel: Panel,
    tool: ToolConfig,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> LocalSearchResult:
    if config is None:
        config = LocalSearchConfig()

    current = directed_units
    current_actions, current_metrics = evaluate_directed_units(
        current,
        panel,
        tool,
        process_model=process_model,
    )
    improved = False

    for iteration in range(config.max_iterations):
        prefix_states = build_prefix_states(
            current,
            panel,
            tool,
            process_model=process_model,
        )
        best_neighbor = current
        best_metrics = current_metrics
        best_key = path_distance_metric_key(
            current_metrics,
            repeat_cut_policy=config.repeat_cut_policy,
        )

        for move in local_neighbor_moves(current, config):
            neighbor_metrics = evaluate_neighbor_move_metrics(
                move,
                prefix_states,
                current_metrics,
                panel,
                tool,
                process_model=process_model,
            )
            neighbor_key = path_distance_metric_key(
                neighbor_metrics,
                repeat_cut_policy=config.repeat_cut_policy,
            )
            if neighbor_key < best_key:
                best_neighbor = move.directed_units
                best_metrics = neighbor_metrics
                best_key = neighbor_key
                if config.first_improvement:
                    break

        if best_neighbor == current:
            return LocalSearchResult(
                directed_units=current,
                actions=current_actions,
                metrics=current_metrics,
                iterations=iteration,
                improved=improved,
            )

        current = best_neighbor
        current_actions = materialize_action_clearance(
            directed_units_to_actions(current, start_point=tool.start_point),
            panel,
            tool,
            process_model=process_model,
        )
        current_metrics = best_metrics
        improved = True

    return LocalSearchResult(
        directed_units=current,
        actions=current_actions,
        metrics=current_metrics,
        iterations=config.max_iterations,
        improved=improved,
    )


def path_distance_local_search_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> LocalSearchResult:
    if config is None:
        config = LocalSearchConfig()
    initial_order = nearest_neighbor_unit_order(units, tool.start_point)
    return improve_directed_unit_order_by_path_distance(
        initial_order,
        panel,
        tool,
        config=config,
        process_model=process_model,
    )


def topology_local_search_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> LocalSearchResult:
    if config is None:
        config = LocalSearchConfig()
    if process_model is not None and config.process_aware_initial_order:
        initial_order = process_aware_unit_order(
            units,
            panel=panel,
            tool=tool,
            process_model=process_model,
            candidate_pool_size=config.topology_candidate_pool_size,
            repeat_cut_policy=config.repeat_cut_policy,
        )
    else:
        initial_order = topology_aware_unit_order(
            units,
            start_point=tool.start_point,
            candidate_pool_size=config.topology_candidate_pool_size,
        )
    return improve_directed_unit_order(
        initial_order,
        panel,
        tool,
        config=config,
        process_model=process_model,
    )


def _unit_midpoint(unit: CuttingUnit) -> tuple[float, float]:
    return ((unit.start.x + unit.end.x) / 2.0, (unit.start.y + unit.end.y) / 2.0)


def _direct_units_in_sequence(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
) -> tuple[DirectedUnitCandidate, ...]:
    directed_candidate_cache = {
        unit.unit_id: directed_unit_candidates(unit)
        for unit in units
    }
    current_point = start_point
    ordered: list[DirectedUnitCandidate] = []
    for unit in units:
        best = min(
            directed_candidate_cache[unit.unit_id],
            key=lambda candidate: (
                euclidean_distance(current_point, candidate.start),
                candidate.unit.unit_id,
                candidate.is_reversed,
            ),
        )
        ordered.append(best)
        current_point = best.end
    return tuple(ordered)


def sweep_unit_order(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
    primary_axis: str = "x",
    reverse: bool = False,
) -> tuple[DirectedUnitCandidate, ...]:
    """Build a deterministic row/column sweep order used as a strong baseline seed."""

    if primary_axis not in {"x", "y"}:
        raise ValueError("primary_axis must be 'x' or 'y'")

    def key(unit: CuttingUnit) -> tuple[float, float, int, str]:
        mid_x, mid_y = _unit_midpoint(unit)
        if primary_axis == "x":
            return (mid_x, mid_y, -unit_coverage_count(unit), unit.unit_id)
        return (mid_y, mid_x, -unit_coverage_count(unit), unit.unit_id)

    ordered_units = tuple(sorted(units, key=key, reverse=reverse))
    return _direct_units_in_sequence(ordered_units, start_point)


def _order_signature(
    directed_units: tuple[DirectedUnitCandidate, ...],
) -> tuple[tuple[str, bool], ...]:
    return tuple(
        (candidate.unit.unit_id, candidate.is_reversed)
        for candidate in directed_units
    )


def multistart_process_initial_orders(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    config: LocalSearchConfig,
    process_model: CuttingProcessModel | None = None,
) -> tuple[tuple[DirectedUnitCandidate, ...], ...]:
    """Construct literature-style deterministic seeds for process local search."""

    initial_orders: list[tuple[DirectedUnitCandidate, ...]] = [
        nearest_neighbor_unit_order(units, tool.start_point),
        topology_aware_unit_order(
            units,
            start_point=tool.start_point,
            candidate_pool_size=config.topology_candidate_pool_size,
        ),
        sweep_unit_order(units, tool.start_point, primary_axis="x"),
        sweep_unit_order(units, tool.start_point, primary_axis="y"),
        sweep_unit_order(units, tool.start_point, primary_axis="x", reverse=True),
        sweep_unit_order(units, tool.start_point, primary_axis="y", reverse=True),
    ]
    if process_model is not None:
        initial_orders.append(
            process_aware_unit_order(
                units,
                panel=panel,
                tool=tool,
                process_model=process_model,
                candidate_pool_size=config.topology_candidate_pool_size,
                repeat_cut_policy=config.repeat_cut_policy,
            )
        )

    unique_orders: list[tuple[DirectedUnitCandidate, ...]] = []
    seen: set[tuple[tuple[str, bool], ...]] = set()
    for order in initial_orders:
        signature = _order_signature(order)
        if signature in seen:
            continue
        seen.add(signature)
        unique_orders.append(order)
    return tuple(unique_orders)


def process_local_search_multistart_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    config: LocalSearchConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> LocalSearchResult:
    """Strong process-aware local-search baseline from multiple deterministic seeds."""

    if config is None:
        config = LocalSearchConfig()

    best_result: LocalSearchResult | None = None
    total_iterations = 0
    any_improved = False
    for initial_order in multistart_process_initial_orders(
        units,
        panel=panel,
        tool=tool,
        config=config,
        process_model=process_model,
    ):
        result = improve_directed_unit_order(
            initial_order,
            panel,
            tool,
            config=config,
            process_model=process_model,
        )
        total_iterations += result.iterations
        any_improved = any_improved or result.improved
        if best_result is None or (
            process_metric_key(
                result.metrics,
                repeat_cut_policy=config.repeat_cut_policy,
            ),
            _order_signature(result.directed_units),
        ) < (
            process_metric_key(
                best_result.metrics,
                repeat_cut_policy=config.repeat_cut_policy,
            ),
            _order_signature(best_result.directed_units),
        ):
            best_result = result

    if best_result is None:
        actions: tuple[CuttingAction, ...] = ()
        return LocalSearchResult(
            directed_units=(),
            actions=actions,
            metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
            iterations=0,
            improved=False,
        )

    return LocalSearchResult(
        directed_units=best_result.directed_units,
        actions=best_result.actions,
        metrics=best_result.metrics,
        iterations=total_iterations,
        improved=any_improved,
    )


def process_aware_simulated_annealing_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    config: SimulatedAnnealingConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> LocalSearchResult:
    """Trajectory-based process-aware SA baseline.

    Every accepted or rejected neighbor is evaluated through the same process
    evaluator as the proposed method, including detours, safe lifts, hard
    penalties, low-support rule penalties, and repeat-cut accounting.
    """

    if config is None:
        config = SimulatedAnnealingConfig()

    rng = random.Random(config.seed)
    neighborhood = config.neighborhood
    if process_model is not None and neighborhood.process_aware_initial_order:
        current = process_aware_unit_order(
            units,
            panel=panel,
            tool=tool,
            process_model=process_model,
            candidate_pool_size=neighborhood.topology_candidate_pool_size,
            repeat_cut_policy=neighborhood.repeat_cut_policy,
        )
    else:
        current = topology_aware_unit_order(
            units,
            start_point=tool.start_point,
            candidate_pool_size=neighborhood.topology_candidate_pool_size,
        )
    _, current_metrics = evaluate_directed_units(
        current,
        panel,
        tool,
        process_model=process_model,
    )
    initial_metrics = current_metrics
    best = current
    best_metrics = current_metrics
    accepted_worse = False
    temperature = config.initial_temperature
    iterations = 0

    for iteration in range(config.max_iterations):
        iterations = iteration + 1
        prefix_states = build_prefix_states(
            current,
            panel,
            tool,
            process_model=process_model,
        )
        moves = local_neighbor_moves(current, neighborhood)
        if not moves:
            break
        move = rng.choice(moves)
        neighbor_metrics = evaluate_neighbor_move_metrics(
            move,
            prefix_states,
            current_metrics,
            panel,
            tool,
            process_model=process_model,
        )
        current_key = process_metric_key(
            current_metrics,
            repeat_cut_policy=neighborhood.repeat_cut_policy,
        )
        neighbor_key = process_metric_key(
            neighbor_metrics,
            repeat_cut_policy=neighborhood.repeat_cut_policy,
        )
        accept = neighbor_key < current_key
        if not accept:
            delta = process_metric_energy(
                neighbor_metrics,
                repeat_cut_policy=neighborhood.repeat_cut_policy,
            ) - process_metric_energy(
                current_metrics,
                repeat_cut_policy=neighborhood.repeat_cut_policy,
            )
            if delta <= 0.0:
                accept = True
            else:
                probability = exp(-delta / max(temperature, config.min_temperature))
                accept = rng.random() < probability
                accepted_worse = accepted_worse or accept
        if accept:
            current = move.directed_units
            current_metrics = neighbor_metrics
            if neighbor_key < process_metric_key(
                best_metrics,
                repeat_cut_policy=neighborhood.repeat_cut_policy,
            ):
                best = current
                best_metrics = current_metrics
        temperature = max(config.min_temperature, temperature * config.cooling_rate)
        if temperature <= config.min_temperature and not accept:
            continue

    actions = materialize_action_clearance(
        directed_units_to_actions(best, start_point=tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return LocalSearchResult(
        directed_units=best,
        actions=actions,
        metrics=best_metrics,
        iterations=iterations,
        improved=process_metric_key(
            best_metrics,
            repeat_cut_policy=neighborhood.repeat_cut_policy,
        )
        < process_metric_key(
            initial_metrics,
            repeat_cut_policy=neighborhood.repeat_cut_policy,
        )
        or accepted_worse,
    )


def _random_directed_order(
    units: tuple[CuttingUnit, ...],
    start_point: Point,
    rng: random.Random,
) -> tuple[DirectedUnitCandidate, ...]:
    shuffled = list(units)
    rng.shuffle(shuffled)
    directed = list(_direct_units_in_sequence(tuple(shuffled), start_point))
    for index, candidate in enumerate(directed):
        if rng.random() < 0.5:
            reversed_candidate = reverse_candidate(candidate)
            if reversed_candidate is not None:
                directed[index] = reversed_candidate
    return tuple(directed)


def _chromosome_signature(
    chromosome: tuple[DirectedUnitCandidate, ...],
) -> tuple[tuple[str, bool], ...]:
    return _order_signature(chromosome)


def _ordered_crossover(
    left: tuple[DirectedUnitCandidate, ...],
    right: tuple[DirectedUnitCandidate, ...],
    rng: random.Random,
) -> tuple[DirectedUnitCandidate, ...]:
    if len(left) <= 2:
        return left
    start = rng.randrange(0, len(left) - 1)
    end = rng.randrange(start + 1, len(left))
    child: list[DirectedUnitCandidate | None] = [None] * len(left)
    child[start : end + 1] = left[start : end + 1]
    used = {candidate.unit.unit_id for candidate in child if candidate is not None}
    fill = [candidate for candidate in right if candidate.unit.unit_id not in used]
    fill_index = 0
    for index, candidate in enumerate(child):
        if candidate is None:
            child[index] = fill[fill_index]
            fill_index += 1
    return tuple(candidate for candidate in child if candidate is not None)


def _mutate_chromosome(
    chromosome: tuple[DirectedUnitCandidate, ...],
    rng: random.Random,
) -> tuple[DirectedUnitCandidate, ...]:
    if len(chromosome) < 2:
        return chromosome
    mutated = list(chromosome)
    move_type = rng.choice(("swap", "relocate", "two_opt"))
    first, second = sorted(rng.sample(range(len(mutated)), 2))
    if move_type == "swap":
        mutated[first], mutated[second] = mutated[second], mutated[first]
        return tuple(mutated)
    if move_type == "relocate":
        item = mutated.pop(second)
        mutated.insert(first, item)
        return tuple(mutated)

    block = mutated[first : second + 1]
    reversed_block: list[DirectedUnitCandidate] = []
    for candidate in reversed(block):
        reversed_candidate = reverse_candidate(candidate)
        if reversed_candidate is None:
            mutated[first], mutated[second] = mutated[second], mutated[first]
            return tuple(mutated)
        reversed_block.append(reversed_candidate)
    return tuple(mutated[:first] + reversed_block + mutated[second + 1 :])


def _tournament_select(
    ranked_population: tuple[tuple[tuple, tuple[DirectedUnitCandidate, ...], PathMetrics], ...],
    rng: random.Random,
    tournament_size: int = 3,
) -> tuple[DirectedUnitCandidate, ...]:
    contenders = rng.sample(
        ranked_population,
        k=min(tournament_size, len(ranked_population)),
    )
    return min(contenders, key=lambda item: item[0])[1]


def process_aware_genetic_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    config: GeneticAlgorithmConfig | None = None,
    process_model: CuttingProcessModel | None = None,
) -> LocalSearchResult:
    """Population-based process-aware GA baseline sharing the process evaluator."""

    if config is None:
        config = GeneticAlgorithmConfig()

    rng = random.Random(config.seed)
    seed_config = LocalSearchConfig(
        max_iterations=1,
        process_aware_initial_order=True,
        topology_candidate_pool_size=config.topology_candidate_pool_size,
        repeat_cut_policy=config.repeat_cut_policy,
    )
    population: list[tuple[DirectedUnitCandidate, ...]] = list(
        multistart_process_initial_orders(
            units,
            panel=panel,
            tool=tool,
            config=seed_config,
            process_model=process_model,
        )
    )
    while len(population) < config.population_size:
        population.append(_random_directed_order(units, tool.start_point, rng))

    seen: set[tuple[tuple[str, bool], ...]] = set()
    unique_population: list[tuple[DirectedUnitCandidate, ...]] = []
    for chromosome in population:
        signature = _chromosome_signature(chromosome)
        if signature in seen:
            continue
        seen.add(signature)
        unique_population.append(chromosome)
    population = unique_population[: config.population_size]
    while len(population) < config.population_size:
        population.append(_random_directed_order(units, tool.start_point, rng))

    best_chromosome: tuple[DirectedUnitCandidate, ...] | None = None
    best_metrics: PathMetrics | None = None
    best_key: tuple | None = None

    for _ in range(config.generations + 1):
        evaluated: list[tuple[tuple, tuple[DirectedUnitCandidate, ...], PathMetrics]] = []
        for chromosome in population:
            _, metrics = evaluate_directed_units(
                chromosome,
                panel,
                tool,
                process_model=process_model,
            )
            key = process_metric_key(metrics, repeat_cut_policy=config.repeat_cut_policy)
            evaluated.append((key, chromosome, metrics))
            if best_key is None or key < best_key:
                best_key = key
                best_chromosome = chromosome
                best_metrics = metrics
        ranked = tuple(sorted(evaluated, key=lambda item: (item[0], _order_signature(item[1]))))
        next_population = [item[1] for item in ranked[: config.elite_count]]
        while len(next_population) < config.population_size:
            parent_a = _tournament_select(ranked, rng)
            parent_b = _tournament_select(ranked, rng)
            if rng.random() < config.crossover_rate:
                child = _ordered_crossover(parent_a, parent_b, rng)
            else:
                child = parent_a
            if rng.random() < config.mutation_rate:
                child = _mutate_chromosome(child, rng)
            next_population.append(child)
        population = next_population

    if best_chromosome is None or best_metrics is None:
        actions: tuple[CuttingAction, ...] = ()
        return LocalSearchResult(
            directed_units=(),
            actions=actions,
            metrics=evaluate_actions(actions, panel, tool, process_model=process_model),
            iterations=0,
            improved=False,
        )

    actions = materialize_action_clearance(
        directed_units_to_actions(best_chromosome, start_point=tool.start_point),
        panel,
        tool,
        process_model=process_model,
    )
    return LocalSearchResult(
        directed_units=best_chromosome,
        actions=actions,
        metrics=best_metrics,
        iterations=config.generations,
        improved=True,
    )


def process_aware_beam_polished_search_order(
    units: tuple[CuttingUnit, ...],
    panel: Panel,
    tool: ToolConfig,
    process_model: CuttingProcessModel | None = None,
    beam_config: BeamSearchConfig | None = None,
    polish_config: LocalSearchConfig | None = None,
) -> BeamSearchResult:
    """Run process-aware beam search and polish the result with process local search."""

    beam_result = process_aware_beam_search_order(
        units,
        panel,
        tool,
        process_model=process_model,
        config=beam_config,
    )
    if not beam_result.directed_units:
        return beam_result
    if polish_config is None:
        repeat_cut_policy = (
            beam_config.repeat_cut_policy
            if beam_config is not None
            else DEFAULT_REPEAT_CUT_POLICY
        )
        polish_config = LocalSearchConfig(
            max_iterations=2,
            first_improvement=True,
            max_swap_span=6,
            max_relocate_span=6,
            max_two_opt_span=6,
            max_neighbors_per_iteration=160,
            process_aware_initial_order=True,
            repeat_cut_policy=repeat_cut_policy,
        )

    polished = improve_directed_unit_order(
        beam_result.directed_units,
        panel,
        tool,
        config=polish_config,
        process_model=process_model,
    )
    return BeamSearchResult(
        directed_units=polished.directed_units,
        actions=polished.actions,
        metrics=polished.metrics,
        expanded_nodes=beam_result.expanded_nodes,
        diagnostics=beam_result.diagnostics,
    )
