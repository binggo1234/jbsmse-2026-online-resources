from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import asdict, fields
from pathlib import Path
from time import perf_counter


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import scripts.run_holdout_routes as v1


OUTPUT = v1.OUTPUT_DIR / "route_results_cache_isolated.csv"
AMENDMENT = v1.OUTPUT_DIR / "route_run_isolation_amendment_v2.json"
DEFECT_JOB_ID = "f52e5eaa170221a6b062"


def append_csv(path: Path, fieldnames: tuple[str, ...], row: dict[str, object]) -> None:
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def freeze_amendment() -> dict:
    original = v1.verify_full_plan()
    evidence = next(
        row
        for row in v1.read_csv(v1.OUTPUT_DIR / "proposed_atomic_span_audit.csv")
        if row["job_id"] == DEFECT_JOB_ID
    )
    if evidence["replay_metrics_match"] != "False":
        raise ValueError("the predeclared isolation defect is not present")
    amendment = {
        "status": "frozen_before_corrected_quality_analysis",
        "reason": (
            "method-order contamination from the module-level low-clearance "
            "detour cache was detected by deterministic proposed-only replay"
        ),
        "quarantined_output": {
            "path": str(v1.FULL_RESULTS.resolve()),
            "sha256": v1.sha256_file(v1.FULL_RESULTS),
            "permitted_use": "audit evidence only; excluded from method comparison",
        },
        "defect_evidence": {
            "job_id": DEFECT_JOB_ID,
            "placements_member": evidence["placements_member"],
            "board_id": evidence["board_id"],
            "atomic_span_status": "passed",
            "replay_metrics_match": False,
        },
        "correction": (
            "call cnc_cutting.travel.clear_detour_cache() immediately before "
            "every method planner invocation"
        ),
        "unchanged_design": {
            "methods": original["methods"],
            "method_parameters": original["method_parameters"],
            "board_count": original["board_count"],
            "method_task_count": original["method_task_count"],
            "schedule_seed": original["full_run"]["schedule_seed"],
            "frozen_jobs_sha256": original["inputs"]["full_jobs"]["sha256"],
            "timeout_seconds": original["full_run"]["timeout_seconds"],
        },
        "software": {
            "stage7_git_commit": original["software"]["stage7_git_commit"],
            "original_orchestrator_sha256": original["software"][
                "orchestrator_sha256"
            ],
            "isolated_orchestrator": str(Path(__file__).resolve()),
            "isolated_orchestrator_sha256": v1.sha256_file(Path(__file__).resolve()),
        },
        "output": str(OUTPUT.resolve()),
    }
    AMENDMENT.write_text(
        json.dumps(amendment, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return amendment


def verify_amendment() -> dict:
    v1.verify_full_plan()
    amendment = json.loads(AMENDMENT.read_text(encoding="utf-8"))
    if v1.sha256_file(Path(__file__).resolve()) != amendment["software"][
        "isolated_orchestrator_sha256"
    ]:
        raise ValueError("isolated route orchestrator changed after amendment freeze")
    if v1.sha256_file(v1.FULL_JOBS) != amendment["unchanged_design"][
        "frozen_jobs_sha256"
    ]:
        raise ValueError("frozen jobs changed after isolation amendment")
    if v1.sha256_file(v1.FULL_RESULTS) != amendment["quarantined_output"]["sha256"]:
        raise ValueError("quarantined v1 result changed after isolation amendment")
    return amendment


def run(resume: bool) -> None:
    amendment = verify_amendment()
    stage7 = v1._load_stage7()
    from cnc_cutting.travel import clear_detour_cache

    output_fields = v1.FULL_PREFIX_FIELDS + tuple(
        field.name for field in fields(stage7.BatchRouteRow)
    )
    jobs = v1.read_csv(v1.FULL_JOBS)
    completed = (
        {row["job_id"] for row in v1.read_csv(OUTPUT)}
        if resume and OUTPUT.exists()
        else set()
    )
    if not resume and OUTPUT.exists():
        OUTPUT.unlink()
    args = v1.stage7_args()
    timeout_seconds = float(amendment["unchanged_design"]["timeout_seconds"])

    for (
        board_jobs,
        layout,
        panel,
        tool,
        process_model,
        tool_event_gate,
        units,
    ) in v1.iter_loaded_boards(jobs, stage7):
        methods = tuple(job["method"] for job in board_jobs)
        specs = {
            spec.method: spec
            for spec in stage7.build_planners(
                methods,
                units,
                panel,
                tool,
                process_model,
                tool_event_gate,
                len(layout.rectangles),
                args.repeat_cut_policy,
                algorithm_seed=args.algorithm_seed,
            )
        }
        for job in board_jobs:
            if job["job_id"] in completed:
                continue
            clear_detour_cache()
            started = perf_counter()
            status = "completed"
            error_class = ""
            error_message = ""
            batch_values: dict[str, object] = {}
            try:
                with stage7.task_timeout(timeout_seconds):
                    result = stage7.run_plan(
                        v1.LAYOUT_ARCHIVE,
                        job["placements_member"],
                        job["board_id"],
                        args.support_policy,
                        args.min_support_count,
                        args.min_support_ratio,
                        args.min_area_normalized_support,
                        args.adjacency_support_weight,
                        tool_event_gate.enabled,
                        tool_event_gate.min_travel_saving_per_extra_event,
                        tool_event_gate.min_travel_saving_ratio_per_extra_event,
                        tool_event_gate.min_machining_saving,
                        args.repeat_cut_policy,
                        specs[job["method"]],
                        layout,
                        panel,
                        tool,
                        units,
                        process_model,
                    )
                batch_values = asdict(result)
            except stage7.TaskTimeoutError as exc:
                status = "timed_out"
                error_class = type(exc).__name__
                error_message = str(exc)
            except Exception as exc:  # pragma: no cover - persisted for audit
                status = "failed"
                error_class = type(exc).__name__
                error_message = str(exc)[:500]
            row: dict[str, object] = {
                "job_id": job["job_id"],
                "schedule_order": job["schedule_order"],
                "status": status,
                "error_class": error_class,
                "error_message": error_message,
            }
            for field in output_fields[len(v1.FULL_PREFIX_FIELDS) :]:
                row[field] = batch_values.get(field, "")
            append_csv(OUTPUT, output_fields, row)
            completed.add(job["job_id"])
            elapsed_ms = (perf_counter() - started) * 1000.0
            print(
                f"isolated route {len(completed)}/{len(jobs)} "
                f"{job['method']} {status} {elapsed_ms:.3f} ms",
                flush=True,
            )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("freeze")
    route = subparsers.add_parser("run")
    route.add_argument("--resume", action="store_true")
    subparsers.add_parser("verify")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "freeze":
        print(json.dumps(freeze_amendment(), indent=2, ensure_ascii=False))
    elif args.command == "run":
        run(resume=args.resume)
    else:
        amendment = verify_amendment()
        print(
            f"verified isolated rerun of "
            f"{amendment['unchanged_design']['method_task_count']} jobs"
        )


if __name__ == "__main__":
    main()
