from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = (
    WORKSPACE_ROOT / "outputs" / "ijamt_submission_working_v27_figure_system"
)

COLORS = {
    "ink": "#1F2937",
    "muted": "#64748B",
    "outline": "#94A3B8",
    "part": "#F1F5F9",
    "released": "#CBD5E1",
    "blue": "#0072B2",
    "detour": "#0891B2",
    "safe": "#7C3AED",
    "green": "#009E73",
    "red": "#B91C1C",
    "amber": "#D6A84B",
}


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 6.4,
            "axes.titlesize": 7.0,
            "axes.labelsize": 6.4,
            "figure.dpi": 180,
            "savefig.dpi": 600,
            "savefig.bbox": "tight",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
        }
    )


def save_figure(
    fig: plt.Figure,
    output_dir: Path,
    stem: str,
) -> tuple[Path, Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    outputs = tuple(output_dir / f"{stem}{suffix}" for suffix in (".pdf", ".svg", ".png"))
    fig.savefig(outputs[0], bbox_inches="tight")
    fig.savefig(outputs[1], bbox_inches="tight")
    fig.savefig(outputs[2], dpi=600, bbox_inches="tight")
    plt.close(fig)
    return outputs


def panel_title(ax: plt.Axes, label: str, title: str) -> None:
    ax.set_title(
        f"{label}  {title}",
        loc="left",
        pad=3.0,
        fontweight="bold",
        color=COLORS["ink"],
    )
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.axis("off")


def draw_board_parts(ax: plt.Axes, *, released: bool = False) -> None:
    parts = (
        (0.05, 0.60, 0.24, 0.17),
        (0.37, 0.60, 0.24, 0.17),
        (0.69, 0.60, 0.24, 0.17),
        (0.05, 0.19, 0.28, 0.18),
        (0.67, 0.19, 0.26, 0.18),
    )
    for x, y, width, height in parts:
        ax.add_patch(
            Rectangle(
                (x, y),
                width,
                height,
                facecolor=COLORS["part"],
                edgecolor=COLORS["ink"],
                linewidth=0.55,
            )
        )
    ax.add_patch(
        Rectangle(
            (0.39, 0.17),
            0.22,
            0.25,
            facecolor=COLORS["released"] if released else COLORS["part"],
            edgecolor=COLORS["muted"],
            linewidth=0.7,
            linestyle="--" if released else "-",
        )
    )
    ax.text(0.50, 0.285, r"part $j$", ha="center", va="center", fontsize=5.8)


def draw_release_panel(ax: plt.Axes) -> None:
    panel_title(ax, "a", "Release-state update")
    draw_board_parts(ax, released=True)
    ax.add_patch(
        FancyBboxPatch(
            (0.13, 0.82),
            0.74,
            0.10,
            boxstyle="round,pad=0.018,rounding_size=0.02",
            facecolor="#ECFDF5",
            edgecolor=COLORS["green"],
            linewidth=0.75,
        )
    )
    ax.text(
        0.50,
        0.87,
        r"$\mathcal{R}^{\mathrm{rel}}_{k+1}=\mathcal{R}^{\mathrm{rel}}_k\cup\{j\}$",
        ha="center",
        va="center",
        fontsize=6.0,
        color=COLORS["ink"],
    )
    ax.annotate(
        "boundary complete",
        xy=(0.50, 0.42),
        xytext=(0.50, 0.51),
        ha="center",
        va="center",
        fontsize=5.5,
        color=COLORS["green"],
        arrowprops={"arrowstyle": "-|>", "color": COLORS["green"], "linewidth": 0.85},
    )
    ax.text(0.50, 0.07, "released envelope enters the route state", ha="center", fontsize=5.4, color=COLORS["muted"])


def draw_blocked_panel(ax: plt.Axes) -> None:
    panel_title(ax, "b", "Direct transition rejected")
    draw_board_parts(ax, released=True)
    start, end = (0.03, 0.49), (0.97, 0.49)
    ax.scatter([start[0], end[0]], [start[1], end[1]], s=8, color=COLORS["ink"], zorder=5)
    ax.plot([start[0], end[0]], [start[1], end[1]], color=COLORS["muted"], linewidth=1.0)
    ax.scatter([0.50], [0.49], marker="x", s=31, color=COLORS["red"], linewidths=1.3, zorder=6)
    ax.text(
        0.50,
        0.87,
        r"$\gamma_{\mathrm{low}}(\sigma_k,d_{k+1})\cap Q_j^c\ne\varnothing$",
        ha="center",
        va="center",
        fontsize=5.8,
        color=COLORS["red"],
    )
    ax.text(0.50, 0.07, "released-part envelope blocks low travel", ha="center", fontsize=5.4, color=COLORS["muted"])


def draw_travel_alternatives_panel(ax: plt.Axes) -> None:
    panel_title(ax, "c", "Admissible travel response")
    ax.text(0.08, 0.83, "direct blocked", ha="left", va="center", fontsize=5.5, color=COLORS["red"])
    ax.scatter([0.20], [0.75], s=12, color=COLORS["ink"], zorder=5)
    ax.plot([0.20, 0.31], [0.75, 0.75], color=COLORS["ink"], linewidth=0.8)
    ax.plot([0.31, 0.40], [0.75, 0.58], color=COLORS["ink"], linewidth=0.8)
    ax.plot([0.31, 0.40], [0.75, 0.30], color=COLORS["ink"], linewidth=0.8)

    ax.add_patch(Rectangle((0.48, 0.51), 0.20, 0.16, facecolor=COLORS["released"], edgecolor=COLORS["muted"], linewidth=0.65, linestyle="--"))
    ax.plot([0.40, 0.46, 0.46, 0.72, 0.72, 0.92], [0.58, 0.58, 0.43, 0.43, 0.58, 0.58], color=COLORS["detour"], linewidth=1.35, linestyle=(0, (3, 2)))
    ax.text(0.66, 0.70, "detour if available", ha="center", fontsize=5.5, color=COLORS["detour"])

    ax.add_patch(Rectangle((0.48, 0.16), 0.20, 0.15, facecolor=COLORS["released"], edgecolor=COLORS["muted"], linewidth=0.65, linestyle="--"))
    ax.plot([0.40, 0.92], [0.30, 0.30], color=COLORS["safe"], linewidth=1.35, linestyle=(0, (3, 2)))
    ax.annotate("", xy=(0.44, 0.39), xytext=(0.44, 0.27), arrowprops={"arrowstyle": "-|>", "color": COLORS["safe"], "linewidth": 0.9})
    ax.text(0.71, 0.08, "otherwise safe lift", ha="center", fontsize=5.5, color=COLORS["safe"])
    ax.text(0.50, 0.91, "exclusive alternatives", ha="center", fontsize=5.4, color=COLORS["muted"])


def draw_support_panel(ax: plt.Axes) -> None:
    panel_title(ax, "d", "Support-continuity decision")
    ax.add_patch(Rectangle((0.28, 0.28), 0.44, 0.46, facecolor=COLORS["part"], edgecolor=COLORS["outline"], linewidth=0.65))
    ax.plot([0.28, 0.72], [0.74, 0.74], color=COLORS["red"], linewidth=1.6)
    ax.plot([0.28, 0.28], [0.28, 0.74], color=COLORS["green"], linewidth=1.7)
    ax.plot([0.28, 0.62], [0.22, 0.22], color=COLORS["muted"], linewidth=0.7)
    ax.plot([0.28, 0.28], [0.19, 0.25], color=COLORS["muted"], linewidth=0.7)
    ax.plot([0.62, 0.62], [0.19, 0.25], color=COLORS["muted"], linewidth=0.7)
    ax.text(0.45, 0.14, r"$L_i(k)$", ha="center", fontsize=5.8, color=COLORS["ink"])
    ax.plot([0.28, 0.76], [0.86, 0.86], color=COLORS["red"], linewidth=0.8, linestyle=(0, (3, 2)))
    ax.text(0.52, 0.90, r"planning threshold $\rho_iL_i^0$", ha="center", fontsize=5.5, color=COLORS["red"])
    ax.text(0.50, 0.80, r"$L_i(k)<\rho_iL_i^0$", ha="center", fontsize=5.9, color=COLORS["red"])
    ax.annotate(
        "continue tracked part",
        xy=(0.28, 0.48),
        xytext=(0.02, 0.03),
        ha="left",
        fontsize=5.1,
        color=COLORS["green"],
        arrowprops={"arrowstyle": "-|>", "color": COLORS["green"], "linewidth": 0.8},
    )
    ax.annotate(
        "switch away:\nmodeled penalty",
        xy=(0.50, 0.74),
        xytext=(0.98, 0.08),
        ha="right",
        va="center",
        fontsize=5.0,
        color=COLORS["red"],
        arrowprops={"arrowstyle": "-|>", "color": COLORS["red"], "linewidth": 0.8},
    )


def make_process_state_figure(output_dir: Path) -> tuple[Path, Path, Path]:
    configure_style()
    fig, axes = plt.subplots(1, 4, figsize=(7.2, 2.05))
    draw_release_panel(axes[0])
    draw_blocked_panel(axes[1])
    draw_travel_alternatives_panel(axes[2])
    draw_support_panel(axes[3])
    fig.subplots_adjust(left=0.018, right=0.992, top=0.89, bottom=0.08, wspace=0.19)
    for left_ax, right_ax in zip(axes[:-1], axes[1:]):
        left = left_ax.get_position()
        right = right_ax.get_position()
        fig.add_artist(
            FancyArrowPatch(
                (left.x1 + 0.003, 0.50 * (left.y0 + left.y1)),
                (right.x0 - 0.003, 0.50 * (right.y0 + right.y1)),
                transform=fig.transFigure,
                arrowstyle="-|>",
                mutation_scale=7,
                linewidth=0.65,
                color=COLORS["outline"],
            )
        )
    return save_figure(fig, output_dir, "fig_process_constraints")


def workflow_box(
    ax: plt.Axes,
    x: float,
    y: float,
    width: float,
    height: float,
    text: str,
    *,
    facecolor: str = "white",
    edgecolor: str = COLORS["outline"],
    linestyle: str = "-",
    linewidth: float = 0.75,
    fontsize: float = 5.7,
    fontweight: str = "normal",
) -> FancyBboxPatch:
    patch = FancyBboxPatch(
        (x, y),
        width,
        height,
        boxstyle="round,pad=0.008,rounding_size=0.012",
        facecolor=facecolor,
        edgecolor=edgecolor,
        linewidth=linewidth,
        linestyle=linestyle,
    )
    ax.add_patch(patch)
    ax.text(
        x + width / 2,
        y + height / 2,
        text,
        ha="center",
        va="center",
        fontsize=fontsize,
        color=COLORS["ink"],
        fontweight=fontweight,
        linespacing=1.15,
    )
    return patch


def workflow_arrow(
    ax: plt.Axes,
    start: tuple[float, float],
    end: tuple[float, float],
    *,
    color: str = COLORS["ink"],
    linestyle: str = "-",
    linewidth: float = 0.72,
    connectionstyle: str = "arc3,rad=0",
    mutation_scale: float = 7.0,
) -> None:
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            arrowstyle="-|>",
            mutation_scale=mutation_scale,
            linewidth=linewidth,
            linestyle=linestyle,
            color=color,
            connectionstyle=connectionstyle,
            shrinkA=0,
            shrinkB=0,
        )
    )


def zone_background(
    ax: plt.Axes,
    x: float,
    width: float,
    title: str,
    *,
    facecolor: str,
) -> None:
    ax.add_patch(
        FancyBboxPatch(
            (x, 0.05),
            width,
            0.90,
            boxstyle="round,pad=0.006,rounding_size=0.015",
            facecolor=facecolor,
            edgecolor="#CBD5E1",
            linewidth=0.65,
        )
    )
    ax.text(
        x + 0.012,
        0.91,
        title,
        ha="left",
        va="center",
        fontsize=6.2,
        color=COLORS["ink"],
        fontweight="bold",
    )


def make_solver_flow_figure(output_dir: Path) -> tuple[Path, Path, Path]:
    configure_style()
    fig, ax = plt.subplots(figsize=(7.2, 3.05))
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.axis("off")

    zone_background(ax, 0.01, 0.155, "1  Geometry input", facecolor="#F8FAFC")
    zone_background(ax, 0.175, 0.135, "2  Executable units", facecolor="#F5F9FC")
    zone_background(ax, 0.32, 0.365, "3  Bounded solver", facecolor="#EFF6FF")
    zone_background(ax, 0.695, 0.155, "4  Selection / validation", facecolor="#F8FAFC")
    zone_background(ax, 0.86, 0.13, "5  Outputs / analyses", facecolor="#F7FAF9")

    workflow_box(ax, 0.028, 0.66, 0.118, 0.12, "Fixed nested\nlayout", fontweight="bold")
    workflow_box(ax, 0.028, 0.43, 0.118, 0.14, "Kerf compensation\nand atomic spans", facecolor="#EFF6FF", edgecolor=COLORS["blue"])
    workflow_box(ax, 0.028, 0.20, 0.118, 0.12, "Geometry and\ncoverage checks", facecolor="#F1F5F9")
    workflow_arrow(ax, (0.087, 0.66), (0.087, 0.57))
    workflow_arrow(ax, (0.087, 0.43), (0.087, 0.32))

    workflow_box(ax, 0.192, 0.59, 0.102, 0.16, "Residual\nsingle spans", facecolor="#F8FAFC", edgecolor=COLORS["muted"])
    workflow_box(ax, 0.192, 0.34, 0.102, 0.16, "Shared cutter-\ncenterline units", facecolor="#EAF4FB", edgecolor=COLORS["blue"], fontweight="bold")
    workflow_box(ax, 0.192, 0.16, 0.102, 0.09, "cover-complete\nselected set", facecolor="#ECFDF5", edgecolor=COLORS["green"], fontsize=5.4)
    workflow_arrow(ax, (0.146, 0.50), (0.192, 0.67), color=COLORS["blue"])
    workflow_arrow(ax, (0.146, 0.50), (0.192, 0.42), color=COLORS["blue"])
    workflow_arrow(ax, (0.243, 0.34), (0.243, 0.25), color=COLORS["green"])

    workflow_box(
        ax,
        0.337,
        0.67,
        0.092,
        0.13,
        "Directed actions\n" + r"$\mathcal{D}(\sigma_k)$",
        facecolor="white",
        edgecolor=COLORS["blue"],
        fontweight="bold",
        fontsize=5.2,
    )
    workflow_box(
        ax,
        0.456,
        0.67,
        0.096,
        0.13,
        "State transition\n" + r"$\delta(\sigma_k,d_{k+1})$",
        facecolor="#EAF4FB",
        edgecolor=COLORS["blue"],
        fontweight="bold",
        fontsize=5.1,
    )
    workflow_box(
        ax,
        0.579,
        0.67,
        0.087,
        0.13,
        "Next state\n" + r"$\sigma_{k+1}$",
        facecolor="#ECFDF5",
        edgecolor=COLORS["green"],
        fontweight="bold",
        fontsize=5.2,
    )
    workflow_arrow(ax, (0.294, 0.205), (0.337, 0.735), color=COLORS["blue"], connectionstyle="arc3,rad=-0.08")
    workflow_arrow(ax, (0.429, 0.735), (0.456, 0.735), color=COLORS["blue"])
    workflow_arrow(ax, (0.552, 0.735), (0.579, 0.735), color=COLORS["green"])
    workflow_arrow(
        ax,
        (0.622, 0.665),
        (0.383, 0.665),
        color=COLORS["blue"],
        connectionstyle="arc3,rad=-0.38",
        linewidth=0.9,
        mutation_scale=8.0,
    )
    ax.text(0.505, 0.565, "next-prefix feedback", ha="center", va="center", fontsize=5.4, color=COLORS["blue"])

    workflow_box(ax, 0.337, 0.36, 0.074, 0.13, "Topology\nreference", facecolor="#F8FAFC", fontsize=5.4)
    workflow_box(ax, 0.421, 0.36, 0.074, 0.13, "Prefix\nbeam", facecolor="#EAF4FB", edgecolor=COLORS["blue"], fontweight="bold", fontsize=5.4)
    workflow_box(ax, 0.505, 0.36, 0.077, 0.13, "Local refine +\nmulti-start", facecolor="#EAF4FB", edgecolor=COLORS["blue"], fontsize=5.2)
    workflow_box(ax, 0.592, 0.36, 0.076, 0.13, "Conditional\nwider beam", facecolor="#F8FAFC", edgecolor=COLORS["outline"], linestyle="--", fontsize=5.2)
    for center_x in (0.374, 0.458, 0.543, 0.630):
        workflow_arrow(ax, (0.504, 0.67), (center_x, 0.49), color=COLORS["outline"], linewidth=0.62)
    ax.text(0.630, 0.315, "locked fallback rule", ha="center", fontsize=5.0, color=COLORS["muted"])

    workflow_box(ax, 0.414, 0.13, 0.170, 0.11, "Candidate portfolio\n(shared evaluator and objective)", facecolor="white", edgecolor=COLORS["blue"], fontweight="bold", fontsize=5.4)
    for center_x in (0.374, 0.458, 0.543, 0.630):
        workflow_arrow(ax, (center_x, 0.36), (0.499, 0.24), color=COLORS["outline"], linewidth=0.60)

    workflow_box(ax, 0.710, 0.66, 0.125, 0.11, "Optional admission screen\ninactive in reported cohort", facecolor="#FAFAFA", edgecolor=COLORS["outline"], linestyle="--", fontsize=5.0)
    workflow_box(
        ax,
        0.710,
        0.43,
        0.125,
        0.12,
        "Lexicographic selection\nby " + r"$F_{\mathrm{proc}}$",
        facecolor="#EAF4FB",
        edgecolor=COLORS["blue"],
        fontweight="bold",
        fontsize=5.2,
    )
    workflow_box(ax, 0.710, 0.18, 0.125, 0.13, "Validation\ncoverage, feasibility,\nsupport and repeat cut", facecolor="#ECFDF5", edgecolor=COLORS["green"], fontweight="bold", fontsize=5.1)
    workflow_arrow(ax, (0.584, 0.185), (0.710, 0.715), color=COLORS["blue"], connectionstyle="arc3,rad=-0.10")
    workflow_arrow(ax, (0.7725, 0.66), (0.7725, 0.55), color=COLORS["outline"], linestyle="--")
    workflow_arrow(ax, (0.7725, 0.43), (0.7725, 0.31), color=COLORS["green"])

    workflow_box(ax, 0.875, 0.60, 0.100, 0.14, "Directed route\nand canonical NC", facecolor="#ECFDF5", edgecolor=COLORS["green"], fontweight="bold", fontsize=5.4)
    workflow_box(ax, 0.875, 0.28, 0.100, 0.18, "Planning, NC and\nqualified simulator\nanalyses", facecolor="#F8FAFC", edgecolor=COLORS["muted"], fontsize=5.2)
    workflow_arrow(ax, (0.835, 0.245), (0.875, 0.67), color=COLORS["green"], connectionstyle="arc3,rad=-0.12")
    workflow_arrow(ax, (0.925, 0.60), (0.925, 0.46), color=COLORS["green"])
    ax.text(0.925, 0.19, "report only after validation", ha="center", fontsize=5.0, color=COLORS["muted"])

    fig.subplots_adjust(left=0.01, right=0.995, top=0.99, bottom=0.01)
    return save_figure(fig, output_dir, "fig_solver_state_feedback_pipeline")


def process_trigger_spec() -> dict[str, object]:
    return {
        "stages": ("release", "blocked_direct", "travel_response", "support"),
        "release_update": r"R_rel(k+1)=R_rel(k) union {j}",
        "collision_trigger": r"gamma_low intersects Q_j^c",
        "travel_responses": ("detour", "safe_lift"),
        "travel_relation": "exclusive_alternatives",
        "support_threshold": r"L_i(k)<\rho_iL_i^0",
    }


def workflow_spec() -> dict[str, object]:
    nodes = {
        "geometry": "Fixed layout and kerf-aware atomic spans",
        "units": "Residual/shared executable units",
        "state": "Shared state evaluator",
        "candidates": "Bounded candidate generation",
        "selection": "Candidate selection",
        "validation": "Validation",
        "outputs": "Directed route and canonical NC",
        "analyses": "Planning, NC and simulator analyses",
    }
    edges = (
        ("geometry", "units", "forward"),
        ("units", "candidates", "forward"),
        ("candidates", "state", "forward"),
        ("state", "candidates", "feedback"),
        ("candidates", "selection", "forward"),
        ("selection", "validation", "forward"),
        ("validation", "outputs", "forward"),
        ("outputs", "analyses", "forward"),
    )
    return {
        "nodes": nodes,
        "edges": edges,
        "order": (
            "geometry",
            "units",
            "candidates",
            "selection",
            "validation",
            "outputs",
            "analyses",
        ),
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate the v27 IJAMT method figures."
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    make_process_state_figure(args.output_dir)
    make_solver_flow_figure(args.output_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
