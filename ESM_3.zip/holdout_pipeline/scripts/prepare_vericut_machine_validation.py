#!/usr/bin/env python3
"""Prepare the qualified-machine VERICUT validation package.

The package preserves the 15 frozen comparison programs and adds five
method-invariant geometry-oracle programs.  Each oracle is the merged cutter
centerline union shared by proposed, topology, and ordinary-beam for one
layout.  VERICUT can simulate an oracle once, export the cut stock, and use
that stock as the Design model for gouge/excess checks of all three methods.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import shutil
import zipfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_NC_ROOT = ROOT / "outputs" / "vericut_validation_prep_v1" / "cases"
DEFAULT_SELECTION = (
    ROOT / "outputs" / "vericut_validation_prep_v1" / "selection_manifest.csv"
)
DEFAULT_LAYOUT_ZIP = (
    ROOT
    / "outputs"
    / "holdout_preflight_v1"
    / "packing_outputs"
    / "holdout_kerf_layouts.zip"
)
DEFAULT_OUTPUT = (
    ROOT / "outputs" / "vericut_machine_validation_prep_v3_20260730"
)


CASE_LAYOUTS = {
    "case01_small": (
        "holdout/FACTORY_TASK_010/seed_1000/placements.csv",
        43,
    ),
    "case02_medium": (
        "holdout/FACTORY_TASK_006/seed_1001/placements.csv",
        65,
    ),
    "case03_medium": (
        "holdout/FACTORY_TASK_015/seed_1002/placements.csv",
        38,
    ),
    "case04_large": (
        "holdout/FACTORY_TASK_009/seed_1001/placements.csv",
        222,
    ),
    "case05_largest": (
        "holdout/FACTORY_TASK_023/seed_1000/placements.csv",
        162,
    ),
}

METHODS = ("proposed", "topology", "ordinary_beam")
STOCK_X = 2440.0
STOCK_Y = 1220.0
STOCK_Z = 18.0
TOOL_DIAMETER = 6.0

NCX_RE = re.compile(r"^\(NCX (.*)\)$")
AXIS_RE = {
    axis: re.compile(rf"\b{axis}(-?\d+(?:\.\d+)?)") for axis in "XYZ"
}


@dataclass(frozen=True, order=True)
class Segment:
    orientation: str
    fixed: float
    start: float
    end: float

    def as_record(self) -> str:
        return (
            f"{self.orientation},{self.fixed:.6f},"
            f"{self.start:.6f},{self.end:.6f}"
        )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def parse_cut_segments(path: Path) -> list[Segment]:
    x = y = z = 0.0
    pending: dict[str, object] | None = None
    output: list[Segment] = []
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        ncx = NCX_RE.match(line)
        if ncx:
            pending = json.loads(ncx.group(1))
            continue
        if not (line.startswith("G0 ") or line.startswith("G1 ")):
            continue
        nx, ny, nz = x, y, z
        for axis, pattern in AXIS_RE.items():
            match = pattern.search(line)
            if not match:
                continue
            value = float(match.group(1))
            if axis == "X":
                nx = value
            elif axis == "Y":
                ny = value
            else:
                nz = value
        if (
            line.startswith("G1 ")
            and pending
            and pending.get("role") == "cut_xy"
            and (x, y) != (nx, ny)
        ):
            if abs(y - ny) <= 1e-9:
                lo, hi = sorted((x, nx))
                output.append(Segment("H", round(y, 6), round(lo, 6), round(hi, 6)))
            elif abs(x - nx) <= 1e-9:
                lo, hi = sorted((y, ny))
                output.append(Segment("V", round(x, 6), round(lo, 6), round(hi, 6)))
            else:
                raise ValueError(f"non-axis-aligned cutting segment in {path}: {line}")
        x, y, z = nx, ny, nz
        pending = None
    if not output:
        raise ValueError(f"no NCX cutting segments parsed from {path}")
    return output


def merge_segments(segments: Iterable[Segment]) -> list[Segment]:
    groups: dict[tuple[str, float], list[tuple[float, float]]] = {}
    for segment in segments:
        groups.setdefault(
            (segment.orientation, round(segment.fixed, 6)), []
        ).append((round(segment.start, 6), round(segment.end, 6)))

    merged: list[Segment] = []
    for (orientation, fixed), intervals in sorted(groups.items()):
        intervals.sort()
        start, end = intervals[0]
        for next_start, next_end in intervals[1:]:
            if next_start <= end + 1e-6:
                end = max(end, next_end)
            else:
                merged.append(Segment(orientation, fixed, start, end))
                start, end = next_start, next_end
        merged.append(Segment(orientation, fixed, start, end))
    return sorted(merged)


def segment_union_hash(segments: Iterable[Segment]) -> str:
    body = "\n".join(segment.as_record() for segment in sorted(segments)) + "\n"
    return sha256_text(body)


def endpoint_degree_one_count(segments: Iterable[Segment]) -> int:
    degree: Counter[tuple[float, float]] = Counter()
    for segment in segments:
        if segment.orientation == "H":
            a = (segment.start, segment.fixed)
            b = (segment.end, segment.fixed)
        else:
            a = (segment.fixed, segment.start)
            b = (segment.fixed, segment.end)
        degree[a] += 1
        degree[b] += 1
    return sum(value == 1 for value in degree.values())


def segment_endpoints(segment: Segment) -> tuple[tuple[float, float], tuple[float, float]]:
    if segment.orientation == "H":
        return (
            (segment.start, segment.fixed),
            (segment.end, segment.fixed),
        )
    return (
        (segment.fixed, segment.start),
        (segment.fixed, segment.end),
    )


def fmt(value: float) -> str:
    return f"{value:.3f}"


def oracle_nc(
    case_id: str,
    segments: list[Segment],
    *,
    omit_first_segment: bool = False,
    extra_gouge: tuple[tuple[float, float], tuple[float, float]] | None = None,
) -> str:
    chosen = segments[1:] if omit_first_segment else segments
    lines = [
        "(VERICUT geometry oracle; not a production machine program)",
        f"(Case: {case_id})",
        "(Method-invariant merged cutter-centerline union)",
        f"(Stock XY: {STOCK_X:.3f} x {STOCK_Y:.3f} mm)",
        "G21",
        "G90",
        "G17",
        "G40",
        "G0 Z5.000",
        "T1 M6",
        "M3 S18000",
    ]
    for index, segment in enumerate(chosen, start=1):
        a, b = segment_endpoints(segment)
        lines.extend(
            [
                f"(ORACLE_SEGMENT {index:03d} {segment.as_record()})",
                "G0 Z5.000",
                f"G0 X{fmt(a[0])} Y{fmt(a[1])}",
                "G0 Z1.000",
            ]
        )
        start, end = a, b
        for depth in (-6.0, -12.0, -18.0):
            lines.append(f"G1 Z{fmt(depth)} F800.0")
            lines.append(f"G1 X{fmt(end[0])} Y{fmt(end[1])} F3600.0")
            start, end = end, start
    if extra_gouge is not None:
        a, b = extra_gouge
        lines.extend(
            [
                "(POSITIVE CONTROL: deliberate interior gouge)",
                "G0 Z5.000",
                f"G0 X{fmt(a[0])} Y{fmt(a[1])}",
                "G1 Z-18.000 F800.0",
                f"G1 X{fmt(b[0])} Y{fmt(b[1])} F3600.0",
            ]
        )
    lines.extend(["G0 Z5.000", "M5", "M30", ""])
    return "\n".join(lines)


def read_selected_layout_rows(
    archive: zipfile.ZipFile, member: str, board_id: int
) -> list[dict[str, str]]:
    with archive.open(member) as raw:
        rows = list(csv.DictReader(io.TextIOWrapper(raw, encoding="utf-8-sig")))
    selected = [row for row in rows if int(row["board"]) == board_id]
    if not selected:
        raise ValueError(f"board {board_id} missing from {member}")
    return selected


def write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def build_readme() -> str:
    return """# IJAMT VERICUT qualified-machine validation prep v3

## What this package is for

This package upgrades the earlier nominal timing replay into a separate,
auditable machine-and-material-removal verification. It does not alter the 15
frozen comparison NC programs. The three required outcomes are:

1. machine/tool-chain/fixture collision status;
2. gouge or overcut relative to an expected as-machined Design model;
3. excess or remaining material relative to the same Design model.

VERICUT must be run on Windows with a licensed Verification and AUTO-DIFF
configuration. The macOS preparation step cannot execute VERICUT.

## Evidence boundary

The result may be called a **qualified representative VERICUT machine-model
check** only after every required row in `tables/machine_model_qualification.csv`
is completed and the positive/negative controls pass. It may be called an
actual-machine digital twin only if the machine, controller, tool chain,
fixture, work offset, and limits are traced to the production equipment. A
generic or library model must remain labelled representative.

## Frozen study design

- Comparison units: five factory-derived layouts.
- Programs per layout: proposed, process-aware topology, ordinary beam.
- Total comparison runs: 15.
- Geometry target runs: five method-invariant oracle programs.
- Repeats are software checks, not independent observations.
- Original run order is retained for comparability. Reset the project and stock
  before every run.
- NC files are frozen; compare their hashes with `manifests/nc_sha256.csv`.

The geometry oracle is not one of the compared methods. For each layout it
contains the merged cutter-centerline union that is identical across all three
methods. Simulate the oracle once and export its cut stock as an STL/Design
model. This retains expected waste islands, avoiding the false excess-material
reports that arise when isolated part solids are used as the only Design.

## Required model gate

Do not start the 15 runs until all of the following are true:

- the machine model contains visible solid geometry for moving and static
  components, not empty kinematic axes;
- X/Y/Z travels, home position, and limits are recorded;
- spindle nose, collet/chuck, holder, shank, and cutter are dimensioned;
- the table/spoilboard/fixture or vacuum support envelope is modelled;
- stock is 2440 x 1220 x 18 mm at X0 Y0 Z0 on its upper surface;
- T1 is a 6 mm flat cutter with sufficient flute and gauge length;
- machine collision detection and axis-limit checking are enabled;
- holder/shank to stock and holder/shank/cutter to fixture checks are enabled;
- cutting-stock contact is treated as cutting, not a collision;
- cut-stock numerical tolerance is no coarser than 0.05 mm;
- AUTO-DIFF solid gouge and excess tolerances are both 0.10 mm;
- the collision negative control is clean and the collision positive control is
  detected;
- the deliberate 0.50 mm gouge and omitted-span controls are detected.

## Windows execution order

1. Copy the package to a short ASCII-only path, for example
   `D:\\IJAMT_VERICUT_V3`.
2. Complete `tables/machine_model_qualification.csv` from the VERICUT project,
   OEM/model records, and tool/fixture measurements.
3. Build and save one qualified master project. Do not tune it after viewing
   method results.
4. Add a temporary 20 x 20 x 2 mm calibration fixture block spanning
   X=90--110, Y=90--110, Z=0--2 in a **copy** of the master. Run
   `controls/collision_negative_control.nc` (must be clean) and
   `controls/collision_positive_control.nc` (must report collision). Delete the
   calibration copy; do not change the frozen master.
5. For each layout, load `geometry_oracles/<case>/design_oracle.nc`, reset the
   2440 x 1220 x 18 mm stock, run to M30, and export the resulting cut stock as
   `design_models/<case>_oracle_cut_stock.stl`.
6. Freeze and hash the five Design files. Import the matching Design for each
   layout with no translation or rotation.
7. In copies of the same master, run the deliberate gouge and omitted-span
   controls for `case01_small`; AUTO-DIFF must detect both.
8. Run the 15 rows in `tables/run_sheet.csv`. For each row reset stock, load the
   matching Design, run from initialization to M30, execute AUTO-DIFF, save the
   project, HTML report, log, AUTO-DIFF report, and the required screenshots.
9. Complete `tables/result_entry.csv`; do not use blank, N/A, or qualitative-only
   entries for collision/gouge/excess results.
10. Run `windows/preflight_gate.ps1`, then `windows/finalize_evidence.ps1`.

## Acceptance rule

The confirmatory comparison package passes only if all 15 programs reach M30
with zero fatal VERICUT errors, zero axis overtravel, zero machine/spindle/
holder/shank/fixture collisions, zero gouge beyond 0.10 mm, and zero excess
material beyond 0.10 mm relative to the frozen oracle Design. A failure is
reported, not silently repaired. Any project/model change increments the setup
version and requires all 15 runs to be repeated.

## Interpretation

A clean result establishes that the three frozen route programs realize the
same intended cutter-swept geometry without collision in the qualified model.
It does not validate vacuum retention, cutting force, part motion, surface
quality, dimensional accuracy, or measured machine cycle time.
"""


def build_protocol() -> str:
    return """# Frozen protocol and reporting rules

## Research question

Do the 15 frozen canonical NC programs complete without modelled machine,
tool-chain, or fixture collision and without overcut or remaining material
beyond 0.10 mm relative to a method-invariant as-machined target?

## Experimental unit and responses

The independent comparison unit is the layout (n=5). Method is a matched
within-layout condition. VERICUT is deterministic; reruns are not replicates.
Primary responses are program completion, collision count by component pair,
maximum gouge depth, gouge count, maximum excess thickness, and excess count.
Reported time remains secondary.

## Controls

- Collision negative control: the tool passes the calibration block at Z=5 mm.
- Collision positive control: the tool crosses the same block at Z=1 mm.
- Gouge positive control: a 0.50 mm-or-larger deliberate interior cutting path.
- Excess positive control: one complete target span omitted at all depths.

The study gate fails if any expected control response is absent.

## Frozen numerical settings

- Tool diameter: 6.000 mm.
- Stock: 2440 x 1220 x 18 mm.
- Work origin: stock lower-left, top surface, X0 Y0 Z0.
- Depths: -6, -12, -18 mm.
- Cut-stock calculation tolerance: <=0.05 mm.
- AUTO-DIFF solid gouge tolerance: 0.10 mm.
- AUTO-DIFF solid excess tolerance: 0.10 mm.
- Near-miss distance: record separately; do not merge near misses with
  collisions.

## Blinding and run order

The previous frozen run order is retained. It was fixed before the present
collision/AUTO-DIFF results existed. Result files use case and method names for
traceability; no subjective scoring is performed. Every method run starts from
the same master and a reset stock state.

## Failure policy

Do not edit an NC file after a failure. First preserve the project, report, log,
AUTO-DIFF report, screenshot, and first offending NC block. Classify the cause
as program, target/coordinate mismatch, tool-chain geometry, fixture/machine
geometry, controller interpretation, or unresolved. If the master changes,
increment the setup version and rerun the complete 15-program set.

## Manuscript claim allowed after a pass

“All 15 frozen programs completed in a qualified representative VERICUT
three-axis-router model with collision and axis-limit checking enabled. Relative
to five method-invariant as-machined Design models, no machine/tool-chain/
fixture collision and no gouge or excess material beyond 0.10 mm was detected.”

Replace “representative” with the exact machine identity only when the complete
model-to-equipment traceability table supports that wording.
"""


def build_chinese_checklist() -> str:
    return """# Windows / VERICUT 图形界面执行清单

## 一、先判断机床模型是否够格

打开主项目后，不要先跑论文程序。依次确认并截图：

1. 项目树中不仅有 X/Y/Z 运动轴，还能看到台面、横梁或移动部件、主轴头等实体；
2. T1 显示刀具、刀杆/夹头和刀柄实体，记录刃长、伸出量、总刀长及刀柄最大直径；
3. Stock 为 2440 x 1220 x 18 mm，顶面为 Z0，左下角为 X0 Y0；
4. 台面、垫板或夹具/真空支撑外形存在，且坐标与Stock一致；
5. 机床碰撞检查和轴行程检查均开启；
6. 碰撞矩阵与 `tables/collision_pair_matrix.csv` 一致；
7. Force、OptiPath、NC重写关闭；
8. 切后Stock计算公差不大于0.05 mm；
9. AUTO-DIFF选择Solid比较，Gouge和Excess阈值均为0.10 mm。

如果只有运动轴名称而没有实体几何，这个模型仍不合格，不能写成“碰撞验证”。

## 二、先跑四个控制程序

在主项目副本中加入临时校准夹具块：

- X=90--110 mm；
- Y=90--110 mm；
- Z=0--2 mm。

然后运行：

- `collision_negative_control.nc`：刀尖以Z5越过校准块，必须零碰撞；
- `collision_positive_control.nc`：刀尖以Z1越过校准块，必须报警；
- `gouge_positive_control.nc`：相对case01 Design必须检出大于0.10 mm的过切；
- `excess_positive_control.nc`：相对case01 Design必须检出大于0.10 mm的余量。

每个控制保存报告和截图，并填写 `tables/control_results.csv`。任何一个控制没有产生预期结果，都停止正式运行。

## 三、生成五个Design

对每个 `geometry_oracles/<case>/design_oracle.nc`：

1. 从合格主项目新建副本；
2. Reset，确认完整原始Stock；
3. 加载对应oracle并运行至M30；
4. 确认无错误后，将切后Stock导出为STL；
5. 严格使用 `manifests/oracle_manifest.csv` 中指定的文件名；
6. 保存到 `design_models/`；
7. 重新导入检查坐标，禁止自动居中、缩放或旋转；
8. 保存一个顶视图和一个斜视图截图。

这里导出的是“预期切后整板”，其中保留正常废料岛。不要只用零件块作为Design，否则正常废料会被误报为余量。

## 四、正式跑15个程序

严格按 `tables/run_sheet.csv` 的顺序。每一行都：

1. 从同一个冻结主项目建立副本；
2. Reset完整Stock；
3. 加载该case对应的Design STL；
4. 只替换NC文件，不改刀具、夹具、坐标、碰撞矩阵或容差；
5. 运行至M30；
6. 运行AUTO-DIFF Solid比较；
7. 记录碰撞数、首次碰撞对象、最大过切、过切数、最大余量、余量数；
8. 保存 `.vcproject`、log、HTML报告、AUTO-DIFF报告、总览截图和差异图；
9. 填写 `tables/result_entry.csv`。

若某个项目失败，先保留证据，不要现场修改NC。只要主模型或设置改变，setup版本必须加一，并重跑全部15个程序。

## 五、完成门

在PowerShell中进入包目录后运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\\windows\\preflight_gate.ps1
powershell -ExecutionPolicy Bypass -File .\\windows\\finalize_evidence.ps1
```

只有出现三个PASS并成功生成结果ZIP，才把包发回Mac端分析和写入论文。
"""


def build_powershell_gate() -> str:
    return r"""param(
    [string]$BundleRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$qualification = Join-Path $BundleRoot 'tables\machine_model_qualification.csv'
$results = Join-Path $BundleRoot 'tables\result_entry.csv'
$controls = Join-Path $BundleRoot 'tables\control_results.csv'

foreach ($path in @($qualification, $results, $controls)) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Missing required table: $path" }
}

$missingQualification = Import-Csv -LiteralPath $qualification |
    Where-Object { $_.required -eq 'yes' -and [string]::IsNullOrWhiteSpace($_.value) }
if ($missingQualification) {
    $fields = ($missingQualification.field -join ', ')
    throw "Qualification gate incomplete: $fields"
}

$qualificationRows = Import-Csv -LiteralPath $qualification
$qualificationMap = @{}
foreach ($row in $qualificationRows) { $qualificationMap[$row.field] = $row.value }
foreach ($field in @(
    'verification_license_enabled', 'autodiff_license_enabled',
    'solid_machine_geometry_present', 'axis_limit_check_enabled',
    'machine_collision_check_enabled'
)) {
    if ($qualificationMap[$field] -ne 'yes') {
        throw "Qualification field must be yes: $field"
    }
}
foreach ($field in @('force_or_optipath_enabled', 'nc_rewrite_enabled')) {
    if ($qualificationMap[$field] -ne 'no') {
        throw "Qualification field must be no: $field"
    }
}
if ($qualificationMap['model_scope'] -notin @('exact_machine','qualified_representative')) {
    throw 'model_scope must be exact_machine or qualified_representative'
}
if ([double]$qualificationMap['cut_stock_tolerance_mm'] -gt 0.05) {
    throw 'Cut-stock tolerance must be no coarser than 0.05 mm.'
}
if ([double]$qualificationMap['autodiff_gouge_tolerance_mm'] -ne 0.10 -or
    [double]$qualificationMap['autodiff_excess_tolerance_mm'] -ne 0.10) {
    throw 'AUTO-DIFF gouge and excess tolerances must both equal 0.10 mm.'
}

$controlRows = Import-Csv -LiteralPath $controls
if ($controlRows.Count -ne 4) { throw 'Exactly four control rows are required.' }
$failedControls = $controlRows | Where-Object { $_.observed_pass -ne 'yes' }
if ($failedControls) {
    throw "Control gate failed: $(($failedControls.control_id) -join ', ')"
}

$rows = Import-Csv -LiteralPath $results
if ($rows.Count -ne 15) { throw "Expected 15 result rows; found $($rows.Count)." }
$requiredColumns = @(
    'program_completed', 'fatal_error_count', 'axis_overtravel_count',
    'collision_count', 'max_gouge_mm', 'gouge_count',
    'max_excess_mm', 'excess_count', 'report_path', 'log_path',
    'autodiff_report_path', 'project_path'
)
foreach ($row in $rows) {
    foreach ($column in $requiredColumns) {
        if ([string]::IsNullOrWhiteSpace($row.$column)) {
            throw "Blank $column for $($row.case_id)/$($row.method)"
        }
    }
    if ($row.program_completed -ne 'yes' -or
        [int]$row.fatal_error_count -ne 0 -or
        [int]$row.axis_overtravel_count -ne 0 -or
        [int]$row.collision_count -ne 0 -or
        [double]$row.max_gouge_mm -gt 0.10 -or
        [int]$row.gouge_count -ne 0 -or
        [double]$row.max_excess_mm -gt 0.10 -or
        [int]$row.excess_count -ne 0) {
        throw "Acceptance failure: $($row.case_id)/$($row.method)"
    }
    foreach ($column in @('report_path','log_path','autodiff_report_path','project_path')) {
        if (-not (Test-Path -LiteralPath $row.$column)) {
            throw "Evidence file missing for $($row.case_id)/$($row.method): $($row.$column)"
        }
    }
    $log = Get-Content -LiteralPath $row.log_path -Raw
    if ($log -match 'collision checking.*disabled|机床碰撞检查已关闭') {
        throw "Collision-disabled warning found: $($row.log_path)"
    }
}

Write-Output 'QUALIFICATION_GATE=PASS'
Write-Output 'CONTROL_GATE=PASS'
Write-Output 'FIFTEEN_RUN_ACCEPTANCE_GATE=PASS'
"""


def build_powershell_finalize() -> str:
    return r"""param(
    [string]$BundleRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'preflight_gate.ps1') -BundleRoot $BundleRoot

$evidenceRoot = Join-Path $BundleRoot 'windows_evidence'
if (-not (Test-Path -LiteralPath $evidenceRoot)) {
    throw "Missing windows_evidence directory: $evidenceRoot"
}
$hashPath = Join-Path $BundleRoot 'WINDOWS_EVIDENCE_SHA256.csv'
$files = Get-ChildItem -LiteralPath $evidenceRoot -File -Recurse | Sort-Object FullName
$rows = foreach ($file in $files) {
    [pscustomobject]@{
        relative_path = $file.FullName.Substring($BundleRoot.Length + 1)
        sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        bytes = $file.Length
    }
}
$rows | Export-Csv -LiteralPath $hashPath -NoTypeInformation -Encoding UTF8

$zipPath = Join-Path (Split-Path -Parent $BundleRoot) 'IJAMT_VERICUT_machine_validation_v3_results.zip'
if (Test-Path -LiteralPath $zipPath) {
    throw "Refusing to overwrite existing evidence zip: $zipPath"
}
Compress-Archive -LiteralPath $BundleRoot -DestinationPath $zipPath -CompressionLevel Optimal
Write-Output "EVIDENCE_ZIP=$zipPath"
Write-Output "EVIDENCE_FILES=$($rows.Count)"
"""


def build_collision_control(z_height: float, label: str) -> str:
    return f"""(VERICUT collision {label} control; calibration project only)
(Temporary fixture block: X90..110 Y90..110 Z0..2)
G21
G90
G17
G40
G0 Z5.000
T1 M6
M3 S18000
G0 X80.000 Y100.000
G0 Z{z_height:.3f}
G0 X120.000 Y100.000
G0 Z5.000
M5
M30
"""


def build_package(
    output: Path,
    *,
    nc_root: Path = DEFAULT_NC_ROOT,
    selection_path: Path = DEFAULT_SELECTION,
    layout_zip: Path = DEFAULT_LAYOUT_ZIP,
) -> None:
    if output.exists():
        raise FileExistsError(f"refusing to overwrite existing output: {output}")
    output.mkdir(parents=True)

    selection_rows = list(
        csv.DictReader(selection_path.open(encoding="utf-8-sig", newline=""))
    )
    selection_by_key = {
        (row["case_id"], row["method"]): row for row in selection_rows
    }
    if len(selection_by_key) != 15:
        raise ValueError("selection manifest must contain 15 unique case/method rows")

    coverage_rows: list[dict[str, object]] = []
    hash_rows: list[dict[str, object]] = []
    layout_rows: list[dict[str, object]] = []
    oracle_rows: list[dict[str, object]] = []
    run_rows: list[dict[str, object]] = []

    with zipfile.ZipFile(layout_zip) as archive:
        for case_id, (member, board_id) in CASE_LAYOUTS.items():
            selected = read_selected_layout_rows(archive, member, board_id)
            for row in selected:
                layout_rows.append({"case_id": case_id, **row})

            unions: dict[str, list[Segment]] = {}
            for method in METHODS:
                source = nc_root / case_id / f"{method}.nc"
                destination = output / "cases" / case_id / f"{method}.nc"
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)

                expected = selection_by_key[(case_id, method)]["nc_sha256"]
                actual = sha256_file(destination)
                if actual != expected:
                    raise ValueError(
                        f"NC hash mismatch for {case_id}/{method}: {actual} != {expected}"
                    )
                raw_segments = parse_cut_segments(destination)
                merged = merge_segments(raw_segments)
                unions[method] = merged
                union_hash = segment_union_hash(merged)
                coverage_rows.append(
                    {
                        "case_id": case_id,
                        "method": method,
                        "raw_cut_segment_count": len(raw_segments),
                        "merged_segment_count": len(merged),
                        "union_sha256": union_hash,
                        "degree_one_endpoint_count": endpoint_degree_one_count(merged),
                        "axis_aligned": "yes",
                    }
                )
                hash_rows.append(
                    {
                        "relative_path": destination.relative_to(output).as_posix(),
                        "sha256": actual,
                        "source_frozen_sha256": expected,
                        "unchanged": "yes",
                    }
                )

            reference = unions[METHODS[0]]
            if any(unions[method] != reference for method in METHODS[1:]):
                raise ValueError(f"method cutter-centerline unions differ for {case_id}")
            union_hash = segment_union_hash(reference)
            for row in coverage_rows:
                if row["case_id"] == case_id:
                    row["oracle_union_sha256"] = union_hash
                    row["method_equals_oracle"] = "yes"

            oracle_dir = output / "geometry_oracles" / case_id
            oracle_dir.mkdir(parents=True, exist_ok=True)
            oracle_path = oracle_dir / "design_oracle.nc"
            oracle_path.write_text(
                oracle_nc(case_id, reference), encoding="utf-8"
            )
            oracle_rows.append(
                {
                    "case_id": case_id,
                    "rectangle_count": len(selected),
                    "merged_segment_count": len(reference),
                    "segment_union_sha256": union_hash,
                    "oracle_nc": oracle_path.relative_to(output).as_posix(),
                    "oracle_nc_sha256": sha256_file(oracle_path),
                    "expected_design_stl": (
                        f"design_models/{case_id}_oracle_cut_stock.stl"
                    ),
                }
            )

            if case_id == "case01_small":
                first = selected[0]
                x = float(first["x"]) + TOOL_DIAMETER / 2 + 20.0
                y = float(first["y"]) + TOOL_DIAMETER / 2 + 20.0
                gouge_path = output / "controls" / "gouge_positive_control.nc"
                gouge_path.parent.mkdir(parents=True, exist_ok=True)
                gouge_path.write_text(
                    oracle_nc(
                        case_id,
                        reference,
                        extra_gouge=((x, y), (x + 20.0, y)),
                    ),
                    encoding="utf-8",
                )
                excess_path = output / "controls" / "excess_positive_control.nc"
                excess_path.write_text(
                    oracle_nc(case_id, reference, omit_first_segment=True),
                    encoding="utf-8",
                )

    previous_order_rows = list(
        csv.DictReader(
            (
                ROOT
                / "outputs"
                / "vericut_supplement_corrected_final_20260730"
                / "IJAMT_VERICUT_supplement_corrected_final_20260730"
                / "results"
                / "run_sheet.csv"
            ).open(encoding="utf-8-sig", newline="")
        )
    )
    for row in sorted(previous_order_rows, key=lambda item: int(item["run_order"])):
        case_id = row["case_id"]
        method = row["method"]
        run_rows.append(
            {
                "run_order": int(row["run_order"]),
                "case_id": case_id,
                "method": method,
                "nc_file": f"cases/{case_id}/{method}.nc",
                "design_file": f"design_models/{case_id}_oracle_cut_stock.stl",
                "setup_version": "QUALIFIED_MACHINE_V3_TO_FILL",
                "reset_stock_before_run": "yes",
                "autodiff_gouge_tolerance_mm": "0.10",
                "autodiff_excess_tolerance_mm": "0.10",
            }
        )

    write_csv(
        output / "manifests" / "geometry_coverage_audit.csv",
        [
            "case_id",
            "method",
            "raw_cut_segment_count",
            "merged_segment_count",
            "union_sha256",
            "degree_one_endpoint_count",
            "axis_aligned",
            "oracle_union_sha256",
            "method_equals_oracle",
        ],
        coverage_rows,
    )
    write_csv(
        output / "manifests" / "nc_sha256.csv",
        ["relative_path", "sha256", "source_frozen_sha256", "unchanged"],
        hash_rows,
    )
    write_csv(
        output / "manifests" / "selected_layout_rows.csv",
        [
            "case_id",
            "board",
            "uid",
            "pid_raw",
            "x",
            "y",
            "w",
            "h",
            "w0",
            "h0",
            "rotated",
        ],
        layout_rows,
    )
    write_csv(
        output / "manifests" / "oracle_manifest.csv",
        [
            "case_id",
            "rectangle_count",
            "merged_segment_count",
            "segment_union_sha256",
            "oracle_nc",
            "oracle_nc_sha256",
            "expected_design_stl",
        ],
        oracle_rows,
    )
    write_csv(
        output / "tables" / "run_sheet.csv",
        [
            "run_order",
            "case_id",
            "method",
            "nc_file",
            "design_file",
            "setup_version",
            "reset_stock_before_run",
            "autodiff_gouge_tolerance_mm",
            "autodiff_excess_tolerance_mm",
        ],
        run_rows,
    )

    result_rows = [
        {
            **row,
            "program_completed": "",
            "fatal_error_count": "",
            "axis_overtravel_count": "",
            "collision_count": "",
            "collision_pairs": "",
            "near_miss_count": "",
            "max_gouge_mm": "",
            "gouge_count": "",
            "max_excess_mm": "",
            "excess_count": "",
            "vericut_total_time_s": "",
            "report_path": "",
            "log_path": "",
            "autodiff_report_path": "",
            "project_path": "",
            "screenshot_overview_path": "",
            "screenshot_autodiff_path": "",
            "notes": "",
        }
        for row in run_rows
    ]
    result_fields = list(result_rows[0])
    write_csv(output / "tables" / "result_entry.csv", result_fields, result_rows)

    qualification_rows = [
        ("vericut_version", "", "yes", "About dialog screenshot"),
        ("verification_license_enabled", "", "yes", "VERICUT license dialog"),
        ("autodiff_license_enabled", "", "yes", "VERICUT license dialog"),
        ("model_scope", "", "yes", "exact_machine or qualified_representative"),
        ("machine_manufacturer", "", "yes", "OEM/nameplate or library model record"),
        ("machine_model", "", "yes", "OEM/nameplate or library model record"),
        ("controller_model", "", "yes", "controller record"),
        ("machine_file_path", "", "yes", "frozen project"),
        ("machine_file_sha256", "", "yes", "Get-FileHash"),
        ("master_project_path", "", "yes", "frozen project"),
        ("master_project_sha256", "", "yes", "Get-FileHash"),
        ("solid_machine_geometry_present", "", "yes", "project tree + screenshot"),
        ("x_travel_mm", "", "yes", "machine model"),
        ("y_travel_mm", "", "yes", "machine model"),
        ("z_travel_mm", "", "yes", "machine model"),
        ("axis_limit_check_enabled", "", "yes", "project setting"),
        ("machine_collision_check_enabled", "", "yes", "project setting"),
        ("spindle_head_geometry_source", "", "yes", "CAD/OEM/library record"),
        ("tool_library_path", "", "yes", "frozen project"),
        ("tool_library_sha256", "", "yes", "Get-FileHash"),
        ("tool_diameter_mm", "6.000", "yes", "tool setup"),
        ("tool_flute_length_mm", "", "yes", "tool datasheet/setup"),
        ("tool_gauge_length_mm", "", "yes", "tool setup"),
        ("holder_geometry_source", "", "yes", "CAD/tool setup"),
        ("holder_max_diameter_mm", "", "yes", "tool setup"),
        ("fixture_or_spoilboard_geometry_source", "", "yes", "CAD/setup"),
        ("stock_definition", "2440 x 1220 x 18 mm", "yes", "frozen protocol"),
        ("work_origin", "stock lower-left top; X0 Y0 Z0", "yes", "frozen protocol"),
        ("cut_stock_tolerance_mm", "0.05", "yes", "project setting; <=0.05"),
        ("autodiff_gouge_tolerance_mm", "0.10", "yes", "AUTO-DIFF"),
        ("autodiff_excess_tolerance_mm", "0.10", "yes", "AUTO-DIFF"),
        ("force_or_optipath_enabled", "no", "yes", "project setting"),
        ("nc_rewrite_enabled", "no", "yes", "project setting"),
        ("freeze_timestamp", "", "yes", "ISO 8601"),
    ]
    write_csv(
        output / "tables" / "machine_model_qualification.csv",
        ["field", "value", "required", "evidence_source"],
        (
            {
                "field": field,
                "value": value,
                "required": required,
                "evidence_source": source,
            }
            for field, value, required, source in qualification_rows
        ),
    )

    collision_rows = [
        ("holder", "stock", "enabled", "collision"),
        ("holder", "fixture_or_spoilboard", "enabled", "collision"),
        ("shank", "stock", "enabled", "collision"),
        ("shank", "fixture_or_spoilboard", "enabled", "collision"),
        ("cutter", "fixture_or_spoilboard", "enabled", "collision"),
        ("spindle_or_head", "stock", "enabled", "collision"),
        ("spindle_or_head", "fixture_or_spoilboard", "enabled", "collision"),
        ("moving_machine_components", "static_machine_components", "enabled", "collision"),
        ("cutter", "stock_during_M3_cutting", "cutting", "material removal"),
    ]
    write_csv(
        output / "tables" / "collision_pair_matrix.csv",
        ["component_a", "component_b", "required_state", "classification"],
        (
            {
                "component_a": a,
                "component_b": b,
                "required_state": state,
                "classification": classification,
            }
            for a, b, state, classification in collision_rows
        ),
    )

    control_rows = [
        (
            "collision_negative",
            "controls/collision_negative_control.nc",
            "zero collision",
        ),
        (
            "collision_positive",
            "controls/collision_positive_control.nc",
            "one or more cutter-fixture collisions",
        ),
        (
            "gouge_positive",
            "controls/gouge_positive_control.nc",
            "gouge greater than 0.10 mm",
        ),
        (
            "excess_positive",
            "controls/excess_positive_control.nc",
            "excess greater than 0.10 mm",
        ),
    ]
    write_csv(
        output / "tables" / "control_results.csv",
        [
            "control_id",
            "nc_file",
            "expected_response",
            "observed_response",
            "observed_pass",
            "report_path",
            "screenshot_path",
        ],
        (
            {
                "control_id": control_id,
                "nc_file": nc_file,
                "expected_response": expected,
                "observed_response": "",
                "observed_pass": "",
                "report_path": "",
                "screenshot_path": "",
            }
            for control_id, nc_file, expected in control_rows
        ),
    )

    controls = output / "controls"
    controls.mkdir(parents=True, exist_ok=True)
    (controls / "collision_negative_control.nc").write_text(
        build_collision_control(5.0, "negative"),
        encoding="utf-8",
    )
    (controls / "collision_positive_control.nc").write_text(
        build_collision_control(1.0, "positive"),
        encoding="utf-8",
    )

    (output / "README_CN_AND_EN.md").write_text(
        build_readme(), encoding="utf-8"
    )
    (output / "protocol" / "FROZEN_PROTOCOL.md").parent.mkdir(
        parents=True, exist_ok=True
    )
    (output / "protocol" / "FROZEN_PROTOCOL.md").write_text(
        build_protocol(), encoding="utf-8"
    )
    (output / "protocol" / "WINDOWS_GUI_CHECKLIST_CN.md").write_text(
        build_chinese_checklist(), encoding="utf-8"
    )
    (output / "windows").mkdir(parents=True, exist_ok=True)
    (output / "windows" / "preflight_gate.ps1").write_text(
        build_powershell_gate().replace("\n", "\r\n"), encoding="utf-8-sig"
    )
    (output / "windows" / "finalize_evidence.ps1").write_text(
        build_powershell_finalize().replace("\n", "\r\n"), encoding="utf-8-sig"
    )
    (output / "design_models").mkdir()
    (output / "windows_evidence").mkdir()
    (output / "design_models" / "PUT_FIVE_ORACLE_STL_FILES_HERE.txt").write_text(
        "Export one cut-stock STL per oracle using the exact filenames in "
        "manifests/oracle_manifest.csv.\n",
        encoding="utf-8",
    )
    (output / "windows_evidence" / "PUT_WINDOWS_RESULTS_HERE.txt").write_text(
        "Store frozen projects, logs, HTML reports, AUTO-DIFF reports, and "
        "screenshots below this directory.\n",
        encoding="utf-8",
    )

    package_files = sorted(path for path in output.rglob("*") if path.is_file())
    manifest_rows = [
        {
            "relative_path": path.relative_to(output).as_posix(),
            "sha256": sha256_file(path),
            "bytes": path.stat().st_size,
        }
        for path in package_files
    ]
    write_csv(
        output / "PACKAGE_SHA256.csv",
        ["relative_path", "sha256", "bytes"],
        manifest_rows,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--nc-root", type=Path, default=DEFAULT_NC_ROOT)
    parser.add_argument("--selection", type=Path, default=DEFAULT_SELECTION)
    parser.add_argument("--layout-zip", type=Path, default=DEFAULT_LAYOUT_ZIP)
    args = parser.parse_args()
    build_package(
        args.output,
        nc_root=args.nc_root,
        selection_path=args.selection,
        layout_zip=args.layout_zip,
    )
    print(args.output)


if __name__ == "__main__":
    main()
