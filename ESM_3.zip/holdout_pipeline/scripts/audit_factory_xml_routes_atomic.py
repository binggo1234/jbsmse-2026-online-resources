from __future__ import annotations

import csv
import json
import os
import sys
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from time import perf_counter


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.audit_holdout_routes import audit_plan_atomic_spans, metrics_match
import scripts.run_factory_xml_routes as track_b
import scripts.run_holdout_routes as stage7_run


OUTPUT = track_b.OUTPUT_DIR / "proposed_atomic_span_audit.csv"
SUMMARY = track_b.OUTPUT_DIR / "atomic_span_audit.json"
REPORT = track_b.OUTPUT_DIR / "atomic_span_audit.md"
REQUIRED_PYTHON_HASH_SEED = "0"


@dataclass(frozen=True)
class AtomicAuditRow:
    job_id: str
    task_id: str
    confirmatory_status: str
    pattern_id: str
    placements_member: str
    rectangle_count: int
    atomic_span_count: int
    covered_atomic_span_count: int
    missing_atomic_span_count: int
    repeated_atomic_span_count: int
    unknown_cutting_unit_count: int
    coverage_ratio: float
    hard_penalty: float
    stored_metrics_match: bool
    status: str
    audit_runtime_ms: float
    error_class: str
    error_message: str


def append_row(row: AtomicAuditRow) -> None:
    fields = list(AtomicAuditRow.__dataclass_fields__)
    write_header = not OUTPUT.exists() or OUTPUT.stat().st_size == 0
    with OUTPUT.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        if write_header:
            writer.writeheader()
        writer.writerow(asdict(row))


def run(resume: bool) -> None:
    if os.environ.get("PYTHONHASHSEED") != REQUIRED_PYTHON_HASH_SEED:
        raise ValueError(
            "Track B atomic replay requires PYTHONHASHSEED="
            f"{REQUIRED_PYTHON_HASH_SEED}"
        )
    track_b.audit()
    stage7 = stage7_run._load_stage7()
    from cnc_cutting.models import CuttingActionType
    from cnc_cutting.travel import clear_detour_cache

    jobs = [
        row
        for row in track_b.read_csv(track_b.FROZEN_JOBS)
        if row["method"] == track_b.PROPOSED
    ]
    stored = {
        row["job_id"]: row
        for row in track_b.read_csv(track_b.RESULTS)
        if row["method"] == track_b.PROPOSED
    }
    completed = (
        {row["job_id"] for row in track_b.read_csv(OUTPUT)}
        if resume and OUTPUT.exists()
        else set()
    )
    if not resume and OUTPUT.exists():
        raise ValueError("atomic audit exists; use --resume")
    args = stage7_run.stage7_args()
    total = len(jobs)
    for (
        pattern_jobs,
        layout,
        panel,
        tool,
        process_model,
        tool_event_gate,
        units,
    ) in track_b.iter_patterns(jobs, stage7):
        job = pattern_jobs[0]
        if job["job_id"] in completed:
            continue
        started = perf_counter()
        clear_detour_cache()
        status = "passed"
        error_class = ""
        error_message = ""
        atomic_count = covered_count = missing_count = repeated_count = unknown = 0
        coverage_ratio = 0.0
        hard_penalty = float("inf")
        matches = False
        try:
            spec = stage7.build_planners(
                (track_b.PROPOSED,),
                units,
                panel,
                tool,
                process_model,
                tool_event_gate,
                len(layout.rectangles),
                args.repeat_cut_policy,
                algorithm_seed=args.algorithm_seed,
            )[0]
            with stage7.task_timeout(track_b.TIMEOUT_SECONDS):
                plan = spec.planner()
            (
                atomic_count,
                covered_count,
                missing_count,
                repeated_count,
                unknown,
                coverage_ratio,
            ) = audit_plan_atomic_spans(units, plan, CuttingActionType.CUT)
            hard_penalty = float(plan.metrics.hard_penalty)
            matches = metrics_match(plan, stored[job["job_id"]])
            if (
                missing_count
                or repeated_count
                or unknown
                or hard_penalty != 0.0
                or not matches
            ):
                status = "failed"
        except Exception as exc:  # pragma: no cover - persisted for audit
            status = "failed"
            error_class = type(exc).__name__
            error_message = str(exc)[:500]
        append_row(
            AtomicAuditRow(
                job_id=job["job_id"],
                task_id=job["task_id"],
                confirmatory_status=job["confirmatory_status"],
                pattern_id=job["pattern_id"],
                placements_member=job["placements_member"],
                rectangle_count=len(layout.rectangles),
                atomic_span_count=atomic_count,
                covered_atomic_span_count=covered_count,
                missing_atomic_span_count=missing_count,
                repeated_atomic_span_count=repeated_count,
                unknown_cutting_unit_count=unknown,
                coverage_ratio=coverage_ratio,
                hard_penalty=hard_penalty,
                stored_metrics_match=matches,
                status=status,
                audit_runtime_ms=(perf_counter() - started) * 1000.0,
                error_class=error_class,
                error_message=error_message,
            )
        )
        completed.add(job["job_id"])
        if len(completed) % 100 == 0 or len(completed) == total:
            print(f"track-b atomic audit {len(completed)}/{total}", flush=True)


def summarize() -> dict[str, object]:
    rows = track_b.read_csv(OUTPUT)
    expected = int(track_b.verify_freeze()["pattern_count"])
    status_counts = Counter(row["status"] for row in rows)
    summary = {
        "audit_status": "passed",
        "python_hash_seed": REQUIRED_PYTHON_HASH_SEED,
        "route_count": len(rows),
        "status_counts": dict(status_counts),
        "missing_atomic_span_count": sum(
            int(row["missing_atomic_span_count"]) for row in rows
        ),
        "repeated_atomic_span_count": sum(
            int(row["repeated_atomic_span_count"]) for row in rows
        ),
        "unknown_cutting_unit_count": sum(
            int(row["unknown_cutting_unit_count"]) for row in rows
        ),
        "hard_failure_count": sum(float(row["hard_penalty"]) != 0.0 for row in rows),
        "stored_replay_mismatch_count": sum(
            row["stored_metrics_match"] != "True" for row in rows
        ),
        "files": {
            "audit_rows": {
                "path": str(OUTPUT),
                "sha256": stage7_run.sha256_file(OUTPUT),
            },
            "route_results": {
                "path": str(track_b.RESULTS),
                "sha256": stage7_run.sha256_file(track_b.RESULTS),
            },
        },
    }
    passed = (
        len(rows) == expected
        and status_counts == Counter({"passed": expected})
        and summary["missing_atomic_span_count"] == 0
        and summary["repeated_atomic_span_count"] == 0
        and summary["unknown_cutting_unit_count"] == 0
        and summary["hard_failure_count"] == 0
        and summary["stored_replay_mismatch_count"] == 0
    )
    summary["audit_status"] = "passed" if passed else "failed"
    SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    REPORT.write_text(
        "\n".join(
            [
                "# Track B proposed atomic-span audit",
                "",
                f"- Audit status: **{summary['audit_status']}**",
                f"- Python hash seed: {summary['python_hash_seed']}",
                f"- Proposed routes replayed: {len(rows)}",
                f"- Missing atomic spans: {summary['missing_atomic_span_count']}",
                f"- Repeated atomic spans: {summary['repeated_atomic_span_count']}",
                f"- Unknown cutting units: {summary['unknown_cutting_unit_count']}",
                f"- Hard failures: {summary['hard_failure_count']}",
                f"- Stored replay mismatches: {summary['stored_replay_mismatch_count']}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    if not passed:
        raise ValueError("Track B atomic-span audit failed")
    return summary


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    route = commands.add_parser("run")
    route.add_argument("--resume", action="store_true")
    commands.add_parser("summarize")
    args = parser.parse_args()
    if args.command == "run":
        run(args.resume)
    else:
        print(json.dumps(summarize(), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
