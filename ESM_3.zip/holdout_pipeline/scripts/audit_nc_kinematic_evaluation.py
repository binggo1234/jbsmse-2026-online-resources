from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

from scripts.prepare_nc_kinematic_evaluation import (
    FREEZE_MANIFEST,
    sha256_file,
)
from scripts.run_nc_kinematic_evaluation import FULL_OUTPUT, PILOT_OUTPUT


ROOT = Path(__file__).resolve().parents[1]
REQUIRED_ANALYSIS_FILES = (
    "gate_report.json",
    "task_scenario_metrics.csv",
    "scenario_comparisons.csv",
    "scenario_robustness_summary.csv",
    "task_equal_geometry_summary.csv",
    "planning_nc_spearman.csv",
)
REQUIRED_EXECUTION_FILES = (
    "results.sqlite",
    "job_results.csv",
    "scenario_times.csv",
    "run_summary.json",
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def canonical_job(row: dict[str, object]) -> tuple[object, ...]:
    return (
        int(row["schedule_order"]),
        str(row["task_id"]),
        str(row["packing_seed"]),
        str(row["placements_member"]),
        str(row["board_id"]),
        str(row["method"]),
    )


def database_audit(
    connection: sqlite3.Connection,
    *,
    expected_job_rows: Iterable[dict[str, object]],
    expected_scenarios: Iterable[dict[str, object]],
    expected_methods: Iterable[str],
    expected_board_count: int,
    expected_task_count: int,
    coordinate_tolerance_mm: float,
) -> dict[str, object]:
    expected_jobs = {str(row["job_id"]): canonical_job(row) for row in expected_job_rows}
    if len(expected_jobs) == 0:
        raise ValueError("expected job manifest is empty")

    cursor = connection.execute(
        """
        SELECT job_id, schedule_order, task_id, packing_seed, placements_member,
               board_id, method
        FROM job_results
        """
    )
    columns = [column[0] for column in cursor.description]
    actual_rows = [dict(zip(columns, row)) for row in cursor]
    actual_jobs = {
        str(row["job_id"]): canonical_job(row)
        for row in actual_rows
    }
    missing_job_ids = sorted(set(expected_jobs) - set(actual_jobs))
    unexpected_job_ids = sorted(set(actual_jobs) - set(expected_jobs))
    metadata_mismatches = sorted(
        job_id
        for job_id in set(expected_jobs) & set(actual_jobs)
        if expected_jobs[job_id] != actual_jobs[job_id]
    )

    board_methods: dict[tuple[str, str, str, str], set[str]] = defaultdict(set)
    task_seeds: dict[str, set[str]] = defaultdict(set)
    for row in actual_rows:
        board = (
            str(row["task_id"]),
            str(row["packing_seed"]),
            str(row["placements_member"]),
            str(row["board_id"]),
        )
        board_methods[board].add(str(row["method"]))
        task_seeds[str(row["task_id"])].add(str(row["packing_seed"]))

    expected_method_set = set(expected_methods)
    malformed_boards = sorted(
        "|".join(board)
        for board, methods in board_methods.items()
        if methods != expected_method_set
    )
    seed_count_distribution = Counter(len(seeds) for seeds in task_seeds.values())

    status_counts = dict(
        connection.execute(
            "SELECT status, COUNT(*) FROM job_results GROUP BY status ORDER BY status"
        ).fetchall()
    )
    audit_failures = connection.execute(
        "SELECT COUNT(*) FROM job_results WHERE audit_passed != 1"
    ).fetchone()[0]
    reference_mismatches = connection.execute(
        "SELECT COUNT(*) FROM job_results WHERE reference_match != 1"
    ).fetchone()[0]
    blank_action_hashes = connection.execute(
        """
        SELECT COUNT(*) FROM job_results
        WHERE length(action_sequence_sha256) != 64 OR length(gcode_sha256) != 64
        """
    ).fetchone()[0]
    maximum_coordinate_error_mm = float(
        connection.execute(
            "SELECT COALESCE(MAX(maximum_coordinate_error_mm), 0) FROM job_results"
        ).fetchone()[0]
    )

    scenario_names = {
        str(row["scenario"]) for row in expected_scenarios
    }
    actual_scenario_names = {
        str(row[0])
        for row in connection.execute(
            "SELECT DISTINCT scenario FROM scenario_times ORDER BY scenario"
        )
    }
    expected_scenarios_per_job = len(scenario_names)
    malformed_scenario_jobs = connection.execute(
        """
        SELECT COUNT(*) FROM (
            SELECT job_id, COUNT(*) AS row_count,
                   COUNT(DISTINCT scenario) AS scenario_count
            FROM scenario_times
            GROUP BY job_id
            HAVING row_count != ? OR scenario_count != ?
        )
        """,
        (expected_scenarios_per_job, expected_scenarios_per_job),
    ).fetchone()[0]
    orphan_scenario_rows = connection.execute(
        """
        SELECT COUNT(*)
        FROM scenario_times AS s
        LEFT JOIN job_results AS j ON j.job_id = s.job_id
        WHERE j.job_id IS NULL
        """
    ).fetchone()[0]
    scenario_row_count = connection.execute(
        "SELECT COUNT(*) FROM scenario_times"
    ).fetchone()[0]

    passed = (
        len(actual_jobs) == len(expected_jobs)
        and not missing_job_ids
        and not unexpected_job_ids
        and not metadata_mismatches
        and len(board_methods) == expected_board_count
        and not malformed_boards
        and len(task_seeds) == expected_task_count
        and seed_count_distribution == Counter({3: expected_task_count})
        and status_counts == {"completed": len(expected_jobs)}
        and audit_failures == 0
        and reference_mismatches == 0
        and blank_action_hashes == 0
        and maximum_coordinate_error_mm <= coordinate_tolerance_mm + 1e-12
        and actual_scenario_names == scenario_names
        and malformed_scenario_jobs == 0
        and orphan_scenario_rows == 0
        and scenario_row_count == len(expected_jobs) * expected_scenarios_per_job
    )
    return {
        "passed": passed,
        "expected_job_count": len(expected_jobs),
        "actual_job_count": len(actual_jobs),
        "missing_job_count": len(missing_job_ids),
        "unexpected_job_count": len(unexpected_job_ids),
        "job_metadata_mismatch_count": len(metadata_mismatches),
        "expected_board_count": expected_board_count,
        "actual_board_count": len(board_methods),
        "boards_without_exact_method_set": len(malformed_boards),
        "expected_methods": sorted(expected_method_set),
        "factory_task_count": len(task_seeds),
        "seed_count_distribution": {
            str(seed_count): task_count
            for seed_count, task_count in sorted(seed_count_distribution.items())
        },
        "status_counts": status_counts,
        "nc_audit_failures": audit_failures,
        "route_reference_mismatches": reference_mismatches,
        "invalid_action_or_gcode_hashes": blank_action_hashes,
        "maximum_coordinate_error_mm": maximum_coordinate_error_mm,
        "coordinate_tolerance_mm": coordinate_tolerance_mm,
        "expected_scenarios_per_job": expected_scenarios_per_job,
        "scenario_row_count": scenario_row_count,
        "malformed_scenario_jobs": malformed_scenario_jobs,
        "orphan_scenario_rows": orphan_scenario_rows,
        "scenario_name_set_matches_freeze": actual_scenario_names == scenario_names,
        "examples": {
            "missing_job_ids": missing_job_ids[:10],
            "unexpected_job_ids": unexpected_job_ids[:10],
            "metadata_mismatch_job_ids": metadata_mismatches[:10],
            "malformed_boards": malformed_boards[:10],
        },
    }


def frozen_file_audit(manifest: dict[str, object]) -> dict[str, object]:
    file_specs = {
        "pilot_boards": (
            manifest["pilot"]["boards_file"],
            manifest["pilot"]["boards_sha256"],
        ),
        "pilot_jobs": (
            manifest["pilot"]["jobs_file"],
            manifest["pilot"]["jobs_sha256"],
        ),
        "full_jobs": (
            manifest["full_run"]["jobs_file"],
            manifest["full_run"]["jobs_sha256"],
        ),
        "reference_results": (
            manifest["full_run"]["reference_results_file"],
            manifest["full_run"]["reference_results_sha256"],
        ),
        "route_freeze_manifest": (
            manifest["inputs"]["route_freeze_manifest"],
            manifest["inputs"]["route_freeze_manifest_sha256"],
        ),
        "board_index": (
            manifest["inputs"]["board_index"],
            manifest["inputs"]["board_index_sha256"],
        ),
        "protocol": (
            manifest["inputs"]["protocol"],
            manifest["inputs"]["protocol_sha256"],
        ),
        "preparation_script": (
            manifest["software"]["preparation_script"],
            manifest["software"]["preparation_script_sha256"],
        ),
        "core_module": (
            manifest["software"]["core_module"],
            manifest["software"]["core_module_sha256"],
        ),
        "runner": (
            manifest["software"]["runner"],
            manifest["software"]["runner_sha256"],
        ),
        "analysis": (
            manifest["software"]["analysis"],
            manifest["software"]["analysis_sha256"],
        ),
        "merge": (
            manifest["software"]["merge"],
            manifest["software"]["merge_sha256"],
        ),
    }
    rows: dict[str, object] = {}
    for label, (path_text, expected) in file_specs.items():
        path = Path(str(path_text))
        actual = sha256_file(path)
        rows[label] = {
            "path": str(path),
            "expected_sha256": str(expected),
            "actual_sha256": actual,
            "matches": actual == expected,
        }
    return {
        "passed": all(bool(row["matches"]) for row in rows.values()),
        "files": rows,
    }


def audit_track(track: str) -> Path:
    manifest = json.loads(FREEZE_MANIFEST.read_text(encoding="utf-8"))
    output_dir = PILOT_OUTPUT if track == "pilot" else FULL_OUTPUT
    scope = manifest["pilot"] if track == "pilot" else manifest["full_run"]
    expected_jobs = read_csv(Path(str(scope["jobs_file"])))
    with sqlite3.connect(
        f"file:{output_dir / 'results.sqlite'}?mode=ro",
        uri=True,
    ) as connection:
        database = database_audit(
            connection,
            expected_job_rows=expected_jobs,
            expected_scenarios=manifest["kinematic_scenarios"],
            expected_methods=manifest["full_run"]["methods"],
            expected_board_count=int(scope["board_count"]),
            expected_task_count=int(manifest["pilot"]["task_count"]),
            coordinate_tolerance_mm=float(
                manifest["nc_template"]["nc_tolerance_mm"]
            ),
        )

    frozen_files = frozen_file_audit(manifest)
    analysis_files: dict[str, object] = {}
    missing_analysis_files: list[str] = []
    for filename in REQUIRED_ANALYSIS_FILES:
        path = output_dir / filename
        if not path.exists():
            missing_analysis_files.append(filename)
            continue
        analysis_files[filename] = {
            "path": str(path),
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    gate_path = output_dir / "gate_report.json"
    gate_passed = False
    if gate_path.exists():
        gate_passed = bool(json.loads(gate_path.read_text(encoding="utf-8"))["passed"])
    expected_analysis_rows = {
        "task_scenario_metrics.csv": (
            int(manifest["pilot"]["task_count"])
            * int(manifest["full_run"]["method_count"])
            * len(manifest["kinematic_scenarios"])
        ),
        "scenario_comparisons.csv": (
            len(manifest["kinematic_scenarios"]) * 4 * 4
        ),
        "scenario_robustness_summary.csv": 4 * 4,
        "task_equal_geometry_summary.csv": int(
            manifest["full_run"]["method_count"]
        ),
        "planning_nc_spearman.csv": (
            int(manifest["full_run"]["method_count"])
            * len(manifest["kinematic_scenarios"])
            * 4
        ),
    }
    analysis_row_count_mismatches: dict[str, object] = {}
    for filename, expected_rows in expected_analysis_rows.items():
        path = output_dir / filename
        if not path.exists():
            continue
        actual_rows = len(read_csv(path))
        if actual_rows != expected_rows:
            analysis_row_count_mismatches[filename] = {
                "expected": expected_rows,
                "actual": actual_rows,
            }
    execution_files: dict[str, object] = {}
    missing_execution_files: list[str] = []
    for filename in REQUIRED_EXECUTION_FILES:
        path = output_dir / filename
        if not path.exists():
            missing_execution_files.append(filename)
            continue
        execution_files[filename] = {
            "path": str(path),
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    merge_passed = True
    if track == "full":
        merge_path = output_dir / "merge_audit.json"
        if not merge_path.exists():
            missing_execution_files.append("merge_audit.json")
            merge_passed = False
        else:
            merge_report = json.loads(merge_path.read_text(encoding="utf-8"))
            merge_passed = bool(merge_report["passed"])
            execution_files["merge_audit.json"] = {
                "path": str(merge_path),
                "bytes": merge_path.stat().st_size,
                "sha256": sha256_file(merge_path),
            }

    report = {
        "schema_version": 1,
        "track": track,
        "scope": manifest["scope"],
        "independent_statistical_unit": manifest["independent_statistical_unit"],
        "frozen_file_audit": frozen_files,
        "database_audit": database,
        "execution_artifacts": {
            "passed": not missing_execution_files and merge_passed,
            "merge_passed": merge_passed,
            "missing_files": missing_execution_files,
            "files": execution_files,
        },
        "analysis_artifacts": {
            "passed": (
                not missing_analysis_files
                and gate_passed
                and not analysis_row_count_mismatches
            ),
            "gate_passed": gate_passed,
            "missing_files": missing_analysis_files,
            "row_count_mismatches": analysis_row_count_mismatches,
            "files": analysis_files,
        },
    }
    report["passed"] = (
        bool(frozen_files["passed"])
        and bool(database["passed"])
        and bool(report["execution_artifacts"]["passed"])
        and bool(report["analysis_artifacts"]["passed"])
    )
    report_path = output_dir / "completion_audit.json"
    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    checksum_rows = [
        f"{row['sha256']}  {filename}"
        for filename, row in sorted(
            {**execution_files, **analysis_files}.items()
        )
    ]
    checksum_rows.append(
        f"{sha256_file(report_path)}  {report_path.name}"
    )
    (output_dir / "artifact_checksums.sha256").write_text(
        "\n".join(checksum_rows) + "\n",
        encoding="utf-8",
    )
    if not report["passed"]:
        raise RuntimeError(f"{track} completion audit failed: {report_path}")
    print(f"{track} completion audit passed")
    print(report_path)
    return report_path


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("track", choices=("pilot", "full"))
    args = parser.parse_args()
    audit_track(args.track)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
