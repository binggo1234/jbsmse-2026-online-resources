from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from time import perf_counter


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_holdout_routes import (
    FREEZE_MANIFEST,
    FULL_JOBS,
    FULL_RESULTS,
    LAYOUT_ARCHIVE,
    METHODS,
    OUTPUT_DIR,
    _load_stage7,
    iter_loaded_boards,
    read_csv,
    sha256_file,
    stage7_args,
    verify_full_plan,
)


PROPOSED = "process_aware_beam_adaptive_polished"
ATOMIC_AUDIT = OUTPUT_DIR / "proposed_atomic_span_audit.csv"
AUDIT_SUMMARY = OUTPUT_DIR / "route_experiment_audit.json"
AUDIT_REPORT = OUTPUT_DIR / "route_experiment_audit.md"
ISOLATED_RESULTS = OUTPUT_DIR / "route_results_cache_isolated.csv"
ISOLATION_AMENDMENT = OUTPUT_DIR / "route_run_isolation_amendment_v2.json"
ISOLATED_AUDIT_SUMMARY = OUTPUT_DIR / "route_experiment_isolated_audit.json"
ISOLATED_AUDIT_REPORT = OUTPUT_DIR / "route_experiment_isolated_audit.md"
DEFECT_JOB_ID = "f52e5eaa170221a6b062"


@dataclass(frozen=True)
class AtomicSpanAudit:
    job_id: str
    placements_member: str
    board_id: str
    rectangle_count: int
    atomic_span_count: int
    covered_atomic_span_count: int
    missing_atomic_span_count: int
    repeated_atomic_span_count: int
    unknown_cutting_unit_count: int
    coverage_ratio: float
    hard_penalty: float
    stored_process_repeated_span_count: int
    replay_metrics_match: bool
    status: str
    runtime_ms: float
    error_class: str
    error_message: str


def action_span_ids(action) -> tuple[str, ...]:
    if action.covered_spans:
        return tuple(span.span_id for span in action.covered_spans)
    if action.covered_segment_ids:
        return action.covered_segment_ids
    if action.segment_id is not None:
        return (action.segment_id,)
    return ()


def audit_plan_atomic_spans(
    candidate_units,
    plan,
    cutting_action_type,
) -> tuple[int, int, int, int, float]:
    single_edge_type = next(
        unit.unit_type
        for unit in candidate_units
        if str(unit.unit_type.value) == "single_edge"
    )
    all_span_ids = {
        span.span_id
        for unit in candidate_units
        if unit.unit_type == single_edge_type
        for span in unit.covered_spans
    }
    candidate_unit_ids = {unit.unit_id for unit in candidate_units}
    counts: Counter[str] = Counter()
    unknown = 0
    for action in plan.actions:
        if action.action_type != cutting_action_type:
            continue
        if (
            action.cutting_unit_id is not None
            and action.cutting_unit_id not in candidate_unit_ids
        ):
            unknown += 1
        counts.update(action_span_ids(action))
    covered = all_span_ids & set(counts)
    missing = all_span_ids - covered
    repeated = sum(
        count > 1
        for span_id, count in counts.items()
        if span_id in all_span_ids
    )
    ratio = len(covered) / len(all_span_ids) if all_span_ids else 1.0
    return len(all_span_ids), len(covered), len(missing), repeated, unknown, ratio


def metrics_match(plan, stored: dict[str, str], tolerance: float = 1e-9) -> bool:
    integer_fields = {
        "pierce_count": "pierce_count",
        "lift_count": "lift_count",
        "safe_lift_count": "safe_lift_count",
        "detour_count": "detour_count",
        "repeated_cut_segment_count": "process_repeated_span_count",
        "redundant_cut_action_count": "process_redundant_action_count",
    }
    float_fields = {
        "air_move_distance": "air_move_distance",
        "cutting_length": "cutting_length",
        "collision_penalty": "collision_penalty",
        "boundary_penalty": "boundary_penalty",
        "stability_penalty": "stability_penalty",
        "safe_lift_distance": "safe_lift_distance",
        "detour_distance": "detour_distance",
        "travel_mode_cost": "travel_mode_cost",
        "hard_penalty": "hard_penalty",
        "repeated_cut_length": "process_repeated_span_length",
    }
    for metric_name, stored_name in integer_fields.items():
        if int(getattr(plan.metrics, metric_name)) != int(stored[stored_name]):
            return False
    for metric_name, stored_name in float_fields.items():
        actual = float(getattr(plan.metrics, metric_name))
        expected = float(stored[stored_name])
        scale = max(1.0, abs(actual), abs(expected))
        if abs(actual - expected) > tolerance * scale:
            return False
    return True


def stored_metrics_match(
    first: dict[str, str],
    second: dict[str, str],
    tolerance: float = 1e-9,
) -> bool:
    integer_fields = (
        "pierce_count",
        "lift_count",
        "safe_lift_count",
        "detour_count",
        "process_repeated_span_count",
        "process_redundant_action_count",
    )
    float_fields = (
        "air_move_distance",
        "cutting_length",
        "collision_penalty",
        "boundary_penalty",
        "stability_penalty",
        "safe_lift_distance",
        "detour_distance",
        "travel_mode_cost",
        "hard_penalty",
        "process_repeated_span_length",
    )
    if any(int(first[name]) != int(second[name]) for name in integer_fields):
        return False
    for name in float_fields:
        left = float(first[name])
        right = float(second[name])
        scale = max(1.0, abs(left), abs(right))
        if abs(left - right) > tolerance * scale:
            return False
    return True


def append_audit(row: AtomicSpanAudit) -> None:
    fields = list(AtomicSpanAudit.__dataclass_fields__)
    write_header = not ATOMIC_AUDIT.exists() or ATOMIC_AUDIT.stat().st_size == 0
    ATOMIC_AUDIT.parent.mkdir(parents=True, exist_ok=True)
    with ATOMIC_AUDIT.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        if write_header:
            writer.writeheader()
        writer.writerow(asdict(row))


def run_atomic_audit(resume: bool) -> None:
    manifest = verify_full_plan()
    stage7 = _load_stage7()
    from cnc_cutting.models import CuttingActionType

    result_by_job = {
        row["job_id"]: row
        for row in read_csv(FULL_RESULTS)
        if row["method"] == PROPOSED
    }
    jobs = [
        row
        for row in read_csv(FULL_JOBS)
        if row["method"] == PROPOSED
    ]
    completed = (
        {row["job_id"] for row in read_csv(ATOMIC_AUDIT)}
        if resume and ATOMIC_AUDIT.exists()
        else set()
    )
    if not resume and ATOMIC_AUDIT.exists():
        ATOMIC_AUDIT.unlink()
    args = stage7_args()
    timeout_seconds = float(manifest["full_run"]["timeout_seconds"])

    for (
        board_jobs,
        layout,
        panel,
        tool,
        process_model,
        tool_event_gate,
        units,
    ) in iter_loaded_boards(jobs, stage7):
        job = board_jobs[0]
        if job["job_id"] in completed:
            continue
        stored = result_by_job[job["job_id"]]
        spec = stage7.build_planners(
            (PROPOSED,),
            units,
            panel,
            tool,
            process_model,
            tool_event_gate,
            len(layout.rectangles),
            args.repeat_cut_policy,
            algorithm_seed=args.algorithm_seed,
        )[0]
        started = perf_counter()
        status = "passed"
        error_class = ""
        error_message = ""
        span_count = covered_count = missing = repeated = unknown = 0
        ratio = 0.0
        replay_match = False
        hard_penalty = float("nan")
        try:
            with stage7.task_timeout(timeout_seconds):
                plan = spec.planner()
            (
                span_count,
                covered_count,
                missing,
                repeated,
                unknown,
                ratio,
            ) = audit_plan_atomic_spans(
                units,
                plan,
                CuttingActionType.CUT,
            )
            replay_match = metrics_match(plan, stored)
            hard_penalty = plan.metrics.hard_penalty
            if (
                missing
                or repeated
                or unknown
                or hard_penalty != 0.0
                or not replay_match
            ):
                status = "failed"
        except Exception as exc:  # pragma: no cover - persisted for audit
            status = "error"
            error_class = type(exc).__name__
            error_message = str(exc)[:500]
        runtime_ms = (perf_counter() - started) * 1000.0
        append_audit(
            AtomicSpanAudit(
                job_id=job["job_id"],
                placements_member=job["placements_member"],
                board_id=job["board_id"],
                rectangle_count=int(job["rectangle_count"]),
                atomic_span_count=span_count,
                covered_atomic_span_count=covered_count,
                missing_atomic_span_count=missing,
                repeated_atomic_span_count=repeated,
                unknown_cutting_unit_count=unknown,
                coverage_ratio=ratio,
                hard_penalty=hard_penalty,
                stored_process_repeated_span_count=int(
                    stored["process_repeated_span_count"]
                ),
                replay_metrics_match=replay_match,
                status=status,
                runtime_ms=runtime_ms,
                error_class=error_class,
                error_message=error_message,
            )
        )
        completed.add(job["job_id"])
        print(
            f"atomic audit {len(completed)}/{len(jobs)} "
            f"{status} {runtime_ms:.3f} ms",
            flush=True,
        )


def finalize_audit() -> dict:
    freeze = verify_full_plan()
    jobs = read_csv(FULL_JOBS)
    results = read_csv(FULL_RESULTS)
    atomic = read_csv(ATOMIC_AUDIT)
    job_ids = [row["job_id"] for row in jobs]
    result_ids = [row["job_id"] for row in results]
    status_counts = Counter(row["status"] for row in results)
    method_counts = Counter(row["method"] for row in results)
    board_methods: dict[tuple[str, str], set[str]] = {}
    for row in results:
        board_methods.setdefault(
            (row["placements_member"], row["board_id"]),
            set(),
        ).add(row["method"])
    atomic_status = Counter(row["status"] for row in atomic)
    passed = (
        len(jobs) == len(results) == freeze["method_task_count"]
        and len(job_ids) == len(set(job_ids))
        and len(result_ids) == len(set(result_ids))
        and set(job_ids) == set(result_ids)
        and status_counts == Counter({"completed": len(results)})
        and method_counts
        == Counter({method: freeze["board_count"] for method in METHODS})
        and len(board_methods) == freeze["board_count"]
        and all(methods == set(METHODS) for methods in board_methods.values())
        and len(atomic) == freeze["board_count"]
        and atomic_status == Counter({"passed": len(atomic)})
    )
    summary = {
        "audit_status": "passed" if passed else "failed",
        "method_task_count": len(results),
        "unique_job_id_count": len(set(result_ids)),
        "status_counts": dict(status_counts),
        "method_counts": dict(method_counts),
        "board_count": len(board_methods),
        "boards_with_all_five_methods": sum(
            methods == set(METHODS) for methods in board_methods.values()
        ),
        "proposed_atomic_span_audit": {
            "route_count": len(atomic),
            "status_counts": dict(atomic_status),
            "missing_atomic_span_count": sum(
                int(row["missing_atomic_span_count"]) for row in atomic
            ),
            "repeated_atomic_span_count": sum(
                int(row["repeated_atomic_span_count"]) for row in atomic
            ),
            "unknown_cutting_unit_count": sum(
                int(row["unknown_cutting_unit_count"]) for row in atomic
            ),
            "hard_penalty_nonzero_route_count": sum(
                float(row["hard_penalty"]) != 0.0 for row in atomic
            ),
            "replay_metric_mismatch_count": sum(
                row["replay_metrics_match"] != "True" for row in atomic
            ),
        },
        "files": {
            "freeze_manifest": {
                "path": str(FREEZE_MANIFEST.resolve()),
                "sha256": sha256_file(FREEZE_MANIFEST),
            },
            "frozen_jobs": {
                "path": str(FULL_JOBS.resolve()),
                "sha256": sha256_file(FULL_JOBS),
            },
            "route_results": {
                "path": str(FULL_RESULTS.resolve()),
                "sha256": sha256_file(FULL_RESULTS),
            },
            "proposed_atomic_span_audit": {
                "path": str(ATOMIC_AUDIT.resolve()),
                "sha256": sha256_file(ATOMIC_AUDIT),
            },
        },
    }
    AUDIT_SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    atomic_summary = summary["proposed_atomic_span_audit"]
    report = f"""# Holdout route experiment audit

- Audit status: **{summary['audit_status']}**
- Frozen method tasks: {summary['method_task_count']}
- Unique job IDs: {summary['unique_job_id_count']}
- Completed routes: {summary['status_counts'].get('completed', 0)}
- Boards with all five methods: {summary['boards_with_all_five_methods']}
- Proposed atomic-span routes audited: {atomic_summary['route_count']}
- Missing atomic spans: {atomic_summary['missing_atomic_span_count']}
- Repeated atomic spans: {atomic_summary['repeated_atomic_span_count']}
- Unknown cutting units: {atomic_summary['unknown_cutting_unit_count']}
- Nonzero hard-penalty routes: {atomic_summary['hard_penalty_nonzero_route_count']}
- Deterministic replay metric mismatches: {atomic_summary['replay_metric_mismatch_count']}

The parent-segment coverage repetition fields are not used as atomic-span
repetition criteria. Atomic spans are audited from `covered_spans`, matching the
frozen Stage7 `audit_stage7_route_spans.py` rule.
"""
    AUDIT_REPORT.write_text(report, encoding="utf-8")
    if not passed:
        raise SystemExit(1)
    return summary


def replay_defect_matches_isolated(stored: dict[str, str]) -> bool:
    stage7 = _load_stage7()
    from cnc_cutting.travel import clear_detour_cache

    job = next(
        row for row in read_csv(FULL_JOBS) if row["job_id"] == DEFECT_JOB_ID
    )
    args = stage7_args()
    for (
        board_jobs,
        layout,
        panel,
        tool,
        process_model,
        tool_event_gate,
        units,
    ) in iter_loaded_boards([job], stage7):
        spec = stage7.build_planners(
            (PROPOSED,),
            units,
            panel,
            tool,
            process_model,
            tool_event_gate,
            len(layout.rectangles),
            args.repeat_cut_policy,
            algorithm_seed=args.algorithm_seed,
        )[0]
        clear_detour_cache()
        plan = spec.planner()
        return metrics_match(plan, stored)
    raise ValueError("defect job was not loaded")


def finalize_isolated_audit() -> dict:
    freeze = verify_full_plan()
    amendment = json.loads(ISOLATION_AMENDMENT.read_text(encoding="utf-8"))
    jobs = read_csv(FULL_JOBS)
    original_rows = read_csv(FULL_RESULTS)
    isolated_rows = read_csv(ISOLATED_RESULTS)
    atomic_rows = read_csv(ATOMIC_AUDIT)
    original_by_id = {row["job_id"]: row for row in original_rows}
    isolated_by_id = {row["job_id"]: row for row in isolated_rows}
    atomic_by_id = {row["job_id"]: row for row in atomic_rows}
    job_ids = [row["job_id"] for row in jobs]
    isolated_ids = [row["job_id"] for row in isolated_rows]
    status_counts = Counter(row["status"] for row in isolated_rows)
    method_counts = Counter(row["method"] for row in isolated_rows)
    board_methods: dict[tuple[str, str], set[str]] = {}
    changed_jobs = Counter()
    changed_quality_fields: Counter[tuple[str, str]] = Counter()
    ignored_fields = {
        "runtime_ms",
        "schedule_order",
        "status",
        "error_class",
        "error_message",
    }
    for row in isolated_rows:
        board_methods.setdefault(
            (row["placements_member"], row["board_id"]),
            set(),
        ).add(row["method"])
        original = original_by_id[row["job_id"]]
        changed = [
            name
            for name in row
            if name not in ignored_fields and row[name] != original[name]
        ]
        if changed:
            changed_jobs[row["method"]] += 1
            changed_quality_fields.update((row["method"], name) for name in changed)

    proposed_rows = [
        row for row in isolated_rows if row["method"] == PROPOSED
    ]
    replay_consistency_failures = 0
    for row in proposed_rows:
        atomic = atomic_by_id[row["job_id"]]
        if row["job_id"] == DEFECT_JOB_ID:
            continue
        if atomic["replay_metrics_match"] != "True" or not stored_metrics_match(
            original_by_id[row["job_id"]],
            row,
        ):
            replay_consistency_failures += 1
    defect_replay_match = replay_defect_matches_isolated(
        isolated_by_id[DEFECT_JOB_ID]
    )
    proposed_hard_failures = sum(
        int(row["coverage_missing_segment_count"]) != 0
        or int(row["process_repeated_span_count"]) != 0
        or float(row["hard_penalty"]) != 0.0
        for row in proposed_rows
    )
    atomic_status = Counter(row["status"] for row in atomic_rows)
    atomic_geometry_failures = sum(
        int(row["missing_atomic_span_count"]) != 0
        or int(row["repeated_atomic_span_count"]) != 0
        or int(row["unknown_cutting_unit_count"]) != 0
        or float(row["hard_penalty"]) != 0.0
        for row in atomic_rows
    )
    passed = (
        len(jobs) == len(isolated_rows) == freeze["method_task_count"]
        and len(isolated_ids) == len(set(isolated_ids))
        and set(job_ids) == set(isolated_ids)
        and status_counts == Counter({"completed": len(isolated_rows)})
        and method_counts
        == Counter({method: freeze["board_count"] for method in METHODS})
        and len(board_methods) == freeze["board_count"]
        and all(methods == set(METHODS) for methods in board_methods.values())
        and len(atomic_rows) == freeze["board_count"]
        and not atomic_status.get("error", 0)
        and atomic_geometry_failures == 0
        and proposed_hard_failures == 0
        and replay_consistency_failures == 0
        and defect_replay_match
    )
    summary = {
        "audit_status": "passed" if passed else "failed",
        "isolation_amendment_status": amendment["status"],
        "method_task_count": len(isolated_rows),
        "unique_job_id_count": len(set(isolated_ids)),
        "status_counts": dict(status_counts),
        "method_counts": dict(method_counts),
        "board_count": len(board_methods),
        "boards_with_all_five_methods": sum(
            methods == set(METHODS) for methods in board_methods.values()
        ),
        "proposed_atomic_span_audit": {
            "route_count": len(atomic_rows),
            "status_counts": dict(atomic_status),
            "missing_atomic_span_count": sum(
                int(row["missing_atomic_span_count"]) for row in atomic_rows
            ),
            "repeated_atomic_span_count": sum(
                int(row["repeated_atomic_span_count"]) for row in atomic_rows
            ),
            "unknown_cutting_unit_count": sum(
                int(row["unknown_cutting_unit_count"]) for row in atomic_rows
            ),
            "geometry_failure_count": atomic_geometry_failures,
            "v1_replay_mismatch_count": atomic_status.get("failed", 0),
            "isolated_serialized_hard_failure_count": proposed_hard_failures,
            "unchanged_route_replay_mismatch_count": replay_consistency_failures,
            "defect_route_fresh_replay_match": defect_replay_match,
        },
        "v1_to_isolated_changes": {
            "changed_job_count": sum(changed_jobs.values()),
            "changed_jobs_by_method": dict(changed_jobs),
            "changed_fields_by_method": {
                method: {
                    name: changed_quality_fields[(method, name)]
                    for changed_method, name in sorted(changed_quality_fields)
                    if changed_method == method
                }
                for method in METHODS
                if changed_jobs[method]
            },
        },
        "files": {
            "isolation_amendment": {
                "path": str(ISOLATION_AMENDMENT.resolve()),
                "sha256": sha256_file(ISOLATION_AMENDMENT),
            },
            "frozen_jobs": {
                "path": str(FULL_JOBS.resolve()),
                "sha256": sha256_file(FULL_JOBS),
            },
            "isolated_route_results": {
                "path": str(ISOLATED_RESULTS.resolve()),
                "sha256": sha256_file(ISOLATED_RESULTS),
            },
            "proposed_atomic_span_audit": {
                "path": str(ATOMIC_AUDIT.resolve()),
                "sha256": sha256_file(ATOMIC_AUDIT),
            },
            "quarantined_v1_results": {
                "path": str(FULL_RESULTS.resolve()),
                "sha256": sha256_file(FULL_RESULTS),
            },
        },
    }
    ISOLATED_AUDIT_SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    atomic = summary["proposed_atomic_span_audit"]
    changes = summary["v1_to_isolated_changes"]
    report = f"""# Cache-isolated holdout route experiment audit

- Audit status: **{summary['audit_status']}**
- Completed method tasks: {summary['method_task_count']}
- Unique job IDs: {summary['unique_job_id_count']}
- Boards with all five methods: {summary['boards_with_all_five_methods']}
- Proposed atomic-span routes audited: {atomic['route_count']}
- Missing atomic spans: {atomic['missing_atomic_span_count']}
- Repeated atomic spans: {atomic['repeated_atomic_span_count']}
- Unknown cutting units: {atomic['unknown_cutting_unit_count']}
- Atomic geometry failures: {atomic['geometry_failure_count']}
- Quarantined-v1 replay mismatches: {atomic['v1_replay_mismatch_count']}
- Proposed serialized hard failures: {atomic['isolated_serialized_hard_failure_count']}
- Proposed replay mismatches after isolation: {atomic['unchanged_route_replay_mismatch_count']}
- Defect-route fresh replay match: {atomic['defect_route_fresh_replay_match']}
- v1 jobs changed by cache isolation: {changes['changed_job_count']}

The v1 route result is quarantined from method comparisons. The isolated result
is the only route-level result authorized for subsequent task aggregation and
confirmatory analysis.
"""
    ISOLATED_AUDIT_REPORT.write_text(report, encoding="utf-8")
    if not passed:
        raise SystemExit(1)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    atomic = subparsers.add_parser("atomic")
    atomic.add_argument("--resume", action="store_true")
    subparsers.add_parser("finalize")
    subparsers.add_parser("finalize-isolated")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "atomic":
        run_atomic_audit(resume=args.resume)
    elif args.command == "finalize-isolated":
        print(
            json.dumps(
                finalize_isolated_audit(),
                indent=2,
                ensure_ascii=False,
            )
        )
    else:
        print(json.dumps(finalize_audit(), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
