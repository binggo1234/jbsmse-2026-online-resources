from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import random
import subprocess

from scripts.factory_csv_converter import (
    FACTORY_ENCODING,
    InventoryPart,
    canonical_decimal,
    read_factory_inventory,
    sha256_file,
    write_inventory,
)


PANEL_WIDTH = Decimal("2440")
PANEL_HEIGHT = Decimal("1220")
TRIM = Decimal("5")
TOOL_DIAMETER = Decimal("6")
ALLOW_ROTATION = True
ORDER_TOP_K = 3
PACKING_SEEDS = (1000, 1001, 1002)
SCHEDULE_SEED = 20260726
EXPECTED_HOLDOUT_TASKS = 20


@dataclass(frozen=True)
class PreflightResult:
    task_id: str
    source_record_count: int
    converted_part_count: int
    quantity_expansion_count: int
    unique_uid_count: int
    blank_source_upi_count: int
    material_count: int
    materials: str
    thickness_count: int
    thicknesses_mm: str
    graining_values: str
    minimum_width_mm: str
    maximum_width_mm: str
    minimum_height_mm: str
    maximum_height_mm: str
    oversized_envelope_count: int
    inventory_sha256: str
    format_passed: bool
    geometry_passed: bool
    passed: bool


def git_commit(repo: Path) -> str:
    completed = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def read_holdout_rows(lineage_manifest: Path) -> list[dict[str, str]]:
    with lineage_manifest.open(encoding="utf-8", newline="") as handle:
        rows = [
            row
            for row in csv.DictReader(handle)
            if row.get("confirmatory_status") == "confirmatory_holdout"
        ]
    if len(rows) != EXPECTED_HOLDOUT_TASKS:
        raise ValueError(
            f"expected {EXPECTED_HOLDOUT_TASKS} holdout tasks, found {len(rows)}"
        )
    task_ids = [row["task_id"] for row in rows]
    if len(set(task_ids)) != len(task_ids):
        raise ValueError("duplicate holdout task ids in lineage manifest")
    return sorted(rows, key=lambda row: row["task_id"])


def envelope_fits(part: InventoryPart) -> bool:
    usable_width = PANEL_WIDTH - Decimal("2") * TRIM
    usable_height = PANEL_HEIGHT - Decimal("2") * TRIM
    envelope_width = part.w0 + TOOL_DIAMETER
    envelope_height = part.h0 + TOOL_DIAMETER
    base_fits = envelope_width <= usable_width and envelope_height <= usable_height
    rotated_fits = (
        ALLOW_ROTATION
        and envelope_height <= usable_width
        and envelope_width <= usable_height
    )
    return base_fits or rotated_fits


def preflight_task(
    *,
    parts: tuple[InventoryPart, ...],
    source_record_count: int,
    blank_source_upi_count: int,
    materials: tuple[str, ...],
    thicknesses: tuple[str, ...],
    graining_values: tuple[str, ...],
    inventory_path: Path,
) -> PreflightResult:
    if not parts:
        raise ValueError("holdout inventory is empty")
    widths = [part.w0 for part in parts]
    heights = [part.h0 for part in parts]
    unique_uid_count = len({part.uid for part in parts})
    oversized_count = sum(not envelope_fits(part) for part in parts)
    format_passed = (
        unique_uid_count == len(parts)
        and len(materials) == 1
        and len(thicknesses) == 1
        and all(width > 0 and height > 0 for width, height in zip(widths, heights))
    )
    geometry_passed = oversized_count == 0
    return PreflightResult(
        task_id=parts[0].task_id,
        source_record_count=source_record_count,
        converted_part_count=len(parts),
        quantity_expansion_count=len(parts) - source_record_count,
        unique_uid_count=unique_uid_count,
        blank_source_upi_count=blank_source_upi_count,
        material_count=len(materials),
        materials="|".join(materials),
        thickness_count=len(thicknesses),
        thicknesses_mm="|".join(thicknesses),
        graining_values="|".join(graining_values),
        minimum_width_mm=canonical_decimal(min(widths)),
        maximum_width_mm=canonical_decimal(max(widths)),
        minimum_height_mm=canonical_decimal(min(heights)),
        maximum_height_mm=canonical_decimal(max(heights)),
        oversized_envelope_count=oversized_count,
        inventory_sha256=sha256_file(inventory_path),
        format_passed=format_passed,
        geometry_passed=geometry_passed,
        passed=format_passed and geometry_passed,
    )


def read_source_metadata(
    path: Path,
) -> tuple[int, tuple[str, ...], tuple[str, ...], tuple[str, ...]]:
    with path.open(encoding=FACTORY_ENCODING, newline="") as handle:
        rows = list(csv.DictReader(handle))
    return (
        sum(not str(row.get("Upi") or "").strip() for row in rows),
        tuple(sorted({str(row.get("Material") or "").strip() for row in rows})),
        tuple(sorted({str(row.get("Thickness") or "").strip() for row in rows})),
        tuple(sorted({str(row.get("Graining") or "").strip() for row in rows})),
    )


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_preflight_summary(
    path: Path,
    results: list[PreflightResult],
) -> None:
    passed = sum(result.passed for result in results)
    lines = [
        "# Holdout Format and Kerf-Geometry Preflight",
        "",
        f"- Independent factory tasks: {len(results)}",
        f"- Passed tasks: {passed}",
        f"- Source records: {sum(r.source_record_count for r in results)}",
        f"- Converted parts: {sum(r.converted_part_count for r in results)}",
        (
            f"- Quantity expansions: "
            f"{sum(r.quantity_expansion_count for r in results)}"
        ),
        (
            f"- Oversized 6 mm envelopes: "
            f"{sum(r.oversized_envelope_count for r in results)}"
        ),
        f"- Mixed-material tasks: {sum(r.material_count != 1 for r in results)}",
        f"- Mixed-thickness tasks: {sum(r.thickness_count != 1 for r in results)}",
        (
            "- Thickness values: "
            + ", ".join(sorted({r.thicknesses_mm for r in results}))
        ),
        (
            "- Graining flags observed: "
            + ", ".join(
                sorted(
                    {
                        value
                        for result in results
                        for value in result.graining_values.split("|")
                    }
                )
            )
            + " (recorded only; the frozen Stage7 packer allows rotation)"
        ),
        f"- Verdict: {'PASS' if passed == len(results) else 'FAIL'}",
        "",
        "| Task | Records | Parts | Quantity expansion | Oversized | Pass |",
        "|---|---:|---:|---:|---:|:---:|",
    ]
    lines.extend(
        (
            f"| {result.task_id} | {result.source_record_count} | "
            f"{result.converted_part_count} | {result.quantity_expansion_count} | "
            f"{result.oversized_envelope_count} | "
            f"{'yes' if result.passed else 'no'} |"
        )
        for result in results
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_run_rows(
    *,
    results: list[PreflightResult],
    inventory_dir: Path,
    stage7_commit: str,
    kerf_packing_sha256: str,
    converter_sha256: str,
    runner_sha256: str,
) -> list[dict[str, object]]:
    jobs: list[tuple[str, int]] = [
        (result.task_id, seed)
        for result in results
        for seed in PACKING_SEEDS
    ]
    generator = random.Random(SCHEDULE_SEED)
    generator.shuffle(jobs)
    result_by_task = {result.task_id: result for result in results}
    rows: list[dict[str, object]] = []
    for run_order, (task_id, seed) in enumerate(jobs, start=1):
        result = result_by_task[task_id]
        inventory_path = inventory_dir / f"{task_id}_inventory.csv"
        rows.append(
            {
                "run_id": f"holdout_pack_{run_order:03d}",
                "run_order": run_order,
                "task_id": task_id,
                "packing_seed": seed,
                "inventory_path": str(inventory_path.resolve()),
                "inventory_sha256": result.inventory_sha256,
                "source_part_count": result.converted_part_count,
                "output_member_prefix": f"holdout/{task_id}/seed_{seed}",
                "panel_width_mm": canonical_decimal(PANEL_WIDTH),
                "panel_height_mm": canonical_decimal(PANEL_HEIGHT),
                "trim_mm": canonical_decimal(TRIM),
                "tool_diameter_mm": canonical_decimal(TOOL_DIAMETER),
                "allow_rotation": ALLOW_ROTATION,
                "packing_method": "deterministic_maxrects_baf_bounded_size_rank_shuffle",
                "packing_order_top_k": ORDER_TOP_K,
                "stage7_commit": stage7_commit,
                "kerf_packing_sha256": kerf_packing_sha256,
                "converter_sha256": converter_sha256,
                "runner_sha256": runner_sha256,
            }
        )
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Convert the 20 frozen holdout tasks, run format/kerf geometry "
            "preflight, and freeze the 60-job packing schedule."
        )
    )
    parser.add_argument("--lineage-manifest", type=Path, required=True)
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--stage7-repo", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--packing-runner",
        type=Path,
        default=Path(__file__).with_name("run_holdout_packing.py"),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = read_holdout_rows(args.lineage_manifest)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    inventory_dir = args.output_dir / "inventories"
    results: list[PreflightResult] = []

    for row in rows:
        source_path = args.raw_root / row["csv_relative_path"]
        if sha256_file(source_path) != row["csv_sha256"]:
            raise ValueError(f"raw CSV hash mismatch: {source_path}")
        parts = read_factory_inventory(source_path, task_id=row["task_id"])
        inventory_path = inventory_dir / f"{row['task_id']}_inventory.csv"
        write_inventory(inventory_path, parts)
        blank_upi, materials, thicknesses, graining_values = read_source_metadata(
            source_path
        )
        results.append(
            preflight_task(
                parts=parts,
                source_record_count=int(row["part_record_count"]),
                blank_source_upi_count=blank_upi,
                materials=materials,
                thicknesses=thicknesses,
                graining_values=graining_values,
                inventory_path=inventory_path,
            )
        )

    preflight_csv = args.output_dir / "format_geometry_preflight.csv"
    preflight_md = args.output_dir / "format_geometry_preflight.md"
    write_csv(preflight_csv, [asdict(result) for result in results])
    write_preflight_summary(preflight_md, results)

    if not all(result.passed for result in results):
        raise SystemExit(
            "holdout preflight failed; packing run manifest was not generated"
        )

    stage7_commit = git_commit(args.stage7_repo)
    kerf_packing_path = args.stage7_repo / "src/cnc_cutting/kerf_packing.py"
    converter_path = Path(__file__).with_name("factory_csv_converter.py")
    runner_path = args.packing_runner
    run_rows = build_run_rows(
        results=results,
        inventory_dir=inventory_dir,
        stage7_commit=stage7_commit,
        kerf_packing_sha256=sha256_file(kerf_packing_path),
        converter_sha256=sha256_file(converter_path),
        runner_sha256=sha256_file(runner_path),
    )
    run_manifest = args.output_dir / "packing_run_manifest.csv"
    write_csv(run_manifest, run_rows)

    freeze_payload = {
        "design": {
            "independent_unit": "factory_task",
            "independent_task_count": len(results),
            "nested_packing_seeds": list(PACKING_SEEDS),
            "job_count": len(run_rows),
            "schedule_seed": SCHEDULE_SEED,
            "all_generated_boards_retained": True,
            "board_selection": "none",
        },
        "packing": {
            "panel_width_mm": canonical_decimal(PANEL_WIDTH),
            "panel_height_mm": canonical_decimal(PANEL_HEIGHT),
            "trim_mm": canonical_decimal(TRIM),
            "tool_diameter_mm": canonical_decimal(TOOL_DIAMETER),
            "allow_rotation": ALLOW_ROTATION,
            "order_top_k": ORDER_TOP_K,
            "method": "deterministic_maxrects_baf_bounded_size_rank_shuffle",
        },
        "inputs": {
            "lineage_manifest": str(args.lineage_manifest.resolve()),
            "lineage_manifest_sha256": sha256_file(args.lineage_manifest),
            "raw_root": str(args.raw_root.resolve()),
            "preflight_report": str(preflight_csv.resolve()),
            "preflight_report_sha256": sha256_file(preflight_csv),
            "packing_run_manifest": str(run_manifest.resolve()),
            "packing_run_manifest_sha256": sha256_file(run_manifest),
        },
        "code": {
            "stage7_repo": str(args.stage7_repo.resolve()),
            "stage7_commit": stage7_commit,
            "kerf_packing_sha256": sha256_file(kerf_packing_path),
            "converter_sha256": sha256_file(converter_path),
            "preflight_script_sha256": sha256_file(Path(__file__)),
            "packing_runner": str(runner_path.resolve()),
            "packing_runner_sha256": sha256_file(runner_path),
        },
        "execution_command": (
            f"python3 {runner_path.resolve()} "
            f"--run-manifest {run_manifest.resolve()} "
            f"--stage7-repo {args.stage7_repo.resolve()} "
            f"--output-dir {(args.output_dir / 'packing_outputs').resolve()}"
        ),
        "preflight_passed": True,
    }
    freeze_manifest = args.output_dir / "freeze_manifest.json"
    freeze_manifest.write_text(
        json.dumps(freeze_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"tasks={len(results)}")
    print(f"jobs={len(run_rows)}")
    print(f"preflight=PASS")
    print(f"run_manifest={run_manifest}")
    print(f"freeze_manifest={freeze_manifest}")


if __name__ == "__main__":
    main()
