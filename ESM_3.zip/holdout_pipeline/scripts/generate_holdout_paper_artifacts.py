from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean

import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS_DIR = ROOT / "outputs" / "holdout_confirmatory_analysis_v1"
TASK_METRICS = ANALYSIS_DIR / "task_metrics.csv"
PAIRWISE = ANALYSIS_DIR / "pairwise_task_comparisons.csv"
CONFIRMATORY = ANALYSIS_DIR / "confirmatory_summary.csv"
METHOD_SUMMARY = ANALYSIS_DIR / "method_summary.csv"
OUTPUT_DIR = ANALYSIS_DIR / "paper_artifacts"

PROPOSED = "process_aware_beam_adaptive_polished"
TOPOLOGY = "topology_process_aware"
GTSP = "endpoint_aware_gtsp"
METHOD_ORDER = (
    PROPOSED,
    "process_aware_beam",
    TOPOLOGY,
    "process_local_search_multistart",
    GTSP,
)
METHOD_LABELS = {
    PROPOSED: "Proposed portfolio",
    "process_aware_beam": "Process-aware beam",
    TOPOLOGY: "Topology heuristic",
    "process_local_search_multistart": "Process local search",
    GTSP: "Endpoint-aware GTSP",
}
COLORS = {
    PROPOSED: "#D55E00",
    "process_aware_beam": "#0072B2",
    TOPOLOGY: "#7F7F7F",
    "process_local_search_multistart": "#009E73",
    GTSP: "#CC79A7",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "DejaVu Serif"],
            "font.size": 9,
            "axes.titlesize": 10,
            "axes.titleweight": "bold",
            "axes.labelsize": 9,
            "legend.fontsize": 8,
            "legend.frameon": False,
            "figure.dpi": 150,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "grid.alpha": 0.18,
            "grid.linestyle": "-",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def format_p(value: float) -> str:
    if value < 0.0001:
        return r"$<0.0001$"
    return f"{value:.4f}"


def latex_escape(value: str) -> str:
    return (
        value.replace("\\", r"\textbackslash{}")
        .replace("_", r"\_")
        .replace("%", r"\%")
        .replace("&", r"\&")
    )


def write_method_table(rows: list[dict[str, str]]) -> Path:
    lookup = {row["method"]: row for row in rows}
    lines = [
        r"\begin{table*}[!t]",
        r"\centering",
        r"\caption{Task-equal results on 20 unseen factory inventories. "
        r"Each task first sums all boards within a packing seed and then "
        r"averages the three seeds equally.}",
        r"\label{tab:factory-holdout-methods}",
        r"\small",
        r"\begin{tabular}{lrrrrr}",
        r"\toprule",
        r"Method & $C_{\mathrm{plan}}$ ($10^6$) & "
        r"$C_{\mathrm{travel}}$ ($10^6$) & Tool events & "
        r"Support+ tasks & Runtime (s) \\",
        r"\midrule",
    ]
    for method in METHOD_ORDER:
        row = lookup[method]
        label = latex_escape(METHOD_LABELS[method])
        if method == PROPOSED:
            label = r"\textbf{" + label + "}"
        lines.append(
            f"{label} & "
            f"{float(row['c_plan_task_mean']) / 1e6:.3f} & "
            f"{float(row['travel_mode_cost_task_mean']) / 1e6:.3f} & "
            f"{float(row['tool_event_count_task_mean']):.1f} & "
            f"{int(row['positive_support_penalty_tasks'])}/20 & "
            f"{float(row['runtime_ms_task_mean']) / 1000:.1f} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
        r"\end{table*}",
            "",
        ]
    )
    path = OUTPUT_DIR / "table_holdout_method_summary.tex"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def write_confirmatory_table(rows: list[dict[str, str]]) -> Path:
    lines = [
        r"\begin{table*}[!t]",
        r"\centering",
        r"\caption{Pre-specified task-level confirmatory comparisons. "
        r"Intervals resample the 20 factory tasks; packing seeds and boards "
        r"are nested repeats. Positive reduction favors the proposed method; "
        r"the two penalty columns count tasks with \(\Phi_{\mathrm{low}}>0\).}",
        r"\label{tab:factory-holdout-confirmatory}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{lrrrrrr}",
        r"\toprule",
        r"Baseline & Mean reduction & 95\% CI & W/T/L & "
        r"\shortstack{Proposed tasks\\with $\Phi_{\mathrm{low}}>0$} & "
        r"\shortstack{Baseline tasks\\with $\Phi_{\mathrm{low}}>0$} & Holm $p$ \\",
        r"\midrule",
    ]
    for row in rows:
        baseline = METHOD_LABELS[row["baseline_method"]]
        baseline_penalty_positive = "20/20" if row["baseline_method"] == GTSP else "0/20"
        lines.append(
            f"{latex_escape(baseline)} & "
            f"{float(row['mean_reduction_pct']):.2f}\\% & "
            f"[{float(row['reduction_ci_low']):.2f}, "
            f"{float(row['reduction_ci_high']):.2f}]\\% & "
            f"{row['wins']}/{row['ties']}/{row['losses']} & 0/20 & "
            f"{baseline_penalty_positive} & "
            f"{format_p(float(row['sign_test_p_holm']))} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
        r"\end{table*}",
            "",
        ]
    )
    path = OUTPUT_DIR / "table_holdout_confirmatory_comparisons.tex"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def task_label_mapping(task_ids: list[str]) -> dict[str, str]:
    return {task_id: f"T{index:02d}" for index, task_id in enumerate(sorted(task_ids), 1)}


def plot_task_reductions(
    pairwise_rows: list[dict[str, str]],
    confirmatory_rows: list[dict[str, str]],
) -> list[Path]:
    selected = [
        row
        for row in pairwise_rows
        if row["metric"] == "c_plan"
        and row["baseline_method"] in {TOPOLOGY, GTSP}
    ]
    by_baseline: dict[str, dict[str, float]] = defaultdict(dict)
    for row in selected:
        by_baseline[row["baseline_method"]][row["task_id"]] = float(
            row["reduction_pct"]
        )
    tasks = sorted(
        by_baseline[TOPOLOGY],
        key=lambda task: by_baseline[TOPOLOGY][task],
    )
    labels = task_label_mapping(tasks)
    summary = {row["baseline_method"]: row for row in confirmatory_rows}

    fig, axes = plt.subplots(1, 2, figsize=(6.75, 4.2), sharey=True)
    for ax, baseline, title, color in (
        (
            axes[0],
            TOPOLOGY,
            "Policy-compliant topology baseline",
            COLORS["process_aware_beam"],
        ),
        (
            axes[1],
            GTSP,
            "Endpoint-aware GTSP",
            COLORS[GTSP],
        ),
    ):
        values = [by_baseline[baseline][task] for task in tasks]
        positions = list(range(len(tasks)))
        ax.axvline(0, color="#333333", linewidth=0.8, zorder=1)
        ax.scatter(
            values,
            positions,
            s=22,
            color=color,
            edgecolor="white",
            linewidth=0.4,
            zorder=3,
        )
        current = summary[baseline]
        center = float(current["mean_reduction_pct"])
        low = float(current["reduction_ci_low"])
        high = float(current["reduction_ci_high"])
        ax.errorbar(
            center,
            -1.4,
            xerr=[[center - low], [high - center]],
            fmt="D",
            color=COLORS[PROPOSED],
            markerfacecolor=COLORS[PROPOSED],
            markersize=5,
            capsize=3,
            linewidth=1.4,
            label="Task-equal mean (95% CI)",
            zorder=4,
        )
        ax.set_title(title)
        ax.set_xlabel(r"$C_{\mathrm{plan}}$ reduction (%)")
        ax.set_ylim(len(tasks) - 0.3, -2.2)
        if baseline == GTSP:
            ax.text(
                0.04,
                0.02,
                "Support-penalty tasks:\nproposed 0/20, GTSP 20/20",
                transform=ax.transAxes,
                ha="left",
                va="bottom",
                fontsize=7.5,
                color="#555555",
            )
    axes[0].set_yticks(range(len(tasks)))
    axes[0].set_yticklabels([labels[task] for task in tasks])
    axes[0].set_ylabel("Factory task")
    handles, legend_labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        legend_labels,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.005),
        ncol=1,
    )
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    paths = [
        OUTPUT_DIR / "fig_holdout_task_reductions.pdf",
        OUTPUT_DIR / "fig_holdout_task_reductions.png",
    ]
    fig.savefig(paths[0])
    fig.savefig(paths[1], dpi=300)
    plt.close(fig)

    mapping_path = OUTPUT_DIR / "holdout_task_label_mapping.csv"
    with mapping_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=("figure_label", "task_id"),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(
            {"figure_label": labels[task], "task_id": task} for task in sorted(tasks)
        )
    return [*paths, mapping_path]


def plot_quality_runtime(
    task_rows: list[dict[str, str]],
    method_rows: list[dict[str, str]],
) -> list[Path]:
    task_lookup = {
        (row["task_id"], row["method"]): float(row["c_plan"])
        for row in task_rows
    }
    task_ids = sorted({row["task_id"] for row in task_rows})
    reduction_vs_topology = {
        method: mean(
            100.0
            * (
                task_lookup[(task_id, TOPOLOGY)]
                - task_lookup[(task_id, method)]
            )
            / task_lookup[(task_id, TOPOLOGY)]
            for task_id in task_ids
        )
        for method in METHOD_ORDER
    }
    runtime = {
        row["method"]: float(row["runtime_ms_task_mean"]) / 1000.0
        for row in method_rows
    }
    fig, ax = plt.subplots(figsize=(4.8, 3.1))
    offsets = {
        PROPOSED: (5, 6),
        "process_aware_beam": (5, -12),
        TOPOLOGY: (5, 6),
        "process_local_search_multistart": (5, 6),
        GTSP: (5, -13),
    }
    for method in METHOD_ORDER:
        support_violation = method == GTSP
        ax.scatter(
            runtime[method],
            reduction_vs_topology[method],
            s=70 if method == PROPOSED else 48,
            marker="D" if method == PROPOSED else "o",
            facecolor="none" if support_violation else COLORS[method],
            edgecolor=COLORS[method],
            linewidth=1.5 if support_violation else 0.8,
            zorder=3,
        )
        dx, dy = offsets[method]
        label = METHOD_LABELS[method]
        ax.annotate(
            label,
            (runtime[method], reduction_vs_topology[method]),
            xytext=(dx, dy),
            textcoords="offset points",
            fontsize=7.5,
        )
    ax.axhline(0, color="#555555", linewidth=0.8)
    ax.set_xscale("log")
    ax.set_xlabel("Task-equal route runtime (s, log scale)")
    ax.set_ylabel(r"Mean task reduction in $C_{\mathrm{plan}}$ vs. topology (%)")
    ax.set_title("Planning quality–runtime tradeoff")
    ax.text(
        0.02,
        0.97,
        "Open marker: support-policy penalty on 20/20 tasks",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=7.2,
        color="#555555",
    )
    fig.tight_layout()
    paths = [
        OUTPUT_DIR / "fig_holdout_quality_runtime.pdf",
        OUTPUT_DIR / "fig_holdout_quality_runtime.png",
    ]
    fig.savefig(paths[0])
    fig.savefig(paths[1], dpi=300)
    plt.close(fig)
    return paths


def main() -> int:
    configure_style()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    task_rows = read_csv(TASK_METRICS)
    pairwise_rows = read_csv(PAIRWISE)
    confirmatory_rows = read_csv(CONFIRMATORY)
    method_rows = read_csv(METHOD_SUMMARY)
    outputs: list[Path] = [
        write_method_table(method_rows),
        write_confirmatory_table(confirmatory_rows),
    ]
    outputs.extend(plot_task_reductions(pairwise_rows, confirmatory_rows))
    outputs.extend(plot_quality_runtime(task_rows, method_rows))
    manifest_path = OUTPUT_DIR / "paper_artifacts_manifest.json"
    manifest = {
        "inputs": [
            {"path": str(path), "sha256": sha256_file(path)}
            for path in (TASK_METRICS, PAIRWISE, CONFIRMATORY, METHOD_SUMMARY)
        ],
        "generator": {
            "path": str(Path(__file__).resolve()),
            "sha256": sha256_file(Path(__file__).resolve()),
        },
        "outputs": [
            {"path": str(path), "sha256": sha256_file(path)} for path in outputs
        ],
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"artifact_count": len(outputs)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
