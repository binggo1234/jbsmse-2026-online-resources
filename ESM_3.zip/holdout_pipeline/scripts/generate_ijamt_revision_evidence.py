#!/usr/bin/env python3
"""Generate auditable aggregate evidence for the IJAMT manuscript revision."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import mean


PROPOSED_METHOD = "process_aware_beam_adaptive_polished"
UNIT_COUNT_COLUMNS = {
    "residual_single": "selected_single_edge_count",
    "shared_compensated_centerline": "selected_shared_edge_count",
    "near_shared_channel": "selected_near_shared_channel_count",
    "collinear_chain": "selected_collinear_chain_count",
}
DECOMPOSITION_COLUMNS = (
    "cutting_length",
    "air_move_distance",
    "safe_lift_distance",
    "detour_distance",
    "safe_lift_count",
    "detour_count",
    "process_tool_event_count",
    "process_turn_penalty",
    "process_repeated_span_count",
    "stability_penalty",
    "runtime_ms",
    "travel_mode_cost",
)


@dataclass(frozen=True)
class TrackInput:
    name: str
    path: Path
    task_mode: str


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_completed_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return [
        row
        for row in rows
        if row.get("status", "completed") == "completed"
    ]


def read_xml_task_status(path: Path) -> dict[str, str]:
    status_by_task: dict[str, str] = {}
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            task = row["task_id"]
            status = row["confirmatory_status"]
            previous = status_by_task.setdefault(task, status)
            if previous != status:
                raise ValueError(
                    f"inconsistent confirmatory status for {task}: "
                    f"{previous!r} versus {status!r}"
                )
    if not status_by_task:
        raise ValueError(f"no XML task-status rows in {path}")
    return status_by_task


def number(row: dict[str, str], column: str) -> float:
    value = row.get(column, "")
    return float(value) if value not in ("", None) else 0.0


def task_id(row: dict[str, str], mode: str) -> str:
    if mode == "placement_method":
        value = row.get("placement_method", "")
        if not value:
            raise ValueError("missing placement_method task identifier")
        return value
    if mode == "xml_member":
        parts = Path(row["placements_member"]).parts
        if len(parts) < 2 or parts[0] != "track_b":
            raise ValueError(
                f"unexpected Track B placements_member={row['placements_member']!r}"
            )
        return parts[1]
    raise ValueError(f"unsupported task mode: {mode}")


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def unit_usage_summary(
    track: TrackInput,
    source_rows: list[dict[str, str]] | None = None,
) -> dict[str, object]:
    rows = [
        row
        for row in (
            source_rows if source_rows is not None else read_completed_rows(track.path)
        )
        if row["method"] == PROPOSED_METHOD
    ]
    if not rows:
        raise ValueError(f"no proposed rows in {track.path}")

    total_units = sum(number(row, "selected_unit_count") for row in rows)
    original_spans = sum(number(row, "coverage_original_segment_count") for row in rows)
    shared_covered_spans = sum(
        number(row, "selected_composite_covered_segment_count") for row in rows
    )
    result: dict[str, object] = {
        "track": track.name,
        "route_count": len(rows),
        "selected_unit_count": int(total_units),
        "original_atomic_span_count": int(original_spans),
    }
    for label, column in UNIT_COUNT_COLUMNS.items():
        count = sum(number(row, column) for row in rows)
        result[f"{label}_count"] = int(count)
        result[f"{label}_unit_share_pct"] = (
            100.0 * count / total_units if total_units else 0.0
        )
    result["shared_span_coverage_pct"] = (
        100.0 * shared_covered_spans / original_spans if original_spans else 0.0
    )
    result["mean_route_shared_span_coverage_pct"] = 100.0 * mean(
        number(row, "selected_composite_coverage_ratio") for row in rows
    )
    return result


def aggregate_task_equal(
    track: TrackInput,
    rows: list[dict[str, str]],
) -> list[dict[str, object]]:
    by_method_task_seed: dict[
        tuple[str, str, str], dict[str, float]
    ] = defaultdict(lambda: defaultdict(float))
    board_counts: dict[tuple[str, str, str], int] = defaultdict(int)

    for row in rows:
        method = row["method"]
        task = task_id(row, track.task_mode)
        seed = row.get("seed", "") or "fixed_coordinates"
        key = (method, task, seed)
        board_counts[key] += 1
        for column in DECOMPOSITION_COLUMNS:
            by_method_task_seed[key][column] += number(row, column)

    by_method_task: dict[
        tuple[str, str], dict[str, list[float]]
    ] = defaultdict(lambda: defaultdict(list))
    task_board_counts: dict[tuple[str, str], list[int]] = defaultdict(list)
    for (method, task, _seed), metrics in by_method_task_seed.items():
        task_key = (method, task)
        for column, value in metrics.items():
            by_method_task[task_key][column].append(value)
        task_board_counts[task_key].append(board_counts[(method, task, _seed)])

    task_means: dict[str, list[dict[str, float]]] = defaultdict(list)
    for (method, task), metrics in by_method_task.items():
        row = {column: mean(values) for column, values in metrics.items()}
        row["board_count"] = mean(task_board_counts[(method, task)])
        row["task"] = task
        task_means[method].append(row)

    output: list[dict[str, object]] = []
    for method in sorted(task_means):
        method_rows = task_means[method]
        values = {
            column: mean(float(row[column]) for row in method_rows)
            for column in DECOMPOSITION_COLUMNS
        }
        direct_low = (
            values["air_move_distance"]
            - values["safe_lift_distance"]
            - values["detour_distance"]
        )
        if direct_low < -1e-6:
            raise ValueError(
                f"negative direct low-clearance distance for {track.name}/{method}"
            )
        output.append(
            {
                "track": track.name,
                "method": method,
                "independent_task_count": len(method_rows),
                "mean_nested_board_count": mean(
                    float(row["board_count"]) for row in method_rows
                ),
                "cutting_length": values["cutting_length"],
                "direct_low_clearance_distance": max(direct_low, 0.0),
                "detour_distance": values["detour_distance"],
                "safe_lift_distance": values["safe_lift_distance"],
                "air_move_distance": values["air_move_distance"],
                "safe_lift_fixed_premium": (
                    values["travel_mode_cost"] - values["air_move_distance"]
                ),
                "travel_mode_cost": values["travel_mode_cost"],
                "c_plan": values["cutting_length"] + values["travel_mode_cost"],
                "safe_lift_count": values["safe_lift_count"],
                "detour_count": values["detour_count"],
                "tool_event_count": values["process_tool_event_count"],
                "direction_change": values["process_turn_penalty"],
                "repeated_span_count": values["process_repeated_span_count"],
                "support_policy_penalty": values["stability_penalty"],
                "runtime_ms": values["runtime_ms"],
            }
        )
    return output


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--development-csv", type=Path, required=True)
    parser.add_argument("--holdout-csv", type=Path, required=True)
    parser.add_argument("--xml-csv", type=Path, required=True)
    parser.add_argument("--xml-task-status-csv", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    development = TrackInput(
        "development_selected_layouts", args.development_csv, "none"
    )
    holdout = TrackInput(
        "all_board_holdout", args.holdout_csv, "placement_method"
    )
    xml_confirmatory = TrackInput(
        "original_coordinate_xml_confirmatory", args.xml_csv, "xml_member"
    )
    xml_historical = TrackInput(
        "original_coordinate_xml_historical", args.xml_csv, "xml_member"
    )
    tracks = (development, holdout, xml_confirmatory, xml_historical)
    output_dir: Path = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    xml_status = read_xml_task_status(args.xml_task_status_csv)
    xml_rows = read_completed_rows(args.xml_csv)
    unknown_xml_tasks = {
        task_id(row, "xml_member") for row in xml_rows
    } - set(xml_status)
    if unknown_xml_tasks:
        raise ValueError(
            "XML results contain tasks missing from the status table: "
            + ", ".join(sorted(unknown_xml_tasks))
        )
    confirmatory_xml_rows = [
        row
        for row in xml_rows
        if xml_status[task_id(row, "xml_member")] == "confirmatory_holdout"
    ]
    historical_xml_rows = [
        row
        for row in xml_rows
        if xml_status[task_id(row, "xml_member")] == "excluded_prior_upstream_use"
    ]

    unit_rows = [
        unit_usage_summary(development),
        unit_usage_summary(holdout),
        unit_usage_summary(xml_confirmatory, confirmatory_xml_rows),
        unit_usage_summary(xml_historical, historical_xml_rows),
    ]
    unit_fields = list(unit_rows[0])
    write_csv(output_dir / "cutting_unit_usage_by_track.csv", unit_fields, unit_rows)

    decomposition_rows: list[dict[str, object]] = []
    decomposition_rows.extend(
        aggregate_task_equal(holdout, read_completed_rows(holdout.path))
    )
    decomposition_rows.extend(
        aggregate_task_equal(xml_confirmatory, confirmatory_xml_rows)
    )
    decomposition_rows.extend(
        aggregate_task_equal(xml_historical, historical_xml_rows)
    )
    decomposition_fields = list(decomposition_rows[0])
    write_csv(
        output_dir / "planning_cost_decomposition_task_equal.csv",
        decomposition_fields,
        decomposition_rows,
    )

    manifest = {
        "schema_version": 1,
        "proposed_method": PROPOSED_METHOD,
        "aggregation": {
            "unit_usage": (
                "Descriptive sums over completed proposed routes within each track."
            ),
            "holdout": (
                "Boards summed within task-seed, seed totals averaged within task, "
                "then tasks weighted equally."
            ),
            "xml": (
                "Patterns summed within task, then tasks weighted equally. The seven "
                "confirmatory tasks and four tasks excluded because of prior upstream "
                "use are reported as separate cohorts."
            ),
            "direct_low_clearance_distance": (
                "air_move_distance - detour_distance - safe_lift_distance"
            ),
            "safe_lift_fixed_premium": (
                "travel_mode_cost - air_move_distance under the locked unit weights"
            ),
        },
        "inputs": {
            track.name: {
                "file": track.path.name,
                "sha256": sha256(track.path),
            }
            for track in tracks
        },
        "xml_task_status": {
            "file": args.xml_task_status_csv.name,
            "sha256": sha256(args.xml_task_status_csv),
            "confirmatory_task_count": sum(
                status == "confirmatory_holdout"
                for status in xml_status.values()
            ),
            "historical_excluded_task_count": sum(
                status == "excluded_prior_upstream_use"
                for status in xml_status.values()
            ),
        },
        "outputs": {
            "cutting_unit_usage_by_track.csv": sha256(
                output_dir / "cutting_unit_usage_by_track.csv"
            ),
            "planning_cost_decomposition_task_equal.csv": sha256(
                output_dir / "planning_cost_decomposition_task_equal.csv"
            ),
        },
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
