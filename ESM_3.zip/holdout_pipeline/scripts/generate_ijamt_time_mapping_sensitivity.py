#!/usr/bin/env python3
"""Map frozen planning diagnostics to explicitly illustrative time scenarios."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


SCENARIOS = (
    {
        "scenario": "low_event_overhead",
        "cut_speed_mm_s": 100.0,
        "air_speed_mm_s": 300.0,
        "safe_lift_time_s": 0.25,
        "tool_event_time_s": 0.05,
    },
    {
        "scenario": "medium_event_overhead",
        "cut_speed_mm_s": 100.0,
        "air_speed_mm_s": 300.0,
        "safe_lift_time_s": 1.0,
        "tool_event_time_s": 0.20,
    },
    {
        "scenario": "high_event_overhead",
        "cut_speed_mm_s": 100.0,
        "air_speed_mm_s": 300.0,
        "safe_lift_time_s": 2.0,
        "tool_event_time_s": 0.50,
    },
)
PROPOSED = "process_aware_beam_adaptive_polished"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def estimate_seconds(row: dict[str, str], scenario: dict[str, object]) -> float:
    return (
        float(row["cutting_length"]) / float(scenario["cut_speed_mm_s"])
        + float(row["air_move_distance"]) / float(scenario["air_speed_mm_s"])
        + float(row["safe_lift_count"])
        * float(scenario["safe_lift_time_s"])
        + float(row["tool_event_count"])
        * float(scenario["tool_event_time_s"])
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--decomposition-csv", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    with args.decomposition_csv.open(newline="", encoding="utf-8") as handle:
        source_rows = list(csv.DictReader(handle))
    source_rows = [
        row for row in source_rows if row["track"] == "all_board_holdout"
    ]
    if not source_rows:
        raise ValueError("no all_board_holdout rows")

    output_rows: list[dict[str, object]] = []
    for scenario in SCENARIOS:
        estimates = {
            row["method"]: estimate_seconds(row, scenario) for row in source_rows
        }
        proposed_seconds = estimates[PROPOSED]
        for method in sorted(estimates):
            seconds = estimates[method]
            output_rows.append(
                {
                    **scenario,
                    "method": method,
                    "estimated_seconds_per_task": seconds,
                    "proposed_reduction_pct": (
                        100.0 * (seconds - proposed_seconds) / seconds
                        if method != PROPOSED
                        else 0.0
                    ),
                }
            )

    output_dir: Path = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    output_csv = output_dir / "illustrative_time_mapping_sensitivity.csv"
    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(output_rows[0]))
        writer.writeheader()
        writer.writerows(output_rows)

    manifest = {
        "schema_version": 1,
        "evidence_boundary": (
            "Illustrative parameter mapping only; not controller-calibrated, "
            "commercial-CAM-estimated, or measured machine time."
        ),
        "formula": (
            "L_cut/v_cut + D_air/v_air + N_safe*t_z + N_tool*t_tool; "
            "turn/transient dynamics omitted."
        ),
        "input": {
            "file": args.decomposition_csv.name,
            "sha256": sha256(args.decomposition_csv),
        },
        "output": {
            "file": output_csv.name,
            "sha256": sha256(output_csv),
        },
        "scenarios": SCENARIOS,
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
