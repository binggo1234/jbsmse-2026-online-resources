from __future__ import annotations

import argparse
import csv
import json
import sqlite3
import sys
from dataclasses import asdict
from pathlib import Path
from time import perf_counter

from scripts import run_holdout_routes as routes
from scripts.nc_kinematic_core import (
    NcTemplate,
    action_sequence_sha256,
    actions_from_diagnostics,
    audit_route_nc,
    default_scenarios,
    estimate_kinematics,
    generate_canonical_gcode,
    geometry_metrics,
    parse_gcode,
    sha256_text,
)
from scripts.prepare_nc_kinematic_evaluation import (
    FREEZE_MANIFEST,
    FULL_JOBS,
    ISOLATED_RESULTS,
    PILOT_JOBS,
    sha256_file,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = ROOT / "outputs/nc_kinematic_evaluation_v2"
PILOT_OUTPUT = OUTPUT_ROOT / "pilot"
FULL_OUTPUT = OUTPUT_ROOT / "full"
FULL_SHARD_ROOT = OUTPUT_ROOT / "full_shards"
FLOAT_REFERENCE_FIELDS = (
    "air_move_distance",
    "cutting_length",
    "collision_penalty",
    "boundary_penalty",
    "stability_penalty",
    "safe_lift_distance",
    "detour_distance",
    "travel_mode_cost",
)
INTEGER_REFERENCE_FIELDS = (
    "action_count",
    "pierce_count",
    "lift_count",
    "safe_lift_count",
    "detour_count",
)
REFERENCE_TOLERANCE = 1e-6


def select_shard_jobs(
    jobs: list[dict[str, str]],
    *,
    shard_index: int,
    shard_count: int,
) -> list[dict[str, str]]:
    if shard_count <= 0:
        raise ValueError("shard_count must be positive")
    if not 0 <= shard_index < shard_count:
        raise ValueError("shard_index must be in [0, shard_count)")
    board_order: dict[tuple[str, str], int] = {}
    for job in sorted(jobs, key=lambda row: int(row["schedule_order"])):
        key = (job["placements_member"], job["board_id"])
        if key not in board_order:
            board_order[key] = len(board_order)
    selected_boards = {
        key
        for key, position in board_order.items()
        if position % shard_count == shard_index
    }
    selected = [
        job
        for job in jobs
        if (job["placements_member"], job["board_id"]) in selected_boards
    ]
    if not selected:
        raise ValueError("selected shard contains no jobs")
    return selected


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def verify_freeze() -> dict[str, object]:
    manifest = json.loads(FREEZE_MANIFEST.read_text(encoding="utf-8"))
    checks = (
        (Path(manifest["pilot"]["jobs_file"]), manifest["pilot"]["jobs_sha256"]),
        (
            Path(manifest["full_run"]["jobs_file"]),
            manifest["full_run"]["jobs_sha256"],
        ),
        (
            Path(manifest["full_run"]["reference_results_file"]),
            manifest["full_run"]["reference_results_sha256"],
        ),
        (Path(manifest["software"]["core_module"]), manifest["software"]["core_module_sha256"]),
        (Path(manifest["software"]["runner"]), manifest["software"]["runner_sha256"]),
        (Path(manifest["software"]["analysis"]), manifest["software"]["analysis_sha256"]),
        (Path(manifest["software"]["merge"]), manifest["software"]["merge_sha256"]),
    )
    for path, expected in checks:
        if sha256_file(path) != expected:
            raise ValueError(f"frozen input or software changed: {path}")
    return manifest


def connect_database(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=FULL")
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS job_results (
            job_id TEXT PRIMARY KEY,
            schedule_order INTEGER NOT NULL,
            task_id TEXT NOT NULL,
            packing_seed TEXT NOT NULL,
            placements_member TEXT NOT NULL,
            board_id TEXT NOT NULL,
            method TEXT NOT NULL,
            status TEXT NOT NULL,
            error_class TEXT NOT NULL,
            error_message TEXT NOT NULL,
            planner_runtime_ms REAL NOT NULL,
            action_sequence_sha256 TEXT NOT NULL,
            gcode_sha256 TEXT NOT NULL,
            source_action_count INTEGER NOT NULL,
            nc_action_count INTEGER NOT NULL,
            cut_xy_block_count INTEGER NOT NULL,
            travel_xy_block_count INTEGER NOT NULL,
            return_xy_block_count INTEGER NOT NULL,
            maximum_coordinate_error_mm REAL NOT NULL,
            audit_passed INTEGER NOT NULL,
            audit_errors TEXT NOT NULL,
            reference_match INTEGER NOT NULL,
            reference_mismatches TEXT NOT NULL,
            cutting_distance_mm REAL NOT NULL,
            rapid_xy_distance_mm REAL NOT NULL,
            setup_xy_distance_mm REAL NOT NULL,
            low_clearance_xy_distance_mm REAL NOT NULL,
            safe_lift_xy_distance_mm REAL NOT NULL,
            return_xy_distance_mm REAL NOT NULL,
            z_retract_distance_mm REAL NOT NULL,
            z_plunge_distance_mm REAL NOT NULL,
            retract_count INTEGER NOT NULL,
            plunge_count INTEGER NOT NULL,
            direction_change_count INTEGER NOT NULL,
            nc_block_count INTEGER NOT NULL,
            source_cutting_length_mm REAL NOT NULL,
            source_air_move_distance_mm REAL NOT NULL,
            source_travel_mode_cost REAL NOT NULL,
            source_safe_lift_count INTEGER NOT NULL,
            source_detour_count INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS scenario_times (
            job_id TEXT NOT NULL,
            scenario TEXT NOT NULL,
            cut_speed_mm_s REAL NOT NULL,
            rapid_speed_mm_s REAL NOT NULL,
            xy_acceleration_mm_s2 REAL NOT NULL,
            z_speed_mm_s REAL NOT NULL,
            z_acceleration_mm_s2 REAL NOT NULL,
            nonmotion_event_time_s REAL NOT NULL,
            continuous_cut_time_s REAL NOT NULL,
            continuous_rapid_time_s REAL NOT NULL,
            continuous_z_time_s REAL NOT NULL,
            continuous_noncut_time_s REAL NOT NULL,
            continuous_total_time_s REAL NOT NULL,
            stop_cut_time_s REAL NOT NULL,
            stop_rapid_time_s REAL NOT NULL,
            stop_z_time_s REAL NOT NULL,
            stop_noncut_time_s REAL NOT NULL,
            stop_total_time_s REAL NOT NULL,
            PRIMARY KEY (job_id, scenario),
            FOREIGN KEY (job_id) REFERENCES job_results(job_id)
        );
        """
    )
    return connection


def reference_mismatches(plan: object, reference: dict[str, str]) -> list[str]:
    metrics = plan.metrics
    actual: dict[str, float | int] = {
        "action_count": len(plan.actions),
        "air_move_distance": metrics.air_move_distance,
        "cutting_length": metrics.cutting_length,
        "pierce_count": metrics.pierce_count,
        "lift_count": metrics.lift_count,
        "collision_penalty": metrics.collision_penalty,
        "boundary_penalty": metrics.boundary_penalty,
        "stability_penalty": metrics.stability_penalty,
        "safe_lift_count": metrics.safe_lift_count,
        "safe_lift_distance": metrics.safe_lift_distance,
        "detour_count": metrics.detour_count,
        "detour_distance": metrics.detour_distance,
        "travel_mode_cost": metrics.travel_mode_cost,
    }
    mismatches: list[str] = []
    for field in INTEGER_REFERENCE_FIELDS:
        expected = int(float(reference[field]))
        if int(actual[field]) != expected:
            mismatches.append(f"{field}: {actual[field]} != {expected}")
    for field in FLOAT_REFERENCE_FIELDS:
        expected = float(reference[field])
        if abs(float(actual[field]) - expected) > REFERENCE_TOLERANCE:
            mismatches.append(
                f"{field}: {float(actual[field]):.12g} != {expected:.12g}"
            )
    return mismatches


def insert_completed(
    connection: sqlite3.Connection,
    *,
    job: dict[str, str],
    planner_runtime_ms: float,
    plan: object,
    actions: tuple,
    gcode: str,
    audit: object,
    geometry: object,
    mismatches: list[str],
) -> None:
    status = "completed" if audit.passed and not mismatches else "failed_audit"
    job_values = {
        "job_id": job["job_id"],
        "schedule_order": int(job["schedule_order"]),
        "task_id": job["task_id"],
        "packing_seed": job["packing_seed"],
        "placements_member": job["placements_member"],
        "board_id": job["board_id"],
        "method": job["method"],
        "status": status,
        "error_class": "",
        "error_message": "",
        "planner_runtime_ms": planner_runtime_ms,
        "action_sequence_sha256": action_sequence_sha256(actions),
        "gcode_sha256": sha256_text(gcode),
        "source_action_count": audit.source_action_count,
        "nc_action_count": audit.nc_action_count,
        "cut_xy_block_count": audit.cut_xy_block_count,
        "travel_xy_block_count": audit.travel_xy_block_count,
        "return_xy_block_count": audit.return_xy_block_count,
        "maximum_coordinate_error_mm": audit.maximum_coordinate_error_mm,
        "audit_passed": int(audit.passed),
        "audit_errors": json.dumps(audit.errors),
        "reference_match": int(not mismatches),
        "reference_mismatches": json.dumps(mismatches),
        **asdict(geometry),
        "source_cutting_length_mm": plan.metrics.cutting_length,
        "source_air_move_distance_mm": plan.metrics.air_move_distance,
        "source_travel_mode_cost": plan.metrics.travel_mode_cost,
        "source_safe_lift_count": plan.metrics.safe_lift_count,
        "source_detour_count": plan.metrics.detour_count,
    }
    columns = list(job_values)
    connection.execute(
        f"INSERT OR REPLACE INTO job_results ({','.join(columns)}) "
        f"VALUES ({','.join('?' for _ in columns)})",
        [job_values[column] for column in columns],
    )
    connection.execute("DELETE FROM scenario_times WHERE job_id = ?", (job["job_id"],))
    parsed = parse_gcode(gcode)
    for scenario in default_scenarios():
        estimate = estimate_kinematics(parsed, scenario)
        scenario_values = {
            "job_id": job["job_id"],
            **asdict(scenario),
            **asdict(estimate),
        }
        scenario_columns = list(scenario_values)
        connection.execute(
            f"INSERT INTO scenario_times ({','.join(scenario_columns)}) "
            f"VALUES ({','.join('?' for _ in scenario_columns)})",
            [scenario_values[column] for column in scenario_columns],
        )


def insert_failure(
    connection: sqlite3.Connection,
    job: dict[str, str],
    runtime_ms: float,
    exc: Exception,
) -> None:
    connection.execute(
        """
        INSERT OR REPLACE INTO job_results (
            job_id, schedule_order, task_id, packing_seed, placements_member,
            board_id, method, status, error_class, error_message,
            planner_runtime_ms, action_sequence_sha256, gcode_sha256,
            source_action_count, nc_action_count, cut_xy_block_count,
            travel_xy_block_count, return_xy_block_count,
            maximum_coordinate_error_mm, audit_passed, audit_errors,
            reference_match, reference_mismatches, cutting_distance_mm,
            rapid_xy_distance_mm, setup_xy_distance_mm,
            low_clearance_xy_distance_mm, safe_lift_xy_distance_mm,
            return_xy_distance_mm, z_retract_distance_mm,
            z_plunge_distance_mm, retract_count, plunge_count,
            direction_change_count, nc_block_count, source_cutting_length_mm,
            source_air_move_distance_mm, source_travel_mode_cost,
            source_safe_lift_count, source_detour_count
        ) VALUES (
            ?,?,?,?,?,?,?,?,?,?,
            ?,'','',0,0,0,0,0,0,0,'[]',
            0,'[]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
        )
        """,
        (
            job["job_id"],
            int(job["schedule_order"]),
            job["task_id"],
            job["packing_seed"],
            job["placements_member"],
            job["board_id"],
            job["method"],
            "failed",
            type(exc).__name__,
            str(exc)[:1000],
            runtime_ms,
        ),
    )
    connection.execute("DELETE FROM scenario_times WHERE job_id = ?", (job["job_id"],))


def export_table(
    connection: sqlite3.Connection,
    query: str,
    output_path: Path,
) -> None:
    cursor = connection.execute(query)
    fieldnames = [description[0] for description in cursor.description]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(fieldnames)
        writer.writerows(cursor)


def export_results(connection: sqlite3.Connection, output_dir: Path) -> None:
    export_table(
        connection,
        "SELECT * FROM job_results ORDER BY schedule_order",
        output_dir / "job_results.csv",
    )
    export_table(
        connection,
        """
        SELECT s.* FROM scenario_times AS s
        JOIN job_results AS j ON j.job_id = s.job_id
        ORDER BY j.schedule_order, s.scenario
        """,
        output_dir / "scenario_times.csv",
    )


def run(
    jobs_path: Path,
    output_dir: Path,
    *,
    resume: bool,
    retain_gcode: bool,
    shard_index: int = 0,
    shard_count: int = 1,
) -> None:
    manifest = verify_freeze()
    all_jobs = read_csv(jobs_path)
    jobs = select_shard_jobs(
        all_jobs,
        shard_index=shard_index,
        shard_count=shard_count,
    )
    references = {row["job_id"]: row for row in read_csv(ISOLATED_RESULTS)}
    if any(job["job_id"] not in references for job in jobs):
        raise ValueError("one or more jobs lack frozen isolated reference results")
    database_path = output_dir / "results.sqlite"
    if database_path.exists() and not resume:
        raise FileExistsError(
            f"{database_path} exists; pass --resume or choose a new output"
        )
    connection = connect_database(database_path)
    completed = {
        row[0]
        for row in connection.execute(
            "SELECT job_id FROM job_results WHERE status = 'completed'"
        )
    }
    stage7 = routes._load_stage7()
    from cnc_cutting.diagnostics import diagnose_actions
    from cnc_cutting.travel import clear_detour_cache

    args = routes.stage7_args()
    timeout_seconds = float(
        json.loads(routes.FREEZE_MANIFEST.read_text(encoding="utf-8"))[
            "full_run"
        ]["timeout_seconds"]
    )
    template = NcTemplate()
    total = len(jobs)
    processed = len(completed & {job["job_id"] for job in jobs})
    try:
        for (
            board_jobs,
            layout,
            panel,
            tool,
            process_model,
            tool_event_gate,
            units,
        ) in routes.iter_loaded_boards(jobs, stage7):
            methods = tuple(job["method"] for job in board_jobs)
            specs = {
                spec.method: spec
                for spec in stage7.build_planners(
                    methods,
                    units,
                    panel,
                    tool,
                    process_model,
                    tool_event_gate,
                    len(layout.rectangles),
                    args.repeat_cut_policy,
                    algorithm_seed=args.algorithm_seed,
                )
            }
            for job in board_jobs:
                if job["job_id"] in completed:
                    continue
                started = perf_counter()
                try:
                    clear_detour_cache()
                    with stage7.task_timeout(timeout_seconds):
                        plan = specs[job["method"]].planner()
                    planner_runtime_ms = (perf_counter() - started) * 1000.0
                    diagnostics = diagnose_actions(
                        plan.actions,
                        panel,
                        tool,
                        process_model=process_model,
                    )
                    actions = actions_from_diagnostics(
                        asdict(diagnostic) for diagnostic in diagnostics
                    )
                    gcode = generate_canonical_gcode(
                        actions,
                        panel_width_mm=panel.panel_width,
                        panel_height_mm=panel.panel_height,
                        start_x_mm=tool.start_point.x,
                        start_y_mm=tool.start_point.y,
                        template=template,
                    )
                    parsed = parse_gcode(gcode)
                    audit = audit_route_nc(
                        actions,
                        parsed,
                        panel_width_mm=panel.panel_width,
                        panel_height_mm=panel.panel_height,
                        template=template,
                    )
                    geometry = geometry_metrics(parsed)
                    mismatches = reference_mismatches(
                        plan,
                        references[job["job_id"]],
                    )
                    with connection:
                        insert_completed(
                            connection,
                            job=job,
                            planner_runtime_ms=planner_runtime_ms,
                            plan=plan,
                            actions=actions,
                            gcode=gcode,
                            audit=audit,
                            geometry=geometry,
                            mismatches=mismatches,
                        )
                    if retain_gcode:
                        target = (
                            output_dir
                            / "gcode"
                            / job["task_id"]
                            / job["packing_seed"]
                            / f"board_{job['board_id']}__{job['method']}.nc"
                        )
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_text(gcode, encoding="utf-8")
                except Exception as exc:
                    runtime_ms = (perf_counter() - started) * 1000.0
                    with connection:
                        insert_failure(connection, job, runtime_ms, exc)
                processed += 1
                if processed % 25 == 0 or processed == total:
                    print(f"NC evaluation {processed}/{total}", flush=True)
    finally:
        export_results(connection, output_dir)
        summary = {
            "freeze_manifest": str(FREEZE_MANIFEST.resolve()),
            "freeze_manifest_sha256": sha256_file(FREEZE_MANIFEST),
            "jobs_file": str(jobs_path.resolve()),
            "jobs_sha256": sha256_file(jobs_path),
            "shard_index": shard_index,
            "shard_count": shard_count,
            "selected_job_count": len(jobs),
            "database": str(database_path.resolve()),
            "job_counts": {
                status: count
                for status, count in connection.execute(
                    "SELECT status, COUNT(*) FROM job_results GROUP BY status"
                )
            },
            "scenario_row_count": connection.execute(
                "SELECT COUNT(*) FROM scenario_times"
            ).fetchone()[0],
            "retained_gcode": retain_gcode,
            "scope": manifest["scope"],
        }
        (output_dir / "run_summary.json").write_text(
            json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        connection.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("track", choices=("pilot", "full"))
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--retain-gcode", action="store_true")
    parser.add_argument("--shard-count", type=int, default=1)
    parser.add_argument("--shard-index", type=int, default=0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.track == "pilot":
        if args.shard_count != 1 or args.shard_index != 0:
            raise ValueError("pilot track must run as one unsharded gate")
        jobs_path = PILOT_JOBS
        output_dir = PILOT_OUTPUT
    else:
        jobs_path = FULL_JOBS
        output_dir = (
            FULL_OUTPUT
            if args.shard_count == 1
            else FULL_SHARD_ROOT
            / f"shard_{args.shard_index:02d}_of_{args.shard_count:02d}"
        )
    run(
        jobs_path,
        output_dir,
        resume=args.resume,
        retain_gcode=args.retain_gcode,
        shard_index=args.shard_index,
        shard_count=args.shard_count,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
