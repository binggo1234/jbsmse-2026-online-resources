from __future__ import annotations

import argparse
from collections import Counter
import csv
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
from pathlib import Path
from typing import Iterable
from zipfile import ZipFile


FACTORY_ENCODING = "gb18030"
REQUIRED_FACTORY_COLUMNS = frozenset(
    {"Upi", "Fleng", "Fwidth", "Quantity"}
)
OUTPUT_COLUMNS = (
    "task_id",
    "uid",
    "pid_raw",
    "w0",
    "h0",
    "source_row",
    "quantity_index",
    "source_csv_sha256",
)


@dataclass(frozen=True)
class InventoryPart:
    task_id: str
    uid: str
    pid_raw: str
    w0: Decimal
    h0: Decimal
    source_row: int
    quantity_index: int
    source_csv_sha256: str


@dataclass(frozen=True)
class GateResult:
    legacy_alias: str
    task_id: str
    raw_record_count: int
    converted_part_count: int
    historical_member_count: int
    historical_part_count: int
    historical_members_consistent: bool
    oriented_missing_count: int
    oriented_extra_count: int
    normalized_missing_count: int
    normalized_extra_count: int
    passed: bool


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_decimal(value: Decimal) -> str:
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def parse_positive_decimal(value: str, *, field: str, row_number: int) -> Decimal:
    try:
        parsed = Decimal(value.strip())
    except (InvalidOperation, AttributeError) as exc:
        raise ValueError(
            f"row {row_number}: invalid {field} value {value!r}"
        ) from exc
    if not parsed.is_finite() or parsed <= 0:
        raise ValueError(
            f"row {row_number}: {field} must be finite and positive, got {value!r}"
        )
    return parsed


def parse_quantity(value: str, *, row_number: int) -> int:
    try:
        parsed = Decimal(value.strip())
    except (InvalidOperation, AttributeError) as exc:
        raise ValueError(
            f"row {row_number}: invalid Quantity value {value!r}"
        ) from exc
    if not parsed.is_finite() or parsed != parsed.to_integral_value() or parsed <= 0:
        raise ValueError(
            f"row {row_number}: Quantity must be a positive integer, got {value!r}"
        )
    return int(parsed)


def task_id_from_path(path: Path) -> str:
    suffix = "_ZN_GSTX.csv"
    if not path.name.endswith(suffix):
        raise ValueError(f"factory CSV name must end with {suffix}: {path}")
    return path.name[: -len(suffix)]


def read_factory_inventory(
    path: Path,
    *,
    task_id: str | None = None,
) -> tuple[InventoryPart, ...]:
    source_hash = sha256_file(path)
    resolved_task_id = task_id or task_id_from_path(path)
    parts: list[InventoryPart] = []

    with path.open(encoding=FACTORY_ENCODING, newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = frozenset(reader.fieldnames or ())
        missing = sorted(REQUIRED_FACTORY_COLUMNS - fieldnames)
        if missing:
            raise ValueError(f"factory CSV missing required columns: {missing}")

        for source_row, row in enumerate(reader, start=1):
            width = parse_positive_decimal(
                row["Fleng"], field="Fleng", row_number=source_row
            )
            height = parse_positive_decimal(
                row["Fwidth"], field="Fwidth", row_number=source_row
            )
            quantity = parse_quantity(row["Quantity"], row_number=source_row)
            raw_part_id = str(row.get("Upi") or "").strip()
            for quantity_index in range(1, quantity + 1):
                uid = (
                    f"{resolved_task_id}:"
                    f"r{source_row:06d}:q{quantity_index:03d}"
                )
                parts.append(
                    InventoryPart(
                        task_id=resolved_task_id,
                        uid=uid,
                        pid_raw=raw_part_id or uid,
                        w0=width,
                        h0=height,
                        source_row=source_row,
                        quantity_index=quantity_index,
                        source_csv_sha256=source_hash,
                    )
                )
    return tuple(parts)


def write_inventory(path: Path, parts: Iterable[InventoryPart]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for part in parts:
            row = asdict(part)
            row["w0"] = canonical_decimal(part.w0)
            row["h0"] = canonical_decimal(part.h0)
            writer.writerow(row)


def oriented_dimension_counter(
    dimensions: Iterable[tuple[Decimal, Decimal]],
) -> Counter[tuple[Decimal, Decimal]]:
    return Counter(dimensions)


def normalized_dimension_counter(
    dimensions: Iterable[tuple[Decimal, Decimal]],
) -> Counter[tuple[Decimal, Decimal]]:
    return Counter(tuple(sorted(pair)) for pair in dimensions)


def placement_members_for_alias(archive: ZipFile, alias: str) -> tuple[str, ...]:
    marker_forward = f"__{alias}/"
    marker_backward = f"__{alias}\\"
    return tuple(
        sorted(
            name
            for name in archive.namelist()
            if name.endswith("placements.csv")
            and (marker_forward in name or marker_backward in name)
        )
    )


def read_historical_dimensions(
    archive: ZipFile,
    member: str,
) -> tuple[tuple[Decimal, Decimal], ...]:
    with archive.open(member) as binary_handle:
        text_handle = io.TextIOWrapper(
            binary_handle, encoding="utf-8-sig", newline=""
        )
        reader = csv.DictReader(text_handle)
        if not {"w0", "h0"} <= set(reader.fieldnames or ()):
            raise ValueError(f"historical placement member lacks w0/h0: {member}")
        return tuple(
            (
                parse_positive_decimal(
                    row["w0"], field="w0", row_number=row_number
                ),
                parse_positive_decimal(
                    row["h0"], field="h0", row_number=row_number
                ),
            )
            for row_number, row in enumerate(reader, start=1)
        )


def audit_alias(
    *,
    archive: ZipFile,
    alias: str,
    task_id: str,
    parts: tuple[InventoryPart, ...],
    raw_record_count: int,
) -> GateResult:
    members = placement_members_for_alias(archive, alias)
    if not members:
        raise ValueError(f"no historical placements.csv members found for {alias}")

    historical_counters = [
        oriented_dimension_counter(read_historical_dimensions(archive, member))
        for member in members
    ]
    reference_counter = historical_counters[0]
    members_consistent = all(
        counter == reference_counter for counter in historical_counters[1:]
    )
    converted = oriented_dimension_counter((part.w0, part.h0) for part in parts)
    converted_normalized = normalized_dimension_counter(
        (part.w0, part.h0) for part in parts
    )
    historical_normalized = normalized_dimension_counter(
        pair
        for pair, count in reference_counter.items()
        for _ in range(count)
    )
    oriented_missing = sum((reference_counter - converted).values())
    oriented_extra = sum((converted - reference_counter).values())
    normalized_missing = sum(
        (historical_normalized - converted_normalized).values()
    )
    normalized_extra = sum(
        (converted_normalized - historical_normalized).values()
    )
    historical_count = sum(reference_counter.values())
    passed = (
        members_consistent
        and len(parts) == historical_count
        and oriented_missing == 0
        and oriented_extra == 0
        and normalized_missing == 0
        and normalized_extra == 0
    )
    return GateResult(
        legacy_alias=alias,
        task_id=task_id,
        raw_record_count=raw_record_count,
        converted_part_count=len(parts),
        historical_member_count=len(members),
        historical_part_count=historical_count,
        historical_members_consistent=members_consistent,
        oriented_missing_count=oriented_missing,
        oriented_extra_count=oriented_extra,
        normalized_missing_count=normalized_missing,
        normalized_extra_count=normalized_extra,
        passed=passed,
    )


def read_raw_record_count(path: Path) -> int:
    with path.open(encoding=FACTORY_ENCODING, newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))


def write_gate_report(path: Path, results: list[GateResult]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(results[0])))
        writer.writeheader()
        writer.writerows(asdict(result) for result in results)


def write_gate_summary(path: Path, results: list[GateResult]) -> None:
    passed = sum(result.passed for result in results)
    lines = [
        "# Factory CSV Conversion Freeze Gate",
        "",
        f"- Development tasks: {len(results)}",
        f"- Passed tasks: {passed}",
        f"- Converted parts: {sum(r.converted_part_count for r in results)}",
        (
            "- Verdict: PASS"
            if passed == len(results)
            else "- Verdict: FAIL"
        ),
        "",
        "| Alias | Task | Parts | Historical members | Oriented missing/extra | Pass |",
        "|---|---|---:|---:|---:|:---:|",
    ]
    lines.extend(
        (
            f"| {result.legacy_alias} | {result.task_id} | "
            f"{result.converted_part_count} | {result.historical_member_count} | "
            f"{result.oriented_missing_count}/{result.oriented_extra_count} | "
            f"{'yes' if result.passed else 'no'} |"
        )
        for result in results
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def load_development_rows(lineage_manifest: Path) -> list[dict[str, str]]:
    with lineage_manifest.open(encoding="utf-8", newline="") as handle:
        rows = [
            row
            for row in csv.DictReader(handle)
            if str(row.get("legacy_alias") or "").strip()
        ]
    aliases = {row["legacy_alias"] for row in rows}
    expected = {f"data{index}" for index in range(1, 7)}
    if aliases != expected or len(rows) != 6:
        raise ValueError(
            f"lineage manifest must contain exactly {sorted(expected)}, got {sorted(aliases)}"
        )
    return sorted(rows, key=lambda row: row["legacy_alias"])


def run_gate(
    *,
    lineage_manifest: Path,
    raw_root: Path,
    reference_archive: Path,
    output_dir: Path,
) -> list[GateResult]:
    development_rows = load_development_rows(lineage_manifest)
    results: list[GateResult] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    with ZipFile(reference_archive) as archive:
        for row in development_rows:
            source = raw_root / row["csv_relative_path"]
            if sha256_file(source) != row["csv_sha256"]:
                raise ValueError(f"raw CSV hash mismatch: {source}")
            parts = read_factory_inventory(source, task_id=row["task_id"])
            inventory_path = (
                output_dir / "inventories" / f"{row['legacy_alias']}_inventory.csv"
            )
            write_inventory(inventory_path, parts)
            results.append(
                audit_alias(
                    archive=archive,
                    alias=row["legacy_alias"],
                    task_id=row["task_id"],
                    parts=parts,
                    raw_record_count=read_raw_record_count(source),
                )
            )

    report_path = output_dir / "conversion_gate_report.csv"
    summary_path = output_dir / "conversion_gate_report.md"
    write_gate_report(report_path, results)
    write_gate_summary(summary_path, results)
    execution_manifest = {
        "lineage_manifest": str(lineage_manifest.resolve()),
        "lineage_manifest_sha256": sha256_file(lineage_manifest),
        "raw_root": str(raw_root.resolve()),
        "reference_archive": str(reference_archive.resolve()),
        "reference_archive_sha256": sha256_file(reference_archive),
        "converter": str(Path(__file__).resolve()),
        "converter_sha256": sha256_file(Path(__file__)),
        "factory_encoding": FACTORY_ENCODING,
        "dimension_fields": ["Fleng", "Fwidth"],
        "quantity_field": "Quantity",
        "results": [asdict(result) for result in results],
        "passed": all(result.passed for result in results),
    }
    (output_dir / "execution_manifest.json").write_text(
        json.dumps(execution_manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return results


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Convert raw factory CSV records to canonical w0/h0 inventories, "
            "or audit the six-task conversion freeze gate."
        )
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    convert = subparsers.add_parser("convert")
    convert.add_argument("--source", type=Path, required=True)
    convert.add_argument("--output", type=Path, required=True)
    convert.add_argument("--task-id")

    gate = subparsers.add_parser("gate")
    gate.add_argument("--lineage-manifest", type=Path, required=True)
    gate.add_argument("--raw-root", type=Path, required=True)
    gate.add_argument("--reference-archive", type=Path, required=True)
    gate.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "convert":
        parts = read_factory_inventory(args.source, task_id=args.task_id)
        write_inventory(args.output, parts)
        print(f"parts={len(parts)}")
        print(f"output={args.output}")
        return

    results = run_gate(
        lineage_manifest=args.lineage_manifest,
        raw_root=args.raw_root,
        reference_archive=args.reference_archive,
        output_dir=args.output_dir,
    )
    passed = all(result.passed for result in results)
    print(f"tasks={len(results)}")
    print(f"passed={sum(result.passed for result in results)}")
    print(f"converted_parts={sum(result.converted_part_count for result in results)}")
    print(f"verdict={'PASS' if passed else 'FAIL'}")
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
