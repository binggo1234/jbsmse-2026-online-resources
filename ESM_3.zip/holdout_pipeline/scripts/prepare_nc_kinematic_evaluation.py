from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Iterable

from scripts.nc_kinematic_core import NcTemplate, default_scenarios


ROOT = Path(__file__).resolve().parents[1]
ROUTE_DIR = ROOT / "outputs/holdout_route_experiment_v1"
BOARD_INDEX = ROUTE_DIR / "board_geometry_index.csv"
FULL_JOBS = ROUTE_DIR / "frozen_route_jobs.csv"
ROUTE_FREEZE = ROUTE_DIR / "route_run_freeze_manifest.json"
ISOLATED_RESULTS = ROUTE_DIR / "route_results_cache_isolated.csv"
OUTPUT_DIR = ROOT / "outputs/nc_kinematic_evaluation_v2"
PILOT_BOARDS = OUTPUT_DIR / "pilot_boards.csv"
PILOT_JOBS = OUTPUT_DIR / "pilot_jobs.csv"
FREEZE_MANIFEST = OUTPUT_DIR / "nc_kinematic_freeze_manifest.json"
PROTOCOL = ROOT / "docs/ijamt_nc_kinematic_evaluation_freeze_v1.md"

SELECTION_SEED = 20260729
BOARDS_PER_TASK = 5
EXPECTED_TASKS = 20
EXPECTED_METHODS = 5
EXPECTED_PILOT_BOARDS = EXPECTED_TASKS * BOARDS_PER_TASK
EXPECTED_PILOT_JOBS = EXPECTED_PILOT_BOARDS * EXPECTED_METHODS
EXPECTED_FULL_JOBS = 58_920


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_hash(*values: object) -> str:
    payload = "|".join(str(value) for value in values)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(
    path: Path,
    fieldnames: Iterable[str],
    rows: Iterable[dict[str, object]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fieldnames), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def board_key(row: dict[str, str]) -> tuple[str, str]:
    return row["placements_member"], row["board_id"]


def select_pilot_boards(
    rows: list[dict[str, str]],
    *,
    expected_tasks: int = EXPECTED_TASKS,
) -> list[dict[str, str]]:
    by_task: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_task[row["task_id"]].append(row)
    if len(by_task) != expected_tasks:
        raise ValueError(f"expected {expected_tasks} tasks, found {len(by_task)}")

    selected: list[dict[str, str]] = []
    for task_id in sorted(by_task):
        task_rows = by_task[task_id]
        by_seed: dict[str, list[dict[str, str]]] = defaultdict(list)
        for row in task_rows:
            by_seed[row["packing_seed"]].append(row)
        task_selected: list[dict[str, str]] = []
        for packing_seed in sorted(by_seed):
            candidates = sorted(
                by_seed[packing_seed],
                key=lambda row: stable_hash(
                    SELECTION_SEED,
                    "seed-representative",
                    task_id,
                    packing_seed,
                    row["placements_member"],
                    row["board_id"],
                ),
            )
            task_selected.append(candidates[0])
        if len(task_selected) > BOARDS_PER_TASK:
            task_selected = sorted(
                task_selected,
                key=lambda row: stable_hash(
                    SELECTION_SEED,
                    "seed-trim",
                    task_id,
                    row["placements_member"],
                    row["board_id"],
                ),
            )[:BOARDS_PER_TASK]
        selected_keys = {board_key(row) for row in task_selected}
        remaining = sorted(
            (row for row in task_rows if board_key(row) not in selected_keys),
            key=lambda row: stable_hash(
                SELECTION_SEED,
                "task-fill",
                task_id,
                row["placements_member"],
                row["board_id"],
            ),
        )
        task_selected.extend(remaining[: BOARDS_PER_TASK - len(task_selected)])
        if len(task_selected) != BOARDS_PER_TASK:
            raise ValueError(
                f"task {task_id} has only {len(task_selected)} selectable boards"
            )
        selected.extend(task_selected)
    return sorted(
        selected,
        key=lambda row: (
            row["task_id"],
            stable_hash(
                SELECTION_SEED,
                "pilot-order",
                row["placements_member"],
                row["board_id"],
            ),
        ),
    )


def verify_sources() -> dict[str, object]:
    route_manifest = json.loads(ROUTE_FREEZE.read_text(encoding="utf-8"))
    if route_manifest["method_count"] != EXPECTED_METHODS:
        raise ValueError("frozen route method count changed")
    if route_manifest["method_task_count"] != EXPECTED_FULL_JOBS:
        raise ValueError("frozen route job count changed")
    if sha256_file(FULL_JOBS) != route_manifest["inputs"]["full_jobs"]["sha256"]:
        raise ValueError("frozen route jobs no longer match their manifest")
    full_jobs = read_csv(FULL_JOBS)
    if len(full_jobs) != EXPECTED_FULL_JOBS:
        raise ValueError(f"expected {EXPECTED_FULL_JOBS} full jobs")
    reference_rows = read_csv(ISOLATED_RESULTS)
    if len(reference_rows) != EXPECTED_FULL_JOBS:
        raise ValueError("isolated reference result count changed")
    if any(row["status"] != "completed" for row in reference_rows):
        raise ValueError("isolated reference results contain non-completed jobs")
    return route_manifest


def freeze() -> None:
    route_manifest = verify_sources()
    boards = read_csv(BOARD_INDEX)
    pilot_boards = select_pilot_boards(boards)
    if len(pilot_boards) != EXPECTED_PILOT_BOARDS:
        raise ValueError("pilot board count mismatch")
    selected_keys = {board_key(row) for row in pilot_boards}
    full_jobs = read_csv(FULL_JOBS)
    pilot_jobs = [
        row for row in full_jobs if board_key(row) in selected_keys
    ]
    pilot_jobs.sort(key=lambda row: int(row["schedule_order"]))
    if len(pilot_jobs) != EXPECTED_PILOT_JOBS:
        raise ValueError(f"pilot job count mismatch: {len(pilot_jobs)}")
    counts: dict[tuple[str, str], int] = defaultdict(int)
    for row in pilot_jobs:
        counts[board_key(row)] += 1
    if set(counts.values()) != {EXPECTED_METHODS}:
        raise ValueError("not every selected board has all five methods")

    write_csv(PILOT_BOARDS, pilot_boards[0].keys(), pilot_boards)
    write_csv(PILOT_JOBS, pilot_jobs[0].keys(), pilot_jobs)
    template = NcTemplate()
    scenarios = default_scenarios()
    manifest = {
        "schema_version": 2,
        "freeze_status": "frozen_before_nc_quality_or_timing_inspection",
        "scope": (
            "Transparent controller-neutral NC-level kinematic sensitivity; "
            "not measured machine time or manufacturing validation."
        ),
        "independent_statistical_unit": "factory_task",
        "nested_units": ["packing_seed", "board"],
        "pilot": {
            "selection_seed": SELECTION_SEED,
            "selection_rule": (
                "five boards per factory task; one deterministic hash-selected "
                "board from each available packing seed, then deterministic "
                "within-task hash fill"
            ),
            "task_count": EXPECTED_TASKS,
            "boards_per_task": BOARDS_PER_TASK,
            "board_count": EXPECTED_PILOT_BOARDS,
            "method_count": EXPECTED_METHODS,
            "job_count": EXPECTED_PILOT_JOBS,
            "boards_file": str(PILOT_BOARDS.resolve()),
            "boards_sha256": sha256_file(PILOT_BOARDS),
            "jobs_file": str(PILOT_JOBS.resolve()),
            "jobs_sha256": sha256_file(PILOT_JOBS),
        },
        "full_run": {
            "board_count": route_manifest["board_count"],
            "method_count": route_manifest["method_count"],
            "job_count": route_manifest["method_task_count"],
            "methods": route_manifest["methods"],
            "jobs_file": str(FULL_JOBS.resolve()),
            "jobs_sha256": sha256_file(FULL_JOBS),
            "reference_results_file": str(ISOLATED_RESULTS.resolve()),
            "reference_results_sha256": sha256_file(ISOLATED_RESULTS),
        },
        "nc_template": {
            "stock_thickness_mm": template.stock_thickness_mm,
            "tool_diameter_mm": template.tool_diameter_mm,
            "z_low_clearance_mm": template.z_low_clearance_mm,
            "z_safe_mm": template.z_safe_mm,
            "step_down_mm": template.step_down_mm,
            "depths_mm": template.depths_mm,
            "spindle_rpm": template.spindle_rpm,
            "feed_cut_mm_min": template.feed_cut_mm_min,
            "feed_plunge_mm_min": template.feed_plunge_mm_min,
            "linear_feed_cap_policy": (
                "every G1 XY or Z block is capped by its modal F word; "
                "scenario speeds are axis limits, while G0 uses the "
                "corresponding scenario limit"
            ),
            "coordinate_decimals": template.coordinate_decimals,
            "nc_tolerance_mm": template.nc_tolerance_mm,
            "multipass_policy": (
                "complete all depth passes for one cutting action before the "
                "next top-level route action; alternate direction by pass"
            ),
            "return_policy": "retract to safe Z and return to the fixed tool start",
        },
        "kinematic_scenarios": [
            {
                "scenario": scenario.scenario,
                "cut_speed_mm_s": scenario.cut_speed_mm_s,
                "rapid_speed_mm_s": scenario.rapid_speed_mm_s,
                "xy_acceleration_mm_s2": scenario.xy_acceleration_mm_s2,
                "z_speed_mm_s": scenario.z_speed_mm_s,
                "z_acceleration_mm_s2": scenario.z_acceleration_mm_s2,
                "z_speed_semantics": (
                    "G0 Z-axis limit; G1 Z is capped by the modal feed"
                ),
                "nonmotion_event_time_s": scenario.nonmotion_event_time_s,
            }
            for scenario in scenarios
        ],
        "hard_pilot_gate": {
            "completed_jobs": EXPECTED_PILOT_JOBS,
            "failed_jobs": 0,
            "route_reference_mismatches": 0,
            "nc_audit_failures": 0,
            "unsupported_nc_words": 0,
            "maximum_coordinate_error_mm": template.nc_tolerance_mm,
            "scenario_rows_per_completed_job": len(scenarios),
            "prohibition": (
                "Do not inspect or compare method timing reductions until all "
                "hard gate conditions have passed."
            ),
        },
        "analysis": {
            "primary_nc_metric": "noncut time",
            "secondary_nc_metric": "total time",
            "models": ["ideal continuous motion", "stop at junction"],
            "aggregation": (
                "sum boards within task-seed, average packing seeds within task, "
                "then compare the 20 factory tasks with equal task weight"
            ),
            "scenario_count": len(scenarios),
            "scenario_direction_counts_are_descriptive_not_independent_replicates": True,
            "gtsp_timing_and_support_policy_penalty_reported_separately": True,
            "execution_sharding": (
                "four deterministic board-level shards; every board's five "
                "methods remain in the same shard; shards are merged by exact "
                "frozen job_id before analysis"
            ),
        },
        "inputs": {
            "route_freeze_manifest": str(ROUTE_FREEZE.resolve()),
            "route_freeze_manifest_sha256": sha256_file(ROUTE_FREEZE),
            "board_index": str(BOARD_INDEX.resolve()),
            "board_index_sha256": sha256_file(BOARD_INDEX),
            "protocol": str(PROTOCOL.resolve()),
            "protocol_sha256": sha256_file(PROTOCOL),
        },
        "software": {
            "preparation_script": str(Path(__file__).resolve()),
            "preparation_script_sha256": sha256_file(Path(__file__).resolve()),
            "core_module": str((ROOT / "scripts/nc_kinematic_core.py").resolve()),
            "core_module_sha256": sha256_file(ROOT / "scripts/nc_kinematic_core.py"),
            "runner": str((ROOT / "scripts/run_nc_kinematic_evaluation.py").resolve()),
            "runner_sha256": sha256_file(
                ROOT / "scripts/run_nc_kinematic_evaluation.py"
            ),
            "analysis": str(
                (ROOT / "scripts/analyze_nc_kinematic_results.py").resolve()
            ),
            "analysis_sha256": sha256_file(
                ROOT / "scripts/analyze_nc_kinematic_results.py"
            ),
            "merge": str(
                (ROOT / "scripts/merge_nc_kinematic_shards.py").resolve()
            ),
            "merge_sha256": sha256_file(
                ROOT / "scripts/merge_nc_kinematic_shards.py"
            ),
        },
    }
    FREEZE_MANIFEST.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"frozen {len(pilot_boards)} pilot boards and {len(pilot_jobs)} jobs")
    print(FREEZE_MANIFEST)


def verify() -> None:
    manifest = json.loads(FREEZE_MANIFEST.read_text(encoding="utf-8"))
    checks = (
        (Path(manifest["pilot"]["boards_file"]), manifest["pilot"]["boards_sha256"]),
        (Path(manifest["pilot"]["jobs_file"]), manifest["pilot"]["jobs_sha256"]),
        (
            Path(manifest["full_run"]["jobs_file"]),
            manifest["full_run"]["jobs_sha256"],
        ),
        (
            Path(manifest["full_run"]["reference_results_file"]),
            manifest["full_run"]["reference_results_sha256"],
        ),
        (
            Path(manifest["inputs"]["route_freeze_manifest"]),
            manifest["inputs"]["route_freeze_manifest_sha256"],
        ),
        (Path(manifest["inputs"]["board_index"]), manifest["inputs"]["board_index_sha256"]),
        (Path(manifest["inputs"]["protocol"]), manifest["inputs"]["protocol_sha256"]),
        (
            Path(manifest["software"]["preparation_script"]),
            manifest["software"]["preparation_script_sha256"],
        ),
        (Path(manifest["software"]["core_module"]), manifest["software"]["core_module_sha256"]),
        (Path(manifest["software"]["runner"]), manifest["software"]["runner_sha256"]),
        (
            Path(manifest["software"]["analysis"]),
            manifest["software"]["analysis_sha256"],
        ),
        (
            Path(manifest["software"]["merge"]),
            manifest["software"]["merge_sha256"],
        ),
    )
    for path, expected in checks:
        actual = sha256_file(path)
        if actual != expected:
            raise ValueError(f"frozen file changed: {path}")
    if len(read_csv(Path(manifest["pilot"]["jobs_file"]))) != EXPECTED_PILOT_JOBS:
        raise ValueError("pilot job count changed")
    print("NC kinematic experiment freeze verified")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("freeze")
    subparsers.add_parser("verify")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.command == "freeze":
        freeze()
    else:
        verify()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
