from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import io
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def git_commit(repo: Path) -> str:
    completed = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def load_packing_module(stage7_repo: Path):
    source_root = str((stage7_repo / "src").resolve())
    if source_root not in sys.path:
        sys.path.insert(0, source_root)
    return importlib.import_module("cnc_cutting.kerf_packing")


def build_parts(module, rows: list[dict[str, str]], tool_diameter: float):
    return tuple(
        module.KerfPackingPart(
            part_id=row["uid"],
            raw_part_id=row["pid_raw"],
            nominal_width=float(row["w0"]),
            nominal_height=float(row["h0"]),
            envelope_width=float(row["w0"]) + tool_diameter,
            envelope_height=float(row["h0"]) + tool_diameter,
        )
        for row in rows
    )


def placement_csv(boards) -> str:
    handle = io.StringIO(newline="")
    writer = csv.writer(handle, lineterminator="\n")
    writer.writerow(
        ("board", "uid", "pid_raw", "x", "y", "w", "h", "w0", "h0", "rotated")
    )
    for board in boards:
        for packed in board.placed:
            writer.writerow(
                (
                    board.board_id,
                    packed.part.part_id,
                    packed.part.raw_part_id,
                    f"{packed.envelope.x:.9f}",
                    f"{packed.envelope.y:.9f}",
                    f"{packed.envelope.width:.9f}",
                    f"{packed.envelope.height:.9f}",
                    f"{packed.part.nominal_width:.9f}",
                    f"{packed.part.nominal_height:.9f}",
                    int(packed.rotated),
                )
            )
    return handle.getvalue()


def audit_boards(boards, expected_part_ids: set[str]) -> None:
    packed_ids: list[str] = []
    for board in boards:
        for index, first in enumerate(board.placed):
            rectangle = first.envelope
            if (
                rectangle.x < board.trim - 1e-9
                or rectangle.y < board.trim - 1e-9
                or rectangle.max_x > board.panel_width - board.trim + 1e-9
                or rectangle.max_y > board.panel_height - board.trim + 1e-9
            ):
                raise AssertionError(
                    f"packed envelope outside trimmed stock: {first.part.part_id}"
                )
            for second in board.placed[index + 1 :]:
                other = second.envelope
                intersects = not (
                    other.x >= rectangle.max_x - 1e-9
                    or other.max_x <= rectangle.x + 1e-9
                    or other.y >= rectangle.max_y - 1e-9
                    or other.max_y <= rectangle.y + 1e-9
                )
                if intersects:
                    raise AssertionError(
                        f"overlapping envelopes: {first.part.part_id}, "
                        f"{second.part.part_id}"
                    )
            packed_ids.append(first.part.part_id)
    if len(packed_ids) != len(set(packed_ids)):
        raise AssertionError("duplicate packed part ids")
    if set(packed_ids) != expected_part_ids:
        raise AssertionError("packing did not preserve the complete inventory")


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Execute the frozen 60-job holdout kerf-packing manifest."
    )
    parser.add_argument("--run-manifest", type=Path, required=True)
    parser.add_argument("--stage7-repo", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    jobs = load_rows(args.run_manifest)
    if len(jobs) != 60:
        raise ValueError(f"expected 60 frozen packing jobs, found {len(jobs)}")
    expected_commit = {row["stage7_commit"] for row in jobs}
    expected_kerf_hash = {row["kerf_packing_sha256"] for row in jobs}
    expected_runner_hash = {row["runner_sha256"] for row in jobs}
    if len(expected_commit) != 1 or git_commit(args.stage7_repo) not in expected_commit:
        raise ValueError("Stage7 git commit does not match frozen run manifest")
    kerf_path = args.stage7_repo / "src/cnc_cutting/kerf_packing.py"
    if {sha256_file(kerf_path)} != expected_kerf_hash:
        raise ValueError("kerf_packing.py hash does not match frozen run manifest")
    if {sha256_file(Path(__file__))} != expected_runner_hash:
        raise ValueError("packing runner hash does not match frozen run manifest")

    module = load_packing_module(args.stage7_repo)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    archive_path = args.output_dir / "holdout_kerf_layouts.zip"
    result_rows: list[dict[str, object]] = []
    with ZipFile(archive_path, "w", compression=ZIP_DEFLATED) as output:
        for job in sorted(jobs, key=lambda row: int(row["run_order"])):
            inventory_path = Path(job["inventory_path"])
            if sha256_file(inventory_path) != job["inventory_sha256"]:
                raise ValueError(f"inventory hash mismatch: {inventory_path}")
            inventory_rows = load_rows(inventory_path)
            tool_diameter = float(job["tool_diameter_mm"])
            parts = build_parts(module, inventory_rows, tool_diameter)
            boards = module.pack_kerf_envelopes(
                parts,
                panel_width=float(job["panel_width_mm"]),
                panel_height=float(job["panel_height_mm"]),
                trim=float(job["trim_mm"]),
                allow_rotation=job["allow_rotation"] == "True",
                order_seed=int(job["packing_seed"]),
                order_top_k=int(job["packing_order_top_k"]),
            )
            audit_boards(boards, {part.part_id for part in parts})
            text = placement_csv(boards)
            prefix = job["output_member_prefix"]
            placement_member = f"{prefix}/placements.csv"
            config_member = f"{prefix}/config_dump.json"
            config = {
                "cfg": {
                    "BOARD_W": float(job["panel_width_mm"]),
                    "BOARD_H": float(job["panel_height_mm"]),
                    "TRIM": float(job["trim_mm"]),
                    "TOOL_D": tool_diameter,
                    "GAP": tool_diameter,
                    "SAFE_GAP": tool_diameter,
                    "BINARY_SPACING": False,
                    "ALLOW_ROT": job["allow_rotation"] == "True",
                    "PACKING_METHOD": job["packing_method"],
                    "PACKING_ORDER_SEED": int(job["packing_seed"]),
                    "PACKING_ORDER_TOP_K": int(job["packing_order_top_k"]),
                    "PLACEMENT_GEOMETRY_MODE": "nominal_from_tool_inflated",
                    "GEOMETRIC_KERF_COMPENSATION": True,
                },
                "provenance": {
                    "run_id": job["run_id"],
                    "task_id": job["task_id"],
                    "inventory_sha256": job["inventory_sha256"],
                    "stage7_commit": job["stage7_commit"],
                    "kerf_packing_sha256": job["kerf_packing_sha256"],
                },
            }
            output.writestr(placement_member, text)
            output.writestr(
                config_member,
                json.dumps(config, ensure_ascii=False, indent=2) + "\n",
            )
            result_rows.append(
                {
                    "run_id": job["run_id"],
                    "run_order": job["run_order"],
                    "task_id": job["task_id"],
                    "packing_seed": job["packing_seed"],
                    "source_part_count": len(parts),
                    "generated_board_count": len(boards),
                    "packed_part_count": sum(len(board.placed) for board in boards),
                    "minimum_board_part_count": min(
                        len(board.placed) for board in boards
                    ),
                    "maximum_board_part_count": max(
                        len(board.placed) for board in boards
                    ),
                    "placements_member": placement_member,
                    "config_member": config_member,
                    "placements_sha256": sha256_text(text),
                }
            )

    result_manifest = args.output_dir / "packing_result_manifest.csv"
    write_csv(result_manifest, result_rows)
    print(f"jobs={len(result_rows)}")
    print(f"archive={archive_path}")
    print(f"manifest={result_manifest}")


if __name__ == "__main__":
    main()
