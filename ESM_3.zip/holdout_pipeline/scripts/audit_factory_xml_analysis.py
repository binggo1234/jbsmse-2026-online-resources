from __future__ import annotations

import csv
import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median


ROOT = Path(__file__).resolve().parents[1]
ROUTE_DIR = ROOT / "outputs" / "factory_xml_routes_v1"
ANALYSIS_DIR = ROOT / "outputs" / "factory_xml_analysis_v1"
ROUTES = ROUTE_DIR / "route_results_cache_isolated.csv"
JOBS = ROUTE_DIR / "frozen_route_jobs.csv"
MANIFEST = ANALYSIS_DIR / "analysis_manifest.json"
TASK_METRICS = ANALYSIS_DIR / "task_metrics.csv"
CONFIRMATORY = ANALYSIS_DIR / "confirmatory_summary.csv"
AUDIT_JSON = ANALYSIS_DIR / "analysis_reproducibility_audit.json"
AUDIT_MD = ANALYSIS_DIR / "analysis_reproducibility_audit.md"

PROPOSED = "process_aware_beam_adaptive_polished"
PRIMARY_BASELINES = ("topology_process_aware", "endpoint_aware_gtsp")
CONFIRMATORY_LABEL = "confirmatory_holdout"
BOOTSTRAP_REPLICATES = 100_000
BOOTSTRAP_SEED = 20_260_726
TOLERANCE = 1e-9
METRICS = (
    "c_plan",
    "travel_mode_cost",
    "air_move_distance",
    "tool_event_count",
    "support_policy_penalty",
    "runtime_ms",
    "cutting_length",
    "hard_penalty",
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def close(left: object, right: object, tolerance: float = 1e-10) -> bool:
    first = float(left)
    second = float(right)
    return abs(first - second) <= tolerance * max(1.0, abs(first), abs(second))


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def bootstrap_ci(values: list[float]) -> tuple[float, float]:
    rng = random.Random(BOOTSTRAP_SEED)
    count = len(values)
    draws = [
        sum(values[rng.randrange(count)] for _ in range(count)) / count
        for _ in range(BOOTSTRAP_REPLICATES)
    ]
    return percentile(draws, 0.025), percentile(draws, 0.975)


def exact_sign_p(wins: int, losses: int) -> float:
    count = wins + losses
    if count == 0:
        return 1.0
    tail = min(wins, losses)
    return min(
        1.0,
        2.0 * sum(math.comb(count, index) for index in range(tail + 1))
        / (2**count),
    )


def task_aggregates() -> list[dict[str, object]]:
    routes = read_csv(ROUTES)
    jobs = read_csv(JOBS)
    job_by_id = {row["job_id"]: row for row in jobs}
    totals: dict[tuple[str, str, str], dict[str, float]] = defaultdict(
        lambda: {metric: 0.0 for metric in METRICS}
    )
    patterns: dict[tuple[str, str, str], set[str]] = defaultdict(set)
    for route in routes:
        job = job_by_id[route["job_id"]]
        key = (
            job["confirmatory_status"],
            job["task_id"],
            route["method"],
        )
        cutting = float(route["cutting_length"])
        travel = float(route["travel_mode_cost"])
        events = (
            float(route["pierce_count"])
            + float(route["lift_count"])
            + float(route["safe_lift_count"])
        )
        if not close(events, route["process_tool_event_count"]):
            raise ValueError(f"tool-event mismatch in {route['job_id']}")
        values = {
            "c_plan": cutting + travel,
            "travel_mode_cost": travel,
            "air_move_distance": float(route["air_move_distance"]),
            "tool_event_count": events,
            "support_policy_penalty": float(route["stability_penalty"]),
            "runtime_ms": float(route["runtime_ms"]),
            "cutting_length": cutting,
            "hard_penalty": float(route["hard_penalty"]),
        }
        for metric, value in values.items():
            totals[key][metric] += value
        patterns[key].add(job["pattern_id"])
    rows: list[dict[str, object]] = []
    for (cohort, task_id, method), values in sorted(totals.items()):
        rows.append(
            {
                "confirmatory_status": cohort,
                "task_id": task_id,
                "method": method,
                "pattern_count": len(patterns[(cohort, task_id, method)]),
                **values,
            }
        )
    if len(routes) != 13_765 or len(rows) != 55:
        raise ValueError("unexpected Track B aggregation dimensions")
    return rows


def compare_task_rows(expected: list[dict[str, object]]) -> None:
    actual = {
        (row["confirmatory_status"], row["task_id"], row["method"]): row
        for row in read_csv(TASK_METRICS)
    }
    if len(actual) != len(expected):
        raise ValueError("task-metric row count differs")
    for row in expected:
        identity = (
            str(row["confirmatory_status"]),
            str(row["task_id"]),
            str(row["method"]),
        )
        stored = actual[identity]
        if int(stored["pattern_count"]) != int(row["pattern_count"]):
            raise ValueError(f"{identity}: Pattern count differs")
        for metric in METRICS:
            if not close(stored[metric], row[metric]):
                raise ValueError(f"{identity}: {metric} differs")


def primary_summaries(
    rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    confirmatory = [
        row
        for row in rows
        if row["confirmatory_status"] == CONFIRMATORY_LABEL
    ]
    lookup = {
        (str(row["task_id"]), str(row["method"])): row
        for row in confirmatory
    }
    tasks = sorted({str(row["task_id"]) for row in confirmatory})
    raw: list[dict[str, object]] = []
    for baseline in PRIMARY_BASELINES:
        proposed_values: list[float] = []
        baseline_values: list[float] = []
        differences: list[float] = []
        reductions: list[float] = []
        wins = ties = losses = 0
        for task in tasks:
            proposed = float(lookup[(task, PROPOSED)]["c_plan"])
            reference = float(lookup[(task, baseline)]["c_plan"])
            difference = proposed - reference
            reduction = 100.0 * (reference - proposed) / reference
            proposed_values.append(proposed)
            baseline_values.append(reference)
            differences.append(difference)
            reductions.append(reduction)
            if abs(difference) <= TOLERANCE * max(1.0, abs(proposed), abs(reference)):
                ties += 1
            elif difference < 0:
                wins += 1
            else:
                losses += 1
        difference_ci = bootstrap_ci(differences)
        reduction_ci = bootstrap_ci(reductions)
        worst_index = min(range(len(tasks)), key=lambda index: (reductions[index], tasks[index]))
        raw.append(
            {
                "baseline_method": baseline,
                "metric": "c_plan",
                "task_count": len(tasks),
                "percent_defined_task_count": len(tasks),
                "proposed_task_mean": mean(proposed_values),
                "baseline_task_mean": mean(baseline_values),
                "mean_difference": mean(differences),
                "median_difference": median(differences),
                "difference_ci_low": difference_ci[0],
                "difference_ci_high": difference_ci[1],
                "mean_reduction_pct": mean(reductions),
                "median_reduction_pct": median(reductions),
                "reduction_ci_low": reduction_ci[0],
                "reduction_ci_high": reduction_ci[1],
                "ratio_of_sums_reduction_pct": (
                    100.0
                    * (sum(baseline_values) - sum(proposed_values))
                    / sum(baseline_values)
                ),
                "wins": wins,
                "ties": ties,
                "losses": losses,
                "sign_test_p_raw": exact_sign_p(wins, losses),
                "worst_task_id": tasks[worst_index],
                "worst_task_reduction_pct": reductions[worst_index],
                "proposed_positive_support_penalty_tasks": sum(
                    float(lookup[(task, PROPOSED)]["support_policy_penalty"]) != 0.0
                    for task in tasks
                ),
                "baseline_positive_support_penalty_tasks": sum(
                    float(lookup[(task, baseline)]["support_policy_penalty"]) != 0.0
                    for task in tasks
                ),
            }
        )
    ordered = sorted(
        raw,
        key=lambda row: (float(row["sign_test_p_raw"]), str(row["baseline_method"])),
    )
    running = 0.0
    for index, row in enumerate(ordered):
        running = max(
            running,
            min(1.0, (len(ordered) - index) * float(row["sign_test_p_raw"])),
        )
        row["sign_test_p_holm"] = running
    return raw


def compare_primary(expected: list[dict[str, object]]) -> None:
    stored = {
        (row["baseline_method"], row["metric"]): row
        for row in read_csv(CONFIRMATORY)
    }
    for row in expected:
        identity = (str(row["baseline_method"]), str(row["metric"]))
        actual = stored[identity]
        for field, value in row.items():
            if isinstance(value, (int, float)):
                if not close(actual[field], value):
                    raise ValueError(f"{identity}: {field} differs")
            elif actual[field] != value:
                raise ValueError(f"{identity}: {field} differs")


def audit() -> dict[str, object]:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    for section in ("authorized_inputs", "outputs"):
        for item in manifest[section]:
            if sha256_file(Path(item["path"])) != item["sha256"]:
                raise ValueError(f"manifest hash mismatch: {item['path']}")
    program = manifest["analysis_program"]
    if sha256_file(Path(program["path"])) != program["sha256"]:
        raise ValueError("analysis program changed after result generation")
    rows = task_aggregates()
    compare_task_rows(rows)
    primary = primary_summaries(rows)
    compare_primary(primary)
    cohort_counts = Counter(
        str(row["confirmatory_status"])
        for row in rows
        if row["method"] == PROPOSED
    )
    summary = {
        "audit_status": "passed",
        "independent_implementation": True,
        "route_result_sha256": sha256_file(ROUTES),
        "route_row_count": 13_765,
        "pattern_count": 2_753,
        "confirmatory_task_count": cohort_counts[CONFIRMATORY_LABEL],
        "supplementary_task_count": cohort_counts["excluded_prior_upstream_use"],
        "bootstrap_replicates_recomputed": BOOTSTRAP_REPLICATES,
        "matched_artifacts": [
            "task_metrics.csv",
            "confirmatory_summary.csv",
        ],
    }
    AUDIT_JSON.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    AUDIT_MD.write_text(
        "\n".join(
            [
                "# Track B analysis reproducibility audit",
                "",
                "- Audit status: **passed**",
                "- Independent raw-route aggregation: passed",
                "- Confirmatory independent units: 7 factory tasks",
                "- Historical supplementary tasks kept separate: 4",
                "- Bootstrap replicates independently recomputed: 100,000",
                "- Task metrics and both primary summaries matched",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return summary


if __name__ == "__main__":
    print(json.dumps(audit(), indent=2, ensure_ascii=False))
