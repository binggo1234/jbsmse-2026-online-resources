from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import random
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean, median, pstdev
from typing import Iterable, Sequence


ROOT = Path(__file__).resolve().parents[1]
ROUTE_DIR = ROOT / "outputs" / "holdout_route_experiment_v1"
AUTHORIZED_RESULTS = ROUTE_DIR / "route_results_cache_isolated.csv"
QUARANTINED_RESULTS = ROUTE_DIR / "route_results.csv"
ISOLATED_AUDIT = ROUTE_DIR / "route_experiment_isolated_audit.json"
ATOMIC_AUDIT = ROUTE_DIR / "proposed_atomic_span_audit.csv"
ANALYSIS_FREEZE = ROOT / "docs" / "ijamt_confirmatory_analysis_freeze_v1.md"
ANALYSIS_FREEZE_AMENDMENT = (
    ROOT / "docs" / "ijamt_confirmatory_analysis_freeze_v1_amendment.md"
)
DEFAULT_OUTPUT_DIR = ROOT / "outputs" / "holdout_confirmatory_analysis_v1"

AUTHORIZED_SHA256 = (
    "2df56a2d5700c1356bb78745e57d3eb69d87d6507222f48730b4a3b3e375aff2"
)
QUARANTINED_SHA256 = (
    "8c1bf0f5cfd76518af97869a9ed3409c8e82a94e095650c3b84cee1ff0e84aed"
)
STAGE7_COMMIT = "083d869ee132a8d6c8f4d12deacb4c78bcbdb2a0"
PROPOSED = "process_aware_beam_adaptive_polished"
METHODS = (
    PROPOSED,
    "process_aware_beam",
    "topology_process_aware",
    "process_local_search_multistart",
    "endpoint_aware_gtsp",
)
BASELINES = tuple(method for method in METHODS if method != PROPOSED)
PRIMARY_BASELINES = ("topology_process_aware", "endpoint_aware_gtsp")
SEEDS = ("seed_1000", "seed_1001", "seed_1002")
BOOTSTRAP_REPLICATES = 100_000
BOOTSTRAP_SEED = 20_260_726
NUMERICAL_TOLERANCE = 1e-9

SUM_METRICS = (
    "c_plan",
    "travel_mode_cost",
    "air_move_distance",
    "tool_event_count",
    "support_policy_penalty",
    "runtime_ms",
    "cutting_length",
    "hard_penalty",
)
COMPARISON_METRICS = (
    "c_plan",
    "travel_mode_cost",
    "air_move_distance",
    "tool_event_count",
    "support_policy_penalty",
    "runtime_ms",
    "cutting_length",
)
REQUIRED_NUMERIC_FIELDS = (
    "runtime_ms",
    "cutting_length",
    "travel_mode_cost",
    "air_move_distance",
    "pierce_count",
    "lift_count",
    "safe_lift_count",
    "process_tool_event_count",
    "stability_penalty",
    "hard_penalty",
)


@dataclass(frozen=True)
class PairSummary:
    baseline_method: str
    metric: str
    task_count: int
    percent_defined_task_count: int
    proposed_task_mean: float
    baseline_task_mean: float
    mean_difference: float
    median_difference: float
    difference_ci_low: float
    difference_ci_high: float
    mean_reduction_pct: float | None
    median_reduction_pct: float | None
    reduction_ci_low: float | None
    reduction_ci_high: float | None
    ratio_of_sums_reduction_pct: float | None
    wins: int
    ties: int
    losses: int
    sign_test_p_raw: float
    worst_task_id: str
    worst_task_reduction_pct: float | None


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Sequence[dict[str, object]], fields: Sequence[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def number(row: dict[str, str], field: str) -> float:
    value = float(row[field])
    if not math.isfinite(value):
        raise ValueError(f"non-finite {field} in job {row.get('job_id', '<unknown>')}")
    return value


def numerically_equal(left: float, right: float) -> bool:
    scale = max(1.0, abs(left), abs(right))
    return abs(left - right) <= NUMERICAL_TOLERANCE * scale


def reduction_pct(baseline: float, proposed: float) -> float | None:
    if numerically_equal(baseline, 0.0):
        return None
    return 100.0 * (baseline - proposed) / baseline


def percentile(values: Sequence[float], probability: float) -> float:
    if not values:
        raise ValueError("cannot calculate a percentile of an empty sample")
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def bootstrap_mean_ci(
    values: Sequence[float],
    *,
    replicates: int = BOOTSTRAP_REPLICATES,
    seed: int = BOOTSTRAP_SEED,
) -> tuple[float, float]:
    if not values:
        raise ValueError("cannot bootstrap an empty sample")
    rng = random.Random(seed)
    count = len(values)
    boot = [
        sum(values[rng.randrange(count)] for _ in range(count)) / count
        for _ in range(replicates)
    ]
    return percentile(boot, 0.025), percentile(boot, 0.975)


def exact_two_sided_sign_test(wins: int, losses: int) -> float:
    non_ties = wins + losses
    if non_ties == 0:
        return 1.0
    tail = min(wins, losses)
    probability = sum(math.comb(non_ties, i) for i in range(tail + 1))
    return min(1.0, 2.0 * probability / (2**non_ties))


def holm_adjust(p_values: dict[str, float]) -> dict[str, float]:
    ordered = sorted(p_values.items(), key=lambda item: (item[1], item[0]))
    adjusted: dict[str, float] = {}
    running = 0.0
    total = len(ordered)
    for rank, (name, p_value) in enumerate(ordered):
        candidate = min(1.0, (total - rank) * p_value)
        running = max(running, candidate)
        adjusted[name] = running
    return adjusted


def task_id(row: dict[str, str]) -> str:
    value = row["placement_method"]
    if not value.startswith("ZJ_"):
        raise ValueError(f"unexpected task identifier {value!r}")
    return value


def board_key(row: dict[str, str]) -> tuple[str, str, str, str]:
    return (
        task_id(row),
        row["seed"],
        row["placements_member"],
        row["board_id"],
    )


def row_metrics(row: dict[str, str]) -> dict[str, float]:
    cutting_length = number(row, "cutting_length")
    travel_mode_cost = number(row, "travel_mode_cost")
    tool_event_count = (
        number(row, "pierce_count")
        + number(row, "lift_count")
        + number(row, "safe_lift_count")
    )
    serialized_tool_events = number(row, "process_tool_event_count")
    if not numerically_equal(tool_event_count, serialized_tool_events):
        raise ValueError(f"tool-event mismatch in job {row['job_id']}")
    return {
        "c_plan": cutting_length + travel_mode_cost,
        "travel_mode_cost": travel_mode_cost,
        "air_move_distance": number(row, "air_move_distance"),
        "tool_event_count": tool_event_count,
        "support_policy_penalty": number(row, "stability_penalty"),
        "runtime_ms": number(row, "runtime_ms"),
        "cutting_length": cutting_length,
        "hard_penalty": number(row, "hard_penalty"),
    }


def validate_rows(rows: Sequence[dict[str, str]]) -> dict[str, object]:
    if len(rows) != 58_920:
        raise ValueError(f"expected 58920 route rows, found {len(rows)}")
    if {row["status"] for row in rows} != {"completed"}:
        raise ValueError("all route rows must have status=completed")
    if set(row["method"] for row in rows) != set(METHODS):
        raise ValueError("route method set does not match the five frozen methods")
    job_ids = [row["job_id"] for row in rows]
    if len(set(job_ids)) != len(job_ids):
        raise ValueError("route job IDs are not unique")

    for row in rows:
        for field in REQUIRED_NUMERIC_FIELDS:
            number(row, field)
        if row["seed"] not in SEEDS:
            raise ValueError(f"unexpected packing seed {row['seed']!r}")
        if not numerically_equal(number(row, "min_support_ratio"), 0.75):
            raise ValueError("support ratio differs from frozen rho=0.75")
        row_metrics(row)

    tasks = sorted({task_id(row) for row in rows})
    if len(tasks) != 20:
        raise ValueError(f"expected 20 factory tasks, found {len(tasks)}")
    seeds_by_task: dict[str, set[str]] = defaultdict(set)
    methods_by_board: dict[tuple[str, str, str, str], list[str]] = defaultdict(list)
    boards_by_group: dict[tuple[str, str, str], set[tuple[str, str, str, str]]] = (
        defaultdict(set)
    )
    for row in rows:
        current_task = task_id(row)
        seeds_by_task[current_task].add(row["seed"])
        key = board_key(row)
        methods_by_board[key].append(row["method"])
        boards_by_group[(current_task, row["seed"], row["method"])].add(key)

    if any(seeds != set(SEEDS) for seeds in seeds_by_task.values()):
        raise ValueError("every task must contain exactly the three frozen seeds")
    if len(methods_by_board) != 11_784:
        raise ValueError(f"expected 11784 boards, found {len(methods_by_board)}")
    for key, board_methods in methods_by_board.items():
        if Counter(board_methods) != Counter(METHODS):
            raise ValueError(f"board {key} does not contain each frozen method once")
    for current_task in tasks:
        for seed in SEEDS:
            reference = boards_by_group[(current_task, seed, METHODS[0])]
            for method in METHODS[1:]:
                if boards_by_group[(current_task, seed, method)] != reference:
                    raise ValueError(
                        f"board keys differ across methods for {current_task} {seed}"
                    )

    proposed_rows = [row for row in rows if row["method"] == PROPOSED]
    if any(not numerically_equal(number(row, "hard_penalty"), 0.0) for row in proposed_rows):
        raise ValueError("proposed route contains nonzero hard penalty")
    return {
        "route_row_count": len(rows),
        "unique_job_id_count": len(set(job_ids)),
        "task_count": len(tasks),
        "packing_seed_count": len(SEEDS),
        "board_count": len(methods_by_board),
        "method_count": len(METHODS),
        "tasks": tasks,
    }


def validate_provenance() -> dict[str, object]:
    authorized_sha = sha256_file(AUTHORIZED_RESULTS)
    if authorized_sha != AUTHORIZED_SHA256:
        raise ValueError(
            f"authorized v2 SHA mismatch: expected {AUTHORIZED_SHA256}, "
            f"found {authorized_sha}"
        )
    with ISOLATED_AUDIT.open(encoding="utf-8") as handle:
        audit = json.load(handle)
    if audit["audit_status"] != "passed":
        raise ValueError("isolated route audit has not passed")
    audit_sha = audit["files"]["isolated_route_results"]["sha256"]
    if audit_sha != AUTHORIZED_SHA256:
        raise ValueError("isolated audit points to a different route result")
    proposed_audit = audit["proposed_atomic_span_audit"]
    if proposed_audit["geometry_failure_count"] != 0:
        raise ValueError("proposed atomic audit contains geometry failures")
    if proposed_audit["missing_atomic_span_count"] != 0:
        raise ValueError("proposed atomic audit contains missing spans")
    if proposed_audit["repeated_atomic_span_count"] != 0:
        raise ValueError("proposed atomic audit contains repeated spans")
    if proposed_audit["unknown_cutting_unit_count"] != 0:
        raise ValueError("proposed atomic audit contains unknown cutting units")
    return {
        "authorized_result_sha256": authorized_sha,
        "quarantined_v1_sha256": QUARANTINED_SHA256,
        "isolated_audit_status": audit["audit_status"],
        "atomic_geometry_failure_count": proposed_audit["geometry_failure_count"],
        "atomic_missing_span_count": proposed_audit["missing_atomic_span_count"],
        "atomic_repeated_span_count": proposed_audit["repeated_atomic_span_count"],
        "atomic_unknown_unit_count": proposed_audit["unknown_cutting_unit_count"],
    }


def aggregate_task_seed(
    rows: Sequence[dict[str, str]],
) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[(task_id(row), row["seed"], row["method"])].append(row)
    output: list[dict[str, object]] = []
    for (current_task, seed, method), items in sorted(grouped.items()):
        totals = {metric: 0.0 for metric in SUM_METRICS}
        for row in items:
            metrics = row_metrics(row)
            for metric in SUM_METRICS:
                totals[metric] += metrics[metric]
        output.append(
            {
                "task_id": current_task,
                "packing_seed": seed,
                "method": method,
                "board_count": len(items),
                **totals,
            }
        )
    if len(output) != 20 * len(SEEDS) * len(METHODS):
        raise ValueError("task×seed aggregation is incomplete")
    return output


def aggregate_task(
    task_seed_rows: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in task_seed_rows:
        grouped[(str(row["task_id"]), str(row["method"]))].append(row)
    output: list[dict[str, object]] = []
    for (current_task, method), items in sorted(grouped.items()):
        if {str(row["packing_seed"]) for row in items} != set(SEEDS):
            raise ValueError(f"incomplete seeds for {current_task} {method}")
        result: dict[str, object] = {
            "task_id": current_task,
            "method": method,
            "seed_count": len(items),
            "board_count_mean": mean(float(row["board_count"]) for row in items),
            "board_count_min": min(int(row["board_count"]) for row in items),
            "board_count_max": max(int(row["board_count"]) for row in items),
        }
        for metric in SUM_METRICS:
            values = [float(row[metric]) for row in items]
            result[metric] = mean(values)
            result[f"{metric}_seed_sd"] = pstdev(values)
        output.append(result)
    if len(output) != 20 * len(METHODS):
        raise ValueError("task-level aggregation is incomplete")
    return output


def summarize_pair(
    task_rows: Sequence[dict[str, object]],
    baseline_method: str,
    metric: str,
    *,
    bootstrap_replicates: int = BOOTSTRAP_REPLICATES,
) -> tuple[PairSummary, list[dict[str, object]]]:
    lookup = {
        (str(row["task_id"]), str(row["method"])): row
        for row in task_rows
    }
    tasks = sorted({str(row["task_id"]) for row in task_rows})
    pairs: list[dict[str, object]] = []
    differences: list[float] = []
    reductions: list[float] = []
    wins = ties = losses = 0
    for current_task in tasks:
        proposed = float(lookup[(current_task, PROPOSED)][metric])
        baseline = float(lookup[(current_task, baseline_method)][metric])
        difference = proposed - baseline
        reduction = reduction_pct(baseline, proposed)
        if numerically_equal(proposed, baseline):
            outcome = "tie"
            ties += 1
        elif proposed < baseline:
            outcome = "win"
            wins += 1
        else:
            outcome = "loss"
            losses += 1
        differences.append(difference)
        if reduction is not None:
            reductions.append(reduction)
        pairs.append(
            {
                "task_id": current_task,
                "baseline_method": baseline_method,
                "metric": metric,
                "proposed_value": proposed,
                "baseline_value": baseline,
                "difference_proposed_minus_baseline": difference,
                "reduction_pct": reduction,
                "outcome": outcome,
            }
        )
    difference_ci = bootstrap_mean_ci(
        differences,
        replicates=bootstrap_replicates,
    )
    reduction_ci = (
        bootstrap_mean_ci(reductions, replicates=bootstrap_replicates)
        if reductions
        else (None, None)
    )
    proposed_values = [float(row["proposed_value"]) for row in pairs]
    baseline_values = [float(row["baseline_value"]) for row in pairs]
    total_reduction = reduction_pct(sum(baseline_values), sum(proposed_values))
    worst = min(
        pairs,
        key=lambda row: (
            float("inf") if row["reduction_pct"] is None else float(row["reduction_pct"]),
            str(row["task_id"]),
        ),
    )
    summary = PairSummary(
        baseline_method=baseline_method,
        metric=metric,
        task_count=len(tasks),
        percent_defined_task_count=len(reductions),
        proposed_task_mean=mean(proposed_values),
        baseline_task_mean=mean(baseline_values),
        mean_difference=mean(differences),
        median_difference=median(differences),
        difference_ci_low=difference_ci[0],
        difference_ci_high=difference_ci[1],
        mean_reduction_pct=mean(reductions) if reductions else None,
        median_reduction_pct=median(reductions) if reductions else None,
        reduction_ci_low=reduction_ci[0],
        reduction_ci_high=reduction_ci[1],
        ratio_of_sums_reduction_pct=total_reduction,
        wins=wins,
        ties=ties,
        losses=losses,
        sign_test_p_raw=exact_two_sided_sign_test(wins, losses),
        worst_task_id=str(worst["task_id"]),
        worst_task_reduction_pct=(
            None
            if worst["reduction_pct"] is None
            else float(worst["reduction_pct"])
        ),
    )
    return summary, pairs


def build_summaries(
    task_rows: Sequence[dict[str, object]],
    *,
    bootstrap_replicates: int = BOOTSTRAP_REPLICATES,
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
]:
    summaries: dict[tuple[str, str], PairSummary] = {}
    pair_rows: list[dict[str, object]] = []
    for baseline in BASELINES:
        for metric in COMPARISON_METRICS:
            summary, pairs = summarize_pair(
                task_rows,
                baseline,
                metric,
                bootstrap_replicates=bootstrap_replicates,
            )
            summaries[(baseline, metric)] = summary
            pair_rows.extend(pairs)

    primary_p = {
        baseline: summaries[(baseline, "c_plan")].sign_test_p_raw
        for baseline in PRIMARY_BASELINES
    }
    adjusted = holm_adjust(primary_p)
    task_lookup = {
        (str(row["task_id"]), str(row["method"])): row
        for row in task_rows
    }
    tasks = sorted({str(row["task_id"]) for row in task_rows})
    confirmatory: list[dict[str, object]] = []
    for baseline in PRIMARY_BASELINES:
        row = asdict(summaries[(baseline, "c_plan")])
        proposed_support = [
            float(task_lookup[(current_task, PROPOSED)]["support_policy_penalty"])
            for current_task in tasks
        ]
        baseline_support = [
            float(task_lookup[(current_task, baseline)]["support_policy_penalty"])
            for current_task in tasks
        ]
        row.update(
            {
                "sign_test_p_holm": adjusted[baseline],
                "proposed_support_penalty_task_mean": mean(proposed_support),
                "baseline_support_penalty_task_mean": mean(baseline_support),
                "proposed_positive_support_penalty_tasks": sum(
                    not numerically_equal(value, 0.0) for value in proposed_support
                ),
                "baseline_positive_support_penalty_tasks": sum(
                    not numerically_equal(value, 0.0) for value in baseline_support
                ),
            }
        )
        confirmatory.append(row)
    secondary = [
        asdict(summaries[(baseline, metric)])
        for baseline in BASELINES
        for metric in COMPARISON_METRICS
    ]
    return confirmatory, secondary, pair_rows


def build_method_summary(
    task_rows: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in task_rows:
        grouped[str(row["method"])].append(row)
    output: list[dict[str, object]] = []
    for method in METHODS:
        items = grouped[method]
        row: dict[str, object] = {
            "method": method,
            "task_count": len(items),
        }
        for metric in COMPARISON_METRICS:
            values = [float(item[metric]) for item in items]
            row[f"{metric}_task_mean"] = mean(values)
            row[f"{metric}_task_median"] = median(values)
            row[f"{metric}_task_min"] = min(values)
            row[f"{metric}_task_max"] = max(values)
        row["positive_support_penalty_tasks"] = sum(
            not numerically_equal(float(item["support_policy_penalty"]), 0.0)
            for item in items
        )
        output.append(row)
    return output


def build_seed_sensitivity(
    task_seed_rows: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in task_seed_rows:
        grouped[(str(row["task_id"]), str(row["method"]))].append(row)
    output: list[dict[str, object]] = []
    for method in METHODS:
        for metric in COMPARISON_METRICS:
            task_records: list[tuple[str, float, float, float | None]] = []
            for (current_task, current_method), items in sorted(grouped.items()):
                if current_method != method:
                    continue
                values = [float(item[metric]) for item in items]
                task_mean = mean(values)
                seed_sd = pstdev(values)
                seed_cv = (
                    None
                    if numerically_equal(task_mean, 0.0)
                    else 100.0 * seed_sd / abs(task_mean)
                )
                task_records.append((current_task, task_mean, seed_sd, seed_cv))
            relative = [
                (current_task, seed_cv)
                for current_task, _, _, seed_cv in task_records
                if seed_cv is not None
            ]
            worst_task = (
                max(relative, key=lambda item: (item[1], item[0]))[0]
                if relative
                else ""
            )
            relative_values = [value for _, value in relative]
            output.append(
                {
                    "method": method,
                    "metric": metric,
                    "task_count": len(task_records),
                    "relative_task_count": len(relative_values),
                    "mean_task_value": mean(item[1] for item in task_records),
                    "mean_within_task_seed_sd": mean(
                        item[2] for item in task_records
                    ),
                    "median_within_task_seed_sd": median(
                        item[2] for item in task_records
                    ),
                    "mean_within_task_seed_cv_pct": (
                        mean(relative_values) if relative_values else None
                    ),
                    "median_within_task_seed_cv_pct": (
                        median(relative_values) if relative_values else None
                    ),
                    "max_within_task_seed_cv_pct": (
                        max(relative_values) if relative_values else None
                    ),
                    "worst_task_id": worst_task,
                }
            )
    return output


def format_markdown(
    validation: dict[str, object],
    confirmatory: Sequence[dict[str, object]],
) -> str:
    lines = [
        "# Holdout confirmatory analysis audit",
        "",
        "- Analysis status: **passed**",
        f"- Independent factory tasks: {validation['task_count']}",
        f"- Nested packing seeds per task: {validation['packing_seed_count']}",
        f"- Boards: {validation['board_count']}",
        f"- Route-method rows: {validation['route_row_count']}",
        "- Authorized route input: cache-isolated v2 only",
        "",
        "## Confirmatory task-level results",
        "",
        "| Baseline | Mean task reduction in C_plan | 95% task-bootstrap CI | W/T/L | Exact sign p | Holm p | Proposed/baseline positive support tasks |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in confirmatory:
        lines.append(
            "| {baseline_method} | {mean_reduction_pct:.3f}% | "
            "[{reduction_ci_low:.3f}, {reduction_ci_high:.3f}] | "
            "{wins}/{ties}/{losses} | {sign_test_p_raw:.6g} | "
            "{sign_test_p_holm:.6g} | "
            "{proposed_positive_support_penalty_tasks}/"
            "{baseline_positive_support_penalty_tasks} |".format(**row)
        )
    lines.extend(
        [
            "",
            "The bootstrap and sign test use the 20 factory tasks as the only",
            "independent units. Boards and packing seeds are not counted as",
            "independent replicates.",
            "",
        ]
    )
    return "\n".join(lines)


def run_analysis(
    output_dir: Path = DEFAULT_OUTPUT_DIR,
    *,
    bootstrap_replicates: int = BOOTSTRAP_REPLICATES,
) -> dict[str, object]:
    provenance = validate_provenance()
    rows = read_csv(AUTHORIZED_RESULTS)
    validation = validate_rows(rows)
    task_seed_rows = aggregate_task_seed(rows)
    task_rows = aggregate_task(task_seed_rows)
    confirmatory, secondary, pair_rows = build_summaries(
        task_rows,
        bootstrap_replicates=bootstrap_replicates,
    )
    method_summary = build_method_summary(task_rows)
    seed_sensitivity = build_seed_sensitivity(task_seed_rows)

    output_dir.mkdir(parents=True, exist_ok=True)
    task_seed_path = output_dir / "task_seed_metrics.csv"
    task_path = output_dir / "task_metrics.csv"
    pair_path = output_dir / "pairwise_task_comparisons.csv"
    confirmatory_path = output_dir / "confirmatory_summary.csv"
    secondary_path = output_dir / "secondary_summary.csv"
    method_summary_path = output_dir / "method_summary.csv"
    seed_sensitivity_path = output_dir / "seed_sensitivity.csv"
    audit_path = output_dir / "analysis_audit.json"
    report_path = output_dir / "analysis_audit.md"
    manifest_path = output_dir / "analysis_manifest.json"

    task_seed_fields = [
        "task_id",
        "packing_seed",
        "method",
        "board_count",
        *SUM_METRICS,
    ]
    task_fields = [
        "task_id",
        "method",
        "seed_count",
        "board_count_mean",
        "board_count_min",
        "board_count_max",
        *[
            field
            for metric in SUM_METRICS
            for field in (metric, f"{metric}_seed_sd")
        ],
    ]
    pair_fields = [
        "task_id",
        "baseline_method",
        "metric",
        "proposed_value",
        "baseline_value",
        "difference_proposed_minus_baseline",
        "reduction_pct",
        "outcome",
    ]
    confirmatory_fields = list(confirmatory[0])
    secondary_fields = list(secondary[0])
    method_summary_fields = list(method_summary[0])
    seed_sensitivity_fields = list(seed_sensitivity[0])
    write_csv(task_seed_path, task_seed_rows, task_seed_fields)
    write_csv(task_path, task_rows, task_fields)
    write_csv(pair_path, pair_rows, pair_fields)
    write_csv(confirmatory_path, confirmatory, confirmatory_fields)
    write_csv(secondary_path, secondary, secondary_fields)
    write_csv(method_summary_path, method_summary, method_summary_fields)
    write_csv(seed_sensitivity_path, seed_sensitivity, seed_sensitivity_fields)

    audit = {
        "analysis_status": "passed",
        "aggregation_order": [
            "sum boards within task x packing_seed",
            "equal mean of seeds 1000, 1001, 1002",
            "equal-weight analysis of 20 factory tasks",
        ],
        "provenance": provenance,
        "validation": validation,
        "confirmatory_comparisons": confirmatory,
    }
    audit_path.write_text(
        json.dumps(audit, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    report_path.write_text(
        format_markdown(validation, confirmatory),
        encoding="utf-8",
    )

    output_files = [
        task_seed_path,
        task_path,
        pair_path,
        confirmatory_path,
        secondary_path,
        method_summary_path,
        seed_sensitivity_path,
        audit_path,
        report_path,
    ]
    manifest = {
        "analysis_program": {
            "path": str(Path(__file__).resolve()),
            "sha256": sha256_file(Path(__file__).resolve()),
        },
        "software": {
            "python_version": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "platform": platform.platform(),
        },
        "analysis_freeze": {
            "path": str(ANALYSIS_FREEZE),
            "sha256": sha256_file(ANALYSIS_FREEZE),
        },
        "analysis_freeze_amendment": {
            "path": str(ANALYSIS_FREEZE_AMENDMENT),
            "sha256": sha256_file(ANALYSIS_FREEZE_AMENDMENT),
        },
        "stage7_commit": STAGE7_COMMIT,
        "authorized_inputs": [
            {
                "path": str(AUTHORIZED_RESULTS),
                "sha256": sha256_file(AUTHORIZED_RESULTS),
            },
            {
                "path": str(ISOLATED_AUDIT),
                "sha256": sha256_file(ISOLATED_AUDIT),
            },
            {
                "path": str(ATOMIC_AUDIT),
                "sha256": sha256_file(ATOMIC_AUDIT),
            },
        ],
        "forbidden_input_identity": {
            "path": str(QUARANTINED_RESULTS),
            "sha256": QUARANTINED_SHA256,
            "used": False,
        },
        "parameters": {
            "independent_unit": "factory_task",
            "bootstrap_replicates": bootstrap_replicates,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "numerical_tolerance": NUMERICAL_TOLERANCE,
            "c_plan_formula": "cutting_length + travel_mode_cost",
        },
        "outputs": [
            {"path": str(path), "sha256": sha256_file(path)}
            for path in output_files
        ],
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return audit


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen task-level IJAMT holdout analysis."
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Destination for deterministic analysis artifacts.",
    )
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = parse_args(argv)
    audit = run_analysis(args.output_dir)
    print(json.dumps(audit["validation"], indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
