from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

from scripts.prepare_nc_kinematic_evaluation import (
    FREEZE_MANIFEST,
    FULL_JOBS,
    sha256_file,
)
from scripts.run_nc_kinematic_evaluation import (
    FULL_OUTPUT,
    FULL_SHARD_ROOT,
    connect_database,
    export_results,
    read_csv,
    select_shard_jobs,
    verify_freeze,
)


def shard_directory(shard_index: int, shard_count: int) -> Path:
    return FULL_SHARD_ROOT / f"shard_{shard_index:02d}_of_{shard_count:02d}"


def validate_shard(
    path: Path,
    *,
    expected_job_ids: set[str],
    expected_scenarios: int,
) -> dict[str, object]:
    database = path / "results.sqlite"
    if not database.is_file():
        raise FileNotFoundError(database)
    with sqlite3.connect(f"file:{database}?mode=ro", uri=True) as connection:
        actual_job_ids = {
            str(row[0]) for row in connection.execute("SELECT job_id FROM job_results")
        }
        status_counts = dict(
            connection.execute(
                "SELECT status, COUNT(*) FROM job_results GROUP BY status"
            ).fetchall()
        )
        scenario_rows = connection.execute(
            "SELECT COUNT(*) FROM scenario_times"
        ).fetchone()[0]
        malformed = connection.execute(
            """
            SELECT COUNT(*) FROM (
                SELECT job_id, COUNT(*) AS n
                FROM scenario_times
                GROUP BY job_id
                HAVING n != ?
            )
            """,
            (expected_scenarios,),
        ).fetchone()[0]
        audit_failures = connection.execute(
            "SELECT COUNT(*) FROM job_results WHERE audit_passed != 1"
        ).fetchone()[0]
        reference_mismatches = connection.execute(
            "SELECT COUNT(*) FROM job_results WHERE reference_match != 1"
        ).fetchone()[0]
    passed = (
        actual_job_ids == expected_job_ids
        and status_counts == {"completed": len(expected_job_ids)}
        and scenario_rows == len(expected_job_ids) * expected_scenarios
        and malformed == 0
        and audit_failures == 0
        and reference_mismatches == 0
    )
    return {
        "passed": passed,
        "path": str(path),
        "database_sha256": sha256_file(database),
        "expected_job_count": len(expected_job_ids),
        "actual_job_count": len(actual_job_ids),
        "missing_job_count": len(expected_job_ids - actual_job_ids),
        "unexpected_job_count": len(actual_job_ids - expected_job_ids),
        "status_counts": status_counts,
        "scenario_row_count": scenario_rows,
        "malformed_scenario_jobs": malformed,
        "nc_audit_failures": audit_failures,
        "route_reference_mismatches": reference_mismatches,
    }


def merge(shard_count: int) -> Path:
    if shard_count <= 1:
        raise ValueError("shard_count must exceed one")
    manifest = verify_freeze()
    all_jobs = read_csv(FULL_JOBS)
    scenario_count = len(manifest["kinematic_scenarios"])
    expected_by_shard = [
        {
            row["job_id"]
            for row in select_shard_jobs(
                all_jobs,
                shard_index=shard_index,
                shard_count=shard_count,
            )
        }
        for shard_index in range(shard_count)
    ]
    union = set().union(*expected_by_shard)
    if len(union) != len(all_jobs):
        raise RuntimeError("shard union does not cover the frozen job list")
    if sum(len(rows) for rows in expected_by_shard) != len(union):
        raise RuntimeError("shard job sets overlap")

    shard_audits = []
    for shard_index, expected_job_ids in enumerate(expected_by_shard):
        audit = validate_shard(
            shard_directory(shard_index, shard_count),
            expected_job_ids=expected_job_ids,
            expected_scenarios=scenario_count,
        )
        shard_audits.append(audit)
        if not audit["passed"]:
            raise RuntimeError(
                f"shard {shard_index} failed validation; merge not started"
            )

    if FULL_OUTPUT.exists():
        raise FileExistsError(f"refusing to overwrite merge target: {FULL_OUTPUT}")
    FULL_OUTPUT.mkdir(parents=True)
    target = connect_database(FULL_OUTPUT / "results.sqlite")
    try:
        for shard_index in range(shard_count):
            database = shard_directory(shard_index, shard_count) / "results.sqlite"
            target.execute("ATTACH DATABASE ? AS shard", (str(database),))
            with target:
                target.execute("INSERT INTO job_results SELECT * FROM shard.job_results")
                target.execute(
                    "INSERT INTO scenario_times SELECT * FROM shard.scenario_times"
                )
            target.execute("DETACH DATABASE shard")
        job_count = target.execute("SELECT COUNT(*) FROM job_results").fetchone()[0]
        scenario_rows = target.execute(
            "SELECT COUNT(*) FROM scenario_times"
        ).fetchone()[0]
        if job_count != len(all_jobs):
            raise RuntimeError("merged job count differs from frozen list")
        if scenario_rows != len(all_jobs) * scenario_count:
            raise RuntimeError("merged scenario row count differs from freeze")
        export_results(target, FULL_OUTPUT)
        target.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    finally:
        target.close()

    merge_report = {
        "passed": True,
        "freeze_manifest": str(FREEZE_MANIFEST.resolve()),
        "freeze_manifest_sha256": sha256_file(FREEZE_MANIFEST),
        "shard_count": shard_count,
        "shards": shard_audits,
        "merged_database": str((FULL_OUTPUT / "results.sqlite").resolve()),
        "merged_job_count": len(all_jobs),
        "merged_scenario_row_count": len(all_jobs) * scenario_count,
        "scope": manifest["scope"],
    }
    report_path = FULL_OUTPUT / "merge_audit.json"
    report_path.write_text(
        json.dumps(merge_report, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    run_summary = {
        "freeze_manifest": str(FREEZE_MANIFEST.resolve()),
        "freeze_manifest_sha256": sha256_file(FREEZE_MANIFEST),
        "jobs_file": str(FULL_JOBS.resolve()),
        "jobs_sha256": sha256_file(FULL_JOBS),
        "database": str((FULL_OUTPUT / "results.sqlite").resolve()),
        "job_counts": {"completed": len(all_jobs)},
        "scenario_row_count": len(all_jobs) * scenario_count,
        "retained_gcode": False,
        "execution": f"{shard_count} deterministic board-level shards",
        "scope": manifest["scope"],
    }
    (FULL_OUTPUT / "run_summary.json").write_text(
        json.dumps(run_summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"merged {len(all_jobs)} jobs from {shard_count} shards")
    print(FULL_OUTPUT)
    return FULL_OUTPUT


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shard-count", type=int, required=True)
    args = parser.parse_args()
    merge(args.shard_count)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
