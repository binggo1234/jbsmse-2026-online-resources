from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, fields, replace
from pathlib import Path
from time import perf_counter


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import scripts.run_holdout_routes as stage7_run


PREFLIGHT_DIR = ROOT / "outputs" / "factory_xml_preflight_v1"
PREFLIGHT_MANIFEST = PREFLIGHT_DIR / "preflight_manifest.json"
PATTERNS = PREFLIGHT_DIR / "frozen_pattern_manifest.csv"
LAYOUT_ARCHIVE = PREFLIGHT_DIR / "track_b_original_layouts.zip"
FREEZE_SPEC = ROOT / "docs" / "track_b_xml_coordinate_freeze_v1.md"
OUTPUT_DIR = ROOT / "outputs" / "factory_xml_routes_v1"
FROZEN_JOBS = OUTPUT_DIR / "frozen_route_jobs.csv"
RUN_MANIFEST = OUTPUT_DIR / "route_run_manifest.json"
RESULTS = OUTPUT_DIR / "route_results_cache_isolated.csv"
AUDIT_JSON = OUTPUT_DIR / "route_audit.json"
AUDIT_MD = OUTPUT_DIR / "route_audit.md"

METHODS = stage7_run.METHODS
PROPOSED = METHODS[0]
SCHEDULE_SEED = 20_260_729
TIMEOUT_SECONDS = 30.0


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(
    path: Path,
    fieldnames: tuple[str, ...] | list[str],
    rows: list[dict[str, object]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def append_csv(path: Path, fieldnames: tuple[str, ...], row: dict[str, object]) -> None:
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def verify_preflight() -> dict:
    manifest = json.loads(PREFLIGHT_MANIFEST.read_text(encoding="utf-8"))
    if manifest["preflight_status"] != "passed":
        raise ValueError("Track B XML preflight has not passed")
    expected_archive = next(
        item["sha256"]
        for item in manifest["outputs"]
        if item["path"].endswith("track_b_original_layouts.zip")
    )
    if stage7_run.sha256_file(LAYOUT_ARCHIVE) != expected_archive:
        raise ValueError("Track B layout archive SHA mismatch")
    if len(read_csv(PATTERNS)) != manifest["counts"]["eligible_pattern_count"]:
        raise ValueError("frozen Pattern manifest count mismatch")
    return manifest


def make_jobs(patterns: list[dict[str, str]]) -> list[dict[str, object]]:
    ordered_patterns = sorted(
        patterns,
        key=lambda row: stage7_run.stable_hash(
            SCHEDULE_SEED, "pattern", row["pattern_id"]
        ),
    )
    jobs: list[dict[str, object]] = []
    for pattern in ordered_patterns:
        ordered_methods = sorted(
            METHODS,
            key=lambda method: stage7_run.stable_hash(
                SCHEDULE_SEED, "method", pattern["pattern_id"], method
            ),
        )
        for method in ordered_methods:
            jobs.append(
                {
                    "job_id": stage7_run.stable_hash(
                        "track-b-route-v1", pattern["pattern_id"], method
                    )[:20],
                    "schedule_order": len(jobs) + 1,
                    "task_id": pattern["task_id"],
                    "confirmatory_status": pattern["confirmatory_status"],
                    "pattern_id": pattern["pattern_id"],
                    "pattern_sequence": pattern["pattern_sequence"],
                    "placements_member": pattern["placements_member"],
                    "board_id": "1",
                    "rectangle_count": pattern["workpiece_count"],
                    "method": method,
                }
            )
    return jobs


def freeze() -> dict:
    preflight = verify_preflight()
    patterns = read_csv(PATTERNS)
    jobs = make_jobs(patterns)
    if len(jobs) != 2_753 * len(METHODS):
        raise ValueError(f"unexpected Track B job count: {len(jobs)}")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(FROZEN_JOBS, list(jobs[0]), jobs)
    manifest = {
        "freeze_status": "frozen_before_route_quality_results",
        "track": "B_factory_original_xml_coordinates",
        "independent_unit": "factory_task",
        "confirmatory_holdout_task_count": 7,
        "supplementary_historical_task_count": 4,
        "pattern_count": len(patterns),
        "method_count": len(METHODS),
        "route_job_count": len(jobs),
        "methods": list(METHODS),
        "schedule_seed": SCHEDULE_SEED,
        "timeout_seconds": TIMEOUT_SECONDS,
        "cache_isolation": "clear detour cache immediately before every method",
        "coordinate_convention": preflight["coordinate_convention"],
        "method_parameters": {
            "algorithm_seed": stage7_run.ALGORITHM_SEED,
            "support_policy": "all_edges",
            "min_support_count": 1,
            "min_support_ratio": 0.75,
            "min_area_normalized_support": 0.0,
            "adjacency_support_weight": 1.0,
            "repeat_cut_policy": "hard",
            "tool_event_gate_enabled": True,
            "tool_event_min_travel_saving": 25.0,
            "tool_event_min_travel_saving_ratio": 0.0,
            "tool_event_min_machining_saving": 1e-9,
        },
        "software": {
            "stage7_commit": stage7_run.git_commit(stage7_run.STAGE7_ROOT),
            "runner_path": str(Path(__file__).resolve()),
            "runner_sha256": stage7_run.sha256_file(Path(__file__).resolve()),
        },
        "inputs": {
            "freeze_spec": {
                "path": str(FREEZE_SPEC),
                "sha256": stage7_run.sha256_file(FREEZE_SPEC),
            },
            "preflight_manifest": {
                "path": str(PREFLIGHT_MANIFEST),
                "sha256": stage7_run.sha256_file(PREFLIGHT_MANIFEST),
            },
            "pattern_manifest": {
                "path": str(PATTERNS),
                "sha256": stage7_run.sha256_file(PATTERNS),
            },
            "layout_archive": {
                "path": str(LAYOUT_ARCHIVE),
                "sha256": stage7_run.sha256_file(LAYOUT_ARCHIVE),
            },
            "frozen_jobs": {
                "path": str(FROZEN_JOBS),
                "sha256": stage7_run.sha256_file(FROZEN_JOBS),
            },
        },
    }
    RUN_MANIFEST.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return manifest


def verify_freeze() -> dict:
    manifest = json.loads(RUN_MANIFEST.read_text(encoding="utf-8"))
    for item in manifest["inputs"].values():
        if stage7_run.sha256_file(Path(item["path"])) != item["sha256"]:
            raise ValueError(f"frozen Track B input changed: {item['path']}")
    if stage7_run.sha256_file(Path(__file__).resolve()) != manifest["software"][
        "runner_sha256"
    ]:
        raise ValueError("Track B route runner changed after schedule freeze")
    if stage7_run.git_commit(stage7_run.STAGE7_ROOT) != manifest["software"][
        "stage7_commit"
    ]:
        raise ValueError("Stage7 commit changed after Track B schedule freeze")
    return manifest


def iter_patterns(jobs: list[dict[str, str]], stage7):
    from cnc_cutting.models import Point

    args = stage7_run.stage7_args()
    tool_event_gate = stage7.build_tool_event_gate(args)
    by_member: dict[str, list[dict[str, str]]] = defaultdict(list)
    for job in jobs:
        by_member[job["placements_member"]].append(job)
    for member_jobs in by_member.values():
        member = member_jobs[0]["placements_member"]
        config = stage7.load_config(LAYOUT_ARCHIVE, placements_member=member)
        tool = replace(
            stage7.tool_config(config),
            trim_margin=0.0,
            centerline_boundary_margin=0.0,
            start_point=Point(0.0, 0.0),
        )
        layouts = stage7.load_layouts(
            LAYOUT_ARCHIVE,
            placements_member=member,
            board_ids=("1",),
            placement_geometry_mode=stage7.placement_geometry_stored,
            tool_diameter=tool.tool_diameter,
        )
        if len(layouts) != 1:
            raise ValueError(f"expected one layout for {member}")
        layout = layouts[0]
        panel = stage7.Panel(
            layout.panel_id,
            layout.panel_width,
            layout.panel_height,
        )
        process_model = stage7.build_process_model(
            layout,
            args,
            tool=tool,
            max_collinear_gap=tool.min_channel_width,
        )
        units = stage7.build_candidate_cutting_units(
            layout,
            tool,
            max_collinear_gap=tool.min_channel_width,
        )
        yield (
            member_jobs,
            layout,
            panel,
            tool,
            process_model,
            tool_event_gate,
            units,
        )


def run(resume: bool) -> None:
    manifest = verify_freeze()
    stage7 = stage7_run._load_stage7()
    from cnc_cutting.travel import clear_detour_cache

    output_fields = stage7_run.FULL_PREFIX_FIELDS + tuple(
        field.name for field in fields(stage7.BatchRouteRow)
    )
    jobs = read_csv(FROZEN_JOBS)
    completed = (
        {row["job_id"] for row in read_csv(RESULTS)}
        if resume and RESULTS.exists()
        else set()
    )
    if not resume and RESULTS.exists():
        raise ValueError(
            "Track B result already exists; use --resume to preserve completed jobs"
        )
    args = stage7_run.stage7_args()
    total = len(jobs)
    for (
        pattern_jobs,
        layout,
        panel,
        tool,
        process_model,
        tool_event_gate,
        units,
    ) in iter_patterns(jobs, stage7):
        methods = tuple(job["method"] for job in pattern_jobs)
        specs = {
            spec.method: spec
            for spec in stage7.build_planners(
                methods,
                units,
                panel,
                tool,
                process_model,
                tool_event_gate,
                len(layout.rectangles),
                args.repeat_cut_policy,
                algorithm_seed=args.algorithm_seed,
            )
        }
        for job in pattern_jobs:
            if job["job_id"] in completed:
                continue
            clear_detour_cache()
            started = perf_counter()
            status = "completed"
            error_class = ""
            error_message = ""
            values: dict[str, object] = {}
            try:
                with stage7.task_timeout(float(manifest["timeout_seconds"])):
                    result = stage7.run_plan(
                        LAYOUT_ARCHIVE,
                        job["placements_member"],
                        job["board_id"],
                        args.support_policy,
                        args.min_support_count,
                        args.min_support_ratio,
                        args.min_area_normalized_support,
                        args.adjacency_support_weight,
                        tool_event_gate.enabled,
                        tool_event_gate.min_travel_saving_per_extra_event,
                        tool_event_gate.min_travel_saving_ratio_per_extra_event,
                        tool_event_gate.min_machining_saving,
                        args.repeat_cut_policy,
                        specs[job["method"]],
                        layout,
                        panel,
                        tool,
                        units,
                        process_model,
                    )
                values = asdict(result)
            except stage7.TaskTimeoutError as exc:
                status = "timed_out"
                error_class = type(exc).__name__
                error_message = str(exc)
            except Exception as exc:  # pragma: no cover - persisted for audit
                status = "failed"
                error_class = type(exc).__name__
                error_message = str(exc)[:500]
            row: dict[str, object] = {
                "job_id": job["job_id"],
                "schedule_order": job["schedule_order"],
                "status": status,
                "error_class": error_class,
                "error_message": error_message,
            }
            for field in output_fields[len(stage7_run.FULL_PREFIX_FIELDS) :]:
                row[field] = values.get(field, "")
            append_csv(RESULTS, output_fields, row)
            completed.add(job["job_id"])
            if len(completed) % 100 == 0 or len(completed) == total:
                elapsed_ms = (perf_counter() - started) * 1000.0
                print(
                    f"track-b route {len(completed)}/{total} "
                    f"last={job['method']} {status} {elapsed_ms:.3f} ms",
                    flush=True,
                )


def audit() -> dict:
    manifest = verify_freeze()
    rows = read_csv(RESULTS)
    jobs = read_csv(FROZEN_JOBS)
    status_counts = Counter(row["status"] for row in rows)
    methods = Counter(row["method"] for row in rows)
    pattern_methods: dict[tuple[str, str], set[str]] = defaultdict(set)
    for row in rows:
        pattern_methods[(row["placements_member"], row["board_id"])].add(
            row["method"]
        )
    proposed = [row for row in rows if row["method"] == PROPOSED]
    proposed_hard_failures = sum(
        row["status"] != "completed" or float(row["hard_penalty"] or "inf") != 0.0
        for row in proposed
    )
    summary = {
        "audit_status": "passed",
        "route_job_count": len(rows),
        "unique_job_id_count": len({row["job_id"] for row in rows}),
        "status_counts": dict(status_counts),
        "method_counts": dict(methods),
        "pattern_count": len(pattern_methods),
        "patterns_with_all_methods": sum(
            value == set(METHODS) for value in pattern_methods.values()
        ),
        "proposed_route_count": len(proposed),
        "proposed_serialized_hard_failure_count": proposed_hard_failures,
        "files": {
            "results": {
                "path": str(RESULTS),
                "sha256": stage7_run.sha256_file(RESULTS),
            },
            "frozen_jobs": {
                "path": str(FROZEN_JOBS),
                "sha256": stage7_run.sha256_file(FROZEN_JOBS),
            },
        },
    }
    passed = (
        len(rows) == len(jobs) == int(manifest["route_job_count"])
        and len({row["job_id"] for row in rows}) == len(rows)
        and status_counts == Counter({"completed": len(rows)})
        and methods == Counter(
            {method: int(manifest["pattern_count"]) for method in METHODS}
        )
        and len(pattern_methods) == int(manifest["pattern_count"])
        and all(value == set(METHODS) for value in pattern_methods.values())
        and len(proposed) == int(manifest["pattern_count"])
        and proposed_hard_failures == 0
    )
    summary["audit_status"] = "passed" if passed else "failed"
    AUDIT_JSON.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    AUDIT_MD.write_text(
        "\n".join(
            [
                "# Track B route audit",
                "",
                f"- Audit status: **{summary['audit_status']}**",
                f"- Completed route jobs: {status_counts.get('completed', 0)}",
                f"- Patterns with all methods: {summary['patterns_with_all_methods']}",
                f"- Proposed serialized hard failures: {proposed_hard_failures}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    if not passed:
        raise ValueError("Track B route audit failed")
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("freeze")
    route = commands.add_parser("run")
    route.add_argument("--resume", action="store_true")
    commands.add_parser("audit")
    commands.add_parser("verify")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.command == "freeze":
        result = freeze()
        print(json.dumps({key: result[key] for key in (
            "pattern_count", "method_count", "route_job_count"
        )}, indent=2))
    elif args.command == "run":
        run(args.resume)
    elif args.command == "audit":
        print(json.dumps(audit(), indent=2, ensure_ascii=False))
    else:
        result = verify_freeze()
        print(f"verified {result['route_job_count']} frozen Track B route jobs")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
