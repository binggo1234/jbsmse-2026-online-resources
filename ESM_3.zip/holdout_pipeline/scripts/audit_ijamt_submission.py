from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAPER_DIR = ROOT / "outputs" / "ijamt_submission_working_v27_figure_system"
EVIDENCE_MANIFEST = (
    ROOT / "outputs" / "ijamt_evidence_package_v1" / "final_evidence_manifest.json"
)
TRACK_A = ROOT / "outputs" / "holdout_confirmatory_analysis_v1"
TRACK_B = ROOT / "outputs" / "factory_xml_analysis_v1"
NC_RESULTS = ROOT / "outputs" / "nc_kinematic_evaluation_v2" / "full"
PUBLIC_NC = ROOT / "outputs" / "public_nc_repro_examples_v1"
VERICUT = (
    ROOT / "outputs" / "IJAMT_VERICUT_formal_rep_v3_submission_20260731"
)
VERICUT_ZIP = (
    ROOT / "outputs" / "IJAMT_VERICUT_formal_rep_v3_submission_20260731.zip"
)
OUTPUT_DIR = ROOT / "outputs" / "ijamt_submission_audit_v27"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def find_row(rows: list[dict[str, str]], baseline: str) -> dict[str, str]:
    return next(
        row
        for row in rows
        if row["baseline_method"] == baseline and row["metric"] == "c_plan"
    )


def approximate_word_count(text: str) -> int:
    text = re.sub(r"\\\([^)]*\\\)", " TOKEN ", text)
    text = re.sub(r"\\[A-Za-z]+", " ", text)
    return len(re.findall(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*", text))


def main() -> int:
    main_tex = (PAPER_DIR / "main.tex").read_text(encoding="utf-8")
    supplement_tex = (PAPER_DIR / "supplementary.tex").read_text(encoding="utf-8")
    combined_tex = main_tex + "\n" + supplement_tex
    failures: list[str] = []
    checks: dict[str, object] = {}

    abstract_match = re.search(
        r"\\abstract\{(.*?)\}\s*\\keywords", main_tex, flags=re.DOTALL
    )
    if not abstract_match:
        failures.append("abstract block not found")
        abstract_words = 0
    else:
        abstract_words = approximate_word_count(abstract_match.group(1))
        if not 150 <= abstract_words <= 250:
            failures.append(f"abstract word count out of range: {abstract_words}")
    checks["abstract_word_count"] = abstract_words

    keywords_match = re.search(r"\\keywords\{([^}]*)\}", main_tex)
    keyword_count = (
        len([item for item in keywords_match.group(1).split(",") if item.strip()])
        if keywords_match
        else 0
    )
    if not 4 <= keyword_count <= 6:
        failures.append(f"keyword count out of range: {keyword_count}")
    checks["keyword_count"] = keyword_count

    if "\\subsubsubsection" in main_tex:
        failures.append("heading depth exceeds three levels")
    if "Online Resource~1" not in main_tex:
        failures.append("Online Resource 1 is not cited in the manuscript")
    for heading in (
        "Funding",
        "Competing interests",
        "Data availability",
        "Code availability",
        "Author contributions",
    ):
        if f"\\subsection*{{{heading}}}" not in main_tex:
            failures.append(f"missing declaration: {heading}")

    included_assets = set(
        re.findall(r"\\(?:input|includegraphics)(?:\[[^\]]*\])?\{([^}]+)\}", combined_tex)
    )
    missing_assets = sorted(
        asset for asset in included_assets if not (PAPER_DIR / asset).is_file()
    )
    if missing_assets:
        failures.append(f"missing TeX assets: {missing_assets}")
    checks["included_asset_count"] = len(included_assets)

    cite_keys: set[str] = set()
    first_citation_order: list[str] = []
    for group in re.findall(
        r"\\(?:cite|citet|citep|citealp|citeauthor|citeyear)"
        r"(?:\[[^\]]*\]){0,2}\{([^}]+)\}",
        main_tex,
    ):
        for raw_key in group.split(","):
            key = raw_key.strip()
            cite_keys.add(key)
            if key not in first_citation_order:
                first_citation_order.append(key)
    bib_keys = set(
        re.findall(
            r"^@\w+\{([^,]+),",
            (PAPER_DIR / "references.bib").read_text(encoding="utf-8"),
            flags=re.MULTILINE,
        )
    )
    missing_bib = sorted(cite_keys - bib_keys)
    if missing_bib:
        failures.append(f"citation keys missing from BibTeX: {missing_bib}")
    bbl_order = re.findall(
        r"^\\bibitem\{([^}]+)\}",
        (PAPER_DIR / "references_bbl.tex").read_text(encoding="utf-8"),
        flags=re.MULTILINE,
    )
    if bbl_order != first_citation_order:
        mismatches = [
            (index, cited, listed)
            for index, (cited, listed) in enumerate(
                zip(first_citation_order, bbl_order), start=1
            )
            if cited != listed
        ]
        failures.append(
            "references_bbl.tex is not ordered by first citation: "
            f"{mismatches[:10]}"
        )
    checks["cited_key_count"] = len(cite_keys)
    checks["bib_entry_count"] = len(bib_keys)
    checks["bbl_item_count"] = len(bbl_order)
    checks["first_citation_order_matches_bbl"] = bbl_order == first_citation_order
    for required_key in (
        "hu2023_common_edge_paths",
        "moreira2007_dynamic_rural_postman",
    ):
        if required_key not in cite_keys:
            failures.append(f"closest-prior-art citation is not used: {required_key}")
    if "None directly represents a partial rectangle edge" in main_tex:
        failures.append("superseded absolute prior-art claim remains")
    for required_text in (
        "does not claim the first use of common cuts or graph-segment routing",
        "These studies establish both graph-segment common cuts and order-dependent feasibility as prior art",
    ):
        if required_text not in main_tex:
            failures.append(f"prior-art boundary text missing: {required_text}")

    evidence = json.loads(EVIDENCE_MANIFEST.read_text(encoding="utf-8"))
    route_path = Path(evidence["track_a"]["route_result"]["path"])
    route_hash = sha256_file(route_path)
    if route_hash != evidence["track_a"]["route_result"]["sha256"]:
        failures.append("authorized Track A route-result hash changed")
    checks["track_a_route_sha256"] = route_hash

    for asset in evidence["paper"]["generated_assets"]:
        path = Path(asset["path"])
        if sha256_file(path) != asset["sha256"]:
            failures.append(f"generated paper asset changed: {path.name}")

    track_a = read_rows(TRACK_A / "confirmatory_summary.csv")
    track_b = read_rows(TRACK_B / "confirmatory_summary.csv")
    expected_claims = []
    for rows, baseline, mean_digits, low_digits, high_digits, task_count in (
        (track_a, "topology_process_aware", "10.25", "9.91", "10.61", 20),
        (track_a, "endpoint_aware_gtsp", "6.74", "6.23", "7.24", 20),
        (track_b, "topology_process_aware", "9.98", "9.58", "10.45", 7),
        (track_b, "endpoint_aware_gtsp", "7.08", "6.53", "7.68", 7),
    ):
        row = find_row(rows, baseline)
        derived = {
            "mean": f"{float(row['mean_reduction_pct']):.2f}",
            "low": f"{float(row['reduction_ci_low']):.2f}",
            "high": f"{float(row['reduction_ci_high']):.2f}",
            "wins": int(row["wins"]),
            "losses": int(row["losses"]),
        }
        expected = {
            "mean": mean_digits,
            "low": low_digits,
            "high": high_digits,
            "wins": task_count,
            "losses": 0,
        }
        if derived != expected:
            failures.append(
                f"frozen result mismatch for {baseline} with {task_count} tasks: "
                f"{derived} != {expected}"
            )
        for displayed in (mean_digits, low_digits, high_digits):
            if displayed not in combined_tex:
                failures.append(f"frozen display value absent from TeX: {displayed}")
        expected_claims.append(
            {"track_tasks": task_count, "baseline": baseline, **derived}
        )
    checks["confirmatory_claims"] = expected_claims

    nc_gate = json.loads(
        (NC_RESULTS / "gate_report.json").read_text(encoding="utf-8")
    )
    nc_completion = json.loads(
        (NC_RESULTS / "completion_audit.json").read_text(encoding="utf-8")
    )
    nc_merge = json.loads(
        (NC_RESULTS / "merge_audit.json").read_text(encoding="utf-8")
    )
    if not nc_gate["passed"]:
        failures.append("full NC gate did not pass")
    if not nc_completion["passed"]:
        failures.append("full NC completion audit did not pass")
    if not nc_merge["passed"]:
        failures.append("full NC shard merge did not pass")
    nc_database = nc_completion["database_audit"]
    expected_nc_counts = {
        "jobs": 58_920,
        "boards": 11_784,
        "tasks": 20,
        "scenario_rows": 58_920 * 27,
        "audit_failures": 0,
        "reference_mismatches": 0,
    }
    derived_nc_counts = {
        "jobs": int(nc_database["actual_job_count"]),
        "boards": int(nc_database["actual_board_count"]),
        "tasks": int(nc_database["factory_task_count"]),
        "scenario_rows": int(nc_database["scenario_row_count"]),
        "audit_failures": int(nc_database["nc_audit_failures"]),
        "reference_mismatches": int(
            nc_database["route_reference_mismatches"]
        ),
    }
    if derived_nc_counts != expected_nc_counts:
        failures.append(
            f"NC completion counts changed: {derived_nc_counts} "
            f"!= {expected_nc_counts}"
        )
    checks["nc_completion"] = derived_nc_counts

    nc_table = (PAPER_DIR / "table_nc_kinematic_validation.tex").read_text(
        encoding="utf-8"
    )
    nc_nominal_table = (PAPER_DIR / "table_nc_nominal_scenario.tex").read_text(
        encoding="utf-8"
    )
    nc_robustness = read_rows(
        NC_RESULTS / "scenario_robustness_summary.csv"
    )
    for baseline, metric in (
        ("topology_process_aware", "continuous_noncut_time_s"),
        ("topology_process_aware", "continuous_total_time_s"),
        ("process_aware_beam", "stop_total_time_s"),
        ("endpoint_aware_gtsp", "stop_total_time_s"),
    ):
        row = next(
            item
            for item in nc_robustness
            if item["baseline"] == baseline and item["time_metric"] == metric
        )
        displayed_range = (
            f"{float(row['minimum_mean_reduction_pct']):.2f}"
            f"--{float(row['maximum_mean_reduction_pct']):.2f}"
        )
        if displayed_range not in nc_table:
            failures.append(
                f"NC table range missing for {baseline}/{metric}: "
                f"{displayed_range}"
            )
    checks["nc_scenario_count"] = 27
    checks["nc_scope"] = nc_completion["scope"]
    nominal_rows = read_rows(
        NC_RESULTS / "publication_assets/nominal_scenario_task_summary.csv"
    )
    nominal_topology = next(
        row
        for row in nominal_rows
        if row["baseline"] == "topology_process_aware"
    )
    for displayed in (
        f"{float(nominal_topology['mean_reduction_pct']):.2f}",
        f"{float(nominal_topology['median_reduction_pct']):.2f}",
        f"{float(nominal_topology['reduction_ci_low']):.2f}",
        f"{float(nominal_topology['reduction_ci_high']):.2f}",
        "20/0/0",
    ):
        if displayed not in nc_nominal_table:
            failures.append(f"nominal NC table value missing: {displayed}")
    checks["nc_nominal_topology"] = nominal_topology

    public_manifest = json.loads(
        (PUBLIC_NC / "manifest.json").read_text(encoding="utf-8")
    )
    if public_manifest["example_count"] != 5:
        failures.append("public NC example count is not five")
    if public_manifest["scenario_count_per_example"] != 27:
        failures.append("public NC scenario count is not 27 per example")
    for example in public_manifest["examples"]:
        if not example["route_to_nc_audit_passed"]:
            failures.append(f"public NC audit failed: {example['layout']}")
        if example["scenario_count"] != 27:
            failures.append(f"public NC scenario grid failed: {example['layout']}")
    checks["public_nc_examples"] = {
        "count": public_manifest["example_count"],
        "all_audits_passed": all(
            example["route_to_nc_audit_passed"]
            for example in public_manifest["examples"]
        ),
    }

    vericut_rows = read_rows(VERICUT / "results/timing_summary.csv")
    expected_vericut_times = {
        ("case01_small", "proposed"): (751, 53),
        ("case01_small", "topology"): (751, 53),
        ("case01_small", "ordinary_beam"): (775, 76),
        ("case02_medium", "proposed"): (869, 96),
        ("case02_medium", "topology"): (869, 95),
        ("case02_medium", "ordinary_beam"): (868, 97),
        ("case03_medium", "proposed"): (775, 74),
        ("case03_medium", "topology"): (794, 93),
        ("case03_medium", "ordinary_beam"): (788, 88),
        ("case04_large", "proposed"): (919, 132),
        ("case04_large", "topology"): (918, 130),
        ("case04_large", "ordinary_beam"): (928, 141),
        ("case05_largest", "proposed"): (1069, 166),
        ("case05_largest", "topology"): (1087, 184),
        ("case05_largest", "ordinary_beam"): (1079, 176),
    }
    derived_vericut_times = {
        (row["case_id"], row["method"]): (
            int(row["vericut_total_time_s"]),
            int(row["vericut_air_time_s"]),
        )
        for row in vericut_rows
    }
    if derived_vericut_times != expected_vericut_times:
        failures.append("qualified VERICUT timing table changed")

    formal_vericut_rows = read_rows(VERICUT / "results/formal_result_entry.csv")
    if len(formal_vericut_rows) != 15:
        failures.append("qualified VERICUT formal-run count is not 15")
    for row in formal_vericut_rows:
        if row["program_completed"] != "yes":
            failures.append(f"VERICUT program incomplete: {row['nc_file']}")
        for field in (
            "fatal_error_count",
            "warning_count",
            "axis_overtravel_count",
            "collision_count",
            "gouge_count",
            "excess_count",
        ):
            if int(row[field]) != 0:
                failures.append(
                    f"qualified VERICUT formal result has nonzero {field}: "
                    f"{row['nc_file']}"
                )

    vericut_nc_rows = read_rows(VERICUT / "results/nc_integrity_recheck.csv")
    if len(vericut_nc_rows) != 15 or any(
        row["unchanged"] != "yes" for row in vericut_nc_rows
    ):
        failures.append("qualified VERICUT NC identity check failed")

    gate_rows = read_rows(VERICUT / "geometry_gate/gate_summary.csv")
    if len(gate_rows) != 7 or any(row["status"] != "PASS" for row in gate_rows):
        failures.append("qualified VERICUT gate is incomplete or failed")

    expected_vericut_zip_sha256 = (
        "520096496f9a4f970f63814406b17030549d92f2f4963ea8af5bdfe8f47bb51d"
    )
    actual_vericut_zip_sha256 = sha256_file(VERICUT_ZIP)
    if actual_vericut_zip_sha256 != expected_vericut_zip_sha256:
        failures.append("VERICUT V3 archive SHA-256 changed")

    selection_rows = read_rows(
        VERICUT / "selection/selection_manifest_anonymized.csv"
    )
    selection_cases = {row["case_id"] for row in selection_rows}
    selection_tasks = {row["pseudonymized_task_id"] for row in selection_rows}
    selection_methods = {row["method"] for row in selection_rows}
    selection_pairs = {(row["case_id"], row["method"]) for row in selection_rows}
    selection_rectangle_counts = {
        int(row["rectangle_count"]) for row in selection_rows
    }
    if len(selection_rows) != 15:
        failures.append("anonymized VERICUT selection manifest is not 15 rows")
    if len(selection_cases) != 5 or len(selection_tasks) != 5:
        failures.append("VERICUT selection is not five cases from five tasks")
    if selection_methods != {"proposed", "topology", "ordinary_beam"}:
        failures.append("VERICUT selection methods changed")
    if len(selection_pairs) != 15:
        failures.append("VERICUT selection case-method pairs are not unique")
    if selection_rectangle_counts != {5, 7, 8, 12, 19}:
        failures.append("VERICUT selection size coverage changed")
    private_task_prefix = "ZJ_" + "ZN"
    if any(
        private_task_prefix in value
        for row in selection_rows
        for value in row.values()
        if value
    ):
        failures.append("private factory identifier remains in selection manifest")
    for row in selection_rows:
        nc_path = VERICUT / row["nc_file"]
        if not nc_path.is_file() or sha256_file(nc_path) != row["nc_sha256"]:
            failures.append(f"selection NC identity failed: {row['nc_file']}")
    package_rows = read_rows(VERICUT / "PACKAGE_SHA256.csv")
    for row in package_rows:
        path = VERICUT / row["relative_path"]
        if (
            not path.is_file()
            or sha256_file(path) != row["sha256"]
            or path.stat().st_size != int(row["bytes"])
        ):
            failures.append(f"VERICUT package checksum failed: {row['relative_path']}")
    checks["vericut_selection"] = {
        "manifest_rows": len(selection_rows),
        "unique_cases": len(selection_cases),
        "unique_pseudonymized_tasks": len(selection_tasks),
        "private_identifiers_found": False,
        "package_checksum_rows": len(package_rows),
    }

    vericut_table = (PAPER_DIR / "supp_table_vericut_selected_layouts.tex").read_text(
        encoding="utf-8"
    )
    for required_value in (
        "751/53",
        "869/96",
        "775/74",
        "919/132",
        "1069/166",
        "2/3/0",
        "4/1/0",
    ):
        if required_value not in vericut_table:
            failures.append(f"qualified VERICUT table value missing: {required_value}")
    for required_value in ("0.79", "1.31", "6.13", "9.86"):
        if required_value not in combined_tex:
            failures.append(
                f"qualified VERICUT summary value missing from TeX: {required_value}"
            )
    checks["qualified_vericut"] = {
        "formal_programs": len(formal_vericut_rows),
        "all_formal_checks_zero": all(
            row["program_completed"] == "yes"
            and all(
                int(row[field]) == 0
                for field in (
                    "fatal_error_count",
                    "warning_count",
                    "axis_overtravel_count",
                    "collision_count",
                    "gouge_count",
                    "excess_count",
                )
            )
            for row in formal_vericut_rows
        ),
        "gate_rows_passed": sum(row["status"] == "PASS" for row in gate_rows),
        "nc_hashes_unchanged": sum(
            row["unchanged"] == "yes" for row in vericut_nc_rows
        ),
        "archive_sha256": actual_vericut_zip_sha256,
    }

    for required_text in (
        "Scenarios are sensitivity conditions, not independent replicates",
        "not cycle-time or machining-quality evidence",
        "modal programmed feed",
        "\\textbf{RQ5}",
        "isotropic path-level limits",
        "committed only after the final depth pass",
        "controller-agnostic",
        "five complete public examples",
        "qualified representative commercial-simulator cross-check",
        "global cut-stock tolerance was 0.25",
        "not a 0.10~mm dimensional-accuracy claim",
        "qualified through prespecified negative and positive controls",
        "does not denote CGTech or machine-manufacturer certification",
        "shared oracle/proposed removal geometry",
        "route-equivalent final removal",
        "The lexicographic relation strictly orders distinct objective vectors",
        "without inspecting route cost, effect direction, or simulated time",
        "anonymized 15-row selection manifest",
    ):
        if required_text not in main_tex:
            failures.append(f"NC evidence-boundary text missing: {required_text}")
    for forbidden_text in (
        "supp_table_time_mapping_sensitivity",
        "We evaluate only coefficient sensitivity",
        "illustrative \\(v_{\\mathrm{cut}}",
        "machine-collision checking was disabled",
        "without enabling machine-collision checking",
        "Pearson \\(r=0.999929\\)",
        "mean paired reduction, and reported rapid",
        "2/2/1",
        "strict total order over the evaluated route space",
    ):
        if forbidden_text in combined_tex:
            failures.append(f"superseded timing text remains: {forbidden_text}")
    if "controller-neutral" in combined_tex:
        failures.append("ambiguous controller-neutral terminology remains")

    for log_path in (
        PAPER_DIR / "main.log",
        PAPER_DIR / "supplementary.log",
        PAPER_DIR / "cover_letter/cover_letter.log",
    ):
        log_text = log_path.read_text(encoding="utf-8", errors="replace")
        forbidden = (
            "LaTeX Error",
            "undefined references",
            "undefined citations",
            "multiply defined",
            "Overfull",
        )
        hits = [term for term in forbidden if term in log_text]
        if hits:
            failures.append(f"{log_path.name} contains {hits}")

    status = "passed" if not failures else "failed"
    report = {
        "audit_status": status,
        "checks": checks,
        "failures": failures,
        "source_hashes": {
            "main_tex": sha256_file(PAPER_DIR / "main.tex"),
            "supplementary_tex": sha256_file(PAPER_DIR / "supplementary.tex"),
            "cover_letter_tex": sha256_file(
                PAPER_DIR / "cover_letter/cover_letter.tex"
            ),
        },
    }
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUTPUT_DIR / "submission_audit.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    (OUTPUT_DIR / "submission_audit.md").write_text(
        "\n".join(
            [
                "# IJAMT submission consistency audit",
                "",
                f"- Status: **{status}**",
                f"- Abstract words: {abstract_words}",
                f"- Keywords: {keyword_count}",
                f"- Cited keys/BibTeX entries: {len(cite_keys)}/{len(bib_keys)}",
                f"- Included TeX assets found: {len(included_assets)}",
                "- Track A authorized route hash: unchanged",
                "- Track A and Track B confirmatory display values: matched",
                "- Full transparent NC gate, shard merge, and completion audit: passed",
                "- Qualified representative VERICUT timing, gate, AUTO-DIFF, NC identity, and archive hash: matched",
                "- Main, Online Resource, and cover-letter logs: clean",
                "",
                "## Failures",
                "",
                *(f"- {item}" for item in failures),
                "" if failures else "- None",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(json.dumps({"audit_status": status, "failure_count": len(failures)}))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
