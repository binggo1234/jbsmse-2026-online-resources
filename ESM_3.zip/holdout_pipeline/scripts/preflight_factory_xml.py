from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import asdict, dataclass
from decimal import Decimal
from pathlib import Path
from typing import Iterable, Sequence
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.factory_csv_converter import read_factory_inventory


FACTORY_ROOT = Path("<CONTROLLED_FACTORY_DATA>")
LINEAGE = ROOT / "data" / "factory_task_lineage_manifest_v1.csv"
FREEZE_SPEC = ROOT / "docs" / "track_b_xml_coordinate_freeze_v1.md"
DEFAULT_OUTPUT_DIR = ROOT / "outputs" / "factory_xml_preflight_v1"
TOLERANCE = 1e-9


@dataclass(frozen=True)
class WorkpieceGeometry:
    task_id: str
    confirmatory_status: str
    pattern_id: str
    pattern_sequence: int
    workpiece_sequence: int
    workpiece_id: str
    board_length: float
    board_width: float
    tool_diameter: float
    finished_length: str
    finished_width: str
    cut_length: float
    cut_width: float
    nominal_x: float
    nominal_y: float
    nominal_width: float
    nominal_height: float
    lineament_min_x: float
    lineament_min_y: float
    lineament_max_x: float
    lineament_max_y: float
    point_count: int
    rotate_angle: str
    lineament_rotation_angle: str
    rotated_for_placement: bool
    geometry_status: str
    geometry_errors: str


@dataclass(frozen=True)
class PatternGeometry:
    task_id: str
    confirmatory_status: str
    pattern_id: str
    pattern_sequence: int
    patterns_group_index: str
    pattern_index: str
    material_name: str
    board_length: float
    board_width: float
    tool_diameter: float
    workpiece_count: int
    invalid_workpiece_count: int
    nominal_overlap_pair_count: int
    compensated_interior_overlap_pair_count: int
    task_inventory_passed: bool
    geometry_passed: bool
    eligible_for_route: bool
    exclusion_reasons: str
    placements_member: str
    config_member: str


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def finite_number(value: str, label: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError(f"{label} must be finite")
    return parsed


def near(left: float, right: float, tolerance: float = 1e-6) -> bool:
    return abs(left - right) <= tolerance * max(1.0, abs(left), abs(right))


def positive_interior_overlap(
    first: tuple[float, float, float, float],
    second: tuple[float, float, float, float],
) -> bool:
    overlap_x = min(first[2], second[2]) - max(first[0], second[0])
    overlap_y = min(first[3], second[3]) - max(first[1], second[1])
    return overlap_x > TOLERANCE and overlap_y > TOLERANCE


def rectangle_overlap_count(
    rectangles: Sequence[tuple[float, float, float, float]],
) -> int:
    return sum(
        positive_interior_overlap(first, second)
        for index, first in enumerate(rectangles)
        for second in rectangles[index + 1 :]
    )


def task_xml_member(archive: ZipFile, task_id: str) -> str:
    members = [
        name
        for name in archive.namelist()
        if name.lower().endswith(".xml") and task_id in name
    ]
    if len(members) != 1:
        raise ValueError(f"{task_id}: expected one XML member, found {len(members)}")
    return members[0]


def validate_lineament(
    workpiece: ET.Element,
    pattern: ET.Element,
    *,
    task_id: str,
    confirmatory_status: str,
    pattern_id: str,
    pattern_sequence: int,
    workpiece_sequence: int,
    board_length: float,
    board_width: float,
) -> WorkpieceGeometry:
    errors: list[str] = []
    tool_diameter = finite_number(pattern.attrib["ToolDiameter"], "ToolDiameter")
    tool_radius = tool_diameter / 2.0
    cut_length = finite_number(workpiece.attrib["CutLength"], "CutLength")
    cut_width = finite_number(workpiece.attrib["CutWidth"], "CutWidth")
    lineament = workpiece.find("./Lineament")
    points: list[tuple[float, float]] = []
    if lineament is None:
        errors.append("missing_lineament")
        lineament_rotation = ""
    else:
        lineament_rotation = lineament.attrib.get("RotationAngle", "")
        for point in lineament.findall("./Points/Point"):
            try:
                points.append(
                    (
                        finite_number(point.attrib["X"], "Point.X"),
                        finite_number(point.attrib["Y"], "Point.Y"),
                    )
                )
            except (KeyError, ValueError):
                errors.append("invalid_point")
    if len(points) < 4:
        errors.append("fewer_than_four_points")
        min_x = min_y = max_x = max_y = math.nan
    else:
        xs = [point[0] for point in points]
        ys = [point[1] for point in points]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        if max_x - min_x <= TOLERANCE or max_y - min_y <= TOLERANCE:
            errors.append("nonpositive_lineament_bbox")
        corners = {
            (min_x, min_y),
            (min_x, max_y),
            (max_x, min_y),
            (max_x, max_y),
        }
        if not all(
            any(near(x, px) and near(y, py) for px, py in points)
            for x, y in corners
        ):
            errors.append("missing_bbox_corner")
        if any(
            not (
                near(x, min_x)
                or near(x, max_x)
                or near(y, min_y)
                or near(y, max_y)
            )
            for x, y in points
        ):
            errors.append("point_off_rectangular_boundary")
        bbox_width = max_x - min_x
        bbox_height = max_y - min_y
        direct = near(bbox_width, cut_length + tool_diameter) and near(
            bbox_height, cut_width + tool_diameter
        )
        rotated = near(bbox_width, cut_width + tool_diameter) and near(
            bbox_height, cut_length + tool_diameter
        )
        if not (direct or rotated):
            errors.append("cut_dimension_compensation_mismatch")
        if (
            min_x < -TOLERANCE
            or min_y < -TOLERANCE
            or max_x > board_length + TOLERANCE
            or max_y > board_width + TOLERANCE
        ):
            errors.append("cutter_center_outside_board")
    if points:
        nominal_x = min_x + tool_radius
        nominal_y = min_y + tool_radius
        nominal_width = max_x - min_x - tool_diameter
        nominal_height = max_y - min_y - tool_diameter
    else:
        nominal_x = nominal_y = nominal_width = nominal_height = math.nan
    if (
        not math.isfinite(nominal_width)
        or nominal_width <= TOLERANCE
        or nominal_height <= TOLERANCE
    ):
        errors.append("nonpositive_nominal_rectangle")
    if math.isfinite(nominal_x) and (
        nominal_x < -TOLERANCE
        or nominal_y < -TOLERANCE
        or nominal_x + nominal_width > board_length + TOLERANCE
        or nominal_y + nominal_height > board_width + TOLERANCE
    ):
        errors.append("nominal_rectangle_outside_board")
    rotated_for_placement = (
        math.isfinite(nominal_width)
        and near(nominal_width, cut_width)
        and near(nominal_height, cut_length)
        and not (
            near(nominal_width, cut_length) and near(nominal_height, cut_width)
        )
    )
    return WorkpieceGeometry(
        task_id=task_id,
        confirmatory_status=confirmatory_status,
        pattern_id=pattern_id,
        pattern_sequence=pattern_sequence,
        workpiece_sequence=workpiece_sequence,
        workpiece_id=workpiece.attrib.get("WorkpieceId", ""),
        board_length=board_length,
        board_width=board_width,
        tool_diameter=tool_diameter,
        finished_length=workpiece.attrib.get("Designer", ""),
        finished_width=workpiece.attrib.get("clerk", ""),
        cut_length=cut_length,
        cut_width=cut_width,
        nominal_x=nominal_x,
        nominal_y=nominal_y,
        nominal_width=nominal_width,
        nominal_height=nominal_height,
        lineament_min_x=min_x,
        lineament_min_y=min_y,
        lineament_max_x=max_x,
        lineament_max_y=max_y,
        point_count=len(points),
        rotate_angle=workpiece.attrib.get("RotateAngle", ""),
        lineament_rotation_angle=lineament_rotation,
        rotated_for_placement=rotated_for_placement,
        geometry_status="passed" if not errors else "failed",
        geometry_errors=";".join(sorted(set(errors))),
    )


def inventory_check(
    lineage: dict[str, str],
    xml_root: ET.Element,
) -> tuple[bool, dict[str, int]]:
    inventory = read_factory_inventory(
        FACTORY_ROOT / lineage["csv_relative_path"],
        task_id=lineage["task_id"],
    )
    workpieces = xml_root.findall("./Patterns/Pattern/Workpieces/Workpiece")
    inventory_ids = Counter(part.pid_raw for part in inventory)
    xml_ids = Counter(workpiece.attrib.get("WorkpieceId", "") for workpiece in workpieces)
    inventory_dimensions = Counter(
        tuple(sorted((part.w0, part.h0))) for part in inventory
    )
    xml_dimensions = Counter(
        tuple(
            sorted(
                (
                    Decimal(workpiece.attrib["Designer"]),
                    Decimal(workpiece.attrib["clerk"]),
                )
            )
        )
        for workpiece in workpieces
    )
    counts = {
        "csv_part_count": len(inventory),
        "xml_workpiece_count": len(workpieces),
        "id_missing_count": sum((inventory_ids - xml_ids).values()),
        "id_extra_count": sum((xml_ids - inventory_ids).values()),
        "dimension_missing_count": sum(
            (inventory_dimensions - xml_dimensions).values()
        ),
        "dimension_extra_count": sum(
            (xml_dimensions - inventory_dimensions).values()
        ),
    }
    return all(value == 0 for key, value in counts.items() if "count" in key and key not in {"csv_part_count", "xml_workpiece_count"}) and len(inventory) == len(workpieces), counts


def parse_task(
    lineage: dict[str, str],
) -> tuple[list[PatternGeometry], list[WorkpieceGeometry], dict[str, object]]:
    task_id = lineage["task_id"]
    archive_path = FACTORY_ROOT / lineage["xml_archive_relative_path"]
    with ZipFile(archive_path) as archive:
        member = task_xml_member(archive, task_id)
        xml_bytes = archive.read(member)
    if sha256_bytes(xml_bytes) != lineage["xml_member_sha256"]:
        raise ValueError(f"{task_id}: XML member SHA mismatch")
    xml_root = ET.fromstring(xml_bytes)
    task_inventory_passed, inventory_counts = inventory_check(lineage, xml_root)

    patterns: list[PatternGeometry] = []
    all_workpieces: list[WorkpieceGeometry] = []
    sequence = 0
    for group_position, group in enumerate(xml_root.findall("./Patterns"), start=1):
        board_length = finite_number(group.attrib["Length"], "Patterns.Length")
        board_width = finite_number(group.attrib["Width"], "Patterns.Width")
        group_index = group.attrib.get("Index", str(group_position))
        material_name = group.attrib.get("Name", "")
        for pattern_position, pattern in enumerate(group.findall("./Pattern"), start=1):
            sequence += 1
            pattern_index = pattern.attrib.get("Index", str(pattern_position))
            pattern_id = f"{task_id}:g{group_index}:p{pattern_index}:s{sequence:04d}"
            workpieces = [
                validate_lineament(
                    workpiece,
                    pattern,
                    task_id=task_id,
                    confirmatory_status=lineage["confirmatory_status"],
                    pattern_id=pattern_id,
                    pattern_sequence=sequence,
                    workpiece_sequence=workpiece_sequence,
                    board_length=board_length,
                    board_width=board_width,
                )
                for workpiece_sequence, workpiece in enumerate(
                    pattern.findall("./Workpieces/Workpiece"),
                    start=1,
                )
            ]
            all_workpieces.extend(workpieces)
            nominal = [
                (
                    item.nominal_x,
                    item.nominal_y,
                    item.nominal_x + item.nominal_width,
                    item.nominal_y + item.nominal_height,
                )
                for item in workpieces
                if item.geometry_status == "passed"
            ]
            compensated = [
                (
                    item.lineament_min_x,
                    item.lineament_min_y,
                    item.lineament_max_x,
                    item.lineament_max_y,
                )
                for item in workpieces
                if item.geometry_status == "passed"
            ]
            nominal_overlaps = rectangle_overlap_count(nominal)
            compensated_overlaps = rectangle_overlap_count(compensated)
            invalid = sum(item.geometry_status != "passed" for item in workpieces)
            reasons: list[str] = []
            if not workpieces:
                reasons.append("empty_pattern")
            if invalid:
                reasons.append("invalid_workpiece_geometry")
            if nominal_overlaps:
                reasons.append("nominal_positive_area_overlap")
            if compensated_overlaps:
                reasons.append("compensated_positive_area_overlap")
            if not task_inventory_passed:
                reasons.append("task_csv_xml_inventory_mismatch")
            geometry_passed = (
                bool(workpieces)
                and invalid == 0
                and nominal_overlaps == 0
                and compensated_overlaps == 0
            )
            prefix = f"track_b/{task_id}/pattern_{sequence:04d}"
            patterns.append(
                PatternGeometry(
                    task_id=task_id,
                    confirmatory_status=lineage["confirmatory_status"],
                    pattern_id=pattern_id,
                    pattern_sequence=sequence,
                    patterns_group_index=group_index,
                    pattern_index=pattern_index,
                    material_name=material_name,
                    board_length=board_length,
                    board_width=board_width,
                    tool_diameter=finite_number(
                        pattern.attrib["ToolDiameter"], "ToolDiameter"
                    ),
                    workpiece_count=len(workpieces),
                    invalid_workpiece_count=invalid,
                    nominal_overlap_pair_count=nominal_overlaps,
                    compensated_interior_overlap_pair_count=compensated_overlaps,
                    task_inventory_passed=task_inventory_passed,
                    geometry_passed=geometry_passed,
                    eligible_for_route=geometry_passed and task_inventory_passed,
                    exclusion_reasons=";".join(reasons),
                    placements_member=f"{prefix}/placements.csv",
                    config_member=f"{prefix}/config_dump.json",
                )
            )
    task_summary: dict[str, object] = {
        "task_id": task_id,
        "confirmatory_status": lineage["confirmatory_status"],
        "xml_archive_path": str(archive_path),
        "xml_archive_sha256": sha256_file(archive_path),
        "xml_member_sha256": lineage["xml_member_sha256"],
        "pattern_count": len(patterns),
        "eligible_pattern_count": sum(item.eligible_for_route for item in patterns),
        "geometry_failed_pattern_count": sum(
            not item.geometry_passed for item in patterns
        ),
        "inventory_passed": task_inventory_passed,
        **inventory_counts,
    }
    return patterns, all_workpieces, task_summary


def csv_text(rows: Sequence[dict[str, object]], fields: Sequence[str]) -> str:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def deterministic_writestr(archive: ZipFile, name: str, text: str) -> None:
    info = ZipInfo(name, date_time=(2026, 7, 26, 0, 0, 0))
    info.compress_type = ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    archive.writestr(info, text.encode("utf-8"))


def build_layout_archive(
    path: Path,
    patterns: Sequence[PatternGeometry],
    workpieces: Sequence[WorkpieceGeometry],
) -> list[dict[str, str]]:
    by_pattern: dict[str, list[WorkpieceGeometry]] = {}
    for workpiece in workpieces:
        by_pattern.setdefault(workpiece.pattern_id, []).append(workpiece)
    member_hashes: list[dict[str, str]] = []
    with ZipFile(path, "w") as archive:
        for pattern in patterns:
            if not pattern.eligible_for_route:
                continue
            placement_rows = [
                {
                    "board": 1,
                    "uid": (
                        f"{workpiece.task_id}:p{workpiece.pattern_sequence:04d}:"
                        f"w{workpiece.workpiece_sequence:04d}"
                    ),
                    "pid_raw": workpiece.workpiece_id,
                    "x": workpiece.nominal_x,
                    "y": workpiece.nominal_y,
                    "w": workpiece.nominal_width,
                    "h": workpiece.nominal_height,
                    "w0": workpiece.cut_length,
                    "h0": workpiece.cut_width,
                    "rotated": workpiece.rotated_for_placement,
                }
                for workpiece in by_pattern[pattern.pattern_id]
            ]
            placement_text = csv_text(
                placement_rows,
                (
                    "board",
                    "uid",
                    "pid_raw",
                    "x",
                    "y",
                    "w",
                    "h",
                    "w0",
                    "h0",
                    "rotated",
                ),
            )
            config = {
                "cfg": {
                    "BOARD_W": pattern.board_length,
                    "BOARD_H": pattern.board_width,
                    "TRIM": 0.0,
                    "TOOL_D": pattern.tool_diameter,
                    "PLACEMENT_GEOMETRY_MODE": "stored",
                    "GEOMETRIC_KERF_COMPENSATION": True,
                    "CENTERLINE_BOUNDARY_MARGIN": 0.0,
                },
                "provenance": {
                    "task_id": pattern.task_id,
                    "pattern_id": pattern.pattern_id,
                    "source": "factory_xml_lineament",
                },
            }
            config_text = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
            for member, text in (
                (pattern.placements_member, placement_text),
                (pattern.config_member, config_text),
            ):
                deterministic_writestr(archive, member, text)
                member_hashes.append(
                    {"member": member, "sha256": sha256_bytes(text.encode("utf-8"))}
                )
    return member_hashes


def write_csv(path: Path, rows: Sequence[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty CSV: {path}")
    path.write_text(csv_text(rows, list(rows[0])), encoding="utf-8")


def run(output_dir: Path = DEFAULT_OUTPUT_DIR) -> dict[str, object]:
    lineage_rows = [
        row for row in read_rows(LINEAGE) if row["xml_available"] == "yes"
    ]
    if len(lineage_rows) != 11:
        raise ValueError(f"expected 11 XML tasks, found {len(lineage_rows)}")
    patterns: list[PatternGeometry] = []
    workpieces: list[WorkpieceGeometry] = []
    tasks: list[dict[str, object]] = []
    for lineage in lineage_rows:
        current_patterns, current_workpieces, task = parse_task(lineage)
        patterns.extend(current_patterns)
        workpieces.extend(current_workpieces)
        tasks.append(task)
    if len(patterns) != 2_753:
        raise ValueError(f"expected 2753 XML Patterns, found {len(patterns)}")
    if sum(item.workpiece_count for item in patterns) != len(workpieces):
        raise ValueError("Pattern and Workpiece counts disagree")

    output_dir.mkdir(parents=True, exist_ok=True)
    pattern_path = output_dir / "pattern_geometry_preflight.csv"
    workpiece_path = output_dir / "workpiece_geometry.csv"
    task_path = output_dir / "task_preflight.csv"
    eligible_path = output_dir / "frozen_pattern_manifest.csv"
    archive_path = output_dir / "track_b_original_layouts.zip"
    report_path = output_dir / "preflight_report.md"
    manifest_path = output_dir / "preflight_manifest.json"
    pattern_rows = [asdict(item) for item in patterns]
    workpiece_rows = [asdict(item) for item in workpieces]
    eligible_rows = [
        asdict(item) for item in patterns if item.eligible_for_route
    ]
    write_csv(pattern_path, pattern_rows)
    write_csv(workpiece_path, workpiece_rows)
    write_csv(task_path, tasks)
    write_csv(eligible_path, eligible_rows)
    member_hashes = build_layout_archive(archive_path, patterns, workpieces)
    passed = (
        len(eligible_rows) == len(patterns)
        and all(bool(task["inventory_passed"]) for task in tasks)
    )
    report = "\n".join(
        [
            "# Track B factory XML geometry preflight",
            "",
            f"- Preflight status: **{'passed' if passed else 'failed'}**",
            f"- XML tasks: {len(tasks)}",
            "- Confirmatory holdout XML tasks: "
            + str(
                sum(
                    task["confirmatory_status"] == "confirmatory_holdout"
                    for task in tasks
                )
            ),
            f"- Patterns parsed: {len(patterns)}",
            f"- Patterns eligible for routing: {len(eligible_rows)}",
            f"- Workpieces parsed: {len(workpieces)}",
            "- CSV--XML inventory tasks passed: "
            + str(sum(bool(task["inventory_passed"]) for task in tasks)),
            "- Cutter-center boundary convention: centerline inside stock; "
            "exterior tool-disk overhang allowed",
            "",
        ]
    )
    report_path.write_text(report, encoding="utf-8")
    outputs = [
        pattern_path,
        workpiece_path,
        task_path,
        eligible_path,
        archive_path,
        report_path,
    ]
    manifest = {
        "preflight_status": "passed" if passed else "failed",
        "freeze_spec": {
            "path": str(FREEZE_SPEC),
            "sha256": sha256_file(FREEZE_SPEC),
        },
        "lineage_manifest": {
            "path": str(LINEAGE),
            "sha256": sha256_file(LINEAGE),
        },
        "counts": {
            "task_count": len(tasks),
            "confirmatory_holdout_task_count": sum(
                task["confirmatory_status"] == "confirmatory_holdout"
                for task in tasks
            ),
            "pattern_count": len(patterns),
            "eligible_pattern_count": len(eligible_rows),
            "workpiece_count": len(workpieces),
            "archive_member_count": len(member_hashes),
        },
        "coordinate_convention": {
            "tool_diameter_mm": sorted({item.tool_diameter for item in patterns}),
            "centerline_boundary_margin_mm": 0.0,
            "trim_margin_mm": 0.0,
            "placement_geometry_mode": "stored",
            "geometric_kerf_compensation": True,
        },
        "source_xml_tasks": tasks,
        "archive_members": member_hashes,
        "outputs": [
            {"path": str(path), "sha256": sha256_file(path)} for path in outputs
        ],
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    if not passed:
        raise ValueError("Track B XML preflight did not pass")
    return manifest


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Preflight factory XML layouts.")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = parse_args(argv)
    manifest = run(args.output_dir)
    print(json.dumps(manifest["counts"], indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
