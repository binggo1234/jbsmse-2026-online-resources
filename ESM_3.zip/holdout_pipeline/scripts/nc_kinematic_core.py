from __future__ import annotations

import hashlib
import json
import math
import re
from dataclasses import dataclass, replace
from typing import Iterable, Mapping, Sequence


SUPPORTED_G_CODES = {"G0", "G00", "G1", "G01", "G17", "G20", "G21", "G40", "G90", "G91"}
SUPPORTED_M_CODES = {"M3", "M03", "M5", "M05", "M6", "M06", "M30"}
TOKEN_RE = re.compile(r"([A-Za-z])\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+))")
COMMENT_RE = re.compile(r"\(([^()]*)\)")


@dataclass(frozen=True)
class NcTemplate:
    stock_thickness_mm: float = 18.0
    tool_diameter_mm: float = 6.0
    z_low_clearance_mm: float = 1.0
    z_safe_mm: float = 5.0
    step_down_mm: float = 6.0
    spindle_rpm: int = 18000
    feed_cut_mm_min: float = 3600.0
    feed_plunge_mm_min: float = 800.0
    coordinate_decimals: int = 3
    nc_tolerance_mm: float = 0.001

    @property
    def depths_mm(self) -> tuple[float, ...]:
        if self.stock_thickness_mm <= 0.0 or self.step_down_mm <= 0.0:
            raise ValueError("stock thickness and step down must be positive")
        values: list[float] = []
        depth = 0.0
        while depth < self.stock_thickness_mm - 1e-12:
            depth = min(depth + self.step_down_mm, self.stock_thickness_mm)
            values.append(-depth)
        return tuple(values)


@dataclass(frozen=True)
class SourceAction:
    action_index: int
    action_type: str
    travel_mode: str
    start_x: float
    start_y: float
    end_x: float
    end_y: float
    cutting_unit_id: str = ""
    segment_id: str = ""

    @classmethod
    def from_mapping(cls, row: Mapping[str, object]) -> "SourceAction":
        return cls(
            action_index=int(row["action_index"]),
            action_type=str(row["action_type"]),
            travel_mode=str(row.get("travel_mode", "")),
            start_x=float(row["start_x"]),
            start_y=float(row["start_y"]),
            end_x=float(row["end_x"]),
            end_y=float(row["end_y"]),
            cutting_unit_id=str(row.get("cutting_unit_id") or ""),
            segment_id=str(row.get("segment_id") or ""),
        )


@dataclass(frozen=True)
class ParsedMotion:
    block_id: int
    line_number: int
    motion: str
    start_x_mm: float
    start_y_mm: float
    start_z_mm: float
    end_x_mm: float
    end_y_mm: float
    end_z_mm: float
    feed_mm_min: float | None
    action_index: int | None
    role: str
    travel_mode: str
    pass_index: int | None

    @property
    def xy_length_mm(self) -> float:
        return math.hypot(
            self.end_x_mm - self.start_x_mm,
            self.end_y_mm - self.start_y_mm,
        )

    @property
    def z_length_mm(self) -> float:
        return abs(self.end_z_mm - self.start_z_mm)

    @property
    def length_mm(self) -> float:
        return math.sqrt(self.xy_length_mm**2 + self.z_length_mm**2)


@dataclass(frozen=True)
class ParseResult:
    motions: tuple[ParsedMotion, ...]
    unit_mode: str
    absolute_mode: bool
    compensation_cancelled: bool
    spindle_started: bool
    spindle_stopped: bool
    tool_change_count: int


@dataclass(frozen=True)
class AuditResult:
    passed: bool
    errors: tuple[str, ...]
    source_action_count: int
    nc_action_count: int
    cut_xy_block_count: int
    travel_xy_block_count: int
    return_xy_block_count: int
    maximum_coordinate_error_mm: float


@dataclass(frozen=True)
class NcGeometryMetrics:
    cutting_distance_mm: float
    rapid_xy_distance_mm: float
    setup_xy_distance_mm: float
    low_clearance_xy_distance_mm: float
    safe_lift_xy_distance_mm: float
    return_xy_distance_mm: float
    z_retract_distance_mm: float
    z_plunge_distance_mm: float
    retract_count: int
    plunge_count: int
    direction_change_count: int
    nc_block_count: int

    @property
    def z_distance_mm(self) -> float:
        return self.z_retract_distance_mm + self.z_plunge_distance_mm


@dataclass(frozen=True)
class KinematicScenario:
    scenario: str
    cut_speed_mm_s: float
    rapid_speed_mm_s: float
    xy_acceleration_mm_s2: float
    z_speed_mm_s: float
    z_acceleration_mm_s2: float
    nonmotion_event_time_s: float = 0.0


@dataclass(frozen=True)
class KinematicEstimate:
    scenario: str
    continuous_cut_time_s: float
    continuous_rapid_time_s: float
    continuous_z_time_s: float
    continuous_noncut_time_s: float
    continuous_total_time_s: float
    stop_cut_time_s: float
    stop_rapid_time_s: float
    stop_z_time_s: float
    stop_noncut_time_s: float
    stop_total_time_s: float


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def action_sequence_sha256(actions: Sequence[SourceAction]) -> str:
    payload = [
        {
            "action_index": action.action_index,
            "action_type": action.action_type,
            "travel_mode": action.travel_mode,
            "start": [round(action.start_x, 9), round(action.start_y, 9)],
            "end": [round(action.end_x, 9), round(action.end_y, 9)],
            "cutting_unit_id": action.cutting_unit_id,
            "segment_id": action.segment_id,
        }
        for action in actions
    ]
    return sha256_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))


def _format(value: float, decimals: int) -> str:
    return f"{value:.{decimals}f}"


def _metadata_line(**values: object) -> str:
    return "(NCX " + json.dumps(values, sort_keys=True, separators=(",", ":")) + ")"


def generate_canonical_gcode(
    actions: Sequence[SourceAction],
    *,
    panel_width_mm: float,
    panel_height_mm: float,
    start_x_mm: float,
    start_y_mm: float,
    template: NcTemplate = NcTemplate(),
) -> str:
    """Generate controller-neutral NC while preserving top-level route action order.

    Each cutting action is completed through all prescribed depths before the next
    route action. Travel actions retain their low-clearance, detour, or safe-lift
    mode through the selected Z clearance.
    """

    decimals = template.coordinate_decimals
    lines = [
        "(Canonical controller-neutral NC for transparent kinematic evaluation)",
        f"(Stock XY: {_format(panel_width_mm, decimals)} x "
        f"{_format(panel_height_mm, decimals)} mm)",
        "(Geometrically compensated cutter centerlines; controller compensation off)",
        "G21",
        "G90",
        "G17",
        "G40",
        f"G0 Z{_format(template.z_safe_mm, decimals)}",
        "T1 M6",
        f"M3 S{template.spindle_rpm}",
        _metadata_line(action=-1, role="setup_xy", mode="setup"),
        f"G0 X{_format(start_x_mm, decimals)} Y{_format(start_y_mm, decimals)}",
    ]
    current_x = start_x_mm
    current_y = start_y_mm
    current_z = template.z_safe_mm

    for expected_index, action in enumerate(actions):
        if action.action_index != expected_index:
            raise ValueError(
                f"non-contiguous source action index: {action.action_index} != "
                f"{expected_index}"
            )
        gap = math.hypot(action.start_x - current_x, action.start_y - current_y)
        if gap > 1e-6:
            raise ValueError(
                f"source route discontinuity before action {action.action_index}: "
                f"{gap:.9f} mm"
            )
        if action.action_type == "travel":
            if action.travel_mode not in {
                "low_clearance",
                "low_clearance_detour",
                "safe_lift",
            }:
                raise ValueError(
                    f"unsupported travel mode {action.travel_mode!r} at "
                    f"action {action.action_index}"
                )
            target_z = (
                template.z_safe_mm
                if action.travel_mode == "safe_lift"
                else template.z_low_clearance_mm
            )
            lines.append(
                _metadata_line(
                    action=action.action_index,
                    role="travel_z",
                    mode=action.travel_mode,
                )
            )
            if abs(current_z - target_z) > 1e-12:
                lines.append(f"G0 Z{_format(target_z, decimals)}")
                current_z = target_z
            lines.append(
                _metadata_line(
                    action=action.action_index,
                    role="travel_xy",
                    mode=action.travel_mode,
                )
            )
            lines.append(
                f"G0 X{_format(action.end_x, decimals)} "
                f"Y{_format(action.end_y, decimals)}"
            )
            current_x, current_y = action.end_x, action.end_y
            continue

        if action.action_type != "cut":
            raise ValueError(
                f"unsupported action type {action.action_type!r} at "
                f"action {action.action_index}"
            )
        forward = True
        for pass_index, depth in enumerate(template.depths_mm, start=1):
            target_x = action.end_x if forward else action.start_x
            target_y = action.end_y if forward else action.start_y
            lines.append(
                _metadata_line(
                    action=action.action_index,
                    role="cut_z",
                    mode="cut",
                    pass_index=pass_index,
                )
            )
            lines.append(
                f"G1 Z{_format(depth, decimals)} "
                f"F{template.feed_plunge_mm_min:.1f}"
            )
            current_z = depth
            lines.append(
                _metadata_line(
                    action=action.action_index,
                    role="cut_xy",
                    mode="cut",
                    pass_index=pass_index,
                )
            )
            lines.append(
                f"G1 X{_format(target_x, decimals)} "
                f"Y{_format(target_y, decimals)} "
                f"F{template.feed_cut_mm_min:.1f}"
            )
            current_x, current_y = target_x, target_y
            forward = not forward

    lines.append(_metadata_line(action=-1, role="footer_z", mode="return"))
    if abs(current_z - template.z_safe_mm) > 1e-12:
        lines.append(f"G0 Z{_format(template.z_safe_mm, decimals)}")
        current_z = template.z_safe_mm
    lines.append(_metadata_line(action=-1, role="return_xy", mode="return"))
    lines.append(
        f"G0 X{_format(start_x_mm, decimals)} Y{_format(start_y_mm, decimals)}"
    )
    lines.extend(["M5", "M30"])
    return "\n".join(lines) + "\n"


def _normal_code(letter: str, value: float) -> str:
    integer = int(value)
    if abs(value - integer) > 1e-12:
        raise ValueError(f"non-integer {letter}-code {value}")
    return f"{letter}{integer}"


def parse_gcode(text: str) -> ParseResult:
    x = y = z = 0.0
    feed: float | None = None
    units_scale = 1.0
    unit_mode = ""
    absolute = True
    absolute_seen = False
    motion_mode: str | None = None
    compensation_cancelled = False
    spindle_started = False
    spindle_stopped = False
    tool_change_count = 0
    metadata: dict[str, object] = {}
    motions: list[ParsedMotion] = []

    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        for comment in COMMENT_RE.findall(raw_line):
            if comment.startswith("NCX "):
                loaded = json.loads(comment[4:])
                if not isinstance(loaded, dict):
                    raise ValueError(f"invalid NCX metadata at line {line_number}")
                metadata = loaded
        code = COMMENT_RE.sub("", raw_line).strip().upper()
        if not code:
            continue
        tokens = TOKEN_RE.findall(code)
        residue = TOKEN_RE.sub("", code).strip()
        if residue:
            raise ValueError(f"unsupported syntax at line {line_number}: {residue!r}")

        axis_values: dict[str, float] = {}
        explicit_motion: str | None = None
        for letter, raw_value in tokens:
            letter = letter.upper()
            value = float(raw_value)
            if letter == "G":
                gcode = _normal_code("G", value)
                if gcode not in SUPPORTED_G_CODES:
                    raise ValueError(f"unsupported G-code {gcode} at line {line_number}")
                if gcode in {"G0", "G00"}:
                    explicit_motion = "G0"
                elif gcode in {"G1", "G01"}:
                    explicit_motion = "G1"
                elif gcode == "G20":
                    units_scale = 25.4
                    unit_mode = "inch"
                elif gcode == "G21":
                    units_scale = 1.0
                    unit_mode = "mm"
                elif gcode == "G90":
                    absolute = True
                    absolute_seen = True
                elif gcode == "G91":
                    absolute = False
                    absolute_seen = True
                elif gcode == "G40":
                    compensation_cancelled = True
            elif letter == "M":
                mcode = _normal_code("M", value)
                if mcode not in SUPPORTED_M_CODES:
                    raise ValueError(f"unsupported M-code {mcode} at line {line_number}")
                if mcode in {"M3", "M03"}:
                    spindle_started = True
                elif mcode in {"M5", "M05"}:
                    spindle_stopped = True
                elif mcode in {"M6", "M06"}:
                    tool_change_count += 1
            elif letter in {"X", "Y", "Z"}:
                axis_values[letter] = value * units_scale
            elif letter == "F":
                feed = value * units_scale
            elif letter in {"S", "T"}:
                continue
            else:
                raise ValueError(
                    f"unsupported word {letter}{raw_value} at line {line_number}"
                )

        if explicit_motion is not None:
            motion_mode = explicit_motion
        if not axis_values:
            continue
        if motion_mode is None:
            raise ValueError(f"axis word without modal motion at line {line_number}")

        start = (x, y, z)
        targets = {"X": x, "Y": y, "Z": z}
        for axis, value in axis_values.items():
            targets[axis] = value if absolute else targets[axis] + value
        x, y, z = targets["X"], targets["Y"], targets["Z"]
        if math.dist(start, (x, y, z)) <= 1e-12:
            continue
        motions.append(
            ParsedMotion(
                block_id=len(motions),
                line_number=line_number,
                motion=motion_mode,
                start_x_mm=start[0],
                start_y_mm=start[1],
                start_z_mm=start[2],
                end_x_mm=x,
                end_y_mm=y,
                end_z_mm=z,
                feed_mm_min=feed,
                action_index=(
                    int(metadata["action"]) if "action" in metadata else None
                ),
                role=str(metadata.get("role", "")),
                travel_mode=str(metadata.get("mode", "")),
                pass_index=(
                    int(metadata["pass_index"])
                    if "pass_index" in metadata
                    else None
                ),
            )
        )

    if not unit_mode:
        raise ValueError("G-code does not declare G20 or G21 units")
    if not absolute_seen:
        raise ValueError("G-code does not declare G90 or G91 coordinate mode")
    return ParseResult(
        motions=tuple(motions),
        unit_mode=unit_mode,
        absolute_mode=absolute,
        compensation_cancelled=compensation_cancelled,
        spindle_started=spindle_started,
        spindle_stopped=spindle_stopped,
        tool_change_count=tool_change_count,
    )


def audit_route_nc(
    actions: Sequence[SourceAction],
    parsed: ParseResult,
    *,
    panel_width_mm: float,
    panel_height_mm: float,
    template: NcTemplate = NcTemplate(),
) -> AuditResult:
    errors: list[str] = []
    max_error = 0.0
    if parsed.unit_mode != "mm":
        errors.append(f"unexpected final unit mode: {parsed.unit_mode}")
    if not parsed.absolute_mode:
        errors.append("unexpected final incremental coordinate mode")
    if not parsed.compensation_cancelled:
        errors.append("G40 compensation cancellation missing")
    if not parsed.spindle_started or not parsed.spindle_stopped:
        errors.append("spindle start/stop pair incomplete")
    if parsed.tool_change_count != 1:
        errors.append(f"expected one tool change, found {parsed.tool_change_count}")

    action_motions: dict[int, list[ParsedMotion]] = {}
    for motion in parsed.motions:
        if motion.action_index is not None and motion.action_index >= 0:
            action_motions.setdefault(motion.action_index, []).append(motion)
        for x, y in (
            (motion.start_x_mm, motion.start_y_mm),
            (motion.end_x_mm, motion.end_y_mm),
        ):
            if x < -template.nc_tolerance_mm or y < -template.nc_tolerance_mm:
                errors.append(f"negative XY coordinate at NC block {motion.block_id}")
            if x > panel_width_mm + template.nc_tolerance_mm:
                errors.append(f"X out of bounds at NC block {motion.block_id}")
            if y > panel_height_mm + template.nc_tolerance_mm:
                errors.append(f"Y out of bounds at NC block {motion.block_id}")

    if sorted(action_motions) != list(range(len(actions))):
        errors.append("NC action indices do not exactly cover the source sequence")

    for action in actions:
        blocks = action_motions.get(action.action_index, [])
        xy_blocks = [block for block in blocks if block.xy_length_mm > 1e-12]
        if action.action_type == "travel":
            if len(xy_blocks) != 1:
                errors.append(
                    f"travel action {action.action_index} has {len(xy_blocks)} XY blocks"
                )
                continue
            block = xy_blocks[0]
            if block.motion != "G0" or block.role != "travel_xy":
                errors.append(f"travel action {action.action_index} is not canonical G0")
            if block.travel_mode != action.travel_mode:
                errors.append(f"travel mode mismatch at action {action.action_index}")
            expected_z = (
                template.z_safe_mm
                if action.travel_mode == "safe_lift"
                else template.z_low_clearance_mm
            )
            if abs(block.end_z_mm - expected_z) > template.nc_tolerance_mm:
                errors.append(
                    f"travel clearance Z mismatch at action {action.action_index}"
                )
            expected = (
                action.start_x,
                action.start_y,
                action.end_x,
                action.end_y,
            )
            actual = (
                block.start_x_mm,
                block.start_y_mm,
                block.end_x_mm,
                block.end_y_mm,
            )
            max_error = max(max_error, *(abs(a - b) for a, b in zip(actual, expected)))
        elif action.action_type == "cut":
            expected_count = len(template.depths_mm)
            z_blocks = [
                block
                for block in blocks
                if block.role == "cut_z" and block.z_length_mm > 1e-12
            ]
            if len(xy_blocks) != expected_count:
                errors.append(
                    f"cut action {action.action_index} has {len(xy_blocks)} XY blocks; "
                    f"expected {expected_count}"
                )
                continue
            if len(z_blocks) != expected_count:
                errors.append(
                    f"cut action {action.action_index} has {len(z_blocks)} Z blocks; "
                    f"expected {expected_count}"
                )
                continue
            for pass_offset, block in enumerate(xy_blocks):
                forward = pass_offset % 2 == 0
                expected = (
                    action.start_x if forward else action.end_x,
                    action.start_y if forward else action.end_y,
                    action.end_x if forward else action.start_x,
                    action.end_y if forward else action.start_y,
                )
                actual = (
                    block.start_x_mm,
                    block.start_y_mm,
                    block.end_x_mm,
                    block.end_y_mm,
                )
                max_error = max(
                    max_error,
                    *(abs(a - b) for a, b in zip(actual, expected)),
                )
                if block.motion != "G1" or block.role != "cut_xy":
                    errors.append(
                        f"cut action {action.action_index} pass {pass_offset + 1} "
                        "is not canonical G1"
                    )
                expected_depth = template.depths_mm[pass_offset]
                if abs(block.end_z_mm - expected_depth) > template.nc_tolerance_mm:
                    errors.append(
                        f"cut depth mismatch at action {action.action_index} "
                        f"pass {pass_offset + 1}"
                    )
                if (
                    block.feed_mm_min is None
                    or abs(block.feed_mm_min - template.feed_cut_mm_min) > 1e-9
                ):
                    errors.append(
                        f"cut feed mismatch at action {action.action_index} "
                        f"pass {pass_offset + 1}"
                    )
            for pass_offset, block in enumerate(z_blocks):
                expected_depth = template.depths_mm[pass_offset]
                if block.motion != "G1":
                    errors.append(
                        f"plunge motion mismatch at action {action.action_index} "
                        f"pass {pass_offset + 1}"
                    )
                if abs(block.end_z_mm - expected_depth) > template.nc_tolerance_mm:
                    errors.append(
                        f"plunge depth mismatch at action {action.action_index} "
                        f"pass {pass_offset + 1}"
                    )
                if (
                    block.feed_mm_min is None
                    or abs(block.feed_mm_min - template.feed_plunge_mm_min) > 1e-9
                ):
                    errors.append(
                        f"plunge feed mismatch at action {action.action_index} "
                        f"pass {pass_offset + 1}"
                    )
        else:
            errors.append(f"unsupported source action type {action.action_type!r}")

    if max_error > template.nc_tolerance_mm + 1e-12:
        errors.append(
            f"maximum coordinate error {max_error:.9f} mm exceeds "
            f"{template.nc_tolerance_mm:.9f} mm"
        )
    nc_indices = [
        motion.action_index
        for motion in parsed.motions
        if motion.action_index is not None
        and motion.action_index >= 0
        and motion.xy_length_mm > 1e-12
    ]
    if any(second < first for first, second in zip(nc_indices, nc_indices[1:])):
        errors.append("NC action order differs from source action order")

    return AuditResult(
        passed=not errors,
        errors=tuple(dict.fromkeys(errors)),
        source_action_count=len(actions),
        nc_action_count=len(action_motions),
        cut_xy_block_count=sum(
            motion.role == "cut_xy" and motion.xy_length_mm > 1e-12
            for motion in parsed.motions
        ),
        travel_xy_block_count=sum(
            motion.role == "travel_xy" and motion.xy_length_mm > 1e-12
            for motion in parsed.motions
        ),
        return_xy_block_count=sum(
            motion.role == "return_xy" and motion.xy_length_mm > 1e-12
            for motion in parsed.motions
        ),
        maximum_coordinate_error_mm=max_error,
    )


def _direction_change_count(motions: Sequence[ParsedMotion]) -> int:
    vectors: list[tuple[float, float]] = []
    for motion in motions:
        if motion.xy_length_mm <= 1e-12:
            continue
        vectors.append(
            (
                (motion.end_x_mm - motion.start_x_mm) / motion.xy_length_mm,
                (motion.end_y_mm - motion.start_y_mm) / motion.xy_length_mm,
            )
        )
    changes = 0
    for first, second in zip(vectors, vectors[1:]):
        if abs(first[0] * second[1] - first[1] * second[0]) > 1e-9:
            changes += 1
        elif first[0] * second[0] + first[1] * second[1] < 1.0 - 1e-9:
            changes += 1
    return changes


def geometry_metrics(parsed: ParseResult) -> NcGeometryMetrics:
    cutting = rapid = setup = low = safe = returned = retract = plunge = 0.0
    retract_count = plunge_count = 0
    for motion in parsed.motions:
        if motion.role == "cut_xy":
            cutting += motion.xy_length_mm
        elif motion.motion == "G0" and motion.xy_length_mm > 0.0:
            rapid += motion.xy_length_mm
            if motion.role == "setup_xy":
                setup += motion.xy_length_mm
            elif motion.role == "return_xy":
                returned += motion.xy_length_mm
            elif motion.travel_mode == "safe_lift":
                safe += motion.xy_length_mm
            elif motion.role == "travel_xy":
                low += motion.xy_length_mm
        dz = motion.end_z_mm - motion.start_z_mm
        if dz > 1e-12:
            retract += dz
            retract_count += 1
        elif dz < -1e-12:
            plunge += -dz
            plunge_count += 1
    return NcGeometryMetrics(
        cutting_distance_mm=cutting,
        rapid_xy_distance_mm=rapid,
        setup_xy_distance_mm=setup,
        low_clearance_xy_distance_mm=low,
        safe_lift_xy_distance_mm=safe,
        return_xy_distance_mm=returned,
        z_retract_distance_mm=retract,
        z_plunge_distance_mm=plunge,
        retract_count=retract_count,
        plunge_count=plunge_count,
        direction_change_count=_direction_change_count(parsed.motions),
        nc_block_count=len(parsed.motions),
    )


def default_scenarios() -> tuple[KinematicScenario, ...]:
    scenarios: list[KinematicScenario] = []
    z_settings = ((20.0, 200.0), (40.0, 500.0), (60.0, 1000.0))
    for rapid in (100.0, 200.0, 300.0):
        for xy_acceleration in (500.0, 1000.0, 2000.0):
            for z_speed, z_acceleration in z_settings:
                scenarios.append(
                    KinematicScenario(
                        scenario=(
                            f"r{int(rapid)}_axy{int(xy_acceleration)}_"
                            f"z{int(z_speed)}_az{int(z_acceleration)}"
                        ),
                        cut_speed_mm_s=60.0,
                        rapid_speed_mm_s=rapid,
                        xy_acceleration_mm_s2=xy_acceleration,
                        z_speed_mm_s=z_speed,
                        z_acceleration_mm_s2=z_acceleration,
                    )
                )
    return tuple(scenarios)


def segment_stop_time_s(length_mm: float, speed_mm_s: float, acceleration_mm_s2: float) -> float:
    if length_mm <= 0.0:
        return 0.0
    if speed_mm_s <= 0.0 or acceleration_mm_s2 <= 0.0:
        raise ValueError("speed and acceleration must be positive")
    critical_distance = speed_mm_s**2 / acceleration_mm_s2
    if length_mm >= critical_distance:
        return length_mm / speed_mm_s + speed_mm_s / acceleration_mm_s2
    return 2.0 * math.sqrt(length_mm / acceleration_mm_s2)


def _coalesce_collinear(motions: Sequence[ParsedMotion]) -> tuple[ParsedMotion, ...]:
    merged: list[ParsedMotion] = []
    for motion in motions:
        if motion.length_mm <= 1e-12:
            continue
        if not merged:
            merged.append(motion)
            continue
        previous = merged[-1]
        same_class = (
            previous.motion == motion.motion
            and previous.role == motion.role
            and previous.travel_mode == motion.travel_mode
            and previous.feed_mm_min == motion.feed_mm_min
        )
        contiguous = math.dist(
            (previous.end_x_mm, previous.end_y_mm, previous.end_z_mm),
            (motion.start_x_mm, motion.start_y_mm, motion.start_z_mm),
        ) <= 1e-9
        first_vector = (
            previous.end_x_mm - previous.start_x_mm,
            previous.end_y_mm - previous.start_y_mm,
            previous.end_z_mm - previous.start_z_mm,
        )
        second_vector = (
            motion.end_x_mm - motion.start_x_mm,
            motion.end_y_mm - motion.start_y_mm,
            motion.end_z_mm - motion.start_z_mm,
        )
        cross = (
            first_vector[1] * second_vector[2] - first_vector[2] * second_vector[1],
            first_vector[2] * second_vector[0] - first_vector[0] * second_vector[2],
            first_vector[0] * second_vector[1] - first_vector[1] * second_vector[0],
        )
        forward = sum(a * b for a, b in zip(first_vector, second_vector)) > 0.0
        collinear = math.sqrt(sum(value * value for value in cross)) <= 1e-9
        if same_class and contiguous and collinear and forward:
            merged[-1] = replace(
                previous,
                end_x_mm=motion.end_x_mm,
                end_y_mm=motion.end_y_mm,
                end_z_mm=motion.end_z_mm,
            )
        else:
            merged.append(motion)
    return tuple(merged)


def _motion_speed_mm_s(
    motion: ParsedMotion,
    axis_limit_mm_s: float,
) -> float:
    if axis_limit_mm_s <= 0.0:
        raise ValueError("axis speed limit must be positive")
    if motion.motion != "G1" or motion.feed_mm_min is None:
        return axis_limit_mm_s
    commanded_feed_mm_s = motion.feed_mm_min / 60.0
    if commanded_feed_mm_s <= 0.0:
        raise ValueError("linear feed must be positive")
    return min(axis_limit_mm_s, commanded_feed_mm_s)


def estimate_kinematics(
    parsed: ParseResult,
    scenario: KinematicScenario,
) -> KinematicEstimate:
    continuous_cut = continuous_rapid = continuous_z = 0.0
    stop_cut = stop_rapid = stop_z = 0.0
    for motion in _coalesce_collinear(parsed.motions):
        if motion.xy_length_mm > 0.0:
            if motion.role == "cut_xy":
                speed = _motion_speed_mm_s(
                    motion,
                    scenario.cut_speed_mm_s,
                )
                continuous_cut += motion.xy_length_mm / speed
                stop_cut += segment_stop_time_s(
                    motion.xy_length_mm,
                    speed,
                    scenario.xy_acceleration_mm_s2,
                )
            else:
                speed = _motion_speed_mm_s(
                    motion,
                    scenario.rapid_speed_mm_s,
                )
                continuous_rapid += motion.xy_length_mm / speed
                stop_rapid += segment_stop_time_s(
                    motion.xy_length_mm,
                    speed,
                    scenario.xy_acceleration_mm_s2,
                )
        if motion.z_length_mm > 0.0:
            z_speed = _motion_speed_mm_s(
                motion,
                scenario.z_speed_mm_s,
            )
            continuous_z += motion.z_length_mm / z_speed
            stop_z += segment_stop_time_s(
                motion.z_length_mm,
                z_speed,
                scenario.z_acceleration_mm_s2,
            )
    event = scenario.nonmotion_event_time_s
    return KinematicEstimate(
        scenario=scenario.scenario,
        continuous_cut_time_s=continuous_cut,
        continuous_rapid_time_s=continuous_rapid,
        continuous_z_time_s=continuous_z,
        continuous_noncut_time_s=continuous_rapid + continuous_z + event,
        continuous_total_time_s=continuous_cut + continuous_rapid + continuous_z + event,
        stop_cut_time_s=stop_cut,
        stop_rapid_time_s=stop_rapid,
        stop_z_time_s=stop_z,
        stop_noncut_time_s=stop_rapid + stop_z + event,
        stop_total_time_s=stop_cut + stop_rapid + stop_z + event,
    )


def actions_from_diagnostics(rows: Iterable[Mapping[str, object]]) -> tuple[SourceAction, ...]:
    return tuple(SourceAction.from_mapping(row) for row in rows)
