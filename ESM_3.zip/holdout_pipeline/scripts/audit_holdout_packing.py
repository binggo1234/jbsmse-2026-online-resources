from __future__ import annotations

import argparse
import csv
from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile


TOLERANCE = 1e-7


@dataclass(frozen=True)
class JobAudit:
    run_id: str
    task_id: str
    packing_seed: int
    generated_board_count: int
    expected_part_count: int
    packed_part_count: int
    missing_part_count: int
    extra_part_count: int
    duplicate_part_count: int
    boundary_violation_count: int
    overlap_violation_count: int
    envelope_dimension_violation_count: int
    placement_hash_matches: bool
    config_matches: bool
    passed: bool


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def read_csv_bytes(payload: bytes) -> list[dict[str, str]]:
    return list(
        csv.DictReader(
            io.StringIO(payload.decode("utf-8-sig"), newline="")
        )
    )


def rectangles_intersect(first: dict[str, float], second: dict[str, float]) -> bool:
    return not (
        second["x"] >= first["x"] + first["w"] - TOLERANCE
        or second["x"] + second["w"] <= first["x"] + TOLERANCE
        or second["y"] >= first["y"] + first["h"] - TOLERANCE
        or second["y"] + second["h"] <= first["y"] + TOLERANCE
    )


def audit_job(
    *,
    job: dict[str, str],
    result: dict[str, str],
    placement_payload: bytes,
    config_payload: bytes,
) -> JobAudit:
    rows = read_csv_bytes(placement_payload)
    inventory = read_csv(Path(job["inventory_path"]))
    expected_ids = {row["uid"] for row in inventory}
    packed_ids = [row["uid"] for row in rows]
    packed_set = set(packed_ids)
    missing_count = len(expected_ids - packed_set)
    extra_count = len(packed_set - expected_ids)
    duplicate_count = len(packed_ids) - len(packed_set)
    board_rows: dict[int, list[dict[str, float]]] = {}
    boundary_violations = 0
    overlap_violations = 0
    envelope_violations = 0
    panel_width = float(job["panel_width_mm"])
    panel_height = float(job["panel_height_mm"])
    trim = float(job["trim_mm"])
    tool_diameter = float(job["tool_diameter_mm"])

    for row in rows:
        board_id = int(row["board"])
        rectangle = {
            "x": float(row["x"]),
            "y": float(row["y"]),
            "w": float(row["w"]),
            "h": float(row["h"]),
        }
        if (
            rectangle["x"] < trim - TOLERANCE
            or rectangle["y"] < trim - TOLERANCE
            or rectangle["x"] + rectangle["w"]
            > panel_width - trim + TOLERANCE
            or rectangle["y"] + rectangle["h"]
            > panel_height - trim + TOLERANCE
        ):
            boundary_violations += 1
        w0 = float(row["w0"])
        h0 = float(row["h0"])
        rotated = row["rotated"] == "1"
        expected_w = (h0 if rotated else w0) + tool_diameter
        expected_h = (w0 if rotated else h0) + tool_diameter
        if (
            abs(rectangle["w"] - expected_w) > TOLERANCE
            or abs(rectangle["h"] - expected_h) > TOLERANCE
        ):
            envelope_violations += 1
        for other in board_rows.setdefault(board_id, []):
            if rectangles_intersect(rectangle, other):
                overlap_violations += 1
        board_rows[board_id].append(rectangle)

    config = json.loads(config_payload.decode("utf-8"))
    cfg = config.get("cfg", config)
    provenance = config.get("provenance", {})
    config_matches = (
        float(cfg["BOARD_W"]) == panel_width
        and float(cfg["BOARD_H"]) == panel_height
        and float(cfg["TRIM"]) == trim
        and float(cfg["TOOL_D"]) == tool_diameter
        and bool(cfg["ALLOW_ROT"]) == (job["allow_rotation"] == "True")
        and int(cfg["PACKING_ORDER_SEED"]) == int(job["packing_seed"])
        and int(cfg["PACKING_ORDER_TOP_K"]) == int(job["packing_order_top_k"])
        and cfg["BINARY_SPACING"] is False
        and cfg["GEOMETRIC_KERF_COMPENSATION"] is True
        and provenance["run_id"] == job["run_id"]
        and provenance["task_id"] == job["task_id"]
        and provenance["inventory_sha256"] == job["inventory_sha256"]
    )
    generated_board_count = len(board_rows)
    packed_count = len(rows)
    placement_hash_matches = (
        sha256_bytes(placement_payload) == result["placements_sha256"]
    )
    passed = (
        packed_count == len(expected_ids)
        and generated_board_count == int(result["generated_board_count"])
        and missing_count == 0
        and extra_count == 0
        and duplicate_count == 0
        and boundary_violations == 0
        and overlap_violations == 0
        and envelope_violations == 0
        and placement_hash_matches
        and config_matches
    )
    return JobAudit(
        run_id=job["run_id"],
        task_id=job["task_id"],
        packing_seed=int(job["packing_seed"]),
        generated_board_count=generated_board_count,
        expected_part_count=len(expected_ids),
        packed_part_count=packed_count,
        missing_part_count=missing_count,
        extra_part_count=extra_count,
        duplicate_part_count=duplicate_count,
        boundary_violation_count=boundary_violations,
        overlap_violation_count=overlap_violations,
        envelope_dimension_violation_count=envelope_violations,
        placement_hash_matches=placement_hash_matches,
        config_matches=config_matches,
        passed=passed,
    )


def member_hashes(archive: ZipFile) -> dict[str, str]:
    return {
        name: sha256_bytes(archive.read(name))
        for name in sorted(archive.namelist())
        if not name.endswith("/")
    }


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_summary(
    path: Path,
    audits: list[JobAudit],
    deterministic: bool | None,
) -> None:
    seed_counts = Counter(audit.packing_seed for audit in audits)
    lines = [
        "# Holdout Kerf-Packing Audit",
        "",
        f"- Jobs: {len(audits)}",
        f"- Independent tasks: {len({audit.task_id for audit in audits})}",
        f"- Generated boards retained: {sum(a.generated_board_count for a in audits)}",
        f"- Packed parts: {sum(a.packed_part_count for a in audits)}",
        f"- Missing parts: {sum(a.missing_part_count for a in audits)}",
        f"- Extra parts: {sum(a.extra_part_count for a in audits)}",
        f"- Duplicate parts: {sum(a.duplicate_part_count for a in audits)}",
        (
            f"- Boundary violations: "
            f"{sum(a.boundary_violation_count for a in audits)}"
        ),
        (
            f"- Envelope overlaps: "
            f"{sum(a.overlap_violation_count for a in audits)}"
        ),
        (
            f"- Envelope dimension violations: "
            f"{sum(a.envelope_dimension_violation_count for a in audits)}"
        ),
        f"- Seed balance: {dict(sorted(seed_counts.items()))}",
        (
            "- Deterministic archive/result rerun: "
            + (
                "PASS"
                if deterministic is True
                else "FAIL"
                if deterministic is False
                else "not run"
            )
        ),
        f"- Verdict: {'PASS' if all(a.passed for a in audits) else 'FAIL'}",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Independently audit the frozen holdout packing archive."
    )
    parser.add_argument("--run-manifest", type=Path, required=True)
    parser.add_argument("--result-manifest", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--freeze-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--determinism-archive", type=Path)
    parser.add_argument("--determinism-result-manifest", type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    jobs = read_csv(args.run_manifest)
    results = read_csv(args.result_manifest)
    jobs_by_id = {row["run_id"]: row for row in jobs}
    results_by_id = {row["run_id"]: row for row in results}
    if len(jobs_by_id) != 60 or jobs_by_id.keys() != results_by_id.keys():
        raise ValueError("run and result manifests do not contain the same 60 jobs")
    freeze = json.loads(args.freeze_manifest.read_text(encoding="utf-8"))
    if sha256_file(args.run_manifest) != freeze["inputs"]["packing_run_manifest_sha256"]:
        raise ValueError("run manifest hash differs from the frozen design")

    audits: list[JobAudit] = []
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with ZipFile(args.archive) as archive:
        hashes = member_hashes(archive)
        expected_members = {
            member
            for result in results
            for member in (result["placements_member"], result["config_member"])
        }
        if set(hashes) != expected_members:
            raise ValueError("archive member set differs from result manifest")
        for run_id in sorted(jobs_by_id):
            result = results_by_id[run_id]
            audits.append(
                audit_job(
                    job=jobs_by_id[run_id],
                    result=result,
                    placement_payload=archive.read(result["placements_member"]),
                    config_payload=archive.read(result["config_member"]),
                )
            )

    deterministic = None
    deterministic_result_manifest = None
    if args.determinism_archive is not None:
        with ZipFile(args.determinism_archive) as rerun:
            deterministic = hashes == member_hashes(rerun)
    if args.determinism_result_manifest is not None:
        deterministic_result_manifest = (
            args.result_manifest.read_bytes()
            == args.determinism_result_manifest.read_bytes()
        )
        deterministic = (
            deterministic_result_manifest
            if deterministic is None
            else deterministic and deterministic_result_manifest
        )

    audit_csv = args.output_dir / "packing_audit.csv"
    hash_csv = args.output_dir / "archive_member_hashes.csv"
    summary_md = args.output_dir / "packing_audit.md"
    write_csv(audit_csv, [asdict(audit) for audit in audits])
    write_csv(
        hash_csv,
        [
            {"member": member, "sha256": digest}
            for member, digest in sorted(hashes.items())
        ],
    )
    write_summary(summary_md, audits, deterministic)
    audit_manifest = {
        "run_manifest_sha256": sha256_file(args.run_manifest),
        "result_manifest_sha256": sha256_file(args.result_manifest),
        "archive_sha256": sha256_file(args.archive),
        "archive_member_hash_manifest_sha256": sha256_file(hash_csv),
        "audit_csv_sha256": sha256_file(audit_csv),
        "audit_summary_sha256": sha256_file(summary_md),
        "jobs": len(audits),
        "tasks": len({audit.task_id for audit in audits}),
        "generated_boards": sum(audit.generated_board_count for audit in audits),
        "packed_parts": sum(audit.packed_part_count for audit in audits),
        "deterministic_member_content": deterministic,
        "deterministic_result_manifest": deterministic_result_manifest,
        "passed": all(audit.passed for audit in audits)
        and deterministic is not False,
    }
    audit_manifest_path = args.output_dir / "audit_manifest.json"
    audit_manifest_path.write_text(
        json.dumps(audit_manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    package_manifest = {
        "package_status": "frozen",
        "passed": audit_manifest["passed"],
        "design": {
            "independent_unit": "factory_task",
            "independent_tasks": audit_manifest["tasks"],
            "nested_packing_jobs": audit_manifest["jobs"],
            "generated_boards_retained": audit_manifest["generated_boards"],
            "packed_parts": audit_manifest["packed_parts"],
            "board_selection": "none",
        },
        "determinism": {
            "archive_member_content": deterministic,
            "result_manifest": deterministic_result_manifest,
        },
        "files": {
            "layout_archive": {
                "path": str(args.archive.resolve()),
                "sha256": sha256_file(args.archive),
                "member_count": len(hashes),
            },
            "packing_result_manifest": {
                "path": str(args.result_manifest.resolve()),
                "sha256": sha256_file(args.result_manifest),
            },
            "packing_run_manifest": {
                "path": str(args.run_manifest.resolve()),
                "sha256": sha256_file(args.run_manifest),
            },
            "pre_run_freeze_manifest": {
                "path": str(args.freeze_manifest.resolve()),
                "sha256": sha256_file(args.freeze_manifest),
            },
            "archive_member_hashes": {
                "path": str(hash_csv.resolve()),
                "sha256": sha256_file(hash_csv),
            },
            "job_audit": {
                "path": str(audit_csv.resolve()),
                "sha256": sha256_file(audit_csv),
            },
            "audit_summary": {
                "path": str(summary_md.resolve()),
                "sha256": sha256_file(summary_md),
            },
            "audit_manifest": {
                "path": str(audit_manifest_path.resolve()),
                "sha256": sha256_file(audit_manifest_path),
            },
        },
    }
    (args.output_dir / "frozen_layout_package_manifest.json").write_text(
        json.dumps(package_manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"jobs={len(audits)}")
    print(f"boards={audit_manifest['generated_boards']}")
    print(f"parts={audit_manifest['packed_parts']}")
    print(f"deterministic={deterministic}")
    print(f"verdict={'PASS' if audit_manifest['passed'] else 'FAIL'}")
    if not audit_manifest["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
