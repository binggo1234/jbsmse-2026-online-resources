from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
import zipfile
from collections import Counter, defaultdict
from dataclasses import asdict, fields
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace
from typing import Iterable, Iterator


ROOT = Path(__file__).resolve().parents[1]
STAGE7_ROOT = Path(
    "<STAGE7_REPOSITORY>"
)
LAYOUT_ARCHIVE = (
    ROOT
    / "outputs/holdout_preflight_v1/packing_outputs/holdout_kerf_layouts.zip"
)
PACKING_RESULTS = (
    ROOT
    / "outputs/holdout_preflight_v1/packing_outputs/packing_result_manifest.csv"
)
FROZEN_LAYOUT_PACKAGE = (
    ROOT
    / "outputs/holdout_preflight_v1/packing_audit/"
    "frozen_layout_package_manifest.json"
)
OUTPUT_DIR = ROOT / "outputs/holdout_route_experiment_v1"
BOARD_INDEX = OUTPUT_DIR / "board_geometry_index.csv"
PILOT_SAMPLE = OUTPUT_DIR / "runtime_pilot_sample.csv"
PILOT_JOBS = OUTPUT_DIR / "runtime_pilot_jobs.csv"
PILOT_RESULTS = OUTPUT_DIR / "runtime_pilot_results.csv"
FULL_JOBS = OUTPUT_DIR / "frozen_route_jobs.csv"
FREEZE_MANIFEST = OUTPUT_DIR / "route_run_freeze_manifest.json"
FULL_RESULTS = OUTPUT_DIR / "route_results.csv"

METHODS = (
    "process_aware_beam_adaptive_polished",
    "process_aware_beam",
    "topology_process_aware",
    "process_local_search_multistart",
    "endpoint_aware_gtsp",
)
PILOT_SELECTION_SEED = 20260726
PILOT_SCHEDULE_SEED = 20260727
FULL_SCHEDULE_SEED = 20260728
ALGORITHM_SEED = 20260502
PILOT_MINIMUM_PER_BIN = 20
PILOT_TIMEOUT_SECONDS = 30.0
TIMEOUT_MULTIPLIER = 10.0
TIMEOUT_ROUNDING_SECONDS = 5.0
MINIMUM_FULL_TIMEOUT_SECONDS = 30.0

BOARD_FIELDS = (
    "run_id",
    "run_order",
    "task_id",
    "packing_seed",
    "placements_member",
    "board_id",
    "rectangle_count",
    "rectangle_count_bin",
    "geometry_sha256",
)
PILOT_RESULT_FIELDS = (
    "schedule_order",
    "job_id",
    "task_id",
    "packing_seed",
    "placements_member",
    "board_id",
    "rectangle_count",
    "rectangle_count_bin",
    "method",
    "status",
    "runtime_ms",
    "error_class",
)
FULL_PREFIX_FIELDS = (
    "job_id",
    "schedule_order",
    "status",
    "error_class",
    "error_message",
)


def _load_stage7():
    src = str(STAGE7_ROOT / "src")
    experiments = str(STAGE7_ROOT / "experiments")
    if src not in sys.path:
        sys.path.insert(0, src)
    if experiments not in sys.path:
        sys.path.insert(0, experiments)

    from cnc_cutting.cutting_units import build_candidate_cutting_units
    from cnc_cutting.io import (
        PLACEMENT_GEOMETRY_STORED,
        load_chapter2_config_from_zip,
        load_chapter2_layouts_from_zip,
        tool_config_from_chapter2_config,
    )
    from cnc_cutting.models import Panel
    from run_chapter2_batch import BatchRouteRow, build_planners, run_plan
    from process_options import (
        build_process_model_from_args,
        build_tool_event_gate_from_args,
    )
    from task_timeout import TaskTimeoutError, task_timeout

    return SimpleNamespace(
        build_candidate_cutting_units=build_candidate_cutting_units,
        placement_geometry_stored=PLACEMENT_GEOMETRY_STORED,
        load_config=load_chapter2_config_from_zip,
        load_layouts=load_chapter2_layouts_from_zip,
        tool_config=tool_config_from_chapter2_config,
        Panel=Panel,
        BatchRouteRow=BatchRouteRow,
        build_planners=build_planners,
        run_plan=run_plan,
        build_process_model=build_process_model_from_args,
        build_tool_event_gate=build_tool_event_gate_from_args,
        TaskTimeoutError=TaskTimeoutError,
        task_timeout=task_timeout,
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def stable_hash(*values: object) -> str:
    payload = "|".join(str(value) for value in values)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def rectangle_count_bin(count: int) -> str:
    if count <= 5:
        return "002_005"
    if count <= 10:
        return "006_010"
    if count <= 15:
        return "011_015"
    if count <= 20:
        return "016_020"
    return "021_029"


def canonical_board_id(value: str) -> str:
    text = str(value).strip()
    try:
        number = float(text)
    except ValueError:
        return text
    return str(int(number)) if number.is_integer() else text


def board_sort_key(value: str) -> tuple[int, float | str]:
    try:
        return (0, float(value))
    except ValueError:
        return (1, value)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(
    path: Path,
    fieldnames: Iterable[str],
    rows: Iterable[dict[str, object]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fieldnames),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def append_csv(
    path: Path,
    fieldnames: Iterable[str],
    row: dict[str, object],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fieldnames),
            lineterminator="\n",
        )
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def geometry_digest(rows: list[dict[str, str]]) -> str:
    normalized = sorted(
        (
            str(row.get("uid", "")),
            f"{float(row['x']):.9f}",
            f"{float(row['y']):.9f}",
            f"{float(row['w']):.9f}",
            f"{float(row['h']):.9f}",
        )
        for row in rows
    )
    payload = "\n".join(",".join(item) for item in normalized)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def build_board_index(
    archive_path: Path = LAYOUT_ARCHIVE,
    packing_results_path: Path = PACKING_RESULTS,
) -> list[dict[str, object]]:
    packing_rows = read_csv(packing_results_path)
    output: list[dict[str, object]] = []
    with zipfile.ZipFile(archive_path) as archive:
        for packing in packing_rows:
            member = packing["placements_member"]
            text = archive.read(member).decode("utf-8-sig").splitlines()
            by_board: dict[str, list[dict[str, str]]] = defaultdict(list)
            for row in csv.DictReader(text):
                by_board[canonical_board_id(row["board"])].append(row)
            for board_id in sorted(by_board, key=board_sort_key):
                rows = by_board[board_id]
                count = len(rows)
                output.append(
                    {
                        "run_id": packing["run_id"],
                        "run_order": int(packing["run_order"]),
                        "task_id": packing["task_id"],
                        "packing_seed": int(packing["packing_seed"]),
                        "placements_member": member,
                        "board_id": board_id,
                        "rectangle_count": count,
                        "rectangle_count_bin": rectangle_count_bin(count),
                        "geometry_sha256": geometry_digest(rows),
                    }
                )
    return output


def select_runtime_pilot_boards(
    board_rows: list[dict[str, object]],
    minimum_per_bin: int = PILOT_MINIMUM_PER_BIN,
    seed: int = PILOT_SELECTION_SEED,
) -> list[dict[str, object]]:
    selected_keys: set[tuple[str, str]] = set()
    selected: list[dict[str, object]] = []
    by_member: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in board_rows:
        by_member[str(row["placements_member"])].append(row)

    for member in sorted(by_member):
        row = min(
            by_member[member],
            key=lambda item: stable_hash(
                seed,
                item["placements_member"],
                item["board_id"],
            ),
        )
        key = (str(row["placements_member"]), str(row["board_id"]))
        selected_keys.add(key)
        selected.append(row)

    all_bins = sorted({str(row["rectangle_count_bin"]) for row in board_rows})
    for count_bin in all_bins:
        current = sum(
            str(row["rectangle_count_bin"]) == count_bin for row in selected
        )
        candidates = sorted(
            (
                row
                for row in board_rows
                if str(row["rectangle_count_bin"]) == count_bin
                and (
                    str(row["placements_member"]),
                    str(row["board_id"]),
                )
                not in selected_keys
            ),
            key=lambda item: stable_hash(
                seed,
                item["placements_member"],
                item["board_id"],
            ),
        )
        for row in candidates[: max(0, minimum_per_bin - current)]:
            key = (str(row["placements_member"]), str(row["board_id"]))
            selected_keys.add(key)
            selected.append(row)

    return sorted(
        selected,
        key=lambda item: (
            str(item["rectangle_count_bin"]),
            stable_hash(seed, item["placements_member"], item["board_id"]),
        ),
    )


def make_jobs(
    board_rows: list[dict[str, object]],
    methods: tuple[str, ...],
    schedule_seed: int,
) -> list[dict[str, object]]:
    by_member: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in board_rows:
        by_member[str(row["placements_member"])].append(row)
    ordered_members = sorted(
        by_member,
        key=lambda member: stable_hash(schedule_seed, "member", member),
    )

    jobs: list[dict[str, object]] = []
    for member in ordered_members:
        boards = sorted(
            by_member[member],
            key=lambda row: stable_hash(
                schedule_seed,
                "board",
                row["placements_member"],
                row["board_id"],
            ),
        )
        for board in boards:
            ordered_methods = sorted(
                methods,
                key=lambda method: stable_hash(
                    schedule_seed,
                    "method",
                    board["placements_member"],
                    board["board_id"],
                    method,
                ),
            )
            for method in ordered_methods:
                job_id = stable_hash(
                    "route-job-v1",
                    board["placements_member"],
                    board["board_id"],
                    method,
                )[:20]
                jobs.append(
                    {
                        "schedule_order": len(jobs) + 1,
                        "job_id": job_id,
                        **board,
                        "method": method,
                    }
                )
    return jobs


def stage7_args() -> SimpleNamespace:
    return SimpleNamespace(
        support_policy="all_edges",
        min_support_count=1,
        min_support_ratio=0.75,
        min_area_normalized_support=0.0,
        adjacency_support_weight=1.0,
        disable_tool_event_gate=False,
        tool_event_min_travel_saving=25.0,
        tool_event_min_travel_saving_ratio=0.0,
        tool_event_min_machining_saving=1e-9,
        repeat_cut_policy="hard",
        algorithm_seed=ALGORITHM_SEED,
    )


def iter_loaded_boards(
    jobs: list[dict[str, str]],
    stage7,
) -> Iterator[
    tuple[
        list[dict[str, str]],
        object,
        object,
        object,
        object,
        object,
        tuple[object, ...],
    ]
]:
    args = stage7_args()
    tool_event_gate = stage7.build_tool_event_gate(args)
    by_member: dict[str, list[dict[str, str]]] = defaultdict(list)
    for job in jobs:
        by_member[job["placements_member"]].append(job)

    for member_jobs in by_member.values():
        member = member_jobs[0]["placements_member"]
        config = stage7.load_config(LAYOUT_ARCHIVE, placements_member=member)
        tool = stage7.tool_config(config)
        geometry_mode = str(
            config.get(
                "PLACEMENT_GEOMETRY_MODE",
                stage7.placement_geometry_stored,
            )
        )
        board_ids = sorted(
            {job["board_id"] for job in member_jobs},
            key=board_sort_key,
        )
        layouts = stage7.load_layouts(
            LAYOUT_ARCHIVE,
            placements_member=member,
            board_ids=board_ids,
            placement_geometry_mode=geometry_mode,
            tool_diameter=tool.tool_diameter,
        )
        if len(layouts) != len(board_ids):
            raise ValueError(
                f"layout count mismatch for {member}: "
                f"{len(layouts)} != {len(board_ids)}"
            )
        layout_by_board = dict(zip(board_ids, layouts))
        by_board: dict[str, list[dict[str, str]]] = defaultdict(list)
        for job in member_jobs:
            by_board[job["board_id"]].append(job)
        for board_id in board_ids:
            layout = layout_by_board[board_id]
            panel = stage7.Panel(
                layout.panel_id,
                layout.panel_width,
                layout.panel_height,
            )
            process_model = stage7.build_process_model(
                layout,
                args,
                tool=tool,
                max_collinear_gap=tool.min_channel_width,
            )
            units = stage7.build_candidate_cutting_units(
                layout,
                tool,
                max_collinear_gap=tool.min_channel_width,
            )
            yield (
                by_board[board_id],
                layout,
                panel,
                tool,
                process_model,
                tool_event_gate,
                units,
            )


def run_runtime_pilot(
    jobs: list[dict[str, str]],
    output_path: Path,
    timeout_seconds: float = PILOT_TIMEOUT_SECONDS,
    resume: bool = False,
) -> None:
    stage7 = _load_stage7()
    completed = (
        {row["job_id"] for row in read_csv(output_path)}
        if resume and output_path.exists()
        else set()
    )
    if not resume and output_path.exists():
        output_path.unlink()
    args = stage7_args()

    for (
        board_jobs,
        layout,
        panel,
        tool,
        process_model,
        tool_event_gate,
        units,
    ) in iter_loaded_boards(jobs, stage7):
        methods = tuple(job["method"] for job in board_jobs)
        specs = {
            spec.method: spec
            for spec in stage7.build_planners(
                methods,
                units,
                panel,
                tool,
                process_model,
                tool_event_gate,
                len(layout.rectangles),
                args.repeat_cut_policy,
                algorithm_seed=args.algorithm_seed,
            )
        }
        for job in board_jobs:
            if job["job_id"] in completed:
                continue
            started = perf_counter()
            status = "completed"
            error_class = ""
            try:
                with stage7.task_timeout(timeout_seconds):
                    _ = specs[job["method"]].planner()
            except stage7.TaskTimeoutError:
                status = "timed_out"
                error_class = "TaskTimeoutError"
            except Exception as exc:  # pragma: no cover - persisted for audit
                status = "failed"
                error_class = type(exc).__name__
            runtime_ms = (perf_counter() - started) * 1000.0
            row = {
                field: job[field]
                for field in PILOT_RESULT_FIELDS
                if field in job
            }
            row.update(
                {
                    "status": status,
                    "runtime_ms": f"{runtime_ms:.6f}",
                    "error_class": error_class,
                }
            )
            append_csv(output_path, PILOT_RESULT_FIELDS, row)
            completed.add(job["job_id"])
            print(
                f"pilot {len(completed)}/{len(jobs)} "
                f"{job['method']} {status} {runtime_ms:.3f} ms",
                flush=True,
            )


def freeze_timeout_seconds(
    successful_runtime_ms: Iterable[float],
    multiplier: float = TIMEOUT_MULTIPLIER,
    rounding_seconds: float = TIMEOUT_ROUNDING_SECONDS,
    minimum_seconds: float = MINIMUM_FULL_TIMEOUT_SECONDS,
) -> float:
    values = list(successful_runtime_ms)
    if not values:
        raise ValueError("runtime pilot has no successful method runs")
    scaled_seconds = max(values) / 1000.0 * multiplier
    rounded = math.ceil(scaled_seconds / rounding_seconds) * rounding_seconds
    return max(minimum_seconds, rounded)


def estimate_full_runtime_seconds(
    board_rows: list[dict[str, str]],
    pilot_rows: list[dict[str, str]],
    methods: tuple[str, ...] = METHODS,
) -> float:
    values: dict[tuple[str, str], list[float]] = defaultdict(list)
    method_values: dict[str, list[float]] = defaultdict(list)
    for row in pilot_rows:
        if row["status"] != "completed":
            continue
        runtime = float(row["runtime_ms"]) / 1000.0
        values[(row["rectangle_count_bin"], row["method"])].append(runtime)
        method_values[row["method"]].append(runtime)
    estimate = 0.0
    for board in board_rows:
        count_bin = board["rectangle_count_bin"]
        for method in methods:
            candidates = values.get((count_bin, method)) or method_values[method]
            estimate += sorted(candidates)[len(candidates) // 2]
    return estimate


def git_commit(path: Path) -> str:
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=path,
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def verify_frozen_layout_input() -> dict:
    package = json.loads(FROZEN_LAYOUT_PACKAGE.read_text(encoding="utf-8"))
    expected = package["files"]["layout_archive"]["sha256"]
    actual = sha256_file(LAYOUT_ARCHIVE)
    if actual != expected:
        raise ValueError(
            f"layout archive hash mismatch: expected {expected}, got {actual}"
        )
    return package


def freeze_full_plan() -> dict:
    verify_frozen_layout_input()
    boards = read_csv(BOARD_INDEX)
    pilot_rows = read_csv(PILOT_RESULTS)
    expected_pilot_jobs = read_csv(PILOT_JOBS)
    if len(pilot_rows) != len(expected_pilot_jobs):
        raise ValueError(
            f"runtime pilot incomplete: {len(pilot_rows)}/{len(expected_pilot_jobs)}"
        )
    if Counter(row["status"] for row in pilot_rows) != Counter(
        {"completed": len(pilot_rows)}
    ):
        raise ValueError(
            f"runtime pilot has non-completions: "
            f"{dict(Counter(row['status'] for row in pilot_rows))}"
        )

    timeout_seconds = freeze_timeout_seconds(
        float(row["runtime_ms"])
        for row in pilot_rows
        if row["status"] == "completed"
    )
    jobs = make_jobs(boards, METHODS, FULL_SCHEDULE_SEED)
    write_csv(FULL_JOBS, jobs[0].keys(), jobs)
    manifest = {
        "freeze_status": "frozen_before_route_quality_inspection",
        "independent_unit": "factory_task",
        "independent_task_count": 20,
        "nested_packing_seed_count": 3,
        "board_count": len(boards),
        "method_count": len(METHODS),
        "method_task_count": len(jobs),
        "methods": list(METHODS),
        "method_parameters": {
            "source": "Stage7 experiments/run_chapter2_batch.py::build_planners",
            "algorithm_seed": ALGORITHM_SEED,
            "support_policy": "all_edges",
            "min_support_count": 1,
            "min_support_ratio": 0.75,
            "min_area_normalized_support": 0.0,
            "adjacency_support_weight": 1.0,
            "repeat_cut_policy": "hard",
            "tool_event_gate": {
                "enabled": True,
                "min_travel_saving": 25.0,
                "min_travel_saving_ratio": 0.0,
                "min_machining_saving": 1e-9,
            },
        },
        "runtime_pilot": {
            "selection_seed": PILOT_SELECTION_SEED,
            "schedule_seed": PILOT_SCHEDULE_SEED,
            "minimum_per_rectangle_count_bin": PILOT_MINIMUM_PER_BIN,
            "board_count": len(read_csv(PILOT_SAMPLE)),
            "method_task_count": len(pilot_rows),
            "quality_fields_written": [],
            "status_counts": dict(Counter(row["status"] for row in pilot_rows)),
            "maximum_successful_runtime_ms": max(
                float(row["runtime_ms"]) for row in pilot_rows
            ),
        },
        "full_run": {
            "schedule_seed": FULL_SCHEDULE_SEED,
            "schedule_structure": (
                "hash-randomized placement-member blocks; hash-randomized boards "
                "within block; hash-randomized method order within board"
            ),
            "timeout_seconds": timeout_seconds,
            "timeout_formula": (
                "max(30 s, ceil_to_5_s(10 * maximum successful pilot runtime))"
            ),
            "estimated_single_process_cpu_seconds": estimate_full_runtime_seconds(
                boards,
                pilot_rows,
            ),
            "resume_policy": (
                "each scheduled job is written once; completed, timed-out, and "
                "failed jobs are all terminal; no quality-dependent retry"
            ),
        },
        "software": {
            "stage7_root": str(STAGE7_ROOT),
            "stage7_git_commit": git_commit(STAGE7_ROOT),
            "orchestrator": str(Path(__file__).resolve()),
            "orchestrator_sha256": sha256_file(Path(__file__).resolve()),
        },
        "inputs": {
            "layout_archive": {
                "path": str(LAYOUT_ARCHIVE.resolve()),
                "sha256": sha256_file(LAYOUT_ARCHIVE),
            },
            "packing_results": {
                "path": str(PACKING_RESULTS.resolve()),
                "sha256": sha256_file(PACKING_RESULTS),
            },
            "board_index": {
                "path": str(BOARD_INDEX.resolve()),
                "sha256": sha256_file(BOARD_INDEX),
            },
            "pilot_sample": {
                "path": str(PILOT_SAMPLE.resolve()),
                "sha256": sha256_file(PILOT_SAMPLE),
            },
            "pilot_jobs": {
                "path": str(PILOT_JOBS.resolve()),
                "sha256": sha256_file(PILOT_JOBS),
            },
            "pilot_results": {
                "path": str(PILOT_RESULTS.resolve()),
                "sha256": sha256_file(PILOT_RESULTS),
            },
            "full_jobs": {
                "path": str(FULL_JOBS.resolve()),
                "sha256": sha256_file(FULL_JOBS),
            },
        },
    }
    FREEZE_MANIFEST.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return manifest


def verify_full_plan() -> dict:
    manifest = json.loads(FREEZE_MANIFEST.read_text(encoding="utf-8"))
    for item in manifest["inputs"].values():
        path = Path(item["path"])
        actual = sha256_file(path)
        if actual != item["sha256"]:
            raise ValueError(f"frozen input hash mismatch for {path}")
    if git_commit(STAGE7_ROOT) != manifest["software"]["stage7_git_commit"]:
        raise ValueError("Stage7 git commit changed after route-plan freeze")
    if sha256_file(Path(__file__).resolve()) != manifest["software"][
        "orchestrator_sha256"
    ]:
        raise ValueError("route orchestrator changed after route-plan freeze")
    return manifest


def run_full_routes(
    jobs: list[dict[str, str]],
    output_path: Path,
    timeout_seconds: float,
    resume: bool = False,
) -> None:
    stage7 = _load_stage7()
    output_fields = FULL_PREFIX_FIELDS + tuple(
        field.name for field in fields(stage7.BatchRouteRow)
    )
    completed = (
        {row["job_id"] for row in read_csv(output_path)}
        if resume and output_path.exists()
        else set()
    )
    if not resume and output_path.exists():
        output_path.unlink()
    args = stage7_args()

    for (
        board_jobs,
        layout,
        panel,
        tool,
        process_model,
        tool_event_gate,
        units,
    ) in iter_loaded_boards(jobs, stage7):
        methods = tuple(job["method"] for job in board_jobs)
        specs = {
            spec.method: spec
            for spec in stage7.build_planners(
                methods,
                units,
                panel,
                tool,
                process_model,
                tool_event_gate,
                len(layout.rectangles),
                args.repeat_cut_policy,
                algorithm_seed=args.algorithm_seed,
            )
        }
        for job in board_jobs:
            if job["job_id"] in completed:
                continue
            started = perf_counter()
            status = "completed"
            error_class = ""
            error_message = ""
            batch_values: dict[str, object] = {}
            try:
                with stage7.task_timeout(timeout_seconds):
                    result = stage7.run_plan(
                        LAYOUT_ARCHIVE,
                        job["placements_member"],
                        job["board_id"],
                        args.support_policy,
                        args.min_support_count,
                        args.min_support_ratio,
                        args.min_area_normalized_support,
                        args.adjacency_support_weight,
                        tool_event_gate.enabled,
                        tool_event_gate.min_travel_saving_per_extra_event,
                        tool_event_gate.min_travel_saving_ratio_per_extra_event,
                        tool_event_gate.min_machining_saving,
                        args.repeat_cut_policy,
                        specs[job["method"]],
                        layout,
                        panel,
                        tool,
                        units,
                        process_model,
                    )
                batch_values = asdict(result)
            except stage7.TaskTimeoutError as exc:
                status = "timed_out"
                error_class = type(exc).__name__
                error_message = str(exc)
            except Exception as exc:  # pragma: no cover - persisted for audit
                status = "failed"
                error_class = type(exc).__name__
                error_message = str(exc)[:500]
            row: dict[str, object] = {
                "job_id": job["job_id"],
                "schedule_order": job["schedule_order"],
                "status": status,
                "error_class": error_class,
                "error_message": error_message,
            }
            for field in output_fields[len(FULL_PREFIX_FIELDS) :]:
                row[field] = batch_values.get(field, "")
            append_csv(output_path, output_fields, row)
            completed.add(job["job_id"])
            elapsed_ms = (perf_counter() - started) * 1000.0
            print(
                f"route {len(completed)}/{len(jobs)} "
                f"{job['method']} {status} {elapsed_ms:.3f} ms",
                flush=True,
            )


def prepare() -> None:
    package = verify_frozen_layout_input()
    boards = build_board_index()
    if len(boards) != package["design"]["generated_boards_retained"]:
        raise ValueError(
            f"board count mismatch: {len(boards)} != "
            f"{package['design']['generated_boards_retained']}"
        )
    write_csv(BOARD_INDEX, BOARD_FIELDS, boards)
    sample = select_runtime_pilot_boards(boards)
    write_csv(PILOT_SAMPLE, BOARD_FIELDS, sample)
    jobs = make_jobs(sample, METHODS, PILOT_SCHEDULE_SEED)
    write_csv(PILOT_JOBS, jobs[0].keys(), jobs)
    print(f"board index: {len(boards)}")
    print(f"pilot boards: {len(sample)}")
    print(f"pilot method tasks: {len(jobs)}")
    print(f"pilot bins: {dict(Counter(row['rectangle_count_bin'] for row in sample))}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("prepare")
    pilot = subparsers.add_parser("pilot")
    pilot.add_argument("--resume", action="store_true")
    subparsers.add_parser("freeze")
    full = subparsers.add_parser("run")
    full.add_argument("--resume", action="store_true")
    subparsers.add_parser("verify")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "prepare":
        prepare()
    elif args.command == "pilot":
        jobs = read_csv(PILOT_JOBS)
        run_runtime_pilot(jobs, PILOT_RESULTS, resume=args.resume)
    elif args.command == "freeze":
        manifest = freeze_full_plan()
        print(json.dumps(manifest["full_run"], indent=2, ensure_ascii=False))
    elif args.command == "run":
        manifest = verify_full_plan()
        jobs = read_csv(FULL_JOBS)
        run_full_routes(
            jobs,
            FULL_RESULTS,
            timeout_seconds=float(manifest["full_run"]["timeout_seconds"]),
            resume=args.resume,
        )
    elif args.command == "verify":
        manifest = verify_full_plan()
        print(
            f"verified {manifest['method_task_count']} frozen route method tasks"
        )


if __name__ == "__main__":
    main()
