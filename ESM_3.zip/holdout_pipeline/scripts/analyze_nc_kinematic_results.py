from __future__ import annotations

import argparse
import csv
import json
import math
import sqlite3
from collections import defaultdict
from pathlib import Path
from statistics import mean, median
from typing import Iterable

from scripts.prepare_nc_kinematic_evaluation import FREEZE_MANIFEST
from scripts.run_nc_kinematic_evaluation import FULL_OUTPUT, PILOT_OUTPUT


PROPOSED = "process_aware_beam_adaptive_polished"
BASELINES = (
    "topology_process_aware",
    "process_aware_beam",
    "endpoint_aware_gtsp",
    "process_local_search_multistart",
)
TIME_FIELDS = (
    "continuous_cut_time_s",
    "continuous_rapid_time_s",
    "continuous_z_time_s",
    "continuous_noncut_time_s",
    "continuous_total_time_s",
    "stop_cut_time_s",
    "stop_rapid_time_s",
    "stop_z_time_s",
    "stop_noncut_time_s",
    "stop_total_time_s",
)
GEOMETRY_FIELDS = (
    "cutting_distance_mm",
    "rapid_xy_distance_mm",
    "setup_xy_distance_mm",
    "low_clearance_xy_distance_mm",
    "safe_lift_xy_distance_mm",
    "return_xy_distance_mm",
    "z_retract_distance_mm",
    "z_plunge_distance_mm",
    "retract_count",
    "plunge_count",
    "direction_change_count",
    "nc_block_count",
)


def write_csv(
    path: Path,
    fieldnames: Iterable[str],
    rows: Iterable[dict[str, object]],
) -> None:
    rows = list(rows)
    if not rows:
        raise ValueError(f"refusing to write empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fieldnames), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def rank(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=values.__getitem__)
    ranks = [0.0] * len(values)
    index = 0
    while index < len(order):
        end = index + 1
        while end < len(order) and values[order[end]] == values[order[index]]:
            end += 1
        tied_rank = (index + 1 + end) / 2.0
        for position in order[index:end]:
            ranks[position] = tied_rank
        index = end
    return ranks


def pearson(first: list[float], second: list[float]) -> float:
    first_mean = mean(first)
    second_mean = mean(second)
    numerator = sum(
        (x - first_mean) * (y - second_mean) for x, y in zip(first, second)
    )
    denominator = math.sqrt(
        sum((x - first_mean) ** 2 for x in first)
        * sum((y - second_mean) ** 2 for y in second)
    )
    return numerator / denominator if denominator > 0.0 else float("nan")


def spearman(first: list[float], second: list[float]) -> float:
    return pearson(rank(first), rank(second))


def gate_report(
    connection: sqlite3.Connection,
    *,
    expected_jobs: int,
    expected_scenarios: int,
    tolerance_mm: float,
) -> dict[str, object]:
    job_count = connection.execute("SELECT COUNT(*) FROM job_results").fetchone()[0]
    completed = connection.execute(
        "SELECT COUNT(*) FROM job_results WHERE status = 'completed'"
    ).fetchone()[0]
    failed = job_count - completed
    audit_failures = connection.execute(
        "SELECT COUNT(*) FROM job_results WHERE audit_passed != 1"
    ).fetchone()[0]
    reference_mismatches = connection.execute(
        "SELECT COUNT(*) FROM job_results WHERE reference_match != 1"
    ).fetchone()[0]
    maximum_error = connection.execute(
        "SELECT COALESCE(MAX(maximum_coordinate_error_mm), 0) FROM job_results"
    ).fetchone()[0]
    scenario_rows = connection.execute(
        "SELECT COUNT(*) FROM scenario_times"
    ).fetchone()[0]
    malformed_scenario_jobs = connection.execute(
        """
        SELECT COUNT(*) FROM (
            SELECT job_id, COUNT(*) AS n
            FROM scenario_times
            GROUP BY job_id
            HAVING n != ?
        )
        """,
        (expected_scenarios,),
    ).fetchone()[0]
    passed = (
        job_count == expected_jobs
        and completed == expected_jobs
        and failed == 0
        and audit_failures == 0
        and reference_mismatches == 0
        and maximum_error <= tolerance_mm + 1e-12
        and scenario_rows == expected_jobs * expected_scenarios
        and malformed_scenario_jobs == 0
    )
    return {
        "passed": passed,
        "expected_jobs": expected_jobs,
        "job_count": job_count,
        "completed_jobs": completed,
        "failed_jobs": failed,
        "audit_failures": audit_failures,
        "reference_mismatches": reference_mismatches,
        "maximum_coordinate_error_mm": maximum_error,
        "coordinate_tolerance_mm": tolerance_mm,
        "expected_scenarios_per_job": expected_scenarios,
        "scenario_row_count": scenario_rows,
        "malformed_scenario_jobs": malformed_scenario_jobs,
    }


def task_scenario_rows(connection: sqlite3.Connection) -> list[dict[str, object]]:
    select_times = ", ".join(f"SUM(s.{field}) AS {field}" for field in TIME_FIELDS)
    query = f"""
        SELECT
            j.task_id,
            j.packing_seed,
            j.method,
            s.scenario,
            SUM(j.source_cutting_length_mm + j.source_travel_mode_cost)
                AS planning_cost,
            {select_times}
        FROM job_results AS j
        JOIN scenario_times AS s ON s.job_id = j.job_id
        WHERE j.status = 'completed'
        GROUP BY j.task_id, j.packing_seed, j.method, s.scenario
    """
    seed_rows = [
        dict(zip([column[0] for column in cursor.description], row))
        for cursor in [connection.execute(query)]
        for row in cursor
    ]
    grouped: dict[tuple[str, str, str], list[dict[str, object]]] = defaultdict(list)
    for row in seed_rows:
        grouped[(row["task_id"], row["method"], row["scenario"])].append(row)
    output: list[dict[str, object]] = []
    for (task_id, method, scenario), rows in sorted(grouped.items()):
        output.append(
            {
                "task_id": task_id,
                "method": method,
                "scenario": scenario,
                "packing_seed_count": len(rows),
                "planning_cost": mean(float(row["planning_cost"]) for row in rows),
                **{
                    field: mean(float(row[field]) for row in rows)
                    for field in TIME_FIELDS
                },
            }
        )
    return output


def geometry_summary_rows(connection: sqlite3.Connection) -> list[dict[str, object]]:
    select_geometry = ", ".join(
        f"SUM({field}) AS {field}" for field in GEOMETRY_FIELDS
    )
    cursor = connection.execute(
        f"""
        SELECT task_id, packing_seed, method, {select_geometry}
        FROM job_results
        WHERE status = 'completed'
        GROUP BY task_id, packing_seed, method
        """
    )
    fieldnames = [column[0] for column in cursor.description]
    seed_rows = [dict(zip(fieldnames, row)) for row in cursor]
    by_task_method: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in seed_rows:
        by_task_method[(row["task_id"], row["method"])].append(row)
    task_rows: list[dict[str, object]] = []
    for (task_id, method), rows in by_task_method.items():
        task_rows.append(
            {
                "task_id": task_id,
                "method": method,
                **{
                    field: mean(float(row[field]) for row in rows)
                    for field in GEOMETRY_FIELDS
                },
            }
        )
    by_method: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in task_rows:
        by_method[row["method"]].append(row)
    return [
        {
            "method": method,
            "factory_task_count": len(rows),
            **{
                field: mean(float(row[field]) for row in rows)
                for field in GEOMETRY_FIELDS
            },
        }
        for method, rows in sorted(by_method.items())
    ]


def comparison_rows(task_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    index = {
        (str(row["task_id"]), str(row["method"]), str(row["scenario"])): row
        for row in task_rows
    }
    scenarios = sorted({str(row["scenario"]) for row in task_rows})
    tasks = sorted({str(row["task_id"]) for row in task_rows})
    output: list[dict[str, object]] = []
    for scenario in scenarios:
        for baseline in BASELINES:
            for time_field in (
                "continuous_noncut_time_s",
                "continuous_total_time_s",
                "stop_noncut_time_s",
                "stop_total_time_s",
            ):
                reductions: list[float] = []
                for task_id in tasks:
                    proposed = float(index[(task_id, PROPOSED, scenario)][time_field])
                    reference = float(index[(task_id, baseline, scenario)][time_field])
                    reductions.append(
                        100.0 * (reference - proposed) / reference
                        if reference > 0.0
                        else float("nan")
                    )
                finite = [value for value in reductions if math.isfinite(value)]
                output.append(
                    {
                        "scenario": scenario,
                        "baseline": baseline,
                        "time_metric": time_field,
                        "factory_task_count": len(finite),
                        "mean_reduction_pct": mean(finite),
                        "median_reduction_pct": median(finite),
                        "minimum_reduction_pct": min(finite),
                        "maximum_reduction_pct": max(finite),
                        "positive_task_count": sum(value > 0.0 for value in finite),
                        "zero_task_count": sum(value == 0.0 for value in finite),
                        "negative_task_count": sum(value < 0.0 for value in finite),
                    }
                )
    return output


def scenario_robustness_rows(
    comparisons: list[dict[str, object]],
) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in comparisons:
        grouped[(str(row["baseline"]), str(row["time_metric"]))].append(row)
    output: list[dict[str, object]] = []
    for (baseline, metric), rows in sorted(grouped.items()):
        mean_reductions = [float(row["mean_reduction_pct"]) for row in rows]
        output.append(
            {
                "baseline": baseline,
                "time_metric": metric,
                "scenario_count": len(rows),
                "minimum_mean_reduction_pct": min(mean_reductions),
                "median_mean_reduction_pct": median(mean_reductions),
                "maximum_mean_reduction_pct": max(mean_reductions),
                "positive_mean_scenario_count": sum(
                    value > 0.0 for value in mean_reductions
                ),
                "all_tasks_positive_scenario_count": sum(
                    int(row["positive_task_count"]) == int(row["factory_task_count"])
                    for row in rows
                ),
            }
        )
    return output


def correlation_rows(task_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in task_rows:
        grouped[(str(row["method"]), str(row["scenario"]))].append(row)
    output: list[dict[str, object]] = []
    for (method, scenario), rows in sorted(grouped.items()):
        planning = [float(row["planning_cost"]) for row in rows]
        for metric in (
            "continuous_noncut_time_s",
            "continuous_total_time_s",
            "stop_noncut_time_s",
            "stop_total_time_s",
        ):
            nc_values = [float(row[metric]) for row in rows]
            output.append(
                {
                    "method": method,
                    "scenario": scenario,
                    "time_metric": metric,
                    "factory_task_count": len(rows),
                    "spearman_rho": spearman(planning, nc_values),
                }
            )
    return output


def analyze(track: str) -> None:
    manifest = json.loads(FREEZE_MANIFEST.read_text(encoding="utf-8"))
    if track == "pilot":
        output_dir = PILOT_OUTPUT
        expected_jobs = int(manifest["pilot"]["job_count"])
    else:
        output_dir = FULL_OUTPUT
        expected_jobs = int(manifest["full_run"]["job_count"])
    database = output_dir / "results.sqlite"
    connection = sqlite3.connect(f"file:{database}?mode=ro", uri=True)
    gate = gate_report(
        connection,
        expected_jobs=expected_jobs,
        expected_scenarios=len(manifest["kinematic_scenarios"]),
        tolerance_mm=float(manifest["nc_template"]["nc_tolerance_mm"]),
    )
    (output_dir / "gate_report.json").write_text(
        json.dumps(gate, indent=2) + "\n",
        encoding="utf-8",
    )
    if not gate["passed"]:
        connection.close()
        raise RuntimeError(
            "NC freeze gate failed; timing comparisons were not computed. "
            f"See {output_dir / 'gate_report.json'}"
        )

    tasks = task_scenario_rows(connection)
    comparisons = comparison_rows(tasks)
    robustness = scenario_robustness_rows(comparisons)
    geometry = geometry_summary_rows(connection)
    correlations = correlation_rows(tasks)
    write_csv(output_dir / "task_scenario_metrics.csv", tasks[0].keys(), tasks)
    write_csv(
        output_dir / "scenario_comparisons.csv",
        comparisons[0].keys(),
        comparisons,
    )
    write_csv(
        output_dir / "scenario_robustness_summary.csv",
        robustness[0].keys(),
        robustness,
    )
    write_csv(
        output_dir / "task_equal_geometry_summary.csv",
        geometry[0].keys(),
        geometry,
    )
    write_csv(
        output_dir / "planning_nc_spearman.csv",
        correlations[0].keys(),
        correlations,
    )
    connection.close()
    print(f"{track} NC freeze gate passed")
    print(output_dir / "scenario_robustness_summary.csv")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("track", choices=("pilot", "full"))
    return parser.parse_args()


def main() -> int:
    analyze(parse_args().track)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
