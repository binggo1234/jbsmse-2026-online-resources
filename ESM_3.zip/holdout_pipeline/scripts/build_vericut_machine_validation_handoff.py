#!/usr/bin/env python3
"""Build a self-contained handoff package for the VERICUT v3 experiment."""

from __future__ import annotations

import argparse
import csv
import hashlib
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXPERIMENT = (
    ROOT / "outputs" / "vericut_machine_validation_prep_v3_20260730"
)
DEFAULT_NOMINAL_ROOT = (
    ROOT
    / "outputs"
    / "vericut_nominal_results_20260729"
    / "IJAMT_VERICUT_nominal_results_2026-07-29"
    / "vericut_master"
)
DEFAULT_OUTPUT = (
    ROOT / "outputs" / "IJAMT_VERICUT_machine_validation_handoff_v4_20260730"
)

NOMINAL_FILES = (
    "Generic_3Axis_Router_nominal_v1.mch",
    "IJAMT_VERICUT_MASTER_V1.vcproject",
    "IJAMT_T1_6mm_nominal_v1.tls",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def readme_cn() -> str:
    return """# IJAMT VERICUT机床验证交接包：请先读这里

这份交接包把下一轮实验需要的文件集中到一个目录，但必须区分两类材料：

## 1. 可以直接用于实验准备的冻结材料

位于 `01_experiment_package/`：

- 原15个冻结NC程序；
- 5个方法无关的Design-oracle程序；
- 碰撞阴性/阳性、过切阳性和余量阳性对照；
- 机床模型资格表、碰撞矩阵和15次运行清单；
- 中文Windows操作清单；
- PowerShell完成门。

这些文件已经过本地哈希和覆盖检查，不应修改。

## 2. 仅供搭建项目参考的旧标称文件

位于 `02_nominal_reference_only/`：

- `Generic_3Axis_Router_nominal_v1.mch`；
- `IJAMT_VERICUT_MASTER_V1.vcproject`；
- `IJAMT_T1_6mm_nominal_v1.tls`。

它们来自上一轮标称时间复核。旧`.mch`只有运动链，没有完整实体机床CAD和有效行程边界；`.vcproject`关闭了机床碰撞检查；`.tls`中的刀具与刀柄尺寸没有用实际装配校准。因此，这三个文件可以帮助恢复Stock、坐标、NC解释和刀具模板，但不能直接作为“可信碰撞模型”。

## 3. Windows端仍须补齐的材料

填写 `03_to_be_completed/WINDOWS_MACHINE_INPUT_FORM_CN.csv`，并收集：

- 带实体几何的合格`.mch`及其依赖CAD；
- 基于该模型冻结的新`.vcproject`；
- 核验后的`.tls`；
- 机床制造商、型号、控制器和X/Y/Z行程；
- 刀具刃长、量规长度、伸出量和刀柄最大直径；
- 台面、垫板、夹具或真空支撑几何。

如果采用VERICUT库中的完整三轴机床而非工厂真实机床，`model_scope`必须填写`qualified_representative`，论文中也只能表述为“合格的代表性机床模型”。

## 4. 推荐执行顺序

1. 阅读 `01_experiment_package/protocol/WINDOWS_GUI_CHECKLIST_CN.md`；
2. 补齐输入表并建立新的合格主项目；
3. 先跑4个控制程序；
4. 运行5个oracle并导出Design STL；
5. 严格按清单运行15个正式程序；
6. 执行PowerShell完成门；
7. 将生成的结果ZIP传回分析。

交接包的文件哈希记录在根目录`HANDOFF_SHA256.csv`。
"""


def collection_guide_cn() -> str:
    return """# Windows端材料收集说明

## 必须放回的文件

建议在本目录下新建以下结构：

```text
collected_from_windows/
  machine/
    qualified_machine.mch
    machine_cad_dependencies/
  project/
    IJAMT_VERICUT_QUALIFIED_MASTER_V3.vcproject
  tool/
    IJAMT_T1_6mm_qualified_v3.tls
  fixture/
    table_or_spoilboard.step
    fixture_or_vacuum_support.step
  evidence/
    machine_tree.png
    collision_settings.png
    axis_limits.png
    tool_holder_setup.png
    stock_fixture_alignment.png
```

如果机床CAD嵌入`.mch`而没有外部文件，应在输入表中明确写明“embedded”。如果`.mch`引用外部STL、STEP、IGES或VERICUT模型文件，应复制完整依赖目录，不能只复制`.mch`。

## 信息来源

- 制造商、型号与控制器：机床铭牌、控制器系统页或OEM手册；
- X/Y/Z行程：OEM规格或已核验的机床模型限制；
- 刃长与刀具总长：刀具数据表；
- 量规长度、伸出量与刀柄直径：实际装刀记录或VERICUT Tool Manager；
- 台面、垫板与夹具：工装CAD或按实测尺寸建立的几何；
- 工作原点：主项目中的Program Zero/G54定义。

不要仅凭论文参数或旧Generic模型推断真实机床尺寸。
"""


def input_rows() -> list[dict[str, str]]:
    values = [
        ("model_scope", "", "exact_machine或qualified_representative", "缺失"),
        ("machine_manufacturer", "", "铭牌/OEM/VERICUT库记录", "缺失"),
        ("machine_model", "", "铭牌/OEM/VERICUT库记录", "缺失"),
        ("controller_manufacturer_model", "Fanuc fan15m library control", "控制器系统页或库记录", "仅标称参考"),
        ("x_travel_mm", "", "OEM规格或合格.mch", "缺失"),
        ("y_travel_mm", "", "OEM规格或合格.mch", "缺失"),
        ("z_travel_mm", "", "OEM规格或合格.mch", "缺失"),
        ("qualified_machine_mch", "", "Windows文件路径", "缺失"),
        ("machine_cad_dependencies", "", "文件夹路径或embedded", "缺失"),
        ("qualified_master_vcproject", "", "Windows文件路径", "缺失"),
        ("qualified_tool_library_tls", "", "Windows文件路径", "缺失"),
        ("tool_diameter_mm", "6.000", "冻结NC/刀具设置", "已冻结"),
        ("tool_flute_length_mm", "35", "需由实际刀具资料复核", "模板值，未验证"),
        ("tool_gauge_length_mm", "", "实际装刀或Tool Manager", "缺失"),
        ("tool_stickout_mm", "", "实际装刀或Tool Manager", "缺失"),
        ("holder_max_diameter_mm", "约80（旧模板SOR最大半径40）", "实际刀柄/Tool Manager", "推断值，禁止作为实测值"),
        ("table_geometry", "", "CAD或实测建模", "缺失"),
        ("spoilboard_geometry", "", "CAD或实测建模", "缺失"),
        ("fixture_or_vacuum_support_geometry", "", "CAD或实测建模", "缺失"),
        ("stock_xyz_mm", "2440 x 1220 x 18", "冻结实验协议", "已冻结"),
        ("work_origin", "stock lower-left top; X0 Y0 Z0", "冻结实验协议", "已冻结"),
        ("collision_check_enabled", "", "新主项目截图", "必须填写yes"),
        ("axis_limit_check_enabled", "", "新主项目截图", "必须填写yes"),
        ("autodiff_license_enabled", "", "License界面", "缺失"),
        ("vericut_version", "9.4.2 used previously", "About界面", "需重新确认"),
    ]
    return [
        {
            "field": field,
            "current_reference_value": value,
            "authoritative_source_required": source,
            "current_status": status,
            "windows_verified_value": "",
            "evidence_file": "",
            "notes": "",
        }
        for field, value, source, status in values
    ]


def build_handoff(
    output: Path,
    *,
    experiment: Path = DEFAULT_EXPERIMENT,
    nominal_root: Path = DEFAULT_NOMINAL_ROOT,
) -> None:
    if output.exists():
        raise FileExistsError(f"refusing to overwrite existing output: {output}")
    output.mkdir(parents=True)

    experiment_destination = output / "01_experiment_package"
    shutil.copytree(experiment, experiment_destination)

    nominal_destination = output / "02_nominal_reference_only"
    nominal_destination.mkdir()
    nominal_rows: list[dict[str, str]] = []
    for name in NOMINAL_FILES:
        source = nominal_root / name
        destination = nominal_destination / name
        shutil.copy2(source, destination)
        nominal_rows.append(
            {
                "file": name,
                "sha256": sha256_file(destination),
                "status": "nominal_reference_only",
                "allowed_use": "project reconstruction and parameter reference",
                "prohibited_claim": "qualified collision or actual-machine validation",
            }
        )
    write_csv(
        nominal_destination / "NOMINAL_REFERENCE_SHA256.csv",
        ["file", "sha256", "status", "allowed_use", "prohibited_claim"],
        nominal_rows,
    )
    (nominal_destination / "README_DO_NOT_TREAT_AS_QUALIFIED_MODEL_CN.md").write_text(
        "本目录三个文件仅来自旧标称时间复核。机床实体、行程、实际刀柄和夹具"
        "均未完成校准；不得直接用于论文中的碰撞无误或实际机床验证结论。\n",
        encoding="utf-8",
    )

    to_complete = output / "03_to_be_completed"
    to_complete.mkdir()
    write_csv(
        to_complete / "WINDOWS_MACHINE_INPUT_FORM_CN.csv",
        [
            "field",
            "current_reference_value",
            "authoritative_source_required",
            "current_status",
            "windows_verified_value",
            "evidence_file",
            "notes",
        ],
        input_rows(),
    )
    (to_complete / "WINDOWS_COLLECTION_GUIDE_CN.md").write_text(
        collection_guide_cn(), encoding="utf-8"
    )
    (output / "README_FIRST_CN.md").write_text(readme_cn(), encoding="utf-8")

    files = sorted(path for path in output.rglob("*") if path.is_file())
    rows = [
        {
            "relative_path": path.relative_to(output).as_posix(),
            "sha256": sha256_file(path),
            "bytes": str(path.stat().st_size),
        }
        for path in files
    ]
    write_csv(
        output / "HANDOFF_SHA256.csv",
        ["relative_path", "sha256", "bytes"],
        rows,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--experiment", type=Path, default=DEFAULT_EXPERIMENT)
    parser.add_argument("--nominal-root", type=Path, default=DEFAULT_NOMINAL_ROOT)
    args = parser.parse_args()
    build_handoff(
        args.output,
        experiment=args.experiment,
        nominal_root=args.nominal_root,
    )
    print(args.output)


if __name__ == "__main__":
    main()
