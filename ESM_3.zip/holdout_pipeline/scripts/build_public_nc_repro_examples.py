from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import sys
from dataclasses import asdict
from pathlib import Path

from scripts.nc_kinematic_core import (
    NcTemplate,
    action_sequence_sha256,
    actions_from_diagnostics,
    audit_route_nc,
    default_scenarios,
    estimate_kinematics,
    generate_canonical_gcode,
    geometry_metrics,
    parse_gcode,
    sha256_text,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "outputs/public_nc_repro_examples_v1"
DEFAULT_LAYOUT_NAMES = (
    "public_BENG01.json",
    "public_CGCUT1.json",
    "public_NGCUT1.json",
    "public_OF1.json",
    "public_WANG1.json",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_stage7_root() -> Path:
    candidates = []
    if os.environ.get("IJAMT_STAGE7_ROOT"):
        candidates.append(Path(os.environ["IJAMT_STAGE7_ROOT"]))
    candidates.extend(
        (
            Path(__file__).resolve().parents[2] / "routing_code_and_public_data",
            Path(
                "<LOCAL_HOME>/Documents/Codex/2026-07-01/new-chat/"
                "ijamt-stage7-freeze"
            ),
        )
    )
    for candidate in candidates:
        if (candidate / "src/cnc_cutting").is_dir() and (
            candidate / "experiments/run_public_layout_benchmark.py"
        ).is_file():
            return candidate
    raise FileNotFoundError(
        "Cannot locate routing repository; set IJAMT_STAGE7_ROOT"
    )


def select_layout_paths(
    layout_dir: Path,
    names: tuple[str, ...],
) -> tuple[Path, ...]:
    selected = tuple(layout_dir / name for name in names)
    missing = [path.name for path in selected if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            "Missing declared public layouts: " + ", ".join(missing)
        )
    return selected


def _load_public_dependencies(stage7_root: Path) -> dict[str, object]:
    for path in (stage7_root / "src", stage7_root / "experiments"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    from cnc_cutting.coverage_diagnostics import diagnose_route_coverage
    from cnc_cutting.cutting_units import build_candidate_cutting_units
    from cnc_cutting.diagnostics import diagnose_actions
    from cnc_cutting.io import load_layout
    from cnc_cutting.models import EdgeRole, Panel
    from cnc_cutting.process_model import build_process_model
    from cnc_cutting.travel import clear_detour_cache
    from run_public_layout_benchmark import default_public_tool, plan_method

    return locals()


def build_example(
    layout_path: Path,
    output_dir: Path,
    dependencies: dict[str, object],
) -> dict[str, object]:
    load_layout = dependencies["load_layout"]
    Panel = dependencies["Panel"]
    EdgeRole = dependencies["EdgeRole"]
    default_public_tool = dependencies["default_public_tool"]
    build_process_model = dependencies["build_process_model"]
    build_candidate_cutting_units = dependencies["build_candidate_cutting_units"]
    plan_method = dependencies["plan_method"]
    diagnose_route_coverage = dependencies["diagnose_route_coverage"]
    diagnose_actions = dependencies["diagnose_actions"]
    clear_detour_cache = dependencies["clear_detour_cache"]

    layout = load_layout(layout_path)
    panel = Panel(layout.panel_id, layout.panel_width, layout.panel_height)
    tool = default_public_tool(5.0, 6.0, 0.0, True)
    process_model = build_process_model(
        layout,
        tool=tool,
        support_edge_roles=(
            EdgeRole.BOTTOM,
            EdgeRole.RIGHT,
            EdgeRole.TOP,
            EdgeRole.LEFT,
        ),
        min_remaining_support_count=1,
        min_remaining_support_length_ratio=0.75,
        min_area_normalized_support_length=0.0,
        adjacency_support_weight=1.0,
    )
    units = build_candidate_cutting_units(
        layout,
        tool,
        max_collinear_gap=tool.min_channel_width,
    )
    clear_detour_cache()
    plan = plan_method(
        "process_aware_beam_adaptive_polished",
        units=units,
        panel=panel,
        tool=tool,
        process_model=process_model,
        rectangle_count=len(layout.rectangles),
        repeat_cut_policy="hard",
    )
    diagnostics = diagnose_actions(
        plan.actions,
        panel,
        tool,
        process_model=process_model,
    )
    actions = actions_from_diagnostics(
        asdict(diagnostic) for diagnostic in diagnostics
    )
    template = NcTemplate()
    gcode = generate_canonical_gcode(
        actions,
        panel_width_mm=panel.panel_width,
        panel_height_mm=panel.panel_height,
        start_x_mm=tool.start_point.x,
        start_y_mm=tool.start_point.y,
        template=template,
    )
    parsed = parse_gcode(gcode)
    audit = audit_route_nc(
        actions,
        parsed,
        panel_width_mm=panel.panel_width,
        panel_height_mm=panel.panel_height,
        template=template,
    )
    if not audit.passed:
        raise RuntimeError(f"public NC audit failed for {layout_path.name}")
    coverage = diagnose_route_coverage(
        units,
        plan.selected_units,
        plan.actions,
        process_model=process_model,
    )
    geometry = geometry_metrics(parsed)
    estimates = [
        asdict(estimate_kinematics(parsed, scenario))
        for scenario in default_scenarios()
    ]

    output_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(layout_path, output_dir / "input_layout.json")
    route_payload = {
        "schema_version": "public_nc_route_v1",
        "method": "process_aware_beam_adaptive_polished",
        "panel_id": layout.panel_id,
        "panel_width_mm": panel.panel_width,
        "panel_height_mm": panel.panel_height,
        "rectangle_count": len(layout.rectangles),
        "candidate_unit_count": len(units),
        "selected_unit_count": len(plan.selected_units),
        "action_sequence_sha256": action_sequence_sha256(actions),
        "plan_metrics": asdict(plan.metrics),
        "coverage_audit": asdict(coverage),
        "actions": [asdict(action) for action in actions],
    }
    (output_dir / "route_actions.json").write_text(
        json.dumps(route_payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (output_dir / "canonical.nc").write_text(gcode, encoding="utf-8")
    parser_payload = {
        **{
            key: value
            for key, value in asdict(parsed).items()
            if key != "motions"
        },
        "motions": [asdict(motion) for motion in parsed.motions],
    }
    (output_dir / "parser_output.json").write_text(
        json.dumps(parser_payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    audit_payload = {
        "route_to_nc": asdict(audit),
        "geometry": asdict(geometry),
        "gcode_sha256": sha256_text(gcode),
        "action_sequence_sha256": action_sequence_sha256(actions),
        "scenario_count": len(estimates),
    }
    (output_dir / "parser_audit.json").write_text(
        json.dumps(audit_payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    scenario_path = output_dir / "scenario_times.csv"
    with scenario_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(estimates[0]),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(estimates)
    files = sorted(path for path in output_dir.iterdir() if path.is_file())
    example_manifest = {
        "layout": layout_path.name,
        "panel_id": layout.panel_id,
        "method": "process_aware_beam_adaptive_polished",
        "route_to_nc_audit_passed": audit.passed,
        "scenario_count": len(estimates),
        "files": {path.name: sha256_file(path) for path in files},
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(example_manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return example_manifest


def build_all(output: Path, names: tuple[str, ...]) -> None:
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite {output}")
    stage7_root = resolve_stage7_root()
    layout_dir = (
        stage7_root
        / "data/public_benchmarks/layouts_2dpacklib30_stage7_kerf"
    )
    layouts = select_layout_paths(layout_dir, names)
    dependencies = _load_public_dependencies(stage7_root)
    output.mkdir(parents=True)
    examples = []
    for layout_path in layouts:
        example_dir = output / layout_path.stem
        examples.append(build_example(layout_path, example_dir, dependencies))
    readme = """# Public planning-to-NC reproducibility examples

Five 2DPackLib-derived public layouts are replayed through the proposed planning
method, route-action serialization, canonical linear NC postprocessor, modal parser,
route-to-NC semantic audit, and all 27 disclosed kinematic scenarios. These examples
contain no factory data. The speed and acceleration values are isotropic path-level
limits, and the resulting times are controller-agnostic sensitivity calculations,
not measured machine cycle times.

Each example directory contains the input layout, route actions, canonical NC,
complete parser motion output, semantic audit, scenario table, and SHA-256 manifest.
"""
    (output / "README.md").write_text(readme, encoding="utf-8")
    root_manifest = {
        "schema_version": "public_nc_repro_examples_v1",
        "example_count": len(examples),
        "scenario_count_per_example": 27,
        "method": "process_aware_beam_adaptive_polished",
        "examples": examples,
        "scope": (
            "Controller-agnostic NC kinematic sensitivity; not measured machine "
            "time or manufacturing validation."
        ),
    }
    (output / "manifest.json").write_text(
        json.dumps(root_manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    checksum_paths = sorted(
        path for path in output.rglob("*") if path.is_file()
    )
    (output / "SHA256SUMS.txt").write_text(
        "\n".join(
            f"{sha256_file(path)}  {path.relative_to(output)}"
            for path in checksum_paths
        )
        + "\n",
        encoding="utf-8",
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--layout", action="append", default=[])
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    names = tuple(args.layout) if args.layout else DEFAULT_LAYOUT_NAMES
    build_all(args.output, names)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
