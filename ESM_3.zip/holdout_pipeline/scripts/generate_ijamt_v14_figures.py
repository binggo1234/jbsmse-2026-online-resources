from __future__ import annotations

import argparse
import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = WORKSPACE_ROOT / "outputs" / "ijamt_submission_working_v14"
SOURCE_ROOT_ENV = "CHAPTER3_SOURCE_ROOT"

COLORS = {
    "ink": "#1F2937",
    "muted": "#6B7280",
    "outline": "#94A3B8",
    "part": "#F1F5F9",
    "single": "#64748B",
    "shared": "#0072B2",
    "direct": "#D6A84B",
    "detour": "#0891B2",
    "safe": "#7C3AED",
    "accent": "#D55E00",
    "support": "#009E73",
    "released": "#CBD5E1",
}


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 7,
            "axes.titlesize": 7.5,
            "axes.labelsize": 7,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "legend.fontsize": 6.5,
            "figure.dpi": 180,
            "savefig.dpi": 600,
            "savefig.bbox": "tight",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def save_figure(fig: plt.Figure, output_dir: Path, stem: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for suffix in (".pdf", ".svg"):
        fig.savefig(output_dir / f"{stem}{suffix}", bbox_inches="tight")
    fig.savefig(output_dir / f"{stem}.png", dpi=600, bbox_inches="tight")
    plt.close(fig)


def rounded_box(
    ax: plt.Axes,
    xy: tuple[float, float],
    width: float,
    height: float,
    *,
    facecolor: str = "white",
    edgecolor: str = COLORS["outline"],
    linewidth: float = 0.8,
) -> FancyBboxPatch:
    patch = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.015,rounding_size=0.025",
        facecolor=facecolor,
        edgecolor=edgecolor,
        linewidth=linewidth,
    )
    ax.add_patch(patch)
    return patch


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.03,
        1.03,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8,
        fontweight="bold",
        color=COLORS["ink"],
    )


def draw_simple_layout(ax: plt.Axes, *, split_edges: bool = False) -> None:
    panel = Rectangle(
        (0.08, 0.17),
        0.84,
        0.64,
        facecolor="white",
        edgecolor=COLORS["ink"],
        linewidth=0.8,
    )
    ax.add_patch(panel)
    parts = (
        (0.11, 0.49, 0.37, 0.28),
        (0.50, 0.49, 0.39, 0.28),
        (0.11, 0.20, 0.26, 0.26),
        (0.39, 0.20, 0.50, 0.26),
    )
    for x, y, w, h in parts:
        ax.add_patch(
            Rectangle(
                (x, y),
                w,
                h,
                facecolor=COLORS["part"],
                edgecolor=COLORS["outline"],
                linewidth=0.55,
            )
        )
    if split_edges:
        split_points = ((0.48, 0.49), (0.50, 0.49), (0.37, 0.20), (0.39, 0.20))
        for x, y in split_points:
            ax.plot([x, x], [y - 0.035, y + 0.035], color=COLORS["accent"], linewidth=1.0)
        ax.plot([0.50, 0.50], [0.49, 0.77], color=COLORS["shared"], linewidth=2.0)
        ax.plot([0.39, 0.89], [0.47, 0.47], color=COLORS["single"], linewidth=1.2)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_aspect("equal")
    ax.axis("off")


def make_cutting_unit_figure(output_dir: Path) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(3.45, 1.42))
    titles = ("Fixed nested layout", "Atomic-span partition", "Executable active units")
    for index, (ax, title) in enumerate(zip(axes, titles)):
        ax.set_title(
            f"{chr(ord('a') + index)}  {title}",
            loc="left",
            pad=2.5,
            color=COLORS["ink"],
            fontweight="bold",
            fontsize=6.3,
        )

    draw_simple_layout(axes[0], split_edges=False)
    draw_simple_layout(axes[1], split_edges=True)

    ax = axes[2]
    rounded_box(ax, (0.08, 0.53), 0.84, 0.28, facecolor="#F8FAFC")
    ax.plot([0.18, 0.80], [0.67, 0.67], color=COLORS["single"], linewidth=2.2)
    ax.text(0.50, 0.58, r"$U_{\mathrm{single}}$: residual span", ha="center", va="center", fontsize=5.8)
    rounded_box(ax, (0.08, 0.16), 0.84, 0.28, facecolor="#EFF6FF", edgecolor="#7FB3D5")
    ax.add_patch(Rectangle((0.16, 0.28), 0.25, 0.12, facecolor=COLORS["part"], edgecolor=COLORS["outline"], linewidth=0.5))
    ax.add_patch(Rectangle((0.59, 0.28), 0.25, 0.12, facecolor=COLORS["part"], edgecolor=COLORS["outline"], linewidth=0.5))
    ax.plot([0.41, 0.59], [0.34, 0.34], color=COLORS["shared"], linewidth=2.5)
    ax.text(0.50, 0.205, r"$U_{\mathrm{shared}}$: shared centerline", ha="center", va="center", fontsize=5.8)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    for left_ax, right_ax in zip(axes[:-1], axes[1:]):
        left_ax.annotate(
            "",
            xy=(1.06, 0.50),
            xytext=(0.97, 0.50),
            xycoords=left_ax.transAxes,
            textcoords=left_ax.transAxes,
            arrowprops={"arrowstyle": "->", "color": COLORS["ink"], "linewidth": 0.8},
            annotation_clip=False,
        )
    fig.subplots_adjust(left=0.025, right=0.985, top=0.88, bottom=0.04, wspace=0.20)
    save_figure(fig, output_dir, "fig_cutting_unit_construction")


def draw_process_panel(ax: plt.Axes, mode: str, label: str, title: str) -> None:
    ax.set_title(
        f"{label}  {title}",
        loc="left",
        pad=2.5,
        fontweight="bold",
        color=COLORS["ink"],
        fontsize=7.0,
    )
    for x, y, w, h in (
        (0.07, 0.63, 0.25, 0.16),
        (0.39, 0.63, 0.22, 0.16),
        (0.68, 0.63, 0.25, 0.16),
        (0.07, 0.18, 0.28, 0.17),
        (0.67, 0.18, 0.26, 0.17),
    ):
        ax.add_patch(Rectangle((x, y), w, h, facecolor=COLORS["part"], edgecolor=COLORS["ink"], linewidth=0.55))
    ax.add_patch(
        Rectangle(
            (0.39, 0.16),
            0.22,
            0.25,
            facecolor=COLORS["released"],
            edgecolor=COLORS["muted"],
            linewidth=0.65,
            linestyle="--",
        )
    )
    start = (0.05, 0.46)
    end = (0.95, 0.46)
    ax.scatter(*zip(start, end), s=8, color=COLORS["ink"], zorder=5)

    if mode == "blocked":
        ax.plot([start[0], end[0]], [start[1], end[1]], color=COLORS["muted"], linewidth=0.9)
        ax.scatter([0.50], [0.46], marker="x", s=30, color="#B91C1C", linewidths=1.3, zorder=6)
        ax.text(0.50, 0.05, "blocked direct move", ha="center", fontsize=5.7, color=COLORS["muted"])
    elif mode == "detour":
        ax.plot(
            [start[0], 0.34, 0.34, 0.66, 0.66, end[0]],
            [start[1], start[1], 0.08, 0.08, end[1], end[1]],
            color=COLORS["detour"],
            linewidth=1.4,
            linestyle=(0, (3, 2)),
        )
        ax.text(0.50, 0.05, "released-part-aware detour", ha="center", fontsize=5.7, color=COLORS["detour"])
    elif mode == "safe":
        ax.plot([start[0], end[0]], [start[1], end[1]], color=COLORS["safe"], linewidth=1.5, linestyle=(0, (3, 2)))
        ax.annotate(
            "",
            xy=(0.17, 0.58),
            xytext=(0.17, 0.44),
            arrowprops={"arrowstyle": "->", "color": COLORS["safe"], "linewidth": 1.0},
        )
        ax.text(0.50, 0.05, "retract + rapid + plunge", ha="center", fontsize=5.7, color=COLORS["safe"])
    elif mode == "support":
        ax.cla()
        ax.set_title(
            f"{label}  {title}",
            loc="left",
            pad=2.5,
            fontweight="bold",
            color=COLORS["ink"],
            fontsize=7.0,
        )
        ax.add_patch(Rectangle((0.30, 0.24), 0.40, 0.46, facecolor=COLORS["part"], edgecolor=COLORS["outline"], linewidth=0.6))
        ax.plot([0.30, 0.70], [0.70, 0.70], color="#B91C1C", linewidth=1.7)
        ax.plot([0.30, 0.30], [0.24, 0.70], color=COLORS["support"], linewidth=1.7)
        ax.annotate("", xy=(0.30, 0.43), xytext=(0.18, 0.12), arrowprops={"arrowstyle": "->", "color": COLORS["support"], "linewidth": 0.9})
        ax.annotate("", xy=(0.50, 0.70), xytext=(0.82, 0.12), arrowprops={"arrowstyle": "->", "color": "#B91C1C", "linewidth": 0.9})
        ax.text(0.08, 0.05, "continue", fontsize=5.8, color=COLORS["support"], ha="left")
        ax.text(0.92, 0.05, "switch away: penalty", fontsize=5.5, color="#B91C1C", ha="right")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")


def make_process_constraint_figure(output_dir: Path) -> None:
    fig, axes = plt.subplots(1, 4, figsize=(7.2, 1.82))
    specs = (
        ("blocked", "a", "Released-part block"),
        ("detour", "b", "Detour"),
        ("safe", "c", "Safe lift"),
        ("support", "d", "Support continuity"),
    )
    for ax, spec in zip(axes, specs):
        draw_process_panel(ax, *spec)
    fig.subplots_adjust(left=0.025, right=0.99, top=0.88, bottom=0.08, wspace=0.18)
    save_figure(fig, output_dir, "fig_process_constraints")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def load_route_case(source_root: Path):
    sys.path.insert(0, str(source_root / "src"))
    from cnc_cutting.io import (  # pylint: disable=import-outside-toplevel
        PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
        load_chapter2_layouts_from_zip,
    )

    stage_root = source_root / "results" / "corrected_model_stage7_kerf"
    case_rows = read_csv(stage_root / "auxiliary_nc_cam_fusion_5case" / "case_index.csv")
    case = next(row for row in case_rows if row["case_id"] == "case_04_high_gain")
    member = case["record_member"]
    config_member = str(Path(member).with_name("config_dump.json"))
    layout = load_chapter2_layouts_from_zip(
        stage_root / "kerf_layouts" / "stage7_kerf_layouts.zip",
        placements_member=member,
        config_member=config_member,
        board_ids=(case["board_id"],),
        placement_geometry_mode=PLACEMENT_GEOMETRY_NOMINAL_FROM_TOOL_INFLATED,
        tool_diameter=6.0,
    )[0]
    methods = ("topology_process_aware", "process_aware_beam_adaptive_polished")
    formal_rows = read_csv(stage_root / "formal" / "chapter3_stage7_main.csv")
    matched = {
        row["method"]: row
        for row in formal_rows
        if row["placements_member"] == member
        and row["board_id"] == case["board_id"]
        and row["method"] in methods
    }
    if set(matched) != set(methods):
        raise RuntimeError("The frozen route case does not contain both requested methods.")
    diagnostics = {
        method: read_csv(source_root / matched[method]["diagnostics_file"])
        for method in methods
    }
    return layout, matched, diagnostics


def number(row: dict[str, str], key: str) -> float:
    value = row.get(key, "")
    return float(value) if value else 0.0


def draw_route(ax: plt.Axes, layout, rows: list[dict[str, str]], title: str, metrics: str) -> None:
    panel_label(ax, title[0])
    ax.set_title(title[3:], loc="left", pad=3.0, fontweight="bold")
    for rectangle in layout.rectangles:
        ax.add_patch(
            Rectangle(
                (rectangle.x, rectangle.y),
                rectangle.width,
                rectangle.height,
                facecolor=COLORS["part"],
                edgecolor=COLORS["outline"],
                linewidth=0.35,
                zorder=0,
            )
        )
    ax.add_patch(
        Rectangle(
            (0, 0),
            layout.panel_width,
            layout.panel_height,
            fill=False,
            edgecolor=COLORS["ink"],
            linewidth=0.9,
            zorder=8,
        )
    )

    for row in rows:
        x = (number(row, "start_x"), number(row, "end_x"))
        y = (number(row, "start_y"), number(row, "end_y"))
        if row["action_type"] == "cut":
            shared = row["cutting_unit_id"].startswith("shared_edge:")
            ax.plot(
                x,
                y,
                color=COLORS["shared"] if shared else COLORS["single"],
                linewidth=1.35 if shared else 0.75,
                alpha=0.88 if shared else 0.56,
                solid_capstyle="round",
                zorder=4 if shared else 2,
            )
            continue
        mode = row["travel_mode"]
        color = {
            "low_clearance_detour": COLORS["detour"],
            "safe_lift": COLORS["safe"],
        }.get(mode, COLORS["direct"])
        ax.plot(
            x,
            y,
            color=color,
            linewidth=1.0 if mode != "low_clearance" else 0.45,
            linestyle=(0, (3, 2)),
            alpha=0.78 if mode != "low_clearance" else 0.22,
            zorder=3 if mode != "low_clearance" else 1,
        )

    ax.text(
        0.015,
        0.025,
        metrics,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=6.0,
        linespacing=1.15,
        bbox={
            "boxstyle": "round,pad=0.22",
            "facecolor": "white",
            "edgecolor": "#CBD5E1",
            "linewidth": 0.55,
            "alpha": 0.95,
        },
        zorder=10,
    )
    padding = 0.015 * max(layout.panel_width, layout.panel_height)
    ax.set_xlim(-padding, layout.panel_width + padding)
    ax.set_ylim(-padding, layout.panel_height + padding)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.grid(False)


def route_components(rows: list[dict[str, str]], cutting_length: float) -> dict[str, float]:
    components = defaultdict(float)
    components["Cutting"] = cutting_length
    for row in rows:
        if row["action_type"] != "travel":
            continue
        label = {
            "low_clearance": "Direct",
            "low_clearance_detour": "Detour",
            "safe_lift": "Safe lift",
        }.get(row["travel_mode"], "Direct")
        components[label] += number(row, "travel_mode_cost")
    return dict(components)


def make_route_interpretation_figure(source_root: Path, output_dir: Path) -> None:
    layout, summaries, diagnostics = load_route_case(source_root)
    topology = "topology_process_aware"
    proposed = "process_aware_beam_adaptive_polished"
    method_labels = {topology: "Process-aware topology", proposed: "Proposed route"}
    fig = plt.figure(figsize=(7.2, 4.15))
    grid = fig.add_gridspec(2, 2, height_ratios=(2.35, 1.0), hspace=0.24, wspace=0.08)
    route_axes = (fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1]))

    for index, (ax, method) in enumerate(zip(route_axes, (topology, proposed))):
        summary = summaries[method]
        rows = diagnostics[method]
        c_plan = float(summary["cutting_length"]) + float(summary["travel_mode_cost"])
        metrics = (
            rf"$C_{{\mathrm{{plan}}}}$={c_plan:,.1f}; "
            rf"$L_{{\mathrm{{cut}}}}$={float(summary['cutting_length']):,.1f}" "\n"
            f"detours={int(summary['detour_count'])}; "
            f"safe lifts={int(summary['safe_lift_count'])}; "
            rf"$\Phi_{{\mathrm{{low}}}}$={float(summary['stability_penalty']):.0f}"
        )
        draw_route(
            ax,
            layout,
            rows,
            f"{chr(ord('a') + index)}  {method_labels[method]}",
            metrics,
        )

    bar_ax = fig.add_subplot(grid[1, :])
    panel_label(bar_ax, "c")
    components = {
        method: route_components(
            diagnostics[method],
            float(summaries[method]["cutting_length"]),
        )
        for method in (topology, proposed)
    }
    component_order = ("Cutting", "Direct", "Detour", "Safe lift")
    component_colors = {
        "Cutting": COLORS["single"],
        "Direct": COLORS["direct"],
        "Detour": COLORS["detour"],
        "Safe lift": COLORS["safe"],
    }
    y_positions = (1, 0)
    totals: dict[str, float] = {}
    for y, method in zip(y_positions, (topology, proposed)):
        left = 0.0
        for component in component_order:
            value = components[method].get(component, 0.0) / 1000.0
            bar_ax.barh(
                y,
                value,
                left=left,
                height=0.52,
                color=component_colors[component],
                edgecolor="white",
                linewidth=0.45,
                label=component if y == 1 else None,
            )
            if value >= 0.8:
                bar_ax.text(
                    left + value / 2,
                    y,
                    f"{value:.1f}",
                    ha="center",
                    va="center",
                    fontsize=5.8,
                    color="white" if component in {"Cutting", "Detour", "Safe lift"} else COLORS["ink"],
                )
            left += value
        totals[method] = left
        bar_ax.text(left + 0.25, y, f"{left:.1f}", ha="left", va="center", fontsize=6.5, fontweight="bold")

    reduction = 100.0 * (totals[topology] - totals[proposed]) / totals[topology]
    bar_ax.text(
        0.995,
        1.04,
        rf"Same selected active-unit family and evaluator; total reduction = {reduction:.2f}\%",
        transform=bar_ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=6.4,
        color=COLORS["accent"],
        fontweight="bold",
    )
    bar_ax.set_yticks(y_positions)
    bar_ax.set_yticklabels((method_labels[topology], method_labels[proposed]))
    bar_ax.set_xlabel(r"$C_{\mathrm{plan}}$ components ($10^3$ layout-length-equivalent units)")
    bar_ax.grid(axis="x", color="#E5E7EB", linewidth=0.5)
    bar_ax.set_axisbelow(True)
    bar_ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.62), ncol=4, frameon=False)
    fig.legend(
        handles=(
            plt.Line2D([0], [0], color=COLORS["shared"], linewidth=1.8, label="shared cutter-centerline"),
            plt.Line2D([0], [0], color=COLORS["single"], linewidth=1.2, label="residual single span"),
            plt.Line2D([0], [0], color=COLORS["detour"], linewidth=1.2, linestyle="--", label="detour"),
            plt.Line2D([0], [0], color=COLORS["safe"], linewidth=1.2, linestyle="--", label="safe lift"),
        ),
        loc="upper center",
        bbox_to_anchor=(0.5, 1.005),
        ncol=4,
        frameon=False,
    )
    fig.subplots_adjust(left=0.10, right=0.99, top=0.91, bottom=0.18)
    save_figure(fig, output_dir, "fig_route_topology_proposed_interpretation")

    summary_path = output_dir / "fig_route_topology_proposed_interpretation_source.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=(
                "method",
                "cutting",
                "direct",
                "detour",
                "safe_lift",
                "c_plan",
                "detour_count",
                "safe_lift_count",
                "support_policy_penalty",
                "hard_penalty",
            ),
            lineterminator="\n",
        )
        writer.writeheader()
        for method in (topology, proposed):
            values = components[method]
            writer.writerow(
                {
                    "method": method,
                    "cutting": f"{values.get('Cutting', 0.0):.12f}",
                    "direct": f"{values.get('Direct', 0.0):.12f}",
                    "detour": f"{values.get('Detour', 0.0):.12f}",
                    "safe_lift": f"{values.get('Safe lift', 0.0):.12f}",
                    "c_plan": f"{sum(values.values()):.12f}",
                    "detour_count": summaries[method]["detour_count"],
                    "safe_lift_count": summaries[method]["safe_lift_count"],
                    "support_policy_penalty": summaries[method]["stability_penalty"],
                    "hard_penalty": summaries[method]["hard_penalty"],
                }
            )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate revised IJAMT manuscript figures.")
    parser.add_argument(
        "--source-root",
        type=Path,
        default=Path(os.environ[SOURCE_ROOT_ENV]) if SOURCE_ROOT_ENV in os.environ else None,
        help=f"Chapter 3 source repository. May also be supplied through ${SOURCE_ROOT_ENV}.",
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.source_root is None:
        raise SystemExit(f"Provide --source-root or set ${SOURCE_ROOT_ENV}.")
    configure_style()
    make_cutting_unit_figure(args.output_dir)
    make_process_constraint_figure(args.output_dir)
    make_route_interpretation_figure(args.source_root.resolve(), args.output_dir.resolve())
    print(f"figures: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
