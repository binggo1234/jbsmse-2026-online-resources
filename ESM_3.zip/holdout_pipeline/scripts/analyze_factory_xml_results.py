from __future__ import annotations

import csv
import json
import platform
import sys
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median
from typing import Sequence


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import scripts.analyze_holdout_results as holdout
import scripts.run_factory_xml_routes as track_b
import scripts.run_holdout_routes as stage7_run


OUTPUT_DIR = ROOT / "outputs" / "factory_xml_analysis_v1"
ANALYSIS_FREEZE = ROOT / "docs" / "track_b_task_level_analysis_freeze_v1.md"
HASH_DIAGNOSTIC = ROOT / "docs" / "track_b_hash_seed_diagnostic.md"
ROUTE_AUDIT = track_b.OUTPUT_DIR / "route_audit.json"
ATOMIC_AUDIT = track_b.OUTPUT_DIR / "atomic_span_audit.json"
PREFLIGHT_AUDIT = track_b.PREFLIGHT_MANIFEST

CONFIRMATORY = "confirmatory_holdout"
SUPPLEMENTARY = "excluded_prior_upstream_use"
COHORTS = (CONFIRMATORY, SUPPLEMENTARY)


def write_csv(
    path: Path,
    rows: Sequence[dict[str, object]],
    fields: Sequence[str],
) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def validate_provenance() -> dict[str, object]:
    route_audit = json.loads(ROUTE_AUDIT.read_text(encoding="utf-8"))
    atomic_audit = json.loads(ATOMIC_AUDIT.read_text(encoding="utf-8"))
    preflight = json.loads(PREFLIGHT_AUDIT.read_text(encoding="utf-8"))
    if route_audit["audit_status"] != "passed":
        raise ValueError("Track B route audit has not passed")
    if atomic_audit["audit_status"] != "passed":
        raise ValueError("Track B atomic replay audit has not passed")
    if atomic_audit.get("python_hash_seed") != "0":
        raise ValueError("Track B atomic replay did not use PYTHONHASHSEED=0")
    if preflight["preflight_status"] != "passed":
        raise ValueError("Track B XML preflight has not passed")
    result_sha = stage7_run.sha256_file(track_b.RESULTS)
    if route_audit["files"]["results"]["sha256"] != result_sha:
        raise ValueError("route audit points to a different Track B result")
    if atomic_audit["files"]["route_results"]["sha256"] != result_sha:
        raise ValueError("atomic audit points to a different Track B result")
    return {
        "route_result_sha256": result_sha,
        "route_audit_status": route_audit["audit_status"],
        "atomic_audit_status": atomic_audit["audit_status"],
        "atomic_python_hash_seed": atomic_audit["python_hash_seed"],
        "preflight_status": preflight["preflight_status"],
    }


def joined_rows() -> tuple[list[dict[str, str]], dict[str, object]]:
    routes = track_b.read_csv(track_b.RESULTS)
    jobs = track_b.read_csv(track_b.FROZEN_JOBS)
    if len(routes) != 13_765 or len(jobs) != 13_765:
        raise ValueError("unexpected Track B route or job count")
    job_by_id = {row["job_id"]: row for row in jobs}
    if len(job_by_id) != len(jobs):
        raise ValueError("frozen Track B job IDs are not unique")
    if len({row["job_id"] for row in routes}) != len(routes):
        raise ValueError("Track B route job IDs are not unique")

    output: list[dict[str, str]] = []
    method_by_pattern: dict[str, list[str]] = defaultdict(list)
    task_statuses: dict[str, set[str]] = defaultdict(set)
    for route in routes:
        if route["status"] != "completed":
            raise ValueError(f"incomplete Track B route {route['job_id']}")
        job = job_by_id.get(route["job_id"])
        if job is None:
            raise ValueError(f"unknown Track B job {route['job_id']}")
        for field in ("method", "placements_member", "board_id"):
            if route[field] != job[field]:
                raise ValueError(f"route/job {field} mismatch for {route['job_id']}")
        if job["confirmatory_status"] not in COHORTS:
            raise ValueError("unexpected Track B cohort label")
        for field in holdout.REQUIRED_NUMERIC_FIELDS:
            holdout.number(route, field)
        if not holdout.numerically_equal(
            holdout.number(route, "min_support_ratio"), 0.75
        ):
            raise ValueError("Track B support ratio differs from rho=0.75")
        holdout.row_metrics(route)
        enriched = dict(route)
        enriched.update(
            {
                "task_id": job["task_id"],
                "confirmatory_status": job["confirmatory_status"],
                "pattern_id": job["pattern_id"],
            }
        )
        output.append(enriched)
        method_by_pattern[job["pattern_id"]].append(route["method"])
        task_statuses[job["task_id"]].add(job["confirmatory_status"])

    if set(route["method"] for route in output) != set(holdout.METHODS):
        raise ValueError("Track B method set differs from the frozen five methods")
    if len(method_by_pattern) != 2_753:
        raise ValueError("unexpected Track B Pattern count")
    if any(
        Counter(value) != Counter(holdout.METHODS)
        for value in method_by_pattern.values()
    ):
        raise ValueError("a Track B Pattern does not contain every method once")
    if any(len(statuses) != 1 for statuses in task_statuses.values()):
        raise ValueError("a Track B task has conflicting cohort labels")
    status_task_counts = Counter(next(iter(value)) for value in task_statuses.values())
    if status_task_counts != Counter({CONFIRMATORY: 7, SUPPLEMENTARY: 4}):
        raise ValueError(f"unexpected Track B task cohorts: {status_task_counts}")
    proposed = [row for row in output if row["method"] == holdout.PROPOSED]
    if any(
        not holdout.numerically_equal(holdout.number(row, "hard_penalty"), 0.0)
        for row in proposed
    ):
        raise ValueError("Track B proposed result contains a nonzero hard penalty")
    return output, {
        "route_row_count": len(output),
        "pattern_count": len(method_by_pattern),
        "method_count": len(holdout.METHODS),
        "task_count": len(task_statuses),
        "confirmatory_task_count": status_task_counts[CONFIRMATORY],
        "supplementary_task_count": status_task_counts[SUPPLEMENTARY],
    }


def aggregate_tasks(rows: Sequence[dict[str, str]]) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[
            (row["confirmatory_status"], row["task_id"], row["method"])
        ].append(row)
    output: list[dict[str, object]] = []
    for (cohort, task_id, method), items in sorted(grouped.items()):
        totals = {metric: 0.0 for metric in holdout.SUM_METRICS}
        for row in items:
            metrics = holdout.row_metrics(row)
            for metric in holdout.SUM_METRICS:
                totals[metric] += metrics[metric]
        output.append(
            {
                "confirmatory_status": cohort,
                "task_id": task_id,
                "method": method,
                "pattern_count": len(items),
                **totals,
            }
        )
    if len(output) != 11 * len(holdout.METHODS):
        raise ValueError("Track B task aggregation is incomplete")
    return output


def cohort_method_summary(
    rows: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[str(row["method"])].append(row)
    output: list[dict[str, object]] = []
    for method in holdout.METHODS:
        items = grouped[method]
        result: dict[str, object] = {"method": method, "task_count": len(items)}
        for metric in holdout.COMPARISON_METRICS:
            values = [float(item[metric]) for item in items]
            result[f"{metric}_task_mean"] = mean(values)
            result[f"{metric}_task_median"] = median(values)
            result[f"{metric}_task_min"] = min(values)
            result[f"{metric}_task_max"] = max(values)
        result["positive_support_penalty_tasks"] = sum(
            not holdout.numerically_equal(
                float(item["support_policy_penalty"]), 0.0
            )
            for item in items
        )
        output.append(result)
    return output


def format_report(
    validation: dict[str, object],
    confirmatory: Sequence[dict[str, object]],
) -> str:
    lines = [
        "# Track B factory-XML task-level analysis",
        "",
        "- Analysis status: **passed**",
        f"- Fixed-coordinate Patterns: {validation['pattern_count']}",
        f"- Confirmatory independent tasks: {validation['confirmatory_task_count']}",
        f"- Historical supplementary tasks: {validation['supplementary_task_count']}",
        "- Patterns were summed within task; only tasks were analyzed independently.",
        "",
        "## Confirmatory C_plan comparisons",
        "",
        "| Baseline | Mean task reduction | 95% task-bootstrap CI | W/T/L | Exact sign p | Holm p | Positive-support tasks (proposed/baseline) |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in confirmatory:
        lines.append(
            "| {baseline_method} | {mean_reduction_pct:.3f}% | "
            "[{reduction_ci_low:.3f}, {reduction_ci_high:.3f}] | "
            "{wins}/{ties}/{losses} | {sign_test_p_raw:.6g} | "
            "{sign_test_p_holm:.6g} | "
            "{proposed_positive_support_penalty_tasks}/"
            "{baseline_positive_support_penalty_tasks} |".format(**row)
        )
    lines.extend(
        [
            "",
            "The four historical tasks are descriptive only and do not contribute",
            "to the confirmatory sample size or p-values.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    provenance = validate_provenance()
    rows, validation = joined_rows()
    task_rows = aggregate_tasks(rows)
    confirmatory_tasks = [
        row for row in task_rows if row["confirmatory_status"] == CONFIRMATORY
    ]
    supplementary_tasks = [
        row for row in task_rows if row["confirmatory_status"] == SUPPLEMENTARY
    ]
    confirmatory, secondary, pairwise = holdout.build_summaries(
        confirmatory_tasks
    )
    confirmatory_methods = cohort_method_summary(confirmatory_tasks)
    supplementary_methods = cohort_method_summary(supplementary_tasks)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    files = {
        "task_metrics": OUTPUT_DIR / "task_metrics.csv",
        "confirmatory_task_metrics": OUTPUT_DIR / "confirmatory_task_metrics.csv",
        "supplementary_task_metrics": OUTPUT_DIR / "supplementary_task_metrics.csv",
        "pairwise": OUTPUT_DIR / "pairwise_confirmatory_task_comparisons.csv",
        "confirmatory": OUTPUT_DIR / "confirmatory_summary.csv",
        "secondary": OUTPUT_DIR / "secondary_summary.csv",
        "confirmatory_methods": OUTPUT_DIR / "confirmatory_method_summary.csv",
        "supplementary_methods": OUTPUT_DIR / "supplementary_method_summary.csv",
    }
    task_fields = [
        "confirmatory_status",
        "task_id",
        "method",
        "pattern_count",
        *holdout.SUM_METRICS,
    ]
    write_csv(files["task_metrics"], task_rows, task_fields)
    write_csv(files["confirmatory_task_metrics"], confirmatory_tasks, task_fields)
    write_csv(files["supplementary_task_metrics"], supplementary_tasks, task_fields)
    write_csv(files["pairwise"], pairwise, list(pairwise[0]))
    write_csv(files["confirmatory"], confirmatory, list(confirmatory[0]))
    write_csv(files["secondary"], secondary, list(secondary[0]))
    write_csv(
        files["confirmatory_methods"],
        confirmatory_methods,
        list(confirmatory_methods[0]),
    )
    write_csv(
        files["supplementary_methods"],
        supplementary_methods,
        list(supplementary_methods[0]),
    )

    audit = {
        "analysis_status": "passed",
        "aggregation_order": [
            "sum fixed-coordinate Patterns within factory task",
            "equal-weight confirmatory analysis of seven holdout factory tasks",
            "separate task-equal description of four historical tasks",
        ],
        "provenance": provenance,
        "validation": validation,
        "confirmatory_comparisons": confirmatory,
    }
    audit_path = OUTPUT_DIR / "analysis_audit.json"
    report_path = OUTPUT_DIR / "analysis_audit.md"
    manifest_path = OUTPUT_DIR / "analysis_manifest.json"
    audit_path.write_text(
        json.dumps(audit, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    report_path.write_text(
        format_report(validation, confirmatory),
        encoding="utf-8",
    )
    output_paths = [*files.values(), audit_path, report_path]
    manifest = {
        "analysis_program": {
            "path": str(Path(__file__).resolve()),
            "sha256": stage7_run.sha256_file(Path(__file__).resolve()),
        },
        "software": {
            "python_version": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "platform": platform.platform(),
        },
        "analysis_freeze": {
            "path": str(ANALYSIS_FREEZE),
            "sha256": stage7_run.sha256_file(ANALYSIS_FREEZE),
        },
        "hash_seed_diagnostic": {
            "path": str(HASH_DIAGNOSTIC),
            "sha256": stage7_run.sha256_file(HASH_DIAGNOSTIC),
        },
        "authorized_inputs": [
            {
                "path": str(path),
                "sha256": stage7_run.sha256_file(path),
            }
            for path in (
                track_b.RESULTS,
                track_b.FROZEN_JOBS,
                PREFLIGHT_AUDIT,
                ROUTE_AUDIT,
                ATOMIC_AUDIT,
            )
        ],
        "parameters": {
            "independent_unit": "factory_task",
            "confirmatory_task_count": 7,
            "supplementary_task_count": 4,
            "bootstrap_replicates": holdout.BOOTSTRAP_REPLICATES,
            "bootstrap_seed": holdout.BOOTSTRAP_SEED,
            "numerical_tolerance": holdout.NUMERICAL_TOLERANCE,
            "c_plan_formula": "cutting_length + travel_mode_cost",
        },
        "outputs": [
            {"path": str(path), "sha256": stage7_run.sha256_file(path)}
            for path in output_paths
        ],
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(validation, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
