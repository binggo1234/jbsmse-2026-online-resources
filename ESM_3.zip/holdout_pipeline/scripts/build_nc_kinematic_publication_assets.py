from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean
from statistics import median

from scripts.analyze_holdout_results import bootstrap_mean_ci
from scripts.run_nc_kinematic_evaluation import FULL_OUTPUT


ROOT = Path(__file__).resolve().parents[1]
ASSET_OUTPUT = FULL_OUTPUT / "publication_assets"
PAPER_OUTPUT = ROOT / "outputs/ijamt_submission_working_v13"
CENTRAL_SCENARIO = "r200_axy1000_z40_az500"
METHOD_ORDER = (
    "process_aware_beam_adaptive_polished",
    "process_aware_beam",
    "topology_process_aware",
    "process_local_search_multistart",
    "endpoint_aware_gtsp",
)
METHOD_LABELS = {
    "process_aware_beam_adaptive_polished": "Proposed portfolio",
    "process_aware_beam": "Ordinary process-aware beam",
    "topology_process_aware": "Process-aware topology",
    "process_local_search_multistart": "Multi-start process LS",
    "endpoint_aware_gtsp": "Endpoint-aware GTSP",
}
MAIN_BASELINES = (
    "topology_process_aware",
    "process_aware_beam",
    "endpoint_aware_gtsp",
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_text_pair(filename: str, content: str) -> None:
    ASSET_OUTPUT.mkdir(parents=True, exist_ok=True)
    for directory in (ASSET_OUTPUT, PAPER_OUTPUT):
        (directory / filename).write_text(content, encoding="utf-8")


def metric_label(metric: str) -> str:
    return {
        "continuous_noncut_time_s": "Continuous, non-cut",
        "continuous_total_time_s": "Continuous, total",
        "stop_noncut_time_s": "Stop-at-junction, non-cut",
        "stop_total_time_s": "Stop-at-junction, total",
    }[metric]


def format_range(row: dict[str, str]) -> str:
    return (
        f"{float(row['minimum_mean_reduction_pct']):.2f}"
        f"--{float(row['maximum_mean_reduction_pct']):.2f}"
    )


def build_main_table(robustness: list[dict[str, str]]) -> str:
    index = {
        (row["baseline"], row["time_metric"]): row
        for row in robustness
    }
    lines = []
    for baseline in MAIN_BASELINES:
        for model, prefix in (
            ("Continuous", "continuous"),
            ("Stop at junction", "stop"),
        ):
            noncut = index[(baseline, f"{prefix}_noncut_time_s")]
            total = index[(baseline, f"{prefix}_total_time_s")]
            all_positive = (
                f"{int(noncut['all_tasks_positive_scenario_count'])}/27; "
                f"{int(total['all_tasks_positive_scenario_count'])}/27"
            )
            lines.append(
                "{} & {} & {} & {} & {} \\\\".format(
                    METHOD_LABELS[baseline],
                    model,
                    format_range(noncut),
                    format_range(total),
                    all_positive,
                )
            )
    body = "\n".join(lines)
    return rf"""\begin{{table*}}[t]
\centering
\caption{{Transparent NC-level kinematic sensitivity on the full factory-task holdout. Entries are ranges of the task-equal mean reduction (\%) of the proposed route over 27 prespecified scenarios; positive values favor the proposed route. The final column gives the number of scenarios in which all 20 tasks improve, for non-cutting and total time respectively. Scenarios are sensitivity conditions, not independent replicates.}}
\label{{tab:nc-kinematic-main}}
\footnotesize
\begin{{tabular}}{{@{{}}llrrc@{{}}}}
\toprule
Baseline & Motion model & Non-cut reduction & Total reduction & All-task-positive scenarios \\
\midrule
{body}
\bottomrule
\end{{tabular}}
\end{{table*}}
"""


def build_robustness_table(robustness: list[dict[str, str]]) -> str:
    rows = sorted(
        robustness,
        key=lambda row: (
            METHOD_ORDER.index(row["baseline"]),
            (
                "continuous_noncut_time_s",
                "continuous_total_time_s",
                "stop_noncut_time_s",
                "stop_total_time_s",
            ).index(row["time_metric"]),
        ),
    )
    lines = [
        "{} & {} & {:.2f} & {:.2f} & {:.2f} & {}/27 & {}/27 \\\\".format(
            METHOD_LABELS[row["baseline"]],
            metric_label(row["time_metric"]),
            float(row["minimum_mean_reduction_pct"]),
            float(row["median_mean_reduction_pct"]),
            float(row["maximum_mean_reduction_pct"]),
            int(row["positive_mean_scenario_count"]),
            int(row["all_tasks_positive_scenario_count"]),
        )
        for row in rows
    ]
    body = "\n".join(lines)
    return rf"""\begin{{table}}[t]
\centering
\caption{{Complete robustness summary over 27 prespecified NC kinematic scenarios. Min/median/max are across scenario-specific task-equal mean reductions (\%); scenario counts are descriptive only.}}
\label{{tab:nc-robustness-supp}}
\scriptsize
\begin{{tabular}}{{@{{}}llrrrrr@{{}}}}
\toprule
Baseline & Metric & Min & Median & Max & Mean \(>0\) & 20/20 \(>0\) \\
\midrule
{body}
\bottomrule
\end{{tabular}}
\end{{table}}
"""


def build_reference_table(task_rows: list[dict[str, str]]) -> str:
    selected = [
        row for row in task_rows if row["scenario"] == CENTRAL_SCENARIO
    ]
    by_method: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in selected:
        by_method[row["method"]].append(row)
    lines = []
    for method in METHOD_ORDER:
        rows = by_method[method]
        if len(rows) != 20:
            raise ValueError(f"{method} does not have 20 central-scenario task rows")
        values = [
            mean(float(row[field]) for row in rows) / 3600.0
            for field in (
                "continuous_noncut_time_s",
                "continuous_total_time_s",
                "stop_noncut_time_s",
                "stop_total_time_s",
            )
        ]
        lines.append(
            "{} & {:.3f} & {:.3f} & {:.3f} & {:.3f} \\\\".format(
                METHOD_LABELS[method],
                *values,
            )
        )
    body = "\n".join(lines)
    return rf"""\begin{{table}}[t]
\centering
\caption{{Task-equal mean NC time in the central scenario \(v_{{rapid}}=200\)~mm/s, \(a_{{xy}}=1000\)~mm/s\(^2\), \(v_{{z}}=40\)~mm/s, and \(a_{{z}}=500\)~mm/s\(^2\). Values are hours per factory task after summing boards within seed and averaging the three seeds.}}
\label{{tab:nc-reference-scenario-supp}}
\footnotesize
\begin{{tabular}}{{@{{}}lrrrr@{{}}}}
\toprule
Method & Cont. non-cut & Cont. total & Stop non-cut & Stop total \\
\midrule
{body}
\bottomrule
\end{{tabular}}
\end{{table}}
"""


def build_nominal_table(
    task_rows: list[dict[str, str]],
    *,
    bootstrap_replicates: int = 100_000,
    bootstrap_seed: int = 20_260_726,
) -> tuple[str, list[dict[str, object]]]:
    selected = [
        row for row in task_rows if row["scenario"] == CENTRAL_SCENARIO
    ]
    index = {
        (row["task_id"], row["method"]): row
        for row in selected
    }
    tasks = sorted({row["task_id"] for row in selected})
    expected_methods = (METHOD_ORDER[0], *MAIN_BASELINES)
    for method in expected_methods:
        if any((task_id, method) not in index for task_id in tasks):
            raise ValueError(f"incomplete nominal-scenario rows for {method}")

    summaries: list[dict[str, object]] = []
    table_rows = []
    for method in expected_methods:
        method_rows = [index[(task_id, method)] for task_id in tasks]
        noncut_hours = mean(
            float(row["continuous_noncut_time_s"]) for row in method_rows
        ) / 3600.0
        total_hours = mean(
            float(row["continuous_total_time_s"]) for row in method_rows
        ) / 3600.0
        if method == METHOD_ORDER[0]:
            table_rows.append(
                f"{METHOD_LABELS[method]} & {noncut_hours:.3f} & "
                f"{total_hours:.3f} & -- & -- & -- & -- & -- \\\\"
            )
            continue
        reductions = []
        total_reductions = []
        for task_id in tasks:
            proposed = float(
                index[(task_id, METHOD_ORDER[0])]["continuous_noncut_time_s"]
            )
            baseline = float(index[(task_id, method)]["continuous_noncut_time_s"])
            reductions.append(100.0 * (baseline - proposed) / baseline)
            proposed_total = float(
                index[(task_id, METHOD_ORDER[0])]["continuous_total_time_s"]
            )
            baseline_total = float(
                index[(task_id, method)]["continuous_total_time_s"]
            )
            total_reductions.append(
                100.0 * (baseline_total - proposed_total) / baseline_total
            )
        ci_low, ci_high = bootstrap_mean_ci(
            reductions,
            replicates=bootstrap_replicates,
            seed=bootstrap_seed,
        )
        total_ci_low, total_ci_high = bootstrap_mean_ci(
            total_reductions,
            replicates=bootstrap_replicates,
            seed=bootstrap_seed,
        )
        wins = sum(value > 1e-9 for value in reductions)
        losses = sum(value < -1e-9 for value in reductions)
        ties = len(reductions) - wins - losses
        total_wins = sum(value > 1e-9 for value in total_reductions)
        total_losses = sum(value < -1e-9 for value in total_reductions)
        total_ties = len(total_reductions) - total_wins - total_losses
        summary = {
            "scenario": CENTRAL_SCENARIO,
            "motion_model": "continuous",
            "metric": "noncut_time",
            "baseline": method,
            "task_count": len(tasks),
            "proposed_noncut_hours_per_task": mean(
                float(index[(task_id, METHOD_ORDER[0])]["continuous_noncut_time_s"])
                for task_id in tasks
            )
            / 3600.0,
            "baseline_noncut_hours_per_task": noncut_hours,
            "baseline_total_hours_per_task": total_hours,
            "mean_reduction_pct": mean(reductions),
            "median_reduction_pct": median(reductions),
            "reduction_ci_low": ci_low,
            "reduction_ci_high": ci_high,
            "wins": wins,
            "ties": ties,
            "losses": losses,
            "total_mean_reduction_pct": mean(total_reductions),
            "total_median_reduction_pct": median(total_reductions),
            "total_reduction_ci_low": total_ci_low,
            "total_reduction_ci_high": total_ci_high,
            "total_wins": total_wins,
            "total_ties": total_ties,
            "total_losses": total_losses,
            "bootstrap_replicates": bootstrap_replicates,
            "bootstrap_seed": bootstrap_seed,
        }
        summaries.append(summary)
        table_rows.append(
            f"{METHOD_LABELS[method]} & {noncut_hours:.3f} & "
            f"{total_hours:.3f} & {mean(reductions):.2f} "
            f"[{ci_low:.2f}, {ci_high:.2f}] & {median(reductions):.2f} & "
            f"{mean(total_reductions):.2f} "
            f"[{total_ci_low:.2f}, {total_ci_high:.2f}] & "
            f"{wins}/{ties}/{losses} & "
            f"{total_wins}/{total_ties}/{total_losses} \\\\"
        )
    body = "\n".join(table_rows)
    table = rf"""\begin{{table*}}[t]
\centering
\caption{{Nominal continuous-motion scenario at $v_{{\mathrm{{XY}}}}=200$~mm/s and $v_z=40$~mm/s. Acceleration parameters do not enter Eq.~\eqref{{eq:nc-continuous-time}}. Absolute values are task-equal hours per factory task after summing boards within seed and averaging the three seeds. Reductions report the proposed route relative to each baseline; the 95\% task-bootstrap CIs and W/T/L counts use the 20 factory tasks as independent units.}}
\label{{tab:nc-nominal-main}}
\scriptsize
\setlength{{\tabcolsep}}{{3pt}}
\resizebox{{\textwidth}}{{!}}{{%
\begin{{tabular}}{{@{{}}lrrrrrcc@{{}}}}
\toprule
Method & Non-cut (h/task) & Total (h/task) & \shortstack{{Mean non-cut\\reduction (95\% CI)}} & \shortstack{{Non-cut\\median}} & \shortstack{{Mean total\\reduction (95\% CI)}} & \shortstack{{Non-cut\\W/T/L}} & \shortstack{{Total\\W/T/L}} \\
\midrule
{body}
\bottomrule
\end{{tabular}}
}}
\end{{table*}}
"""
    return table, summaries


def build_geometry_table(rows: list[dict[str, str]]) -> str:
    index = {row["method"]: row for row in rows}
    lines = []
    for method in METHOD_ORDER:
        row = index[method]
        lines.append(
            "{} & {:.3f} & {:.3f} & {:.3f} & {:.3f} & {:.0f} & {:.0f} \\\\".format(
                METHOD_LABELS[method],
                float(row["cutting_distance_mm"]) / 1_000_000.0,
                float(row["rapid_xy_distance_mm"]) / 1_000_000.0,
                float(row["low_clearance_xy_distance_mm"]) / 1_000_000.0,
                float(row["safe_lift_xy_distance_mm"]) / 1_000_000.0,
                float(row["retract_count"]),
                float(row["nc_block_count"]),
            )
        )
    body = "\n".join(lines)
    return rf"""\begin{{table}}[t]
\centering
\caption{{Task-equal mean geometry of the canonical NC programs. Distances are kilometres per factory task; counts are per factory task. Setup and final-return motion are included in rapid XY but not in the low-clearance or safe-lift columns.}}
\label{{tab:nc-geometry-supp}}
\footnotesize
\begin{{tabular}}{{@{{}}lrrrrrr@{{}}}}
\toprule
Method & Cut & Rapid XY & Low clearance & Safe lift & Retracts & NC blocks \\
\midrule
{body}
\bottomrule
\end{{tabular}}
\end{{table}}
"""


def build_correlation_table(rows: list[dict[str, str]]) -> str:
    grouped: dict[tuple[str, str], list[float]] = defaultdict(list)
    for row in rows:
        grouped[(row["method"], row["time_metric"])].append(
            float(row["spearman_rho"])
        )
    metrics = (
        "continuous_noncut_time_s",
        "continuous_total_time_s",
        "stop_noncut_time_s",
        "stop_total_time_s",
    )
    lines = []
    for method in METHOD_ORDER:
        for metric in metrics:
            values = grouped[(method, metric)]
            if len(values) != 27:
                raise ValueError(
                    f"{method}/{metric} does not have 27 correlations"
                )
            lines.append(
                "{} & {} & {:.3f} & {:.3f} & {:.3f} \\\\".format(
                    METHOD_LABELS[method],
                    metric_label(metric),
                    min(values),
                    median(values),
                    max(values),
                )
            )
    body = "\n".join(lines)
    return rf"""\begin{{table}}[t]
\centering
\caption{{Descriptive Spearman association between task-level \(C_{{\mathrm{{plan}}}}\) and NC time across the 20 factory tasks. Entries summarize the 27 scenarios. Task scale affects both quantities, so these associations are not controller calibration or evidence of board-level prediction error.}}
\label{{tab:nc-correlation-supp}}
\scriptsize
\begin{{tabular}}{{@{{}}llrrr@{{}}}}
\toprule
Method & Metric & Min \(\rho_s\) & Median \(\rho_s\) & Max \(\rho_s\) \\
\midrule
{body}
\bottomrule
\end{{tabular}}
\end{{table}}
"""


def build_audit_table(
    completion: dict[str, object],
    merge: dict[str, object],
) -> str:
    database = completion["database_audit"]
    rows = (
        ("Frozen method--board jobs", database["actual_job_count"], database["expected_job_count"]),
        ("Distinct boards with all five methods", database["actual_board_count"], database["expected_board_count"]),
        ("Factory tasks", database["factory_task_count"], 20),
        ("Scenario rows", database["scenario_row_count"], 58_920 * 27),
        ("Non-completed jobs", sum(v for k, v in database["status_counts"].items() if k != "completed"), 0),
        ("Route-reference mismatches", database["route_reference_mismatches"], 0),
        ("NC semantic audit failures", database["nc_audit_failures"], 0),
        ("Malformed scenario grids", database["malformed_scenario_jobs"], 0),
        ("Shard job-set/merge failures", 0 if merge["passed"] else 1, 0),
    )
    lines = [
        f"{label} & {observed:,} & {required:,} \\\\"
        for label, observed, required in rows
    ]
    lines.append(
        "Maximum coordinate error (mm) & "
        f"{float(database['maximum_coordinate_error_mm']):.3g} & "
        f"$\\leq {float(database['coordinate_tolerance_mm']):.3f}$ \\\\"
    )
    body = "\n".join(lines)
    return rf"""\begin{{table}}[t]
\centering
\caption{{Hard completion and route-to-NC audit for the full holdout.}}
\label{{tab:nc-audit-supp}}
\footnotesize
\begin{{tabular}}{{@{{}}lrr@{{}}}}
\toprule
Check & Observed & Required \\
\midrule
{body}
\bottomrule
\end{{tabular}}
\end{{table}}
"""


def write_task_reductions(
    task_rows: list[dict[str, str]],
    output: Path,
) -> None:
    index = {
        (row["task_id"], row["method"], row["scenario"]): row
        for row in task_rows
    }
    tasks = sorted({row["task_id"] for row in task_rows})
    scenarios = sorted({row["scenario"] for row in task_rows})
    fields = (
        "continuous_noncut_time_s",
        "continuous_total_time_s",
        "stop_noncut_time_s",
        "stop_total_time_s",
    )
    rows = []
    for scenario in scenarios:
        for baseline in METHOD_ORDER[1:]:
            for task_id in tasks:
                proposed = index[(task_id, METHOD_ORDER[0], scenario)]
                reference = index[(task_id, baseline, scenario)]
                row = {
                    "task_id": task_id,
                    "scenario": scenario,
                    "baseline": baseline,
                }
                for field in fields:
                    p = float(proposed[field])
                    r = float(reference[field])
                    row[f"{field}_reduction_pct"] = 100.0 * (r - p) / r
                rows.append(row)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys(), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    required = (
        "scenario_robustness_summary.csv",
        "task_scenario_metrics.csv",
        "task_equal_geometry_summary.csv",
        "planning_nc_spearman.csv",
        "completion_audit.json",
        "merge_audit.json",
    )
    missing = [name for name in required if not (FULL_OUTPUT / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing full-run artifacts: {missing}")
    robustness = read_csv(FULL_OUTPUT / "scenario_robustness_summary.csv")
    task_rows = read_csv(FULL_OUTPUT / "task_scenario_metrics.csv")
    geometry = read_csv(FULL_OUTPUT / "task_equal_geometry_summary.csv")
    correlations = read_csv(FULL_OUTPUT / "planning_nc_spearman.csv")
    completion = json.loads(
        (FULL_OUTPUT / "completion_audit.json").read_text(encoding="utf-8")
    )
    merge = json.loads(
        (FULL_OUTPUT / "merge_audit.json").read_text(encoding="utf-8")
    )
    if not completion["passed"] or not merge["passed"]:
        raise RuntimeError("publication assets require passed merge and completion audits")

    write_text_pair(
        "table_nc_kinematic_validation.tex",
        build_main_table(robustness),
    )
    write_text_pair(
        "supp_table_nc_robustness.tex",
        build_robustness_table(robustness),
    )
    write_text_pair(
        "supp_table_nc_reference_scenario.tex",
        build_reference_table(task_rows),
    )
    nominal_table, nominal_summaries = build_nominal_table(task_rows)
    write_text_pair(
        "table_nc_nominal_scenario.tex",
        nominal_table,
    )
    nominal_output = ASSET_OUTPUT / "nominal_scenario_task_summary.csv"
    with nominal_output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(nominal_summaries[0]),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(nominal_summaries)
    write_text_pair(
        "supp_table_nc_geometry.tex",
        build_geometry_table(geometry),
    )
    write_text_pair(
        "supp_table_nc_correlation.tex",
        build_correlation_table(correlations),
    )
    write_text_pair(
        "supp_table_nc_audit.tex",
        build_audit_table(completion, merge),
    )
    write_task_reductions(
        task_rows,
        ASSET_OUTPUT / "task_scenario_paired_reductions.csv",
    )
    summary = {
        "scope": (
            "Transparent controller-agnostic NC-level kinematic sensitivity; "
            "not measured machine time or manufacturing validation."
        ),
        "central_scenario": CENTRAL_SCENARIO,
        "factory_task_count": 20,
        "scenario_count": 27,
        "robustness": robustness,
    }
    (ASSET_OUTPUT / "publication_values.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(ASSET_OUTPUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
