from __future__ import annotations

import xml.etree.ElementTree as ET

from scripts.preflight_factory_xml import (
    positive_interior_overlap,
    rectangle_overlap_count,
    validate_lineament,
)


def workpiece_xml(points: list[tuple[float, float]]) -> ET.Element:
    point_xml = "".join(
        f'<Point Index="{index}" X="{x}" Y="{y}" />'
        for index, (x, y) in enumerate(points, start=1)
    )
    return ET.fromstring(
        f"""
        <Workpiece WorkpieceId="part-1" CutLength="94" CutWidth="44"
          Designer="94" clerk="44" RotateAngle="0">
          <Lineament RotationAngle="0">
            <Points>{point_xml}</Points>
          </Lineament>
        </Workpiece>
        """
    )


def test_lineament_recovers_nominal_rectangle_from_compensated_bbox() -> None:
    workpiece = workpiece_xml(
        [(3, 3), (103, 3), (103, 53), (3, 53), (3, 3)]
    )
    pattern = ET.fromstring('<Pattern ToolDiameter="6" />')

    result = validate_lineament(
        workpiece,
        pattern,
        task_id="ZJ_TEST",
        confirmatory_status="confirmatory_holdout",
        pattern_id="pattern-1",
        pattern_sequence=1,
        workpiece_sequence=1,
        board_length=200,
        board_width=100,
    )

    assert result.geometry_status == "passed"
    assert result.nominal_x == 6
    assert result.nominal_y == 6
    assert result.nominal_width == 94
    assert result.nominal_height == 44


def test_lineament_rejects_centerline_outside_board() -> None:
    workpiece = workpiece_xml(
        [(-0.5, 3), (99.5, 3), (99.5, 53), (-0.5, 53), (-0.5, 3)]
    )
    pattern = ET.fromstring('<Pattern ToolDiameter="6" />')

    result = validate_lineament(
        workpiece,
        pattern,
        task_id="ZJ_TEST",
        confirmatory_status="confirmatory_holdout",
        pattern_id="pattern-1",
        pattern_sequence=1,
        workpiece_sequence=1,
        board_length=200,
        board_width=100,
    )

    assert result.geometry_status == "failed"
    assert "cutter_center_outside_board" in result.geometry_errors


def test_touching_rectangles_are_not_positive_area_overlaps() -> None:
    first = (0.0, 0.0, 10.0, 10.0)
    touching = (10.0, 0.0, 20.0, 10.0)
    overlapping = (9.0, 0.0, 20.0, 10.0)

    assert not positive_interior_overlap(first, touching)
    assert positive_interior_overlap(first, overlapping)
    assert rectangle_overlap_count((first, touching, overlapping)) == 2
