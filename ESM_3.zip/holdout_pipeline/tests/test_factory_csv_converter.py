from __future__ import annotations

import csv
from decimal import Decimal
import io
from pathlib import Path
from zipfile import ZipFile

import pytest

from scripts.factory_csv_converter import (
    audit_alias,
    read_factory_inventory,
    write_inventory,
)


def write_factory_csv(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="gb18030", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["Upi", "Fleng", "Fwidth", "Quantity", "PartName"]
        )
        writer.writeheader()
        writer.writerows(rows)


def test_converter_uses_finished_dimensions_and_expands_quantity(
    tmp_path: Path,
) -> None:
    source = tmp_path / "TASK_ZN_GSTX.csv"
    write_factory_csv(
        source,
        [
            {
                "Upi": "A",
                "Fleng": "12.50",
                "Fwidth": "7",
                "Quantity": "2",
                "PartName": "测试件",
            }
        ],
    )

    parts = read_factory_inventory(source)

    assert len(parts) == 2
    assert [(part.w0, part.h0) for part in parts] == [
        (Decimal("12.50"), Decimal("7")),
        (Decimal("12.50"), Decimal("7")),
    ]
    assert parts[0].uid == "TASK:r000001:q001"
    assert parts[1].uid == "TASK:r000001:q002"

    output = tmp_path / "inventory.csv"
    write_inventory(output, parts)
    with output.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert [row["w0"] for row in rows] == ["12.5", "12.5"]
    assert [row["h0"] for row in rows] == ["7", "7"]


@pytest.mark.parametrize("quantity", ["0", "-1", "1.5", "bad"])
def test_converter_rejects_invalid_quantity(
    tmp_path: Path, quantity: str
) -> None:
    source = tmp_path / "TASK_ZN_GSTX.csv"
    write_factory_csv(
        source,
        [
            {
                "Upi": "A",
                "Fleng": "12",
                "Fwidth": "7",
                "Quantity": quantity,
                "PartName": "测试件",
            }
        ],
    )

    with pytest.raises(ValueError, match="Quantity"):
        read_factory_inventory(source)


def test_gate_requires_oriented_multiset_equality(tmp_path: Path) -> None:
    source = tmp_path / "TASK_ZN_GSTX.csv"
    write_factory_csv(
        source,
        [
            {
                "Upi": "A",
                "Fleng": "12",
                "Fwidth": "7",
                "Quantity": "1",
                "PartName": "测试件",
            }
        ],
    )
    parts = read_factory_inventory(source)
    archive_path = tmp_path / "history.zip"
    placement = io.StringIO(newline="")
    writer = csv.DictWriter(placement, fieldnames=["w0", "h0"])
    writer.writeheader()
    writer.writerow({"w0": "7", "h0": "12"})
    with ZipFile(archive_path, "w") as archive:
        archive.writestr("experiment__data1/seed/placements.csv", placement.getvalue())

    with ZipFile(archive_path) as archive:
        result = audit_alias(
            archive=archive,
            alias="data1",
            task_id="TASK",
            parts=parts,
            raw_record_count=1,
        )

    assert result.normalized_missing_count == 0
    assert result.normalized_extra_count == 0
    assert result.oriented_missing_count == 1
    assert result.oriented_extra_count == 1
    assert result.passed is False
