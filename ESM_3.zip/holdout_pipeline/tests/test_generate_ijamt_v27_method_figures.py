from scripts.generate_ijamt_v27_method_figures import (
    make_process_state_figure,
    make_solver_flow_figure,
    process_trigger_spec,
    workflow_spec,
)


def test_process_modes_are_alternatives() -> None:
    spec = process_trigger_spec()
    assert spec["travel_responses"] == ("detour", "safe_lift")
    assert spec["travel_relation"] == "exclusive_alternatives"
    assert spec["support_threshold"] == r"L_i(k)<\rho_iL_i^0"


def test_workflow_has_one_feedback_edge_and_no_mcts() -> None:
    spec = workflow_spec()
    assert sum(edge[2] == "feedback" for edge in spec["edges"]) == 1
    assert "Prefix Beam MCTS" not in " ".join(spec["nodes"].values())
    assert spec["order"].index("validation") < spec["order"].index("outputs")
    assert spec["order"].index("outputs") < spec["order"].index("analyses")


def test_process_figure_exports_all_formats(tmp_path) -> None:
    outputs = make_process_state_figure(tmp_path)
    assert [path.suffix for path in outputs] == [".pdf", ".svg", ".png"]
    assert all(path.stat().st_size > 10_000 for path in outputs)


def test_solver_flow_exports_and_preserves_claims(tmp_path) -> None:
    outputs = make_solver_flow_figure(tmp_path)
    svg = outputs[1].read_text(encoding="utf-8")
    assert all(path.stat().st_size > 10_000 for path in outputs)
    assert "Prefix Beam MCTS" not in svg
    assert "inactive in reported cohort" in svg
    assert svg.index("Validation") < svg.index("Directed route")
