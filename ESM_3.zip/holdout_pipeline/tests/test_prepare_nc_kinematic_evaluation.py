from __future__ import annotations

from collections import Counter

from scripts.prepare_nc_kinematic_evaluation import (
    BOARDS_PER_TASK,
    select_pilot_boards,
)


def test_pilot_selection_is_seeded_task_balanced_and_seed_covering() -> None:
    rows = []
    for task_index in range(2):
        for seed in ("seed_1000", "seed_1001", "seed_1002"):
            for board in range(4):
                rows.append(
                    {
                        "task_id": f"task_{task_index}",
                        "packing_seed": seed,
                        "placements_member": f"task_{task_index}/{seed}/placements.csv",
                        "board_id": str(board),
                    }
                )

    first = select_pilot_boards(rows, expected_tasks=2)
    second = select_pilot_boards(list(reversed(rows)), expected_tasks=2)

    assert first == second
    assert Counter(row["task_id"] for row in first) == {
        "task_0": BOARDS_PER_TASK,
        "task_1": BOARDS_PER_TASK,
    }
    for task in ("task_0", "task_1"):
        assert {
            row["packing_seed"] for row in first if row["task_id"] == task
        } == {"seed_1000", "seed_1001", "seed_1002"}
