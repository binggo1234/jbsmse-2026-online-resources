from __future__ import annotations

import math

from scripts.analyze_holdout_results import (
    METHODS,
    PROPOSED,
    SEEDS,
    aggregate_task,
    aggregate_task_seed,
    build_seed_sensitivity,
    exact_two_sided_sign_test,
    holm_adjust,
    numerically_equal,
    summarize_pair,
)


def route_row(
    task_number: int,
    seed: str,
    method: str,
    board_id: int,
) -> dict[str, str]:
    return {
        "job_id": f"{task_number}-{seed}-{method}-{board_id}",
        "placement_method": f"ZJ_TASK_{task_number:02d}",
        "seed": seed,
        "placements_member": f"task_{task_number}/{seed}/placements.csv",
        "board_id": str(board_id),
        "method": method,
        "cutting_length": "10",
        "travel_mode_cost": "1",
        "air_move_distance": "1",
        "pierce_count": "2",
        "lift_count": "2",
        "safe_lift_count": "0",
        "process_tool_event_count": "4",
        "stability_penalty": "0",
        "runtime_ms": "5",
        "hard_penalty": "0",
    }


def test_aggregation_sums_boards_then_equal_weights_seeds() -> None:
    rows: list[dict[str, str]] = []
    for task_number in range(20):
        for seed_index, seed in enumerate(SEEDS, start=1):
            for method in METHODS:
                for board_id in range(seed_index):
                    rows.append(route_row(task_number, seed, method, board_id))

    task_seed = aggregate_task_seed(rows)
    tasks = aggregate_task(task_seed)
    selected = next(
        row
        for row in tasks
        if row["task_id"] == "ZJ_TASK_00" and row["method"] == PROPOSED
    )

    assert selected["seed_count"] == 3
    assert selected["board_count_mean"] == 2
    assert selected["c_plan"] == 22
    assert selected["cutting_length"] == 20
    assert selected["travel_mode_cost"] == 2


def test_pair_summary_uses_twenty_tasks_not_nested_rows() -> None:
    task_rows: list[dict[str, object]] = []
    baseline = "topology_process_aware"
    for task_number in range(20):
        task_id = f"ZJ_TASK_{task_number:02d}"
        for method in METHODS:
            value = 90.0 if method == PROPOSED else 100.0
            task_rows.append(
                {
                    "task_id": task_id,
                    "method": method,
                    "c_plan": value,
                }
            )

    summary, pairs = summarize_pair(
        task_rows,
        baseline,
        "c_plan",
        bootstrap_replicates=200,
    )

    assert len(pairs) == 20
    assert summary.task_count == 20
    assert summary.mean_reduction_pct == 10
    assert summary.wins == 20
    assert summary.ties == 0
    assert summary.losses == 0
    assert math.isclose(summary.sign_test_p_raw, 2 / (2**20))


def test_numerical_tie_sign_test_and_holm_rules() -> None:
    assert numerically_equal(1_000_000.0, 1_000_000.0005)
    assert not numerically_equal(1_000_000.0, 1_000_000.01)
    assert exact_two_sided_sign_test(0, 0) == 1
    assert exact_two_sided_sign_test(10, 10) == 1
    assert holm_adjust({"a": 0.01, "b": 0.04}) == {"a": 0.02, "b": 0.04}


def test_seed_sensitivity_uses_variation_within_each_task() -> None:
    task_seed_rows: list[dict[str, object]] = []
    for task_number in range(20):
        for method in METHODS:
            for value, seed in zip((10.0, 20.0, 30.0), SEEDS):
                task_seed_rows.append(
                    {
                        "task_id": f"ZJ_TASK_{task_number:02d}",
                        "method": method,
                        "packing_seed": seed,
                        **{
                            metric: value
                            for metric in (
                                "c_plan",
                                "travel_mode_cost",
                                "air_move_distance",
                                "tool_event_count",
                                "support_policy_penalty",
                                "runtime_ms",
                                "cutting_length",
                            )
                        },
                    }
                )

    rows = build_seed_sensitivity(task_seed_rows)
    selected = next(
        row
        for row in rows
        if row["method"] == PROPOSED and row["metric"] == "c_plan"
    )

    assert selected["task_count"] == 20
    assert selected["mean_task_value"] == 20
    assert math.isclose(
        float(selected["mean_within_task_seed_cv_pct"]),
        100 * math.sqrt(200 / 3) / 20,
    )
