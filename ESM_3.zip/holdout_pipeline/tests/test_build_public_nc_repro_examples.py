from pathlib import Path

import pytest

from scripts.build_public_nc_repro_examples import select_layout_paths


def test_select_layout_paths_preserves_declared_public_example_set(
    tmp_path: Path,
) -> None:
    for name in ("public_NGCUT1.json", "public_OF1.json"):
        (tmp_path / name).write_text("{}", encoding="utf-8")

    selected = select_layout_paths(
        tmp_path,
        ("public_OF1.json", "public_NGCUT1.json"),
    )

    assert [path.name for path in selected] == [
        "public_OF1.json",
        "public_NGCUT1.json",
    ]


def test_select_layout_paths_rejects_missing_public_example(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="public_BENG01.json"):
        select_layout_paths(tmp_path, ("public_BENG01.json",))
