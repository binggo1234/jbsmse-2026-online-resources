from __future__ import annotations

from scripts.analyze_factory_xml_results import (
    CONFIRMATORY,
    SUPPLEMENTARY,
    aggregate_tasks,
    cohort_method_summary,
)
from scripts.analyze_holdout_results import METHODS, PROPOSED


def route_row(
    task_number: int,
    cohort: str,
    method: str,
    pattern_number: int,
) -> dict[str, str]:
    return {
        "confirmatory_status": cohort,
        "task_id": f"ZJ_TASK_{task_number:02d}",
        "pattern_id": f"ZJ_TASK_{task_number:02d}:p{pattern_number}",
        "method": method,
        "cutting_length": "10",
        "travel_mode_cost": "1",
        "air_move_distance": "1",
        "pierce_count": "2",
        "lift_count": "2",
        "safe_lift_count": "0",
        "process_tool_event_count": "4",
        "stability_penalty": "0",
        "runtime_ms": "5",
        "hard_penalty": "0",
    }


def test_track_b_sums_patterns_within_task_and_keeps_cohorts_separate() -> None:
    rows: list[dict[str, str]] = []
    for task_number in range(11):
        cohort = CONFIRMATORY if task_number < 7 else SUPPLEMENTARY
        for method in METHODS:
            rows.append(route_row(task_number, cohort, method, 1))
            if task_number == 0:
                rows.append(route_row(task_number, cohort, method, 2))

    tasks = aggregate_tasks(rows)
    assert len(tasks) == 11 * len(METHODS)
    selected = next(
        row
        for row in tasks
        if row["task_id"] == "ZJ_TASK_00" and row["method"] == PROPOSED
    )
    assert selected["confirmatory_status"] == CONFIRMATORY
    assert selected["pattern_count"] == 2
    assert selected["c_plan"] == 22
    assert selected["cutting_length"] == 20
    assert selected["travel_mode_cost"] == 2

    confirmatory = [
        row for row in tasks if row["confirmatory_status"] == CONFIRMATORY
    ]
    summary = cohort_method_summary(confirmatory)
    proposed = next(row for row in summary if row["method"] == PROPOSED)
    assert proposed["task_count"] == 7
