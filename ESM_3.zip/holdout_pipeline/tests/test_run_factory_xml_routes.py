from scripts.run_factory_xml_routes import METHODS, make_jobs


def pattern(pattern_id: str) -> dict[str, str]:
    return {
        "task_id": "ZJ_TEST",
        "confirmatory_status": "confirmatory_holdout",
        "pattern_id": pattern_id,
        "pattern_sequence": "1",
        "placements_member": f"track_b/ZJ_TEST/{pattern_id}/placements.csv",
        "workpiece_count": "4",
    }


def test_track_b_schedule_contains_every_method_once_per_pattern() -> None:
    jobs = make_jobs([pattern("p1"), pattern("p2")])

    assert len(jobs) == 2 * len(METHODS)
    assert len({job["job_id"] for job in jobs}) == len(jobs)
    assert [job["schedule_order"] for job in jobs] == list(range(1, len(jobs) + 1))
    for pattern_id in ("p1", "p2"):
        assert {
            job["method"] for job in jobs if job["pattern_id"] == pattern_id
        } == set(METHODS)
