from __future__ import annotations

from decimal import Decimal
from pathlib import Path

from scripts.factory_csv_converter import InventoryPart
from scripts.prepare_holdout_preflight import (
    build_run_rows,
    envelope_fits,
)


def part(width: str, height: str) -> InventoryPart:
    return InventoryPart(
        task_id="TASK",
        uid="TASK:r000001:q001",
        pid_raw="raw",
        w0=Decimal(width),
        h0=Decimal(height),
        source_row=1,
        quantity_index=1,
        source_csv_sha256="source",
    )


def test_envelope_fit_accepts_rotation_and_rejects_oversize() -> None:
    assert envelope_fits(part("2400", "1200")) is True
    assert envelope_fits(part("1200", "2400")) is True
    assert envelope_fits(part("2430", "1210")) is False


def test_run_schedule_contains_three_nested_seeds_per_task(
    tmp_path: Path,
) -> None:
    from scripts.prepare_holdout_preflight import PreflightResult

    results = [
        PreflightResult(
            task_id=f"TASK_{index:02d}",
            source_record_count=1,
            converted_part_count=1,
            quantity_expansion_count=0,
            unique_uid_count=1,
            blank_source_upi_count=0,
            material_count=1,
            materials="VA_18_TEST",
            thickness_count=1,
            thicknesses_mm="18",
            graining_values="1",
            minimum_width_mm="1",
            maximum_width_mm="1",
            minimum_height_mm="1",
            maximum_height_mm="1",
            oversized_envelope_count=0,
            inventory_sha256=f"hash-{index}",
            format_passed=True,
            geometry_passed=True,
            passed=True,
        )
        for index in range(20)
    ]

    rows = build_run_rows(
        results=results,
        inventory_dir=tmp_path,
        stage7_commit="commit",
        kerf_packing_sha256="kerf",
        converter_sha256="converter",
        runner_sha256="runner",
    )

    assert len(rows) == 60
    for result in results:
        task_rows = [row for row in rows if row["task_id"] == result.task_id]
        assert {row["packing_seed"] for row in task_rows} == {1000, 1001, 1002}
    assert [row["run_order"] for row in rows] == list(range(1, 61))
