from __future__ import annotations

import pytest

from scripts.analyze_nc_kinematic_results import spearman


def test_spearman_tracks_rank_not_scale() -> None:
    assert spearman([1, 2, 3], [10, 20, 1000]) == pytest.approx(1.0)
    assert spearman([1, 2, 3], [1000, 20, 10]) == pytest.approx(-1.0)


def test_spearman_uses_average_ranks_for_ties() -> None:
    assert spearman([1, 1, 2], [3, 3, 9]) == pytest.approx(1.0)
