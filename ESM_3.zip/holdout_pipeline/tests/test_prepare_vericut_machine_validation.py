from pathlib import Path

from scripts.prepare_vericut_machine_validation import (
    DEFAULT_LAYOUT_ZIP,
    DEFAULT_NC_ROOT,
    DEFAULT_SELECTION,
    CASE_LAYOUTS,
    METHODS,
    build_package,
    merge_segments,
    parse_cut_segments,
    segment_union_hash,
)


def test_three_methods_have_identical_centerline_union() -> None:
    for case_id in CASE_LAYOUTS:
        unions = [
            merge_segments(
                parse_cut_segments(DEFAULT_NC_ROOT / case_id / f"{method}.nc")
            )
            for method in METHODS
        ]
        assert unions[0] == unions[1] == unions[2]
        assert len(unions[0]) > 0


def test_build_package_preserves_nc_and_builds_oracles(tmp_path: Path) -> None:
    output = tmp_path / "vericut_v3"
    build_package(
        output,
        nc_root=DEFAULT_NC_ROOT,
        selection_path=DEFAULT_SELECTION,
        layout_zip=DEFAULT_LAYOUT_ZIP,
    )
    assert len(list((output / "cases").glob("*/*.nc"))) == 15
    assert len(list((output / "geometry_oracles").glob("*/design_oracle.nc"))) == 5
    assert (output / "windows" / "preflight_gate.ps1").is_file()
    assert (output / "protocol" / "FROZEN_PROTOCOL.md").is_file()

    for case_id in CASE_LAYOUTS:
        method_hashes = {
            segment_union_hash(
                merge_segments(
                    parse_cut_segments(output / "cases" / case_id / f"{method}.nc")
                )
            )
            for method in METHODS
        }
        assert len(method_hashes) == 1
