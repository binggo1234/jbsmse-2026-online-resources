from collections import namedtuple

from scripts.audit_holdout_routes import audit_plan_atomic_spans


Span = namedtuple("Span", "span_id")
UnitType = namedtuple("UnitType", "value")
Unit = namedtuple("Unit", "unit_id unit_type covered_spans")
ActionType = namedtuple("ActionType", "value")
Action = namedtuple(
    "Action",
    "action_type cutting_unit_id covered_spans covered_segment_ids segment_id",
)
Plan = namedtuple("Plan", "actions")


def test_atomic_span_audit_detects_missing_repeated_and_unknown() -> None:
    single = UnitType("single_edge")
    cut = ActionType("cut")
    units = (
        Unit("u1", single, (Span("a"),)),
        Unit("u2", single, (Span("b"),)),
        Unit("u3", single, (Span("c"),)),
    )
    plan = Plan(
        (
            Action(cut, "u1", (Span("a"),), (), None),
            Action(cut, "u1", (Span("a"),), (), None),
            Action(cut, "missing-unit", (Span("b"),), (), None),
        )
    )
    assert audit_plan_atomic_spans(units, plan, cut) == (3, 2, 1, 1, 1, 2 / 3)
