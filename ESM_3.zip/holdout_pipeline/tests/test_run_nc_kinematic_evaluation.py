from __future__ import annotations

from types import SimpleNamespace

import pytest

from scripts.run_nc_kinematic_evaluation import (
    reference_mismatches,
    select_shard_jobs,
)


def test_reference_mismatch_check_accepts_frozen_equivalent_metrics() -> None:
    metrics = SimpleNamespace(
        air_move_distance=10.0,
        cutting_length=20.0,
        pierce_count=2,
        lift_count=1,
        collision_penalty=0.0,
        boundary_penalty=0.0,
        stability_penalty=0.0,
        safe_lift_count=1,
        safe_lift_distance=4.0,
        detour_count=2,
        detour_distance=6.0,
        travel_mode_cost=260.0,
    )
    plan = SimpleNamespace(actions=(1, 2, 3), metrics=metrics)
    reference = {
        "action_count": "3",
        "air_move_distance": "10",
        "cutting_length": "20",
        "pierce_count": "2",
        "lift_count": "1",
        "collision_penalty": "0",
        "boundary_penalty": "0",
        "stability_penalty": "0",
        "safe_lift_count": "1",
        "safe_lift_distance": "4",
        "detour_count": "2",
        "detour_distance": "6",
        "travel_mode_cost": "260",
    }

    assert reference_mismatches(plan, reference) == []


def test_reference_mismatch_check_reports_changed_route() -> None:
    metrics = SimpleNamespace(
        air_move_distance=11.0,
        cutting_length=20.0,
        pierce_count=2,
        lift_count=1,
        collision_penalty=0.0,
        boundary_penalty=0.0,
        stability_penalty=0.0,
        safe_lift_count=1,
        safe_lift_distance=4.0,
        detour_count=2,
        detour_distance=6.0,
        travel_mode_cost=260.0,
    )
    plan = SimpleNamespace(actions=(1, 2, 3), metrics=metrics)
    reference = {
        "action_count": "3",
        "air_move_distance": "10",
        "cutting_length": "20",
        "pierce_count": "2",
        "lift_count": "1",
        "collision_penalty": "0",
        "boundary_penalty": "0",
        "stability_penalty": "0",
        "safe_lift_count": "1",
        "safe_lift_distance": "4",
        "detour_count": "2",
        "detour_distance": "6",
        "travel_mode_cost": "260",
    }

    assert reference_mismatches(plan, reference) == [
        "air_move_distance: 11 != 10"
    ]


def test_board_shards_are_disjoint_complete_and_keep_methods_together() -> None:
    methods = ("m1", "m2", "m3", "m4", "m5")
    jobs = []
    schedule_order = 0
    for board_index in range(10):
        for method in methods:
            schedule_order += 1
            jobs.append(
                {
                    "job_id": f"job-{schedule_order}",
                    "schedule_order": str(schedule_order),
                    "placements_member": f"placements-{board_index // 3}.csv",
                    "board_id": str(board_index),
                    "method": method,
                }
            )

    shards = [
        select_shard_jobs(jobs, shard_index=index, shard_count=4)
        for index in range(4)
    ]

    assert set().union(
        *({row["job_id"] for row in shard} for shard in shards)
    ) == {row["job_id"] for row in jobs}
    assert sum(len(shard) for shard in shards) == len(jobs)
    for shard in shards:
        by_board = {}
        for row in shard:
            key = (row["placements_member"], row["board_id"])
            by_board.setdefault(key, set()).add(row["method"])
        assert set(map(frozenset, by_board.values())) == {frozenset(methods)}


def test_board_shard_arguments_are_validated() -> None:
    jobs = [
        {
            "job_id": "job-1",
            "schedule_order": "1",
            "placements_member": "p.csv",
            "board_id": "0",
            "method": "m1",
        }
    ]

    with pytest.raises(ValueError):
        select_shard_jobs(jobs, shard_index=0, shard_count=0)
    with pytest.raises(ValueError):
        select_shard_jobs(jobs, shard_index=2, shard_count=2)
