import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "scripts"
    / "generate_ijamt_time_mapping_sensitivity.py"
)
SPEC = importlib.util.spec_from_file_location("time_mapping", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class TimeMappingTests(unittest.TestCase):
    def test_estimate_uses_locked_additive_mapping(self):
        row = {
            "cutting_length": "1000",
            "air_move_distance": "300",
            "safe_lift_count": "2",
            "tool_event_count": "10",
        }
        scenario = {
            "cut_speed_mm_s": 100,
            "air_speed_mm_s": 300,
            "safe_lift_time_s": 1,
            "tool_event_time_s": 0.2,
        }
        self.assertAlmostEqual(MODULE.estimate_seconds(row, scenario), 15.0)


if __name__ == "__main__":
    unittest.main()
