from scripts.run_holdout_routes import (
    freeze_timeout_seconds,
    make_jobs,
    rectangle_count_bin,
    select_runtime_pilot_boards,
)


def board(member: str, board_id: int, count: int) -> dict[str, object]:
    return {
        "run_id": member,
        "run_order": 1,
        "task_id": member,
        "packing_seed": 1000,
        "placements_member": member,
        "board_id": str(board_id),
        "rectangle_count": count,
        "rectangle_count_bin": rectangle_count_bin(count),
        "geometry_sha256": str(board_id),
    }


def test_rectangle_count_bins_cover_frozen_range() -> None:
    assert rectangle_count_bin(2) == "002_005"
    assert rectangle_count_bin(6) == "006_010"
    assert rectangle_count_bin(11) == "011_015"
    assert rectangle_count_bin(16) == "016_020"
    assert rectangle_count_bin(29) == "021_029"


def test_pilot_selection_covers_members_and_bin_minimums() -> None:
    rows = [
        board(f"member_{member}", member * 100 + index, count)
        for member in range(3)
        for index, count in enumerate((2, 7, 12, 17, 22, 23))
    ]
    selected = select_runtime_pilot_boards(rows, minimum_per_bin=2, seed=7)
    assert {row["placements_member"] for row in selected} == {
        "member_0",
        "member_1",
        "member_2",
    }
    for count_bin in {row["rectangle_count_bin"] for row in rows}:
        assert (
            sum(row["rectangle_count_bin"] == count_bin for row in selected) >= 2
        )
    assert len(
        {(row["placements_member"], row["board_id"]) for row in selected}
    ) == len(selected)


def test_job_schedule_is_complete_unique_and_deterministic() -> None:
    rows = [board("a", 1, 2), board("b", 1, 8)]
    jobs = make_jobs(rows, ("m1", "m2"), schedule_seed=11)
    assert jobs == make_jobs(rows, ("m1", "m2"), schedule_seed=11)
    assert len(jobs) == 4
    assert len({job["job_id"] for job in jobs}) == 4
    assert [job["schedule_order"] for job in jobs] == [1, 2, 3, 4]
    assert {
        (job["placements_member"], job["board_id"], job["method"])
        for job in jobs
    } == {
        ("a", "1", "m1"),
        ("a", "1", "m2"),
        ("b", "1", "m1"),
        ("b", "1", "m2"),
    }


def test_timeout_freeze_formula() -> None:
    assert freeze_timeout_seconds([1.0, 2999.0]) == 30.0
    assert freeze_timeout_seconds([3100.0]) == 35.0
