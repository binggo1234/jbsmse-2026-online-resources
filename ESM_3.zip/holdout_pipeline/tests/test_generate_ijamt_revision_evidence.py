import csv
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "scripts"
    / "generate_ijamt_revision_evidence.py"
)
SPEC = importlib.util.spec_from_file_location("revision_evidence", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class RevisionEvidenceTests(unittest.TestCase):
    def test_task_equal_aggregation_sums_boards_then_averages_seeds_and_tasks(self):
        track = MODULE.TrackInput("holdout", Path("unused.csv"), "placement_method")
        rows = []
        for task, seed, cutting, air, detour, safe, premium in (
            ("task_a", "1", 10, 5, 1, 1, 2),
            ("task_a", "1", 20, 7, 2, 1, 2),
            ("task_a", "2", 40, 10, 2, 2, 4),
            ("task_b", "1", 30, 8, 1, 1, 2),
        ):
            row = {column: "0" for column in MODULE.DECOMPOSITION_COLUMNS}
            row.update(
                {
                    "method": "m",
                    "placement_method": task,
                    "seed": seed,
                    "cutting_length": str(cutting),
                    "air_move_distance": str(air),
                    "detour_distance": str(detour),
                    "safe_lift_distance": str(safe),
                    "travel_mode_cost": str(air + premium),
                }
            )
            rows.append(row)

        result = MODULE.aggregate_task_equal(track, rows)

        self.assertEqual(len(result), 1)
        summary = result[0]
        # task_a cutting mean across seed totals: mean(30, 40) = 35;
        # task_b = 30; task-equal mean = 32.5.
        self.assertAlmostEqual(summary["cutting_length"], 32.5)
        self.assertAlmostEqual(summary["direct_low_clearance_distance"], 6.25)
        self.assertAlmostEqual(summary["safe_lift_fixed_premium"], 3.0)
        self.assertEqual(summary["independent_task_count"], 2)

    def test_xml_status_reader_rejects_conflicting_labels(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "status.csv"
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(
                    handle, fieldnames=["task_id", "confirmatory_status"]
                )
                writer.writeheader()
                writer.writerow(
                    {"task_id": "a", "confirmatory_status": "confirmatory_holdout"}
                )
                writer.writerow(
                    {
                        "task_id": "a",
                        "confirmatory_status": "excluded_prior_upstream_use",
                    }
                )
            with self.assertRaisesRegex(ValueError, "inconsistent"):
                MODULE.read_xml_task_status(path)


if __name__ == "__main__":
    unittest.main()
