from pathlib import Path

from scripts.build_vericut_machine_validation_handoff import (
    DEFAULT_EXPERIMENT,
    DEFAULT_NOMINAL_ROOT,
    NOMINAL_FILES,
    build_handoff,
    sha256_file,
)


def test_build_handoff_preserves_nominal_files(tmp_path: Path) -> None:
    output = tmp_path / "handoff"
    build_handoff(
        output,
        experiment=DEFAULT_EXPERIMENT,
        nominal_root=DEFAULT_NOMINAL_ROOT,
    )

    assert (output / "README_FIRST_CN.md").is_file()
    assert (
        output
        / "03_to_be_completed"
        / "WINDOWS_MACHINE_INPUT_FORM_CN.csv"
    ).is_file()
    assert len(list((output / "01_experiment_package" / "cases").glob("*/*.nc"))) == 15

    for name in NOMINAL_FILES:
        copied = output / "02_nominal_reference_only" / name
        assert copied.is_file()
        assert sha256_file(copied) == sha256_file(DEFAULT_NOMINAL_ROOT / name)
