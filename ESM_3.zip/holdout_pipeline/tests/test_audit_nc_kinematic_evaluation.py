from __future__ import annotations

import sqlite3

from scripts.audit_nc_kinematic_evaluation import database_audit
from scripts.run_nc_kinematic_evaluation import connect_database


def test_database_audit_checks_exact_manifest_and_scenario_grid(tmp_path) -> None:
    database = tmp_path / "results.sqlite"
    connection = connect_database(database)
    methods = ("m1", "m2")
    jobs = []
    schedule_order = 0
    for task_index in range(2):
        for seed in ("1000", "1001", "1002"):
            for method in methods:
                schedule_order += 1
                job_id = f"job-{schedule_order}"
                row = {
                    "job_id": job_id,
                    "schedule_order": schedule_order,
                    "task_id": f"task-{task_index}",
                    "packing_seed": seed,
                    "placements_member": f"task-{task_index}-{seed}.csv",
                    "board_id": "0",
                    "method": method,
                }
                jobs.append(row)
                connection.execute(
                    """
                    INSERT INTO job_results (
                        job_id, schedule_order, task_id, packing_seed,
                        placements_member, board_id, method, status,
                        error_class, error_message, planner_runtime_ms,
                        action_sequence_sha256, gcode_sha256,
                        source_action_count, nc_action_count,
                        cut_xy_block_count, travel_xy_block_count,
                        return_xy_block_count, maximum_coordinate_error_mm,
                        audit_passed, audit_errors, reference_match,
                        reference_mismatches, cutting_distance_mm,
                        rapid_xy_distance_mm, setup_xy_distance_mm,
                        low_clearance_xy_distance_mm, safe_lift_xy_distance_mm,
                        return_xy_distance_mm, z_retract_distance_mm,
                        z_plunge_distance_mm, retract_count, plunge_count,
                        direction_change_count, nc_block_count,
                        source_cutting_length_mm, source_air_move_distance_mm,
                        source_travel_mode_cost, source_safe_lift_count,
                        source_detour_count
                    ) VALUES (
                        ?,?,?,?,?,?,?,'completed','','',0,?,?,1,1,1,0,0,0,
                        1,'[]',1,'[]',1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0
                    )
                    """,
                    (
                        job_id,
                        schedule_order,
                        row["task_id"],
                        seed,
                        row["placements_member"],
                        "0",
                        method,
                        "a" * 64,
                        "b" * 64,
                    ),
                )
                for scenario in ("s1", "s2"):
                    connection.execute(
                        """
                        INSERT INTO scenario_times VALUES (
                            ?,?,60,100,500,20,200,0,
                            1,1,1,2,3,1,1,1,2,3
                        )
                        """,
                        (job_id, scenario),
                    )
    connection.commit()

    result = database_audit(
        connection,
        expected_job_rows=jobs,
        expected_scenarios=({"scenario": "s1"}, {"scenario": "s2"}),
        expected_methods=methods,
        expected_board_count=6,
        expected_task_count=2,
        coordinate_tolerance_mm=0.001,
    )

    assert result["passed"]
    assert result["actual_job_count"] == 12
    assert result["actual_board_count"] == 6
    assert result["scenario_row_count"] == 24
    connection.close()


def test_database_audit_fails_for_missing_scenario(tmp_path) -> None:
    database = tmp_path / "results.sqlite"
    connection = connect_database(database)
    job = {
        "job_id": "job-1",
        "schedule_order": 1,
        "task_id": "task-1",
        "packing_seed": "1000",
        "placements_member": "p.csv",
        "board_id": "0",
        "method": "m1",
    }
    connection.close()

    connection = sqlite3.connect(database)
    result = database_audit(
        connection,
        expected_job_rows=(job,),
        expected_scenarios=({"scenario": "s1"},),
        expected_methods=("m1",),
        expected_board_count=1,
        expected_task_count=1,
        coordinate_tolerance_mm=0.001,
    )

    assert not result["passed"]
    assert result["missing_job_count"] == 1
    connection.close()
