from scripts.build_nc_kinematic_publication_assets import build_nominal_table


def test_nominal_table_reports_absolute_time_and_task_uncertainty() -> None:
    rows = []
    values = {
        "process_aware_beam_adaptive_polished": ((90.0, 190.0), (180.0, 380.0)),
        "topology_process_aware": ((100.0, 200.0), (200.0, 400.0)),
        "process_aware_beam": ((95.0, 195.0), (190.0, 390.0)),
        "endpoint_aware_gtsp": ((120.0, 220.0), (240.0, 440.0)),
    }
    for method, task_values in values.items():
        for task_index, (noncut, total) in enumerate(task_values, start=1):
            rows.append(
                {
                    "task_id": f"task_{task_index}",
                    "method": method,
                    "scenario": "r200_axy1000_z40_az500",
                    "continuous_noncut_time_s": str(noncut),
                    "continuous_total_time_s": str(total),
                }
            )

    table, summaries = build_nominal_table(
        rows,
        bootstrap_replicates=200,
        bootstrap_seed=17,
    )

    topology = next(
        row for row in summaries if row["baseline"] == "topology_process_aware"
    )
    assert topology["wins"] == 2
    assert topology["ties"] == 0
    assert topology["losses"] == 0
    assert topology["mean_reduction_pct"] == 10.0
    assert topology["total_wins"] == 2
    assert topology["total_ties"] == 0
    assert topology["total_losses"] == 0
    assert topology["total_mean_reduction_pct"] == 5.0
    assert "95\\% task-bootstrap CI" in table
    assert "Non-cut\\\\W/T/L" in table
    assert "Total\\\\W/T/L" in table
    assert "Mean total" in table
    assert "Non-cut\\\\median" in table
    assert "Non-cut (h/task)" in table
    assert "$v_{\\mathrm{XY}}=200$" in table
    assert "$a_{\\mathrm{XY}}" not in table
    assert "Acceleration parameters do not enter" in table
    assert "\\resizebox{\\textwidth}{!}" in table
