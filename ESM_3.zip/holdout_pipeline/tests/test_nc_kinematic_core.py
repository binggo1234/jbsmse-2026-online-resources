from __future__ import annotations

import math

import pytest

from scripts.nc_kinematic_core import (
    KinematicScenario,
    NcTemplate,
    SourceAction,
    audit_route_nc,
    default_scenarios,
    estimate_kinematics,
    generate_canonical_gcode,
    geometry_metrics,
    parse_gcode,
    segment_stop_time_s,
)


def sample_actions() -> tuple[SourceAction, ...]:
    return (
        SourceAction(0, "travel", "low_clearance", 0, 0, 10, 10),
        SourceAction(1, "cut", "low_clearance", 10, 10, 20, 10, "u1", "s1"),
        SourceAction(2, "travel", "low_clearance_detour", 20, 10, 20, 20),
        SourceAction(3, "travel", "safe_lift", 20, 20, 30, 20),
        SourceAction(4, "cut", "low_clearance", 30, 20, 30, 30, "u2", "s2"),
    )


def test_canonical_round_trip_preserves_action_order_and_modes() -> None:
    actions = sample_actions()
    template = NcTemplate()
    text = generate_canonical_gcode(
        actions,
        panel_width_mm=100,
        panel_height_mm=100,
        start_x_mm=0,
        start_y_mm=0,
        template=template,
    )

    parsed = parse_gcode(text)
    audit = audit_route_nc(
        actions,
        parsed,
        panel_width_mm=100,
        panel_height_mm=100,
        template=template,
    )

    assert audit.passed, audit.errors
    assert audit.source_action_count == len(actions)
    assert audit.cut_xy_block_count == 6
    assert audit.travel_xy_block_count == 3
    assert parsed.compensation_cancelled
    assert parsed.tool_change_count == 1


def test_geometry_metrics_separate_low_safe_and_return_motion() -> None:
    text = generate_canonical_gcode(
        sample_actions(),
        panel_width_mm=100,
        panel_height_mm=100,
        start_x_mm=0,
        start_y_mm=0,
    )
    metrics = geometry_metrics(parse_gcode(text))

    assert metrics.cutting_distance_mm == pytest.approx(60.0)
    assert metrics.low_clearance_xy_distance_mm == pytest.approx(
        math.hypot(10, 10) + 10
    )
    assert metrics.safe_lift_xy_distance_mm == pytest.approx(10.0)
    assert metrics.return_xy_distance_mm == pytest.approx(math.hypot(30, 30))
    assert metrics.rapid_xy_distance_mm == pytest.approx(
        metrics.low_clearance_xy_distance_mm
        + metrics.safe_lift_xy_distance_mm
        + metrics.return_xy_distance_mm
    )


def test_parser_supports_modal_incremental_and_inch_coordinates() -> None:
    parsed = parse_gcode(
        "\n".join(
            (
                "G20",
                "G90",
                "G40",
                "M3",
                "G0 X1 Y1",
                "G91",
                "X1",
                "G90",
                "M5",
            )
        )
    )

    assert parsed.motions[-1].end_x_mm == pytest.approx(50.8)
    assert parsed.motions[-1].end_y_mm == pytest.approx(25.4)


def test_parser_rejects_arcs_and_unknown_words() -> None:
    with pytest.raises(ValueError, match="unsupported G-code G2"):
        parse_gcode("G21\nG90\nG2 X1 Y1\n")
    with pytest.raises(ValueError, match="unsupported word Q1"):
        parse_gcode("G21\nG90\nG0 Q1\n")


def test_audit_detects_coordinate_change() -> None:
    actions = sample_actions()
    text = generate_canonical_gcode(
        actions,
        panel_width_mm=100,
        panel_height_mm=100,
        start_x_mm=0,
        start_y_mm=0,
    ).replace("X20.000 Y10.000 F3600.0", "X20.100 Y10.000 F3600.0", 1)
    audit = audit_route_nc(
        actions,
        parse_gcode(text),
        panel_width_mm=100,
        panel_height_mm=100,
    )

    assert not audit.passed
    assert audit.maximum_coordinate_error_mm == pytest.approx(0.1)


def test_audit_detects_unexpected_cut_depth() -> None:
    actions = sample_actions()
    text = generate_canonical_gcode(
        actions,
        panel_width_mm=100,
        panel_height_mm=100,
        start_x_mm=0,
        start_y_mm=0,
    ).replace("G1 Z-12.000 F800.0", "G1 Z-11.000 F800.0", 1)
    audit = audit_route_nc(
        actions,
        parse_gcode(text),
        panel_width_mm=100,
        panel_height_mm=100,
    )

    assert not audit.passed
    assert any("depth mismatch" in error for error in audit.errors)


def test_segment_stop_time_uses_triangular_and_trapezoidal_profiles() -> None:
    assert segment_stop_time_s(1.0, 10.0, 100.0) == pytest.approx(0.2)
    assert segment_stop_time_s(10.0, 10.0, 100.0) == pytest.approx(1.1)


def test_kinematics_honors_modal_g1_feed_below_axis_limit() -> None:
    parsed = parse_gcode(
        "\n".join(
            (
                "G21",
                "G90",
                "G0 Z5",
                "G1 Z-5 F600",
                "G0 Z5",
                "M30",
            )
        )
    )
    scenario = KinematicScenario(
        scenario="feed-cap",
        cut_speed_mm_s=60.0,
        rapid_speed_mm_s=200.0,
        xy_acceleration_mm_s2=1000.0,
        z_speed_mm_s=40.0,
        z_acceleration_mm_s2=500.0,
    )

    estimate = estimate_kinematics(parsed, scenario)

    assert estimate.continuous_z_time_s == pytest.approx(
        5.0 / 40.0 + 10.0 / 10.0 + 10.0 / 40.0
    )
    assert estimate.stop_z_time_s == pytest.approx(
        segment_stop_time_s(5.0, 40.0, 500.0)
        + segment_stop_time_s(10.0, 10.0, 500.0)
        + segment_stop_time_s(10.0, 40.0, 500.0)
    )


def test_default_grid_contains_27_prespecified_scenarios() -> None:
    scenarios = default_scenarios()
    assert len(scenarios) == 27
    assert len({scenario.scenario for scenario in scenarios}) == 27


def test_estimates_keep_cut_and_noncut_components_separate() -> None:
    parsed = parse_gcode(
        generate_canonical_gcode(
            sample_actions(),
            panel_width_mm=100,
            panel_height_mm=100,
            start_x_mm=0,
            start_y_mm=0,
        )
    )
    estimate = estimate_kinematics(parsed, default_scenarios()[0])

    assert estimate.continuous_total_time_s == pytest.approx(
        estimate.continuous_cut_time_s + estimate.continuous_noncut_time_s
    )
    assert estimate.stop_total_time_s == pytest.approx(
        estimate.stop_cut_time_s + estimate.stop_noncut_time_s
    )
    assert estimate.stop_total_time_s > estimate.continuous_total_time_s
