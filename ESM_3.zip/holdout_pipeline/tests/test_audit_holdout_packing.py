from scripts.audit_holdout_packing import rectangles_intersect


def rectangle(x: float, y: float, w: float, h: float) -> dict[str, float]:
    return {"x": x, "y": y, "w": w, "h": h}


def test_touching_envelopes_do_not_intersect() -> None:
    assert (
        rectangles_intersect(
            rectangle(0, 0, 10, 10),
            rectangle(10, 0, 5, 10),
        )
        is False
    )


def test_positive_overlap_is_detected() -> None:
    assert (
        rectangles_intersect(
            rectangle(0, 0, 10, 10),
            rectangle(9, 0, 5, 10),
        )
        is True
    )
