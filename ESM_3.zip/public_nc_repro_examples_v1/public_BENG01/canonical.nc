(Canonical controller-neutral NC for transparent kinematic evaluation)
(Stock XY: 641.000 x 1358.000 mm)
(Geometrically compensated cutter centerlines; controller compensation off)
G21
G90
G17
G40
G0 Z5.000
T1 M6
M3 S18000
(NCX {"action":-1,"mode":"setup","role":"setup_xy"})
G0 X5.000 Y5.000
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y161.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y161.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y161.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X261.000 Y242.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X261.000 Y242.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X261.000 Y342.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X261.000 Y242.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X261.000 Y342.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X311.000 Y342.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X261.000 Y342.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X311.000 Y342.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X367.000 Y342.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X311.000 Y342.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X367.000 Y342.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X592.000 Y342.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X367.000 Y342.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X592.000 Y342.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X592.000 Y498.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X592.000 Y342.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X592.000 Y498.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X579.000 Y498.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X592.000 Y498.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X579.000 Y498.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X498.000 Y498.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X579.000 Y498.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X498.000 Y498.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X392.000 Y498.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X498.000 Y498.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X392.000 Y498.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X392.000 Y579.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X392.000 Y498.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X392.000 Y579.000 F3600.0
(NCX {"action":12,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":12,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X392.000 Y654.000 F3600.0
(NCX {"action":12,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":12,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X392.000 Y579.000 F3600.0
(NCX {"action":12,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":12,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X392.000 Y654.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X311.000 Y654.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X392.000 Y654.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X311.000 Y654.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X311.000 Y704.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X311.000 Y654.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X311.000 Y704.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X267.000 Y704.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X311.000 Y704.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X267.000 Y704.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y704.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X267.000 Y704.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y704.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y735.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y704.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y735.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y785.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y735.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y785.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X267.000 Y785.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y785.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X267.000 Y785.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X267.000 Y860.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X267.000 Y785.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X267.000 Y860.000 F3600.0
(NCX {"action":21,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":21,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y860.000 F3600.0
(NCX {"action":21,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":21,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X267.000 Y860.000 F3600.0
(NCX {"action":21,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":21,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y860.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y891.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y860.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y891.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y941.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y891.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y941.000 F3600.0
(NCX {"action":24,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":24,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y941.000 F3600.0
(NCX {"action":24,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":24,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y941.000 F3600.0
(NCX {"action":24,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":24,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y941.000 F3600.0
(NCX {"action":25,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y972.000 F3600.0
(NCX {"action":25,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y941.000 F3600.0
(NCX {"action":25,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y972.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y1147.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y972.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y1147.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y1147.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y1147.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y1147.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X317.000 Y1147.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y1147.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X317.000 Y1147.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X317.000 Y1328.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X317.000 Y1147.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X317.000 Y1328.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y1328.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X317.000 Y1328.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y1328.000 F3600.0
(NCX {"action":31,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":31,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y1278.000 F3600.0
(NCX {"action":31,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":31,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y1328.000 F3600.0
(NCX {"action":31,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":31,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y1278.000 F3600.0
(NCX {"action":32,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1278.000 F3600.0
(NCX {"action":32,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y1278.000 F3600.0
(NCX {"action":32,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1278.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1147.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y1278.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1147.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y941.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y1147.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y941.000 F3600.0
(NCX {"action":35,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":35,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y860.000 F3600.0
(NCX {"action":35,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":35,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y941.000 F3600.0
(NCX {"action":35,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":35,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y860.000 F3600.0
(NCX {"action":36,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":36,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X267.000 Y860.000 F3600.0
(NCX {"action":36,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":36,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y860.000 F3600.0
(NCX {"action":36,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":36,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X267.000 Y860.000 F3600.0
(NCX {"action":37,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":37,"mode":"low_clearance","role":"travel_xy"})
G0 X286.000 Y860.000
(NCX {"action":38,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X473.000 Y860.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y860.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X473.000 Y860.000 F3600.0
(NCX {"action":39,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":39,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X567.000 Y860.000 F3600.0
(NCX {"action":39,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":39,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X473.000 Y860.000 F3600.0
(NCX {"action":39,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":39,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X567.000 Y860.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X567.000 Y891.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X567.000 Y860.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X567.000 Y891.000 F3600.0
(NCX {"action":41,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":41,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y891.000 F3600.0
(NCX {"action":41,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":41,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X567.000 Y891.000 F3600.0
(NCX {"action":41,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":41,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y891.000 F3600.0
(NCX {"action":42,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":42,"mode":"low_clearance","role":"travel_xy"})
G0 X236.000 Y735.000
(NCX {"action":43,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":43,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y735.000 F3600.0
(NCX {"action":43,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":43,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y735.000 F3600.0
(NCX {"action":43,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":43,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y735.000 F3600.0
(NCX {"action":44,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":44,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y704.000 F3600.0
(NCX {"action":44,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":44,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y735.000 F3600.0
(NCX {"action":44,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":44,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y704.000 F3600.0
(NCX {"action":45,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":45,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y498.000 F3600.0
(NCX {"action":45,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":45,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y704.000 F3600.0
(NCX {"action":45,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":45,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y498.000 F3600.0
(NCX {"action":46,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":46,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y342.000 F3600.0
(NCX {"action":46,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":46,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y498.000 F3600.0
(NCX {"action":46,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":46,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y342.000 F3600.0
(NCX {"action":47,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":47,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X261.000 Y342.000 F3600.0
(NCX {"action":47,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":47,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y342.000 F3600.0
(NCX {"action":47,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":47,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X261.000 Y342.000 F3600.0
(NCX {"action":48,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":48,"mode":"low_clearance","role":"travel_xy"})
G0 X261.000 Y242.000
(NCX {"action":49,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":49,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X261.000 Y161.000 F3600.0
(NCX {"action":49,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":49,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X261.000 Y242.000 F3600.0
(NCX {"action":49,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":49,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X261.000 Y161.000 F3600.0
(NCX {"action":50,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":50,"mode":"low_clearance","role":"travel_xy"})
G0 X211.000 Y161.000
(NCX {"action":51,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":51,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X211.000 Y111.000 F3600.0
(NCX {"action":51,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":51,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X211.000 Y161.000 F3600.0
(NCX {"action":51,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":51,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X211.000 Y111.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X211.000 Y5.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X211.000 Y111.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X211.000 Y5.000 F3600.0
(NCX {"action":53,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":53,"mode":"low_clearance","role":"travel_xy"})
G0 X492.000 Y5.000
(NCX {"action":54,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X492.000 Y111.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X492.000 Y5.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X492.000 Y111.000 F3600.0
(NCX {"action":55,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":55,"mode":"low_clearance","role":"travel_xy"})
G0 X498.000 Y498.000
(NCX {"action":56,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X498.000 Y579.000 F3600.0
(NCX {"action":56,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X498.000 Y498.000 F3600.0
(NCX {"action":56,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X498.000 Y579.000 F3600.0
(NCX {"action":57,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":57,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X498.000 Y704.000 F3600.0
(NCX {"action":57,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":57,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X498.000 Y579.000 F3600.0
(NCX {"action":57,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":57,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X498.000 Y704.000 F3600.0
(NCX {"action":58,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":58,"mode":"low_clearance","role":"travel_xy"})
G0 X498.000 Y579.000
(NCX {"action":59,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":59,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X392.000 Y579.000 F3600.0
(NCX {"action":59,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":59,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X498.000 Y579.000 F3600.0
(NCX {"action":59,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":59,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X392.000 Y579.000 F3600.0
(NCX {"action":60,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":60,"mode":"low_clearance","role":"travel_xy"})
G0 X392.000 Y498.000
(NCX {"action":61,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":61,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X311.000 Y498.000 F3600.0
(NCX {"action":61,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":61,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X392.000 Y498.000 F3600.0
(NCX {"action":61,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":61,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X311.000 Y498.000 F3600.0
(NCX {"action":62,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":62,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X311.000 Y342.000 F3600.0
(NCX {"action":62,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":62,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X311.000 Y498.000 F3600.0
(NCX {"action":62,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":62,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X311.000 Y342.000 F3600.0
(NCX {"action":63,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":63,"mode":"low_clearance","role":"travel_xy"})
G0 X311.000 Y498.000
(NCX {"action":64,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":64,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y498.000 F3600.0
(NCX {"action":64,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":64,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X311.000 Y498.000 F3600.0
(NCX {"action":64,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":64,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y498.000 F3600.0
(NCX {"action":65,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":65,"mode":"low_clearance","role":"travel_xy"})
G0 X317.000 Y1328.000
(NCX {"action":66,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":66,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X317.000 Y1353.000 F3600.0
(NCX {"action":66,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":66,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X317.000 Y1328.000 F3600.0
(NCX {"action":66,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":66,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X317.000 Y1353.000 F3600.0
(NCX {"action":67,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":67,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X498.000 Y1353.000 F3600.0
(NCX {"action":67,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":67,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X317.000 Y1353.000 F3600.0
(NCX {"action":67,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":67,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X498.000 Y1353.000 F3600.0
(NCX {"action":68,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":68,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X498.000 Y1147.000 F3600.0
(NCX {"action":68,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":68,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X498.000 Y1353.000 F3600.0
(NCX {"action":68,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":68,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X498.000 Y1147.000 F3600.0
(NCX {"action":69,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":69,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X317.000 Y1147.000 F3600.0
(NCX {"action":69,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":69,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X498.000 Y1147.000 F3600.0
(NCX {"action":69,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":69,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X317.000 Y1147.000 F3600.0
(NCX {"action":70,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":70,"mode":"low_clearance","role":"travel_xy"})
G0 X236.000 Y972.000
(NCX {"action":71,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":71,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X467.000 Y972.000 F3600.0
(NCX {"action":71,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":71,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y972.000 F3600.0
(NCX {"action":71,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":71,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X467.000 Y972.000 F3600.0
(NCX {"action":72,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":72,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X467.000 Y941.000 F3600.0
(NCX {"action":72,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":72,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X467.000 Y972.000 F3600.0
(NCX {"action":72,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":72,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X467.000 Y941.000 F3600.0
(NCX {"action":73,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":73,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y941.000 F3600.0
(NCX {"action":73,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":73,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X467.000 Y941.000 F3600.0
(NCX {"action":73,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":73,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y941.000 F3600.0
(NCX {"action":74,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":74,"mode":"low_clearance","role":"travel_xy"})
G0 X267.000 Y785.000
(NCX {"action":75,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":75,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X267.000 Y704.000 F3600.0
(NCX {"action":75,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":75,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X267.000 Y785.000 F3600.0
(NCX {"action":75,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":75,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X267.000 Y704.000 F3600.0
(NCX {"action":76,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":76,"mode":"low_clearance","role":"travel_xy"})
G0 X311.000 Y704.000
(NCX {"action":77,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":77,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X473.000 Y704.000 F3600.0
(NCX {"action":77,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":77,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X311.000 Y704.000 F3600.0
(NCX {"action":77,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":77,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X473.000 Y704.000 F3600.0
(NCX {"action":78,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":78,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X473.000 Y860.000 F3600.0
(NCX {"action":78,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":78,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X473.000 Y704.000 F3600.0
(NCX {"action":78,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":78,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X473.000 Y860.000 F3600.0
(NCX {"action":79,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":79,"mode":"low_clearance","role":"travel_xy"})
G0 X498.000 Y704.000
(NCX {"action":80,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":80,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X579.000 Y704.000 F3600.0
(NCX {"action":80,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":80,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X498.000 Y704.000 F3600.0
(NCX {"action":80,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":80,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X579.000 Y704.000 F3600.0
(NCX {"action":81,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":81,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X579.000 Y498.000 F3600.0
(NCX {"action":81,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":81,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X579.000 Y704.000 F3600.0
(NCX {"action":81,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":81,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X579.000 Y498.000 F3600.0
(NCX {"action":82,"mode":"low_clearance_detour","role":"travel_z"})
G0 Z1.000
(NCX {"action":82,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X582.000 Y498.000
(NCX {"action":83,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":83,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X595.000 Y498.000
(NCX {"action":84,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":84,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X595.000 Y495.000
(NCX {"action":85,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":85,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X595.000 Y342.000
(NCX {"action":86,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":86,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X582.000 Y342.000
(NCX {"action":87,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":87,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X579.000 Y342.000
(NCX {"action":88,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":88,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X570.000 Y342.000
(NCX {"action":89,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":89,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X501.000 Y342.000
(NCX {"action":90,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":90,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X495.000 Y342.000
(NCX {"action":91,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":91,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X476.000 Y342.000
(NCX {"action":92,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":92,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X470.000 Y342.000
(NCX {"action":93,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":93,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X389.000 Y342.000
(NCX {"action":94,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":94,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X367.000 Y342.000
(NCX {"action":95,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":95,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X367.000 Y161.000 F3600.0
(NCX {"action":95,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":95,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X367.000 Y342.000 F3600.0
(NCX {"action":95,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":95,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X367.000 Y161.000 F3600.0
(NCX {"action":96,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":96,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X261.000 Y161.000 F3600.0
(NCX {"action":96,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":96,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X367.000 Y161.000 F3600.0
(NCX {"action":96,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":96,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X261.000 Y161.000 F3600.0
(NCX {"action":97,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":97,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X211.000 Y161.000 F3600.0
(NCX {"action":97,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":97,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X261.000 Y161.000 F3600.0
(NCX {"action":97,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":97,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X211.000 Y161.000 F3600.0
(NCX {"action":98,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":98,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y161.000 F3600.0
(NCX {"action":98,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":98,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X211.000 Y161.000 F3600.0
(NCX {"action":98,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":98,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y161.000 F3600.0
(NCX {"action":99,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":99,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y5.000
(NCX {"action":100,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":100,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X211.000 Y5.000 F3600.0
(NCX {"action":100,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":100,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":100,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":100,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X211.000 Y5.000 F3600.0
(NCX {"action":101,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":101,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X492.000 Y5.000 F3600.0
(NCX {"action":101,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":101,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X211.000 Y5.000 F3600.0
(NCX {"action":101,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":101,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X492.000 Y5.000 F3600.0
(NCX {"action":102,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":102,"mode":"low_clearance","role":"travel_xy"})
G0 X492.000 Y111.000
(NCX {"action":103,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":103,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X211.000 Y111.000 F3600.0
(NCX {"action":103,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":103,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X492.000 Y111.000 F3600.0
(NCX {"action":103,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":103,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X211.000 Y111.000 F3600.0
(NCX {"action":104,"mode":"safe_lift","role":"travel_z"})
G0 Z5.000
(NCX {"action":104,"mode":"safe_lift","role":"travel_xy"})
G0 X311.000 Y498.000
(NCX {"action":105,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":105,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X311.000 Y654.000 F3600.0
(NCX {"action":105,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":105,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X311.000 Y498.000 F3600.0
(NCX {"action":105,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":105,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X311.000 Y654.000 F3600.0
(NCX {"action":106,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":106,"mode":"low_clearance","role":"travel_xy"})
G0 X236.000 Y704.000
(NCX {"action":107,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":107,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y704.000 F3600.0
(NCX {"action":107,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":107,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X236.000 Y704.000 F3600.0
(NCX {"action":107,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":107,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y704.000 F3600.0
(NCX {"action":108,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":108,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y941.000
(NCX {"action":109,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":109,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y941.000 F3600.0
(NCX {"action":109,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":109,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y941.000 F3600.0
(NCX {"action":109,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":109,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y941.000 F3600.0
(NCX {"action":110,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":110,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y1147.000
(NCX {"action":111,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":111,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X236.000 Y1147.000 F3600.0
(NCX {"action":111,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":111,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y1147.000 F3600.0
(NCX {"action":111,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":111,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X236.000 Y1147.000 F3600.0
(NCX {"action":112,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":112,"mode":"low_clearance","role":"travel_xy"})
G0 X286.000 Y1147.000
(NCX {"action":113,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":113,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X286.000 Y1278.000 F3600.0
(NCX {"action":113,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":113,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X286.000 Y1147.000 F3600.0
(NCX {"action":113,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":113,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X286.000 Y1278.000 F3600.0
(NCX {"action":-1,"mode":"return","role":"footer_z"})
G0 Z5.000
(NCX {"action":-1,"mode":"return","role":"return_xy"})
G0 X5.000 Y5.000
M5
M30
