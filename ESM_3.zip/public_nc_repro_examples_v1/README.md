# Public planning-to-NC reproducibility examples

Five 2DPackLib-derived public layouts are replayed through the proposed planning
method, route-action serialization, canonical linear NC postprocessor, modal parser,
route-to-NC semantic audit, and all 27 disclosed kinematic scenarios. These examples
contain no factory data. The speed and acceleration values are isotropic path-level
limits, and the resulting times are controller-agnostic sensitivity calculations,
not measured machine cycle times.

Each example directory contains the input layout, route actions, canonical NC,
complete parser motion output, semantic audit, scenario table, and SHA-256 manifest.
