(Canonical controller-neutral NC for transparent kinematic evaluation)
(Stock XY: 266.000 x 534.000 mm)
(Geometrically compensated cutter centerlines; controller compensation off)
G21
G90
G17
G40
G0 Z5.000
T1 M6
M3 S18000
(NCX {"action":-1,"mode":"setup","role":"setup_xy"})
G0 X5.000 Y5.000
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y186.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y186.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y186.000 F3600.0
(NCX {"action":1,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":1,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y298.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y298.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y404.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y298.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y404.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X136.000 Y404.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y404.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X136.000 Y404.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X136.000 Y298.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X136.000 Y404.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X136.000 Y298.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X192.000 Y298.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X136.000 Y298.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X192.000 Y298.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X261.000 Y298.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X192.000 Y298.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X261.000 Y298.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X261.000 Y242.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X261.000 Y298.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X261.000 Y242.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X211.000 Y242.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X261.000 Y242.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X211.000 Y242.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X211.000 Y186.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X211.000 Y242.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X211.000 Y186.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X86.000 Y186.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X211.000 Y186.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X86.000 Y186.000 F3600.0
(NCX {"action":12,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":12,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y298.000
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X136.000 Y298.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y298.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X136.000 Y298.000 F3600.0
(NCX {"action":14,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":14,"mode":"low_clearance","role":"travel_xy"})
G0 X192.000 Y298.000
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X192.000 Y529.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X192.000 Y298.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X192.000 Y529.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X136.000 Y529.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X192.000 Y529.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X136.000 Y529.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X136.000 Y404.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X136.000 Y529.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X136.000 Y404.000 F3600.0
(NCX {"action":18,"mode":"low_clearance_detour","role":"travel_z"})
G0 Z1.000
(NCX {"action":18,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X136.000 Y295.000
(NCX {"action":19,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":19,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X139.000 Y295.000
(NCX {"action":20,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":20,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X195.000 Y295.000
(NCX {"action":21,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":21,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X211.000 Y295.000
(NCX {"action":22,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":22,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X211.000 Y242.000
(NCX {"action":23,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X211.000 Y242.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y242.000 F3600.0
(NCX {"action":24,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":24,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y186.000
(NCX {"action":25,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X86.000 Y186.000 F3600.0
(NCX {"action":25,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y186.000 F3600.0
(NCX {"action":25,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X86.000 Y186.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X86.000 Y5.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X86.000 Y186.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X86.000 Y5.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X86.000 Y5.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":-1,"mode":"return","role":"footer_z"})
G0 Z5.000
(NCX {"action":-1,"mode":"return","role":"return_xy"})
G0 X5.000 Y5.000
M5
M30
