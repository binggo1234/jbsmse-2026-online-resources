(Canonical controller-neutral NC for transparent kinematic evaluation)
(Stock XY: 841.000 x 13018.000 mm)
(Geometrically compensated cutter centerlines; controller compensation off)
G21
G90
G17
G40
G0 Z5.000
T1 M6
M3 S18000
(NCX {"action":-1,"mode":"setup","role":"setup_xy"})
G0 X5.000 Y5.000
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y5.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y5.000 F3600.0
(NCX {"action":1,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":1,"mode":"low_clearance","role":"travel_xy"})
G0 X786.000 Y1086.000
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X761.000 Y1086.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y1086.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X761.000 Y1086.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1086.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X761.000 Y1086.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1086.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y2117.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y1086.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y2117.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y3098.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y2117.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y3098.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y4054.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y3098.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y4054.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y4985.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y4054.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y4985.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y5891.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y4985.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y5891.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y6772.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5891.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y6772.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y7628.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y6772.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y7628.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y8209.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y7628.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y8209.000 F3600.0
(NCX {"action":12,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":12,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y9015.000 F3600.0
(NCX {"action":12,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":12,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y8209.000 F3600.0
(NCX {"action":12,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":12,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y9015.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y9546.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y9015.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y9546.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y10002.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y9546.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y10002.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y10683.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y10002.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y10683.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y11314.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y10683.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y11314.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y11920.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y11314.000 F3600.0
(NCX {"action":17,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":17,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y11920.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y12276.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y11920.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y12276.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y12582.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y12276.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y12582.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y12863.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y12582.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y12863.000 F3600.0
(NCX {"action":21,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":21,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X486.000 Y12863.000 F3600.0
(NCX {"action":21,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":21,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y12863.000 F3600.0
(NCX {"action":21,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":21,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X486.000 Y12863.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X486.000 Y12582.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X486.000 Y12863.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X486.000 Y12582.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X536.000 Y12582.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X486.000 Y12582.000 F3600.0
(NCX {"action":23,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":23,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X536.000 Y12582.000 F3600.0
(NCX {"action":24,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":24,"mode":"low_clearance","role":"travel_xy"})
G0 X486.000 Y12582.000
(NCX {"action":25,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y12582.000 F3600.0
(NCX {"action":25,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X486.000 Y12582.000 F3600.0
(NCX {"action":25,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":25,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y12582.000 F3600.0
(NCX {"action":26,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":26,"mode":"low_clearance","role":"travel_xy"})
G0 X536.000 Y12276.000
(NCX {"action":27,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X586.000 Y12276.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X536.000 Y12276.000 F3600.0
(NCX {"action":27,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":27,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X586.000 Y12276.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X586.000 Y11920.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X586.000 Y12276.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X586.000 Y11920.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X386.000 Y11920.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X586.000 Y11920.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X386.000 Y11920.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y11920.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X386.000 Y11920.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y11920.000 F3600.0
(NCX {"action":31,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":31,"mode":"low_clearance","role":"travel_xy"})
G0 X386.000 Y11314.000
(NCX {"action":32,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X411.000 Y11314.000 F3600.0
(NCX {"action":32,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X386.000 Y11314.000 F3600.0
(NCX {"action":32,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X411.000 Y11314.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X411.000 Y11289.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X411.000 Y11314.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X411.000 Y11289.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X411.000 Y10683.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X411.000 Y11289.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X411.000 Y10683.000 F3600.0
(NCX {"action":35,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":35,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y10683.000 F3600.0
(NCX {"action":35,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":35,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X411.000 Y10683.000 F3600.0
(NCX {"action":35,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":35,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y10683.000 F3600.0
(NCX {"action":36,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":36,"mode":"low_clearance","role":"travel_xy"})
G0 X411.000 Y10683.000
(NCX {"action":37,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":37,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X436.000 Y10683.000 F3600.0
(NCX {"action":37,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":37,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X411.000 Y10683.000 F3600.0
(NCX {"action":37,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":37,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X436.000 Y10683.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X792.000 Y10683.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X436.000 Y10683.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X792.000 Y10683.000 F3600.0
(NCX {"action":39,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":39,"mode":"low_clearance","role":"travel_xy"})
G0 X736.000 Y10002.000
(NCX {"action":40,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y9546.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y10002.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y9546.000 F3600.0
(NCX {"action":41,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":41,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y9546.000 F3600.0
(NCX {"action":41,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":41,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y9546.000 F3600.0
(NCX {"action":41,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":41,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y9546.000 F3600.0
(NCX {"action":42,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":42,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y9015.000
(NCX {"action":43,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":43,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X561.000 Y9015.000 F3600.0
(NCX {"action":43,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":43,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y9015.000 F3600.0
(NCX {"action":43,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":43,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X561.000 Y9015.000 F3600.0
(NCX {"action":44,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":44,"mode":"low_clearance","role":"travel_xy"})
G0 X736.000 Y9546.000
(NCX {"action":45,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":45,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y9546.000 F3600.0
(NCX {"action":45,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":45,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y9546.000 F3600.0
(NCX {"action":45,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":45,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y9546.000 F3600.0
(NCX {"action":46,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":46,"mode":"low_clearance","role":"travel_xy"})
G0 X836.000 Y8209.000
(NCX {"action":47,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":47,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X836.000 Y7628.000 F3600.0
(NCX {"action":47,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":47,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X836.000 Y8209.000 F3600.0
(NCX {"action":47,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":47,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X836.000 Y7628.000 F3600.0
(NCX {"action":48,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":48,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X611.000 Y7628.000 F3600.0
(NCX {"action":48,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":48,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X836.000 Y7628.000 F3600.0
(NCX {"action":48,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":48,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X611.000 Y7628.000 F3600.0
(NCX {"action":49,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":49,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X611.000 Y6772.000 F3600.0
(NCX {"action":49,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":49,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X611.000 Y7628.000 F3600.0
(NCX {"action":49,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":49,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X611.000 Y6772.000 F3600.0
(NCX {"action":50,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":50,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X636.000 Y6772.000 F3600.0
(NCX {"action":50,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":50,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X611.000 Y6772.000 F3600.0
(NCX {"action":50,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":50,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X636.000 Y6772.000 F3600.0
(NCX {"action":51,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":51,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X636.000 Y5891.000 F3600.0
(NCX {"action":51,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":51,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X636.000 Y6772.000 F3600.0
(NCX {"action":51,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":51,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X636.000 Y5891.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X661.000 Y5891.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X636.000 Y5891.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X661.000 Y5891.000 F3600.0
(NCX {"action":53,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":53,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X661.000 Y4985.000 F3600.0
(NCX {"action":53,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":53,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X661.000 Y5891.000 F3600.0
(NCX {"action":53,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":53,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X661.000 Y4985.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X686.000 Y4985.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X661.000 Y4985.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X686.000 Y4985.000 F3600.0
(NCX {"action":55,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":55,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X686.000 Y4054.000 F3600.0
(NCX {"action":55,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":55,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X686.000 Y4985.000 F3600.0
(NCX {"action":55,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":55,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X686.000 Y4054.000 F3600.0
(NCX {"action":56,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X711.000 Y4054.000 F3600.0
(NCX {"action":56,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X686.000 Y4054.000 F3600.0
(NCX {"action":56,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X711.000 Y4054.000 F3600.0
(NCX {"action":57,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":57,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X711.000 Y3098.000 F3600.0
(NCX {"action":57,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":57,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X711.000 Y4054.000 F3600.0
(NCX {"action":57,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":57,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X711.000 Y3098.000 F3600.0
(NCX {"action":58,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":58,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y3098.000 F3600.0
(NCX {"action":58,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":58,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X711.000 Y3098.000 F3600.0
(NCX {"action":58,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":58,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y3098.000 F3600.0
(NCX {"action":59,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":59,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y2117.000 F3600.0
(NCX {"action":59,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":59,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y3098.000 F3600.0
(NCX {"action":59,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":59,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y2117.000 F3600.0
(NCX {"action":60,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":60,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X761.000 Y2117.000 F3600.0
(NCX {"action":60,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":60,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y2117.000 F3600.0
(NCX {"action":60,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":60,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X761.000 Y2117.000 F3600.0
(NCX {"action":61,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":61,"mode":"low_clearance","role":"travel_xy"})
G0 X836.000 Y8209.000
(NCX {"action":62,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":62,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X561.000 Y8209.000 F3600.0
(NCX {"action":62,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":62,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X836.000 Y8209.000 F3600.0
(NCX {"action":62,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":62,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X561.000 Y8209.000 F3600.0
(NCX {"action":63,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":63,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X561.000 Y9015.000 F3600.0
(NCX {"action":63,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":63,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X561.000 Y8209.000 F3600.0
(NCX {"action":63,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":63,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X561.000 Y9015.000 F3600.0
(NCX {"action":64,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":64,"mode":"low_clearance","role":"travel_xy"})
G0 X561.000 Y8209.000
(NCX {"action":65,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":65,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y8209.000 F3600.0
(NCX {"action":65,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":65,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X561.000 Y8209.000 F3600.0
(NCX {"action":65,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":65,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y8209.000 F3600.0
(NCX {"action":66,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":66,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y7628.000
(NCX {"action":67,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":67,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X611.000 Y7628.000 F3600.0
(NCX {"action":67,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":67,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y7628.000 F3600.0
(NCX {"action":67,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":67,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X611.000 Y7628.000 F3600.0
(NCX {"action":68,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":68,"mode":"low_clearance","role":"travel_xy"})
G0 X611.000 Y6772.000
(NCX {"action":69,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":69,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y6772.000 F3600.0
(NCX {"action":69,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":69,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X611.000 Y6772.000 F3600.0
(NCX {"action":69,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":69,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y6772.000 F3600.0
(NCX {"action":70,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":70,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y5891.000
(NCX {"action":71,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":71,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X636.000 Y5891.000 F3600.0
(NCX {"action":71,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":71,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5891.000 F3600.0
(NCX {"action":71,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":71,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X636.000 Y5891.000 F3600.0
(NCX {"action":72,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":72,"mode":"low_clearance","role":"travel_xy"})
G0 X661.000 Y4985.000
(NCX {"action":73,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":73,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y4985.000 F3600.0
(NCX {"action":73,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":73,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X661.000 Y4985.000 F3600.0
(NCX {"action":73,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":73,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y4985.000 F3600.0
(NCX {"action":74,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":74,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y4054.000
(NCX {"action":75,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":75,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X686.000 Y4054.000 F3600.0
(NCX {"action":75,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":75,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y4054.000 F3600.0
(NCX {"action":75,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":75,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X686.000 Y4054.000 F3600.0
(NCX {"action":76,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":76,"mode":"low_clearance","role":"travel_xy"})
G0 X711.000 Y3098.000
(NCX {"action":77,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":77,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y3098.000 F3600.0
(NCX {"action":77,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":77,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X711.000 Y3098.000 F3600.0
(NCX {"action":77,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":77,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y3098.000 F3600.0
(NCX {"action":78,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":78,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y2117.000
(NCX {"action":79,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":79,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y2117.000 F3600.0
(NCX {"action":79,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":79,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y2117.000 F3600.0
(NCX {"action":79,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":79,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y2117.000 F3600.0
(NCX {"action":80,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":80,"mode":"low_clearance","role":"travel_xy"})
G0 X761.000 Y2117.000
(NCX {"action":81,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":81,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X761.000 Y1086.000 F3600.0
(NCX {"action":81,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":81,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X761.000 Y2117.000 F3600.0
(NCX {"action":81,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":81,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X761.000 Y1086.000 F3600.0
(NCX {"action":82,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":82,"mode":"low_clearance","role":"travel_xy"})
G0 X786.000 Y1086.000
(NCX {"action":83,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":83,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y5.000 F3600.0
(NCX {"action":83,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":83,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y1086.000 F3600.0
(NCX {"action":83,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":83,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y5.000 F3600.0
(NCX {"action":84,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":84,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y5.000
(NCX {"action":85,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":85,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1086.000 F3600.0
(NCX {"action":85,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":85,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":85,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":85,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1086.000 F3600.0
(NCX {"action":86,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":86,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y11314.000
(NCX {"action":87,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":87,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X386.000 Y11314.000 F3600.0
(NCX {"action":87,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":87,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y11314.000 F3600.0
(NCX {"action":87,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":87,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X386.000 Y11314.000 F3600.0
(NCX {"action":88,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":88,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X386.000 Y11920.000 F3600.0
(NCX {"action":88,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":88,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X386.000 Y11314.000 F3600.0
(NCX {"action":88,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":88,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X386.000 Y11920.000 F3600.0
(NCX {"action":89,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":89,"mode":"low_clearance","role":"travel_xy"})
G0 X536.000 Y12276.000
(NCX {"action":90,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":90,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X536.000 Y12582.000 F3600.0
(NCX {"action":90,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":90,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X536.000 Y12276.000 F3600.0
(NCX {"action":90,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":90,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X536.000 Y12582.000 F3600.0
(NCX {"action":91,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":91,"mode":"low_clearance","role":"travel_xy"})
G0 X536.000 Y12276.000
(NCX {"action":92,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":92,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y12276.000 F3600.0
(NCX {"action":92,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":92,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X536.000 Y12276.000 F3600.0
(NCX {"action":92,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":92,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y12276.000 F3600.0
(NCX {"action":93,"mode":"low_clearance_detour","role":"travel_z"})
G0 Z1.000
(NCX {"action":93,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X5.000 Y12279.000
(NCX {"action":94,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":94,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X5.000 Y12579.000
(NCX {"action":95,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":95,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X5.000 Y12582.000
(NCX {"action":96,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":96,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X389.000 Y12582.000
(NCX {"action":97,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":97,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X414.000 Y12582.000
(NCX {"action":98,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":98,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X489.000 Y12582.000
(NCX {"action":99,"mode":"low_clearance_detour","role":"travel_z"})
(NCX {"action":99,"mode":"low_clearance_detour","role":"travel_xy"})
G0 X536.000 Y12582.000
(NCX {"action":100,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":100,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X717.000 Y12582.000 F3600.0
(NCX {"action":100,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":100,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X536.000 Y12582.000 F3600.0
(NCX {"action":100,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":100,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X717.000 Y12582.000 F3600.0
(NCX {"action":101,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":101,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X717.000 Y13013.000 F3600.0
(NCX {"action":101,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":101,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X717.000 Y12582.000 F3600.0
(NCX {"action":101,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":101,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X717.000 Y13013.000 F3600.0
(NCX {"action":102,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":102,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X486.000 Y13013.000 F3600.0
(NCX {"action":102,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":102,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X717.000 Y13013.000 F3600.0
(NCX {"action":102,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":102,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X486.000 Y13013.000 F3600.0
(NCX {"action":103,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":103,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X486.000 Y12863.000 F3600.0
(NCX {"action":103,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":103,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X486.000 Y13013.000 F3600.0
(NCX {"action":103,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":103,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X486.000 Y12863.000 F3600.0
(NCX {"action":104,"mode":"safe_lift","role":"travel_z"})
G0 Z5.000
(NCX {"action":104,"mode":"safe_lift","role":"travel_xy"})
G0 X411.000 Y11289.000
(NCX {"action":105,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":105,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X792.000 Y11289.000 F3600.0
(NCX {"action":105,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":105,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X411.000 Y11289.000 F3600.0
(NCX {"action":105,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":105,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X792.000 Y11289.000 F3600.0
(NCX {"action":106,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":106,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X792.000 Y10683.000 F3600.0
(NCX {"action":106,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":106,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X792.000 Y11289.000 F3600.0
(NCX {"action":106,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":106,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X792.000 Y10683.000 F3600.0
(NCX {"action":107,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":107,"mode":"low_clearance","role":"travel_xy"})
G0 X436.000 Y10683.000
(NCX {"action":108,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":108,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X436.000 Y10002.000 F3600.0
(NCX {"action":108,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":108,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X436.000 Y10683.000 F3600.0
(NCX {"action":108,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":108,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X436.000 Y10002.000 F3600.0
(NCX {"action":109,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":109,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y10002.000 F3600.0
(NCX {"action":109,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":109,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X436.000 Y10002.000 F3600.0
(NCX {"action":109,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":109,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y10002.000 F3600.0
(NCX {"action":110,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":110,"mode":"low_clearance","role":"travel_xy"})
G0 X436.000 Y10002.000
(NCX {"action":111,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":111,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y10002.000 F3600.0
(NCX {"action":111,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":111,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X436.000 Y10002.000 F3600.0
(NCX {"action":111,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":111,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y10002.000 F3600.0
(NCX {"action":112,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":112,"mode":"low_clearance","role":"travel_xy"})
G0 X786.000 Y9546.000
(NCX {"action":113,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":113,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y9015.000 F3600.0
(NCX {"action":113,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":113,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y9546.000 F3600.0
(NCX {"action":113,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":113,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y9015.000 F3600.0
(NCX {"action":114,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":114,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X561.000 Y9015.000 F3600.0
(NCX {"action":114,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":114,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y9015.000 F3600.0
(NCX {"action":114,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":114,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X561.000 Y9015.000 F3600.0
(NCX {"action":-1,"mode":"return","role":"footer_z"})
G0 Z5.000
(NCX {"action":-1,"mode":"return","role":"return_xy"})
G0 X5.000 Y5.000
M5
M30
