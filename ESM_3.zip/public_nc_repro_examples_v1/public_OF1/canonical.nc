(Canonical controller-neutral NC for transparent kinematic evaluation)
(Stock XY: 1766.000 x 2765.000 mm)
(Geometrically compensated cutter centerlines; controller compensation off)
G21
G90
G17
G40
G0 Z5.000
T1 M6
M3 S18000
(NCX {"action":-1,"mode":"setup","role":"setup_xy"})
G0 X5.000 Y5.000
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y136.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":0,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y136.000 F3600.0
(NCX {"action":1,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":1,"mode":"low_clearance","role":"travel_xy"})
G0 X736.000 Y136.000
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y986.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y136.000 F3600.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":2,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y986.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y986.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y986.000 F3600.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":3,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y986.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1217.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y986.000 F3600.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":4,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1217.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y1217.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y1217.000 F3600.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":5,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y1217.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1067.000 Y1217.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y1217.000 F3600.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":6,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1067.000 Y1217.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1067.000 Y1623.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1067.000 Y1217.000 F3600.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":7,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1067.000 Y1623.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1067.000 Y1748.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1067.000 Y1623.000 F3600.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":8,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1067.000 Y1748.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1142.000 Y1748.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1067.000 Y1748.000 F3600.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":9,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1142.000 Y1748.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1373.000 Y1748.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1142.000 Y1748.000 F3600.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":10,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1373.000 Y1748.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1373.000 Y2654.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1373.000 Y1748.000 F3600.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":11,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1373.000 Y2654.000 F3600.0
(NCX {"action":12,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":12,"mode":"low_clearance","role":"travel_xy"})
G0 X1142.000 Y2229.000
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y2229.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1142.000 Y2229.000 F3600.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":13,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y2229.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y2104.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y2229.000 F3600.0
(NCX {"action":14,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":14,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y2104.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y1748.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y2104.000 F3600.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":15,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y1748.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1067.000 Y1748.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y1748.000 F3600.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":16,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1067.000 Y1748.000 F3600.0
(NCX {"action":17,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":17,"mode":"low_clearance","role":"travel_xy"})
G0 X1067.000 Y1623.000
(NCX {"action":18,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y1623.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1067.000 Y1623.000 F3600.0
(NCX {"action":18,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":18,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y1623.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y1598.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y1623.000 F3600.0
(NCX {"action":19,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":19,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y1598.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1598.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y1598.000 F3600.0
(NCX {"action":20,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":20,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1598.000 F3600.0
(NCX {"action":21,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":21,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y1748.000
(NCX {"action":22,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y2104.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y1748.000 F3600.0
(NCX {"action":22,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":22,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y2104.000 F3600.0
(NCX {"action":23,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":23,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y2654.000
(NCX {"action":24,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":24,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y2760.000 F3600.0
(NCX {"action":24,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":24,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y2654.000 F3600.0
(NCX {"action":24,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":24,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y2760.000 F3600.0
(NCX {"action":25,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":25,"mode":"low_clearance","role":"travel_xy"})
G0 X561.000 Y2760.000
(NCX {"action":26,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X561.000 Y2654.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X561.000 Y2760.000 F3600.0
(NCX {"action":26,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":26,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X561.000 Y2654.000 F3600.0
(NCX {"action":27,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":27,"mode":"low_clearance","role":"travel_xy"})
G0 X1373.000 Y1748.000
(NCX {"action":28,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1648.000 Y1748.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1373.000 Y1748.000 F3600.0
(NCX {"action":28,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":28,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1648.000 Y1748.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1648.000 Y1217.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1648.000 Y1748.000 F3600.0
(NCX {"action":29,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":29,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1648.000 Y1217.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1386.000 Y1217.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1648.000 Y1217.000 F3600.0
(NCX {"action":30,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":30,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1386.000 Y1217.000 F3600.0
(NCX {"action":31,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":31,"mode":"low_clearance","role":"travel_xy"})
G0 X1067.000 Y1217.000
(NCX {"action":32,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1386.000 Y1217.000 F3600.0
(NCX {"action":32,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1067.000 Y1217.000 F3600.0
(NCX {"action":32,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":32,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1386.000 Y1217.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1386.000 Y986.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1386.000 Y1217.000 F3600.0
(NCX {"action":33,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":33,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1386.000 Y986.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X967.000 Y986.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1386.000 Y986.000 F3600.0
(NCX {"action":34,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":34,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X967.000 Y986.000 F3600.0
(NCX {"action":35,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":35,"mode":"low_clearance","role":"travel_xy"})
G0 X736.000 Y986.000
(NCX {"action":36,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":36,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X967.000 Y986.000 F3600.0
(NCX {"action":36,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":36,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y986.000 F3600.0
(NCX {"action":36,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":36,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X967.000 Y986.000 F3600.0
(NCX {"action":37,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":37,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X967.000 Y5.000 F3600.0
(NCX {"action":37,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":37,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X967.000 Y986.000 F3600.0
(NCX {"action":37,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":37,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X967.000 Y5.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y5.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X967.000 Y5.000 F3600.0
(NCX {"action":38,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":38,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y5.000 F3600.0
(NCX {"action":39,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":39,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y136.000 F3600.0
(NCX {"action":39,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":39,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y5.000 F3600.0
(NCX {"action":39,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":39,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y136.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y136.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y136.000 F3600.0
(NCX {"action":40,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":40,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y136.000 F3600.0
(NCX {"action":41,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":41,"mode":"low_clearance","role":"travel_xy"})
G0 X736.000 Y5.000
(NCX {"action":42,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":42,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":42,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":42,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y5.000 F3600.0
(NCX {"action":42,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":42,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y5.000 F3600.0
(NCX {"action":43,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":43,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y1217.000
(NCX {"action":44,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":44,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1598.000 F3600.0
(NCX {"action":44,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":44,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y1217.000 F3600.0
(NCX {"action":44,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":44,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1598.000 F3600.0
(NCX {"action":45,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":45,"mode":"low_clearance","role":"travel_xy"})
G0 X786.000 Y1217.000
(NCX {"action":46,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":46,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X786.000 Y1598.000 F3600.0
(NCX {"action":46,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":46,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X786.000 Y1217.000 F3600.0
(NCX {"action":46,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":46,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X786.000 Y1598.000 F3600.0
(NCX {"action":47,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":47,"mode":"low_clearance","role":"travel_xy"})
G0 X736.000 Y1748.000
(NCX {"action":48,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":48,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y1748.000 F3600.0
(NCX {"action":48,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":48,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X736.000 Y1748.000 F3600.0
(NCX {"action":48,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":48,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y1748.000 F3600.0
(NCX {"action":49,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":49,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y2104.000
(NCX {"action":50,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":50,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X736.000 Y2104.000 F3600.0
(NCX {"action":50,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":50,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y2104.000 F3600.0
(NCX {"action":50,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":50,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X736.000 Y2104.000 F3600.0
(NCX {"action":51,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":51,"mode":"low_clearance","role":"travel_xy"})
G0 X1142.000 Y1748.000
(NCX {"action":52,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1142.000 Y2229.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1142.000 Y1748.000 F3600.0
(NCX {"action":52,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":52,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1142.000 Y2229.000 F3600.0
(NCX {"action":53,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":53,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1142.000 Y2654.000 F3600.0
(NCX {"action":53,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":53,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1142.000 Y2229.000 F3600.0
(NCX {"action":53,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":53,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1142.000 Y2654.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X1373.000 Y2654.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X1142.000 Y2654.000 F3600.0
(NCX {"action":54,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":54,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X1373.000 Y2654.000 F3600.0
(NCX {"action":55,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":55,"mode":"low_clearance","role":"travel_xy"})
G0 X561.000 Y2654.000
(NCX {"action":56,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X5.000 Y2654.000 F3600.0
(NCX {"action":56,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X561.000 Y2654.000 F3600.0
(NCX {"action":56,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":56,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X5.000 Y2654.000 F3600.0
(NCX {"action":57,"mode":"low_clearance","role":"travel_z"})
G0 Z1.000
(NCX {"action":57,"mode":"low_clearance","role":"travel_xy"})
G0 X5.000 Y2760.000
(NCX {"action":58,"mode":"cut","pass_index":1,"role":"cut_z"})
G1 Z-6.000 F800.0
(NCX {"action":58,"mode":"cut","pass_index":1,"role":"cut_xy"})
G1 X561.000 Y2760.000 F3600.0
(NCX {"action":58,"mode":"cut","pass_index":2,"role":"cut_z"})
G1 Z-12.000 F800.0
(NCX {"action":58,"mode":"cut","pass_index":2,"role":"cut_xy"})
G1 X5.000 Y2760.000 F3600.0
(NCX {"action":58,"mode":"cut","pass_index":3,"role":"cut_z"})
G1 Z-18.000 F800.0
(NCX {"action":58,"mode":"cut","pass_index":3,"role":"cut_xy"})
G1 X561.000 Y2760.000 F3600.0
(NCX {"action":-1,"mode":"return","role":"footer_z"})
G0 Z5.000
(NCX {"action":-1,"mode":"return","role":"return_xy"})
G0 X5.000 Y5.000
M5
M30
