# Holdout confirmatory analysis audit

- Analysis status: **passed**
- Independent factory tasks: 20
- Nested packing seeds per task: 3
- Boards: 11784
- Route-method rows: 58920
- Authorized route input: cache-isolated v2 only

## Confirmatory task-level results

| Baseline | Mean task reduction in C_plan | 95% task-bootstrap CI | W/T/L | Exact sign p | Holm p | Proposed/baseline positive support tasks |
|---|---:|---:|---:|---:|---:|---:|
| topology_process_aware | 10.253% | [9.907, 10.615] | 20/0/0 | 1.90735e-06 | 3.8147e-06 | 0/0 |
| endpoint_aware_gtsp | 6.741% | [6.225, 7.240] | 20/0/0 | 1.90735e-06 | 3.8147e-06 | 0/20 |

The bootstrap and sign test use the 20 factory tasks as the only
independent units. Boards and packing seeds are not counted as
independent replicates.
