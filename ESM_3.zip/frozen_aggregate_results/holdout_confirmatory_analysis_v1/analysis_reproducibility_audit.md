# Holdout analysis reproducibility audit

- Audit status: **passed**
- Authorized input: cache-isolated v2 only
- Quarantined v1 used: no
- Independent units: 20 factory tasks
- Nested packing seeds per task: 3
- Boards retained: 11,784
- Bootstrap replicates independently recomputed: 100,000
- All seven analysis CSV artifacts reproduced numerically
