# Track B factory-XML task-level analysis

- Analysis status: **passed**
- Fixed-coordinate Patterns: 2753
- Confirmatory independent tasks: 7
- Historical supplementary tasks: 4
- Patterns were summed within task; only tasks were analyzed independently.

## Confirmatory C_plan comparisons

| Baseline | Mean task reduction | 95% task-bootstrap CI | W/T/L | Exact sign p | Holm p | Positive-support tasks (proposed/baseline) |
|---|---:|---:|---:|---:|---:|---:|
| topology_process_aware | 9.979% | [9.577, 10.452] | 7/0/0 | 0.015625 | 0.03125 | 0/0 |
| endpoint_aware_gtsp | 7.085% | [6.529, 7.682] | 7/0/0 | 0.015625 | 0.03125 | 0/7 |

The four historical tasks are descriptive only and do not contribute
to the confirmatory sample size or p-values.
