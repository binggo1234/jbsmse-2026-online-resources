# Reproducibility snapshot

This reviewer-facing snapshot contains the routing implementation, public benchmark
inputs, holdout conversion/analysis code, frozen run manifests, and task-level or
aggregate analysis tables used by the manuscript.

The transparent NC-level snapshot includes the canonical post-processor, modal
parser, feed-capped continuous and stop-at-junction estimators, deterministic shard
merger, hard completion audits, task-level aggregate metrics, and publication-value
tables. Five complete 2DPackLib-derived examples expose public layout-to-route-to-NC
replay, parsed motions, semantic audits, and all 27 scenario results. Full board-level
NC databases and CSV exports are bound by the hashes in
the completion audit but excluded because they retain controlled factory identifiers
and are large.

The VERICUT case-selection folder records the prespecified size-stratified selection
rule and a 15-row anonymized manifest for five boards from five distinct holdout tasks.
It exposes geometry and NC hashes without disclosing original factory task identifiers.

Proprietary factory CSV/XML inputs and the full board-level route cache are deliberately
excluded. Factory task identifiers are consistently pseudonymized, and local absolute
paths are replaced by placeholders. The frozen Track A cache is bound by the SHA-256
identity recorded in the run manifest and submission audit. Reproduction with
proprietary inputs therefore requires controlled access from the corresponding author;
public-geometry checks can be run from the included public data.
