# VERICUT case-selection protocol

## Role and timing

This protocol documents the five factory-derived boards used for the auxiliary
VERICUT cross-check. Selection was completed before the VERICUT comparison
results were inspected. The commercial-simulator track is descriptive and does
not replace the prespecified 20-task all-board holdout.

## Candidate source

- Source cohort: the frozen 20-task factory holdout.
- Sampling unit: one packed board geometry.
- Required methods: proposed, process-aware topology, and ordinary
  process-aware beam.
- Required NC representation: the same canonical, controller-neutral
  post-processor used by the manuscript's transparent NC track.

## Selection rule

1. Boards were grouped by rectangle-count strata.
2. A prespecified quota produced five cases spanning 5, 7, 8, 12, and 19
   rectangles and five distinct holdout tasks.
3. Within the quota for each stratum, qualifying frozen geometries were ordered
   by SHA-256 geometry hash.
4. The first required hashes for which the three canonical NC programs were
   distinct were retained.
5. Route cost, comparison direction, effect magnitude, VERICUT time, collision
   output, and AUTO-DIFF output were not used for selection.

The distinct-program rule excludes cases that cannot provide a route-order
comparison because all compared methods emit the same program. It does not
select cases by whether the proposed method wins or by the size of a difference.

## Anonymization

The accompanying `selection_manifest_anonymized.csv` replaces factory task
identifiers with stable pseudonyms `FACTORY_TASK_010`, `FACTORY_TASK_006`,
`FACTORY_TASK_015`, `FACTORY_TASK_009`, and `FACTORY_TASK_023`. It retains the
case label, size stratum, packing seed, board ID within the task, rectangle
count, geometry hash, method, NC path, and NC hash needed to audit selection and
file identity. Original task identifiers and production geometry are withheld
for commercial confidentiality.

## Evidence boundary

The five boards are paired descriptive cases from five distinct tasks, not
random factory-task replicates. Deterministic reruns are not independent
replicates. The representative VERICUT model is not a production digital twin,
and its reported time is not a measured or controller-calibrated cycle time.
