# Cache-isolated holdout route experiment audit

- Audit status: **passed**
- Completed method tasks: 58920
- Unique job IDs: 58920
- Boards with all five methods: 11784
- Proposed atomic-span routes audited: 11784
- Missing atomic spans: 0
- Repeated atomic spans: 0
- Unknown cutting units: 0
- Atomic geometry failures: 0
- Quarantined-v1 replay mismatches: 1
- Proposed serialized hard failures: 0
- Proposed replay mismatches after isolation: 0
- Defect-route fresh replay match: True
- v1 jobs changed by cache isolation: 7

The v1 route result is quarantined from method comparisons. The isolated result
is the only route-level result authorized for subsequent task aggregation and
confirmatory analysis.
